#!/usr/bin/env python

import re
import sys
import os
from os.path import abspath, dirname, join
from setuptools import setup

PKGVERSION='1.4.6'
REQUIREMENTS=[]
REQUIREMENTS.append('KaizenBot-CommonLibrary>=1.4')
REQUIREMENTS.append('cx_Oracle==8.3.0')

CLASSIFIERS = '''
Development Status :: 5 - PRODUCTION/STABLE
License :: Itron
Intended Audience :: Automation Engineers
Operating System :: OS Independent
Programming Language :: Python
Topic :: Software Development :: Testing
Framework :: Robot Framework
Framework :: Robot Framework :: Library
'''.strip().splitlines()

setup(
	name='KaizenBot-Gen5RivaLibrary',
	version=PKGVERSION,
	description='Gen5RivaLibrary for testing Gen5 Riva meters',
	author='Gen5Riva Library Developers',
	author_email='Menaka.Rangaswamy@itron.com,Sirajdeen.Hameedkamsa@itron.com, Ayush.Goswami@itron.com,rajasekhar.inguva@itron.com',
	url='https://www.itron.com/',
	keywords='Gen5RivaLibrary Gen5 Riva meters',
	platforms='any',
	classifiers=CLASSIFIERS,
	install_requires=REQUIREMENTS,
    include_package_data=True,
	python_requires='>=3.6',
	packages=['kaizenbot']
)

