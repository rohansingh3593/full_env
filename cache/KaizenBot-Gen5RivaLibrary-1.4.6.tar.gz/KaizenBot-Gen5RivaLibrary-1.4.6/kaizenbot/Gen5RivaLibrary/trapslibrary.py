# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
  Author: Shweta Kaushik (keywords: get_trap_host, set_trap_host, clear_trap_host, 
          get_trap_port, set_trap_port, trap_force, get_trap_key, get_trap_stat, 
          delete trap key)
          Varun Kaundinya (keywords: get_trap_retry_conf, set_trap_retry_conf, 
          get_trap_limit, set_trap_limit, get_sec_threshold, set_sec_threshold)
"""

from kaizenbot.logging_robot import Loggers
import os, re
from kaizenbot.connection import Connection
from .nodelibrary import NodeLibrary
from .netmanagerlibrary import NetManagerLibrary

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class TrapsLibrary:
    def __init__(self):
        pass
    
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError

    
    def get_trap_host(self, node = None, secure_run = True):
        """This keyword gets the trap host receiver address for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=   |    =Node=      |                        =Comment=                          |
        | `Get Trap Host` | 0001:0045:0a26 | This will get trap host receiver address for given Node   |
        | `Get Trap Host` |                | This will get trap host receiver address for default Node |
         
        This returns ``trap host receiver address`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nm_trap host_get'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Trap Host Receiver Address")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Trap Host Address: )(.*)', output)
            if(match):
                trap_host_address = match.group(0)
                self._logger().debug('Trap Host Receiver Address: {}'.format(trap_host_address))
            else:
                self._logger().debug("Exception occurred while getting Trap Host Receiver Address: {}".format(output))
                raise Exception("Exception occurred while getting Trap Host Receiver Address: {}".format(output))
        return trap_host_address
    
    def set_trap_host(self, trap_server_address, node=None, secure_run = True):
        """This keyword sets the trap host receiver address for provided node.
        
        This takes 1 mandatory argument ``trap_server_address``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |      =Keyword=  | =Trap Server Address= |     =Node=     |                           =Comment=                          |
        | `Set Trap Host` |     abcd:0045:0a26    | 0001:0045:0a26 | This will set the trap host receiver address for given Node   |
        | `Set Trap Host` |     abcd:0045:0a26    |                | This will set the trap host receiver address for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Trap Host Receiver Address")
            command = net_mgr_and_node + ' nm_trap host_set ' + str(trap_server_address)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Trap Host Receiver Address failed: {}".format(output))
            raise Exception("Setting Trap Host Receiver Address failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Trap Host Receiver Address for Node '{}' failed.Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Trap Host Receiver Address for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
              
    def clear_trap_host(self, node=None, secure_run = True):
        """This keyword clears the trap host receiver address of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |      =Keyword=    |     =Node=     |                             =Comment=                           |
        | `Clear Trap Host` | 0001:0045:0a26 | This will clear the trap host receiver address for given Node   |
        | `Clear Trap Host` |                | This will clear the trap host receiver address for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Clearing the trap host receiver address")
            command = net_mgr_and_node + ' nm_trap host_clear'
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Clearing of trap host receiver address failed. Output is {]".format(output))
            raise Exception("Clearing of trap host receiver address failed. Output is {]".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Clearing Trap Host Receiver Address for Node '{}' failed.Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Clearing Trap Host Receiver Address for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def get_trap_port(self, node = None, secure_run = True):
        """This keyword gets the trap host receiver port for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=   |    =Node=      |                        =Comment=                       |
        | `Get Trap Port` | 0001:0045:0a26 | This will get trap host receiver port for given Node   |
        | `Get Trap Port` |                | This will get trap host receiver port for default Node |
         
        This returns ``trap host receiver port`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nm_trap port_get'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Trap Host Receiver Port")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Trap Host Port: )(.*)', output)
            if(match):
                trap_host_port = match.group(0)
                self._logger().debug('Trap Host Receiver Port: {}'.format(trap_host_port))
            else:
                self._logger().debug("Exception occurred while getting Trap Host Receiver Port: {}".format(output))
                raise Exception("Exception occurred while getting Trap Host Receiver Port: {}".format(output))
        return trap_host_port
    
    def set_trap_port(self, trap_host_number, node=None, secure_run = True):
        """This keyword sets the trap host receiver port for provided node.
        
        This takes 1 mandatory argument ``trap_host_number``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |      =Keyword=  | =Trap Host Number= |     =Node=     |                         =Comment=                          |
        | `Set Trap Port` |          675       | 0001:0045:0a26 | This will set the trap host receiver port for given Node   |
        | `Set Trap Port` |          430       |                | This will set the trap host receiver port for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Trap Host Receiver Port")
            command = net_mgr_and_node + ' nm_trap port_set ' + str(trap_host_number)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Trap Host Receiver Port failed: {}".format(output))
            raise Exception("Setting Trap Host Receiver Port failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Trap Host Receiver Port for Node '{}' failed.Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Trap Host Receiver Port for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def trap_force(self, force_trap_name, node=None, secure_run = True):
        """This keyword Force the named trap to be sent of provided node.
        
        This takes 1 mandatory argument ``force_trap_name``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |   =Keyword=  | =Force Trap Name= |     =Node=     |                         =Comment=                          |
        | `Trap Force` |   power_loss      | 0001:0045:0a26 | This will Force the named trap to be sent for given Node   |
        | `Trap Force` |   power_loss      |                | This will Force the named trap to be sent for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Force the named trap to be sent")
            command = net_mgr_and_node + ' nm_trap force ' + str(force_trap_name)
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Forcing the named trap to be sent failed. Output is {]".format(output))
            raise Exception("Forcing the named trap to be sent failed. Output is {]".format(output))
        else:
            return output
            
    def get_trap_key(self, node = None, secure_run = True):
        """This keyword gets the trap host receiver IP address and secure_port for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=  |    =Node=      |                                  =Comment=                                   |
        | `Get Trap Key` | 0001:0045:0a26 | This will get trap host receiver IP address and secure_port for given Node   |
        | `Get Trap Key` |                | This will get trap host receiver IP address and secure_port for default Node |
         
        This returns ``the trap host receiver IP address and secure_port`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nm_trap key_get'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Trap Host Key")
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while getting Trap Host key: {}".format(output))
        else:
            self._logger().debug(type(output))
            if 'Not set' in output:
                return output
            else:
                index_of_port=output.index('Trap Host Port')
                self._logger().debug(index_of_port)
                new_output = output[index_of_port:]
                self._logger().info(new_output)
                if new_output == '' or new_output == None:
                    return "Null: No key present"
                else:
                    return new_output
            
    def get_trap_stat(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the SSN Trap Statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        trap statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |     =Keyword=   | =Only Header= |                       =Filter=                   |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Get Trap Stat` |    False      | filter=Traps rate limited AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Get Trap Stat` |    True       | filter=Traps sent securely                       | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Get Trap Stat` |    True       |                                                  | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Get Trap Stat` |    False      |                                                  |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting SSN Trap Statistics data from net manager")
            command = net_mgr_and_node + ' stat nm_trap' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='SSN Trap Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= NetManagerLibrary._convert_stat_output_in_list(self, output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= NetManagerLibrary._convert_stat_output_in_list(self, output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= NetManagerLibrary._convert_stat_output_in_list(self, output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
    
    def delete_trap_key(self, node=None, secure_run = True):
        """This keyword deletes the trap receiver's public key and disable secure traps for provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |      =Keyword=    |     =Node=     |                                         =Comment=                                          |
        | `Delete Trap Key` | 0001:0045:0a26 | This will deletes the trap receiver's public key and disable secure traps for given Node   |
        | `Delete Trap Key` |                | This will deletes the trap receiver's public key and disable secure traps for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Deleting the trap receiver's public key and disable secure traps")
            command = net_mgr_and_node + ' nm_trap key_del'
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Deleting the trap receiver's public key and disable secure traps failed. Output is {]".format(output))
            raise Exception("Deleting the trap receiver's public key and disable secure traps failed. Output is {]".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Deleting the trap receiver's public key and disable secure traps for Node '{}' failed.Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Deleting the trap receiver's public key and disable secure traps for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
       
    def get_trap_retry_conf(self, node = None, secure_run = True):           
        """This keyword gets the trap retry configuration values for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=         |       =Node=   |                        =Comment=               |
        | `Get Trap Retry Conf` | 0001:0045:0a26 | This will get trap retry conf for given Node   |
        | `Get Trap Retry Conf` |                | This will get trap retry conf for default Node |
         
        This returns ``trap retry configuration`` on success.
        
        Retry Configuration values would be read as below:
        Example: 3:100:200  - 3 retries, 100 is average second retry delay, 200 is average third retry delay
        """
        node = node or self.get_current_node()  
        if (not(node)):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' nm_trap_retry_conf read'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Trap Retry Configuration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Trap settings )(.*)', output)
            if(match):
                trap_retry_conf = match.group(0)
                self._logger().info('Trap Retry Settings {}'.format(trap_retry_conf))
                return trap_retry_conf
            else:
                self._logger().debug("Exception occurred while getting Trap Retry Configuration {}".format(output))
                raise Exception("Exception occurred while getting Trap Retry Configuration {}".format(output))
              
    def set_trap_retry_conf(self, retry_conf, node = None, secure_run = True):
        """This keyword sets the trap retry configuration for the provided node.
        
        This takes 1 mandatory argument - ``retry_conf``
        
        This takes 1 optional argument ``node``.
        
        ``retry_conf`` follows the structure: noOfDelays:delay1:delay2:..:delay(n-1) 
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails. 
      
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
            = Examples =
        |      =Keyword=            | =Trap Retry Conf= |     =Node=     |                           =Comment=                  |
        | `Set Trap Retry Conf`     |     3:100:200     | 0001:0045:0a26 | This will set the trap retry conf for given Node     |
        | `Set Trap Retry Conf`     |  4:100:200:300    |                | This will set the trap retry conf for default Node   |

        This returns ``Ok`` on success

        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        
            command = net_mgr_and_node + ' nm_trap_retry_conf ' + str(retry_conf)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Setting Trap Retry Configuration as {}".format(retry_conf))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Trap Retry Configuration for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Trap Host Retry Configuration for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'

    def get_trap_limit(self, trap_id, node = None, secure_run = True):
        """This keyword gets the trap limits for the provided node.
        
        This takes one mandatory argument ``trap_id``
        
        This takes 1 optional argument ``node``.
                
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        ``trap_id`` is either the trap_id for that particular trap or "all" for all ids.
            
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=     | =Trap_id= |     =Node=     |                           =Comment=                  |
        | `Get Trap Limit`  |    1321   | 0001:0045:0a26 | This will get the trap limit for given Node          |
        | `Get Trap Limit`  |     all   |                | This will get all the trap limit for default Node    |
          
        This returns ``trap limit`` on success. If trap id is all, returns a list of all the limits, else returns a string
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            all_flag = 0
            if ("all" == str(trap_id)):         
                all_flag = 1
            command = net_mgr_and_node + ' nm_trap limit ' + str(trap_id) 
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting Trap Limit for trap_id {}'.format(trap_id))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if (1 == all_flag):
                match = re.findall(r'(?<=Trap: )(.*)', output)
            else:
                match = re.search(r'(?<=limited to: )(.*)', output)
            if(match):
                if (1 == all_flag):
                    trap_limit = []
                    for ele in match:
                        trap_limit.append(re.split(': ', ele))
                else:
                    trap_limit = match.group(0).split(' ')[0]
                self._logger().debug('Trap Limits {}'.format(trap_limit))
                return trap_limit
            else:
                self._logger().debug("Exception occurred while getting Trap Retry Configuration {}".format(output))
                raise Exception("Exception occurred while getting Trap Retry Configuration {}".format(output))
            
    def set_trap_limit(self, trap_id, trap_limit, node = None, secure_run = True):
        """This keyword sets the trap limits for the provided node.
        
        This takes 2 mandatory arguments ``trap_id`` and ``trap_limit``
        
        This takes 1 optional argument ``node``.
        
        ``trap_id`` is either the trap_id for that particular trap or "all" for all ids.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=     | =Trap Id= | =Trap_limit=  |     =Node=     |                           =Comment=                          |
        | `Set Trap Limit`  |    1321   | 20000         | 0001:0045:0a26 | This will set the trap limit as 2000 for 1321 for given Node |
        | `Set Trap Limit`  |     all   | 50            |                | This will set 50 trap limit for all traps for default Node   |
          
        
        This returns ``Ok`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            all_flag = 0
            if ("all" == str(trap_id)):
              all_flag = 1
            command = net_mgr_and_node + ' nm_trap limit ' + str(trap_id) + ' ' + str(trap_limit)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting Trap Limit for trap_id {} as limit {}'.format(trap_id, trap_limit))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Trap Limit for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Trap Limit for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
              
    def get_sec_threshold (self, input_values, data,  node = None, secure_run = True):
        """This keyword gets the security threshold configurations for the provided node.
        
        This takes 2 mandatory arguments ``input_values`` and ``data``
        
        
        This takes 1 optional argument ``node``.
        
        ``input_values`` follow space separated values for each security threshold parameter
            CERT_AUTH_FAIL             = 1,
            ASSOC_INVALID_CERT_CHAIN   = 2,
            ASSOC_MISC_FAIL            = 3,
            ASSOC_AUTH_FAIL            = 4,
            NM_AUTH_FAIL               = 5,
            CERT_POLICY_FAIL           = 6,
            AUTH_FAIL_ASSOC            = 7,
            DNS_TSIG_ERR_BADKEY        = 8,
            DNS_TSIG_ERR_BADSIG        = 9,
            DTLS_HANDSHAKE_FAILED      = 10,
            DTLS_RX_MISC_ERRORS        = 11,
            NM_WRITE_FAIL              = 12,
            NM_POLICY_FAIL             = 13,
            MSS_KEY_BAD                = 129,
            MSS_KEY_BAD_SIGNATURE      = 130,
            MSS_KEY_CERT_MISSING       = 131,
            MSS_KEY_SIGNATURE_MISMATCH = 132,
            MSS_CERT_INVALID           = 133,
            MSS_SEQ_RENEGOTIATED       = 134,
            MSS_CERT_BAD               = 135,
            MSFS_MAINT_BAD_CERT        = 136,
            MSFS_MAINT_BAD_SIGNATURE   = 137
            MSS_DROP_BAD_NEIGHBOUR     = 138
            MLME_SEC_REJECT            = 139    
            
        ``data`` is either ``value`` or ``period`` or ``threshold`` or ``all``
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=       | =input_values= |  =data= |     =Node=     |                           =Comment=                                                |
        | `Get Sec Threshold` |    2           | period  | 0001:0045:0a26 | This will get the security thresholds for period parameter 2 for given Node        |
        | `Get Sec Threshold` |    2 3 4       | all     |                | This will get the security thresholds for all parameters 2, 3, 4 for default Node  |
         
        This returns ``sec_threshold_list`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' sec_thresholds get ' + str(input_values) 
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting Security Thresholds for {}'.format(input_values))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            valuelist = []
            periodlist = []
            thresholdlist = []
            sec_threshold_list = []
            output_lines = re.split('\n', output)
            if ("all" == data):
                for line in output_lines:
                    matrix = re.split(' +', line.strip())
                    if (matrix):
                        if ('' != matrix[0]):
                            if (("statistics" == matrix[1]) | ("Statistic" == matrix[1])):
                                continue
                            sec_threshold_list.append([matrix[1], matrix[2], matrix[3], matrix[4]])
            else:
                for line in output_lines:
                    matrix = re.split(' +', line.strip())
                    if (matrix[0]):
                        if (("statistics" == matrix[1]) | ("Statistic" == matrix[1])):
                            continue
                        if ("value" == data):
                            valuelist.append(matrix[2])
                            sec_threshold_list = valuelist
                        if ("threshold" == data):
                            thresholdlist.append(matrix[3])
                            sec_threshold_list = thresholdlist
                        if ("period" == data):
                            periodlist.append(matrix[4])
                            sec_threshold_list = periodlist
            if (sec_threshold_list):
                self._logger().info('Security Thresholds {}'.format(sec_threshold_list))
                return sec_threshold_list
            else:
                self._logger().debug("Exception occurred while getting Security Thresholds {}".format(output))
                raise Exception("Exception occurred while getting Security Thresholds {}".format(output))
            
    def set_sec_threshold (self, sec_item, threshold, period, node = None, secure_run = True):
        """This keyword sets the security threshold configuration for the provided node.
        
        This takes 3 mandatory argument - ``sec_item``,``threshold``, ``period``
        
        This takes 1 optional argument ``node``.
         
        ``sec_item`` will be one of 
            CERT_AUTH_FAIL             = 1,
            ASSOC_INVALID_CERT_CHAIN   = 2,
            ASSOC_MISC_FAIL            = 3,
            ASSOC_AUTH_FAIL            = 4,
            NM_AUTH_FAIL               = 5,
            CERT_POLICY_FAIL           = 6,
            AUTH_FAIL_ASSOC            = 7,
            DNS_TSIG_ERR_BADKEY        = 8,
            DNS_TSIG_ERR_BADSIG        = 9,
            DTLS_HANDSHAKE_FAILED      = 10,
            DTLS_RX_MISC_ERRORS        = 11,
            NM_WRITE_FAIL              = 12,
            NM_POLICY_FAIL             = 13,
            MSS_KEY_BAD                = 129,
            MSS_KEY_BAD_SIGNATURE      = 130,
            MSS_KEY_CERT_MISSING       = 131,
            MSS_KEY_SIGNATURE_MISMATCH = 132,
            MSS_CERT_INVALID           = 133,
            MSS_SEQ_RENEGOTIATED       = 134,
            MSS_CERT_BAD               = 135,
            MSFS_MAINT_BAD_CERT        = 136,
            MSFS_MAINT_BAD_SIGNATURE   = 137
            MSS_DROP_BAD_NEIGHBOUR     = 138
            MLME_SEC_REJECT            = 139
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        = Examples =
        |      =Keyword=            | =sec_item= | =threshold=  | =period=  |     =Node=        |                           =Comment=                   |
        | `Set Sec Threshold`       |  2         |  8           |   86400   | 0001:0045:0a26    | This will set the trap retry conf for given Node  |
        | `Set Sec Threshold`       |  1         |  5           |   86400   |                   | This will set the trap retry conf for default Node    |
        
        This returns ``Ok`` on success
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' sec_thresholds set ' + str(sec_item) + ' ' + str(threshold) + ' ' + str(period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting Security Thresholds for {}'.format(sec_item))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Security Thresholds for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Security Thresholds for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            