# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
Author: Banoth Saikumar
"""
import re, os, time
from kaizenbot.connection import Connection
from kaizenbot.logging_robot import Loggers
from kaizenbot.exceptions import NotATableError, MACNotFoundError
from .netmanagerlibrary import NetManagerLibrary

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

netmgrlib = NetManagerLibrary()
            
class TimeSpectrumLibrary:

    def __init__(self):
        pass  
    
    def _logger(self):
        raise NotImplementedError

    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError        
    
           
    def set_ts_refresh_itvl(self, ts_refresh_itvl, node = None, secure_run = True):
        """This keyword sets the ts_refresh_itvl of provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``ts_refresh_itvl``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |     =Keyword=          | =ts_refresh_itvl= |  =node=        |                            =Comment=                    |
        | `Set Ts Refresh Itvl`  |   20              | 0013:0000:0034 | This will set provided ts_refresh_itvl for given Node   |
        | `Set Ts Refresh Itvl`  |   16              |                | This will set provided ts_refresh_itvl for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            TsRefreshItvl = int(ts_refresh_itvl)
        except ValueError:
            self._logger().exception("Timesync refresh interval must be either integer or string-convertible-to-integer")
            raise Exception("Timesync refresh interval must be either integer or string-convertible-to-integer")
         
        if (not (TsRefreshItvl >= 0) ):
            self._logger().debug("Invalid Timesync refresh interval. Timesync refresh interval must be greater than 0")
            raise Exception("Invalid Timesync refresh interval. Timesync refresh interval must be greater than 0") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Timesync refresh interval")
            command = net_mgr_and_node + ' conf timesync ts_refresh_itvl ' + str(TsRefreshItvl)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Timesync refresh interval failed: {}".format(e))
            raise Exception("Setting Timesync refresh interval failed: {}".format(e))
        return output
        
    def get_ts_refresh_itvl(self, node = None, secure_run = True):
        """This keyword gets the ts_refresh_itvl of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Time sync refresh interval`` in seconds on success.

        = Examples =
        |     =Keyword=          |   =node=       |                  =Comment=                     |
        | `Get Ts Refresh Itvl`  | 0013:0000:0034 | This will get ts_refresh_itvl for given Node   |
        | `Get Ts Refresh Itvl`  |                | This will get ts_refresh_itvl for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Getting Timesync refresh interval")
            command = net_mgr_and_node + ' conf timesync ts_refresh_itvl | awk ' + "'" + '{print $8}' + "'"
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Timesync refresh interval failed: {}".format(e))
            raise Exception("Getting Timesync refresh interval failed: {}".format(e))
        return output
        
    def set_ts_resync_itvl(self, ts_resync_itvl, node = None, secure_run = True):
        """This keyword sets the Timesync resync interval of provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``ts_resync_itvl`` .
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=          | =ts_resync_itvl=    |  =node=        |                            =Comment=                             |
        | `Set Ts Resync Itvl`  |   20                | 0013:0000:0034 | This will set provided ts_resync_itvl for given Node   |
        | `Set Ts Resync Itvl`  |   16                |                | This will set provided ts_resync_itvl for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            TsResyncItvl = int(ts_resync_itvl)
        except ValueError:
            self._logger().exception("Timesync resync interval must be either integer or string-convertible-to-integer")
            raise Exception("Timesync resync interval must be either integer or string-convertible-to-integer")
         
        if (not (TsResyncItvl >= 0) ):
            self._logger().debug("Invalid Timesync resync interval. Timesync resync interval must be greater than 0")
            raise Exception("Invalid Timesync resync interval. Timesync resync interval must be greater than 0") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Timesync resync interval")
            command = net_mgr_and_node + ' conf timesync ts_resync_itvl ' + str(TsResyncItvl)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Timesync resync interval failed:{}".format(e))
            raise Exception("Setting Timesync resync interval failed:{}".format(e))
        return output
    
    def get_ts_resync_itvl(self, node = None, secure_run = True):
        """This keyword gets the ts_resync_itvl of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Resync retry interval`` in seconds on success.

        = Examples =
        |    =Keyword=          |  =node=      |                            =Comment=            |
        | `Get Ts Resync Itvl`  | 0013:0000:0034 | This will get ts_resync_itvl for given Node   |
        | `Get Ts Resync Itvl`  |                | This will get ts_resync_itvl for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Getting Timesync resync interval")
            command = net_mgr_and_node + ' conf timesync ts_resync_itvl | awk ' + "'" + '{print $7}' + "'"
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Timesync resync interval failed:{}".format(e))
            raise Exception("Getting Timesync resync interval failed:{}".format(e))
        return output
    
    def set_ts_accuracy_req(self, ts_accuracy_req, node = None, secure_run = True):
        """This keyword sets the ts_accuracy_req of provided node
        
        This takes 1 optional argument ``node``.
         
        This takes 1 mandatory argument ``ts_accuracy_req`` . 
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |     =Keyword=          | =ts_accuracy_req= |  =node=        |                            =Comment=                    |
        | `Set Ts Accuracy Req`  |   200             | 0013:0000:0034 | This will set provided ts_accuracy_req for given Node   |
        | `Set Ts Accuracy Req`  |   385             |                | This will set provided ts_accuracy_req for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            TsAccuracyReq = int(ts_accuracy_req)
        except ValueError:
            self._logger().exception("Timesync Accuracy Requirement must be either integer or string-convertible-to-integer")
            raise Exception("Timesync Accuracy Requirement must be either integer or string-convertible-to-integer")
         
        if (not (TsAccuracyReq >= 0) ):
            self._logger().debug("Invalid Timesync Accuracy Requirement. Timesync Accuracy Requirement must be greater than 0")
            raise Exception("Invalid Timesync Accuracy Requirement. Timesync Accuracy Requirement must be greater than 0") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Timesync Accuracy Requirement")
            command = net_mgr_and_node + ' conf timesync ts_accuracy_req ' + str(TsAccuracyReq)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Timesync Accuracy Requirement failed:{}".format(e))
            raise Exception("Setting Timesync Accuracy Requirement failed:{}".format(e))
        return output
    
    def get_ts_accuracy_req(self, node = None, secure_run = True):
        """This keyword gets the ts_accuracy_req of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Time sync accuracy requirement`` in seconds on success.

        = Examples =
        |     =Keyword=          |  =node=        |                            =Comment=           |
        | `Get Ts Accuracy Req`  | 0013:0000:0034 | This will get ts_accuracy_req for given Node   |
        | `Get Ts Accuracy Req`  |                | This will get ts_accuracy_req for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
         
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Timesync Accuracy Requirement")
            command = net_mgr_and_node + ' conf timesync ts_accuracy_req | awk ' + "'" + '{print $8}' + "'"
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Timesync Accuracy Requirement failed:{}".format(e))
            raise Exception("Getting Timesync Accuracy Requirement failed:{}".format(e))
        return output
    
    def set_ts_time_lost_limit(self, ts_time_lost_limit, node = None, secure_run = True):
        """This keyword sets the ts_time_lost_limit  of provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``ts_time_lost_limit`` .
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |        =Keyword=          | =ts_time_lost_limit = |  =node=        |                            =Comment=                        |
        | `Set Ts Time Lost Limit`  |   200                 | 0013:0000:0034 | This will set provided ts_time_lost_limit  for given Node   |
        | `Set Ts Time Lost Limit`  |   385                 |                | This will set provided ts_time_lost_limit  for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            TsTimeLostLimit = int(ts_time_lost_limit)
        except ValueError:
            self._logger().exception("Timesync Time Lost Limit must be either integer or string-convertible-to-integer")
            raise Exception("Timesync Time Lost Limit must be either integer or string-convertible-to-integer")
         
        if (not (TsTimeLostLimit >= 0) ):
            self._logger().debug("Invalid Timesync Time Lost Limit. Timesync Time Lost Limit must be greater than 0")
            raise Exception("Invalid Timesync Time Lost Limit. Timesync Time Lost Limit must be greater than 0") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Timesync Time Lost Limit")
            command = net_mgr_and_node + ' conf timesync ts_time_lost_limit ' + str(TsTimeLostLimit)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Timesync Time Lost Limit failed:{}".format(e))
            raise Exception("Setting Timesync Time Lost Limit failed:{}".format(e))
        return output
    
    def get_ts_time_lost_limit(self, node = None, secure_run = True):
        """This keyword gets the ts_time_lost_limit  of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Time Lost limit`` in seconds on success.

        = Examples =
        |        =Keyword=          |  =node=        |                            =Comment=               |
        | `Get Ts Time Lost Limit`  | 0013:0000:0034 | This will get ts_time_lost_limit  for given Node   |
        | `Get Ts Time Lost Limit`  |                | This will get ts_time_lost_limit  for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Getting Timesync Time Lost Limit")
            command = net_mgr_and_node + ' conf timesync ts_time_lost_limit | awk ' + "'" + '{print $13}' + "'"
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Timesync Time Lost Limit failed:{}".format(e))
            raise Exception("Getting Timesync Time Lost Limit failed:{}".format(e))
        return output
    
    def set_ts_req_short_itvl(self, ts_req_short_itvl, node = None, secure_run = True):
        """This keyword sets the ts_req_short_itvl  of provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``ts_req_short_itvl`` .
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |       =Keyword=          | =ts_req_short_itvl= |  =node=        |                            =Comment=                       |
        | `Set Ts Req Short Itvl`  |   200               | 0013:0000:0034 | This will set provided ts_req_short_itvl  for given Node   |
        | `Set Ts Req Short Itvl`  |   385               |                | This will set provided ts_req_short_itvl  for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            TsReqShortItvl = int(ts_req_short_itvl)
        except ValueError:
            self._logger().exception("Timesync Short Interval must be either integer or string-convertible-to-integer")
            raise Exception("Timesync Short Interval must be either integer or string-convertible-to-integer")
         
        if (not (TsReqShortItvl >= 0) ):
            self._logger().debug("Invalid Timesync Short Interval. Timesync Short Interval must be greater than 0")
            raise Exception("Invalid Timesync Short Interval. Timesync Short Interval must be greater than 0") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Timesync Short Interval")
            command = net_mgr_and_node + ' conf timesync ts_req_short_itvl ' + str(TsReqShortItvl)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Timesync Short Interval failed: {}".format(e))
            raise Exception("Setting Timesync Short Interval failed: {}".format(e))
        return output
        
    def get_ts_req_short_itvl(self, node = None, secure_run = True):
        """This keyword gets the Timesync Short Interval  of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Time sync request short interval``in seconds on success.

        = Examples =
        |       =Keyword=          |  =node=        |                            =Comment=              |
        | `Get Ts Req Short Itvl`  | 0013:0000:0034 | This will get ts_req_short_itvl  for given Node   |
        | `Get Ts Req Short Itvl`  |                | This will get ts_req_short_itvl  for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Getting Timesync Short Interval")
            command = net_mgr_and_node + ' conf timesync ts_req_short_itvl | awk ' + "'" + '{print $9}' + "'"
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Timesync Short Interval failed: {}".format(e))
            raise Exception("Getting Timesync Short Interval failed: {}".format(e))
        return output
        
    def force_timesync(self, peer_mac, node = None, secure_run = True):
        """This keyword is used to force timesync of provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``peer_mac`` .
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        | =Keyword=        | =peer_mac=            |  =node=        |                            =Comment=           |
        | `Force Timesync` | 00:12:23:34:45:56:78  | 0013:0000:0034 | This will send force timesync for given Node   |
        | `Force Timesync` | 00:12:23:34:45:56:78  |                | This will send force timesync for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Running Force Timesync")
            command = net_mgr_and_node + ' time force ' + str(peer_mac)
            
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Running force timesync failed: {}".format(e))
            raise Exception("Running force timesync failed: {}".format(e))
        return output
    
    def verify_spectrum_analysis_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the Spectrum_Analysis Statistics of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=                   | =Only Header= |                  =Filter= |  =node=        |  =ignore_case= |                                =Comment=                                  |
        | `Verify Spectrum_Analysis Statistics` |    False      | filter=passive sessions   | 0013:0000:0034 |      True      | This will verify provided list for filtered data for given Node           |
        | `Verify Spectrum_Analysis Statistics` |    True       | filter=passive sessions   | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Spectrum_Analysis Statistics` |    True       |                           | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Spectrum_Analysis Statistics` |    False      |                           |                |                | This will verify provided list of data with numbers for default Node      |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting Spectrum Analysis Statistics data from net manager")
            command = net_mgr_and_node + ' spectrum_analysis read:stats' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='Spectrum_Analysis Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= NetManagerLibrary._convert_stat_output_in_list(self, output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= NetManagerLibrary._convert_stat_output_in_list(self, output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= NetManagerLibrary._convert_stat_output_in_list(self, output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
                
    
    
    def spectrum_analysis_run(self, parameter, node = None, secure_run = True):
        """This keyword runs Spectrum_Analysis on provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``parameter`` .
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |           =Keyword=     |   =parameter=                                                             |  =node=        |               =Comment=                   |
        | `Spectrum Analysis Run` | parameter=sweeps:2 AND samples:2                                          | 0013:0000:0034 | This will RUN Passive Spectrum Analysis   |
        | `Spectrum Analysis Run` | parameter=sweeps:2 AND samples:2 AND pktsize:16 AND mac:0011223344556677  | 0013:0000:0034 | This will RUN Active Spectrum Analysis    |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        filter_cmd=''
        if(parameter is None):
            self._logger().debug("No parameter provided by User to execute command")
            raise Exception("No parameter provided by User to execute command")
            
        if(parameter is not None):
            filter_strs = parameter.split(' AND ')
            for filter_str in filter_strs:
                filter_cmd += filter_str + ' '    
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Running Spectrum_Analysis from net manager")
            command = net_mgr_and_node + ' spectrum_analysis ' + filter_cmd
            output = Connection.execute_command(self, command)
            
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Running Spectrum_Analysis from net manager failed: {}".format(e))
            raise Exception("Running Spectrum_Analysis from net manager failed: {}".format(e))
        return output
        
    def spectrum_analysis_read_state(self, node = None, secure_run = True):
        """This keyword reads Spectrum_Analysis state of provided node
        
        This takes 1 optional arguments ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Spectrum Analysis State`` on success.

        = Examples =
        |           =Keyword=            |   =node=        |                                 =Comment=                       |
        | `Spectrum Analysis Read State` |  0013:0000:0034 |  This will read the state of Spectrum_Analysis for given node   |
        | `Spectrum Analysis Read State` |  0013:0000:0034 |  This will read the state of Spectrum_Analysis for given node   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
            
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting Spectrum Analysis Read State from net manager")
            command = net_mgr_and_node + ' spectrum_analysis read:state | awk ' + "'" + '{print $4}' + "'"
            output = Connection.execute_command(self, command)
            
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Spectrum Analysis Read State from net manager failed: {}".format(e))
            raise Exception("Getting Spectrum Analysis Read State data from net manager failed: {}".format(e))
        return output
        
    def spectrum_analysis_clear(self, node = None, secure_run = True):
        """This keyword clear Spectrum_Analysis state of provided node
        
        This takes 1 optional arguments ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ```` on success.

        = Examples =
        |           =Keyword=       |   =node=        |                                 =Comment=                     |
        | `Spectrum Analysis Clear` |  0013:0000:0034 |  This will clear the Spectrum_Analysis stats for given Node   |
        | `Spectrum Analysis Clear` |  0013:0000:0034 |  This will clear the Spectrum_Analysis stats for given Node   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
            
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Running Spectrum Analysis Clear from net manager")
            command = net_mgr_and_node + ' spectrum_analysis read:clear'
            output = Connection.execute_command(self, command)
            
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Running Spectrum Analysis Clear from net manager failed: {}".format(e))
            raise Exception("Running Spectrum Analysis Clear from net manager failed: {}".format(e))
        return output