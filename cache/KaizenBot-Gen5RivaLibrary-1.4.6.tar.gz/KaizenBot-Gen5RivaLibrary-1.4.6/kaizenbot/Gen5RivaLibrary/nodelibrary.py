# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from kaizenbot.logging_robot import Loggers
import os
from kaizenbot.connection import Connection
import re
from pytz import all_timezones, timezone
from datetime import datetime
from kaizenbot.exceptions import NotATableError, NotADictionaryError

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class NodeLibrary:
    
    def __init__(self, node = None):
        self.current_node = node
             
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError

    def set_node(self, node):
        """This keyword sets the current node to ``node``.
        
        If the keyword is used in suite setups then ``node`` will be available for all the keywords.
        
        if keyword is used in a test case,``node`` will be available for all subsequent keywords of the test case and 
        for all the keywords of the subsequent test cases.
        
        = Example =
        | = keyword = | = node =     |
        | `Set Node`  | 10.21.00.124 |
        """
        self.current_node = node

    def verify_node_is_registered(self, node = None, secure_run = True, via_gwncc=False):
        """
        This checks whether node is registered with AP or not.
        
        This takes 1 optional argument ``node``. 
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        A true value to ``via_gwncc`` enables the ``-g`` option of net mgr and command is sent via gwncc deamon. 
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        
        This returns ``Ok`` (case sensitive) on success.
        
        The most suitable use of this keyword is in test setups.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try: 
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node 
            
            g_option = '-g ' if via_gwncc else ''
            command = net_mgr_and_node + g_option + ' echo 1'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Verification for node register could not complete: {}".format(e))
            raise Exception("Verification for node register could not complete: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Node '{}' is not registered".format(node))
                self._logger().info(output)
                raise Exception("Node '{}' is not registered. Output is {}".format(node, output))
            else:
                return 'Ok'
         
    def reboot(self, type, node = None, secure_run = True):
        """
        This restarts the node.
        
        This takes 2 arguments: ``type`` and ``node`` (``node`` is optional).
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
              
        User can specify type of the reboot in ``type``.
        ``type`` must contain either of ``now``, ``in`` or ``at`` type. 
        If ``type`` contains more than 1 type, the order that will be taken into consideration is ``now``, ``in`` then ``at``.
        
        | `Reboot` | in 5 now | # now has preference, immediately restarts node |
        | `Reboot` | now in 5 | # now has preference, immediately restarts node |
        
        If ``type`` contains a type more than 1 time, the last one will overwrite the earlier ones. 
        
        | `Reboot` | in 5 in 10 | # will restart node in 10 minutes | 
        
        A full time string must be provided with type ``at``. 
        
        | `Reboot` | at mm:dd:yyyy:hr:min tz | # restarts at the specified time with timezone tz: eg US/Pacific |
        
        Where Month: 01-12, day: 01-31, hr: 0-23 min: 00-59
        
        Examples:
        
        | `Reboot`    | now                     |                | # immediately restarts node. Node must be provided at library import        |
        | `Reboot`    | now                     | 10.10.10.10    | # immediately restarts node 10.10.10.10                                     |
        | `Reboot`    | in 5 with gasp          |                | # will restart node in 5 ``minutes``. Gasp is sent before restart           |
        | `Reboot`    | now with gasp wait 180  |                | # waits for 180 ``seconds`` after gasp is sent and before node is restarted |
        
        Time units are predefined (i.e. for time to reboot: minutes and for wait after gasp: seconds) and does not affect if provided. 
        Following examples are similar that restarts the node in 5 minutes and no gasp is sent:
        
        | `Reboot` | in 5         |                                 |
        | `Reboot` | in 5 minutes |                                 |
        | `Reboot` | in 5 seconds | # no impact of ``seconds`` here |
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        This returns ``Ok`` (case-sensitive) on success.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        type_ = type.lower()
        gasp = ''
        gencore = ''
        wait = ''
        time = ''
        if('gasp' in type_):
            gasp = 'gasp '
            if( 'wait' in type_):
                match = re.findall(r'(?<=wait )\d+', type_)
                if(len(match) > 0):
                    wait = 'wait ' + match[-1] + ' '
        elif('gencore' in type_):
            gencore = 'gencore '
            
        if('now' in  type_):
            time = 'now '
        elif('in' in type_):
            match = match = re.findall(r'(?<=in )\d+', type_)
            if(len(match) > 0):
                time = 'in ' + match[-1]
            else:
                self._logger().debug("time required after 'in': {}".format(type))
                raise Exception("time required after 'in': {}".format(type))
        elif('at' in type_):
            match = match = re.findall(r'(?<=at )(\d{2}:\d{2}:\d{4}:\d{2}:\d{2}\s[^\s]+)', type_)
            if(len(match) > 0):
                try:
                    self._validate_time(match[-1])
                    time = 'at ' + match[-1]
                except Exception as e:
                    self._logger().exception(e)
                    raise Exception(e)
            else:
                self._logger().debug("time required after 'at': {}".format(type))
                raise Exception("time required after 'at': {}".format(type))
        else:
            self._logger().debug("'type' must contain either of 'now', 'in' or 'at' but given: {}".format(type))
            raise Exception("'type' must contain either of 'now', 'in' or 'at' but given: {}".format(type))
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node

        command = net_mgr_and_node + ' restart '+ gencore + gasp + wait + time
        try:
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Reboot failed: {}".format(e))
            raise Exception("Reboot failed: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                return 'Fail'
            else:
                return 'Ok' 
            
    def get_dest_route_from_nexthop_table(self, node = None, secure_run = True):
        """*DEPRECATED in version 0.5.* Use keyword `Get Data From Nexthop Table` instead.
          
        This returns the destination route in the nexthop table.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        = Example =
        
        | `Get Dest Route From Nexthop Table` | 10.21.100.235 |
           
        """
        
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nexthop show'
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('(.*) \(CPD \) - destination route\n',output)
            if(match):
                dest_route = match.group(1)
                self._logger().debug('Destination Route: {}'.format(dest_route))
                return dest_route
            else:
                self._logger().debug("dest route not available: {}".format(output))
                self._logger().info(output)
                raise Exception("dest route not available: {}".format(output))
            
    def get_data_from_nexthop_table(self, data, node = None, secure_run = True):
        """This returns all values for ``data`` in the nexthop table.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        Below are the ``data`` values supported:
        
        - ``1`` OR ``dst_rt`` for destination route
        - ``2`` OR ``cost`` for cost
        - ``3`` OR ``path_cost`` for path cost
        - ``4`` OR ``hopcnt`` for hopcnt
        - ``5`` OR ``max_hopcnt`` for max_hopcnt
        - ``6`` OR ``flags`` for flags
        - ``7`` OR ``timestamp`` for timestamp in epoch
        - ``8`` OR ``nexthop`` for nexthop in route
        - ``0`` OR ``all`` for all above (1-8) values) as a python like-tuple
        
        If ``node`` is an AP, python-like ``None`` is returned.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        =Example=
        |             = keyword =       | = data =    | = node =      |  =comment=                                      |
        | `Get Data From Nexthop Table` | data=hopcnt | 10.21.100.235 | a list of all hopcount values will be returned  |
        | `Get Data From Nexthop Table` | data=4      | 10.21.100.235 | a list of all hopcount values will be returned  |
           
        """
        
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nexthop show'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('(.*) \(CPD \) - hop route\n',output)
            if match:
                self._logger().info('Nexthop stats is not returned for AP')
                return None
            
            out_list = []
            
            dst_rt = re.findall('(.*) \(CPD \) - destination route\n',output)
            out_list.append(dst_rt)
            
            cost = re.findall('\s*(\d+) cost\n',output)
            out_list.append(cost)
            
            path_cost = re.findall('\s*(\d+) path cost\n',output)
            out_list.append(path_cost)
            
            hopcnt = re.findall('\s*(\d+) hopcnt\n',output)
            out_list.append(hopcnt)
            
            max_hopcnt = re.findall('\s*(\d+) max hopcnt\n',output)
            out_list.append(max_hopcnt)
            
            flags = re.findall('\s*Flags: (\w+)\n',output)
            out_list.append(flags)
            
            timestamp = re.findall('\s*Timestamp: (\d+) ',output)
            out_list.append(timestamp)
            
            nexthop = re.findall('\s*Route:\s*\n*\s*([A-Za-z0-9:]{23})',output)
            out_list.append(nexthop)
            
            if str(data) == '0' or str(data).lower() == 'all':
                return out_list
            
            if str(data) == '1' or str(data).lower() == 'dst_rt':
                return out_list[0]
            
            if str(data) == '2' or str(data).lower() == 'cost':
                return out_list[1]
            
            if str(data) == '3' or str(data).lower() == 'path_cost':
                return out_list[2]
            
            if str(data) == '4' or str(data).lower() == 'hopcnt':
                return out_list[3]
            
            if str(data) == '5' or str(data).lower() == 'max_hopcnt':
                return out_list[4]
            
            if str(data) == '6' or str(data).lower() == 'flags':
                return out_list[5]
            
            if str(data) == '7' or str(data).lower() == 'timestamp':
                return out_list[6]
            
            if str(data) == '8' or str(data).lower() == 'nexthop':
                return out_list[7]
            
    def get_start_word(self, return_as = 'hex', node = None, secure_run = True):
        """This returns the start word of node either as hexadecimal or decimal depending on ``hex`` or ``dec`` provided in ``return_as``.
        Default is ``hex``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
    
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        =Example=
        
        | = keyword =      | = return_as = | = node =       |   =comment=                                  |
        | `Get Start Word` | dec           |  fd59::a2:add1 | # start word will be returned as decimal     |
        | `Get Start Word` |               |  fd59::a2:add1 | # start word will be returned as hexadecimal |
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf phy phy_start_word'
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(return_as.lower() == 'dec'):
                match = re.search('PHY start word is set to (\d+)', output)
            else:
                match = re.search('PHY start word is set to \d+ \((.*)\)', output)
            if(match):
                st_word = match.group(1)
                self._logger().debug('Phy Start Word: {}'.format(st_word))
            else:
                self._logger().debug("start word not found: {}".format(output))
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("start word not found: {}".format(output))
            return st_word

    def set_start_word(self, start_word, node = None, secure_run = True):
        """This sets the start word to ``start_word`` of the node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        =Example=
        | = keyword =      | = start_word = |
        | `Set Start Word` | 0x193d         |
       
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf phy phy_start_word ' + start_word
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("could not set start word: {}".format(output))
            else:
                return 'Ok'
            
    def set_chanusage_mask(self, mask, node = None, secure_run = True):
        """This sets the chanusage mask to ``mask`` of the node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
         
        =Example=
        |     = keyword =      |           = mask =               |
        | `Set Chanusage Mask` | ff:ff:ff:ff:ff:ff:ff:ff:ff:ff:07 |  
           
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' chanusage add plan:1 mask:' + mask + ' default'
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("could not set chanusage mask: {}".format(output))
            else:
                return 'Ok'

    def get_chanusage_mask(self, mask = 'AD', node = None, secure_run = True):
        """This returns a python-like list of chanusage masks.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon. 
            
        ``mask`` can be provided to get the kind of masks, default is ``AD``. It supports 5 kinds of masks:
        ``AO`` - Active Only
        ``DO`` - Default Only
        ``AD`` - Active Default
        ``A``  - Active
        ``D``  - Default
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        =Example=
        |     = keyword =      | = mask = |
        | `Get Chanusage Mask` | AO       | 
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' chanusage show'
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            olines = output.split('\n')
            for index, oline in enumerate(olines):
                oline = re.sub(' +', ' ', oline.strip())
                if(oline == 'planid flags minchans masklen mask'):
                    break
                
            if(len(olines) > 0):
                olines_ = olines[index+1:]
            else:
                return []
            
            masks = []
            for oline in olines_:
                oline = re.sub(' +', ' ', oline.strip())
                match = re.search('(.*)\s+-*([AD]+)-*\s+(\d+)\s+(\d+)\s+(.*)', oline)
                if(match):
                    if(mask.upper() == match.group(2)):
                        masks.append(match.group(5))
                    elif(mask.upper() == 'D' and match.group(2).find('D') != -1):
                        masks.append(match.group(5))
                    elif(mask.upper() == 'A' and match.group(2).find('A') != -1):
                        masks.append(match.group(5))
                    elif(mask.upper() == 'DO' and match.group(2) == 'D'):
                        masks.append(match.group(5))
                    elif(mask.upper() == 'AO' and match.group(2) == 'A'):
                        masks.append(match.group(5))
                        
            return masks      
           
    def get_net_id(self, return_as = 'hex', node = None, secure_run = True):
        """This returns the net id of node either as hexadecimal or decimal depending on ``hex`` or ``dec`` provided in ``return_as``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        =Example=
        | = keyword =  | = return_as = | = comment =                              |
        | `Get Net Id` | return_as=dec | # net id will be returned as decimal     |
        | `Get Net Id` |               | # net id will be returned as hexadecimal |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_mac_net_id'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(return_as.lower() == 'dec'):
                match = re.search('MAC Network ID is set to (\d+)', output)
            else:
                match = re.search('MAC Network ID is set to \d+ \((.*)\)', output)
            if(match):
                net_id = match.group(1)
                self._logger().debug('Net ID: {}'.format(net_id))
                return net_id
            else:
                self._logger().debug("net id not found: {}".format(output))
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("net id not found: {}".format(output))  
        
    def set_net_id(self, net_id, node = None, secure_run = True):
        """This sets the net id of node ``node`` to ``net_id``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        = Example =
        | = keyword =  | = net_id = |
        | `Set Net Id` | 0xfab0     |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_mac_net_id ' + net_id
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set net id: {}".format(output))
            else:
                return 'Ok'


    def _validate_time(self, time):
        """
        This validates the provided time is correct and has not passed.
        """
        try:
            time, tz = time.split(' ')
            if(tz in all_timezones):
                month, day, year, hour, minute = time.split(':')
                dt = datetime(year = year, month = month,  day = day, hour = hour,  minute = minute, tzinfo = timezone(tz))
                dt_now = datetime.now(tzinfo = timezone(tz))
                if(dt < dt_now):
                    raise Exception("Time has already passed\ntime provided: {} and current time: {}".format(dt, dt_now))
            else:
                raise Exception("Invalid timezone: {}".format(tz))             
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
    
    def get_data_from_ip_rt_table(self, Address, data, node = None, secure_run = True):
        """This returns the value of provided ``data`` header with respect to the provided value of ``Address`` header.
    
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        The ``data`` must be the exact header name both case and space sensitive.
        
        = Examples =
        |          = keyword =        | = Address =  | = data =     |   
        | `Get Data From Ip Rt Table` | Address=::/0 | data=Nexthop |
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        if not isinstance(Address, str):
            self._logger().debug("'Address' must be a string but given {}".format(Address.__class__.__name__))
            raise TypeError("'Address' must be a string but given {}".format(Address.__class__.__name__))
        
        try:        
            ip_rt_table = self._get_ip_rt(node, secure_run)
            self._logger().info(ip_rt_table)
            print(ip_rt_table)
        except Exception as e:
            self._logger().exception("Could not get data from ip rt table: {}".format(e))
            raise Exception("Could not get data from ip rt table: {}".format(e))
        else:
            if(ip_rt_table == {}):
                self._logger().debug("ip rt table is empty")
                raise Exception("ip rt table is empty")
            
            try:
                data_list = []
                addr_list = ip_rt_table['Address']
                for ind, addr in enumerate(addr_list):
                    if(addr.lower() == Address.lower()):  
                         data_list.append(ip_rt_table[data][ind])
                return data_list
            except KeyError as e:
                 self._logger().exception("Invalid data '{}'".format(data)) 
                 raise Exception("Invalid data '{}'".format(data))         
        
    def _get_ip_rt(self, node = None, secure_run = True):
        """
        This returns the ip rt table as python-like dictionary for the node ``node``.
 
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """       
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        tablename = 'ip_rt show'
        try:
            ip_rt = self._get_table_containing_empty_values(node, tablename, secure_run)
            # self._print_dict_as_table(ip_rt)
            addr_list = ip_rt['Address']
            for i in range(1, len(addr_list)):  #enumerate(addr_list):
                if addr_list[i] == '':
                    addr_list[i] = addr_list[i-1]
            ip_rt['Address'] = addr_list
            return ip_rt 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e) 
    
    def get_count_of_total_nodes_in_nodeq(self, nodeq, node=None, secure_run=True):
        """This returns the count of total nodes in the nodeq ``nodeq``.
    
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
         = Example =
        |            = keyword =              | = nodeq = |
        | `Get Count Of Total Nodes In Nodeq` | 0         |
        | `Get Count Of Total Nodes In Nodeq` | bad       |
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if nodeq.lower() == 'bad':
                nodeq = 'bad_nodeq'
            else:
                nodeq = int(nodeq)
                if(nodeq < 0 or nodeq > 12):
                    self._logger().debug("ValueError")
                    raise ValueError
                else:
                    nodeq = 'nodeq ' + str(nodeq)
        except ValueError:
            self._logger().exception("nodeq must be either between 0-12 inclusive or bad")
            raise Exception("nodeq must be either between 0-12 inclusive or bad") 
        except AttributeError:
            self._logger().exception("nodeq must be a string but given {}".format(nodeq.__class__.__name__))
            raise TypeError("nodeq must be a string but given {}".format(nodeq.__class__.__name__))
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + nodeq
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('Node Queue\. (\d+) total nodes', output)
            if match:
                self._logger().debug('Total Node count: {}'.format(match.group(1)))
                return match.group(1)
            else:
                self._logger().debug("something went wrong; could not get count of total nodes: {}".format(output))
                raise RuntimeError("something went wrong; could not get count of total nodes: {}".format(output))           
    
    def get_data_from_nodeq0(self, data, mac='all', node = None, secure_run = True):
        """*DEPRECATED in version 0.6.* Use keyword `Get Data From Nodeq` instead.
        
        This returns the value of provided ``data`` header with respect to the provided value of ``mac`` header.
    
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        The ``data`` must be the exact header name both case and space sensitive.
        
        By default ``mac`` is set to ``all``.
        
        = Examples =
        |      = keyword =       |     = mac =                 | = data =    |
        | `Get Data From Nodeq0` | mac=00:13:50:ff:fe:70:85:10 | data=mflags |
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        if not isinstance(mac, str):
            self._logger().debug("'mac' must be a string but given {}".format(mac.__class__.__name__))
            raise TypeError("'mac' must be a string but given {}".format(mac.__class__.__name__))
            
        try:        
            nodeq_table = self._get_nodeq(0, node, secure_run)
            self._logger().info(nodeq_table)
        except Exception as e:
            self._logger().exception("Could not get data from nodeq 0: {}".format(e))
            raise Exception("Could not get data from nodeq 0: {}".format(e))
        else:
            if(nodeq_table == {}):
                self._logger().debug("nodeq table is empty")
                raise Exception("nodeq table is empty")
            try:
                if(mac.lower() != 'all'):
                    mac_list = nodeq_table['mac']
                    for ind, mac_addr in enumerate(mac_list):
                        if(mac_addr.lower() == mac.lower()):  
                             return nodeq_table[data][ind]
                else:
                    data_list= nodeq_table[data]
                    return data_list
            except KeyError as e:
                 self._logger().exception("Invalid data '{}'".format(data)) 
                 raise Exception("Invalid data '{}'".format(data))
    
    def get_data_from_nodeq(self, nodeq, mac='all', data='mac', node = None, secure_run = True):
        """This returns the value of mac data list if default ``mac`` and ``data`` is present for the provided 
        nodeq table and also return value of provided ``data`` header with respect to the provided value of ``mac`` header.
    
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        ``Nodeq`` is mandatory argument and it ranges from 0-12.
        
        By default ``mac`` is set to ``all`` and ``data`` is set to ``mac`` (case-sensitive).
        
        The ``data`` must be the exact header name both case and space sensitive. 
         
        = Examples =
        |         =Keyword=     | =Nodeq= |            =mac=            |   =data=    |                                       =Comment=                                    |
        | `Get Data From Nodeq` |    1    |                             |             | This will return mac_addr list for the provided nodeq table                        |
        | `Get Data From Nodeq` |    0    | mac=00:13:50:ff:fe:70:85:10 | data=mflags | This will return data value corresponding to mac_addr for the provided nodeq table |
        | `Get Data From Nodeq` |    0    |                             | data=mflags | This will return list of mflags data for the provided nodeq table                  |        
        
        ``Note: For getting data of mde from `Nodeq 10`.``
            It assumes the headers to be in the form of 
            ``mac cur def change fl ( mde flg suc fst    cost),( mde flg suc fst    cost),( mde flg suc fst    cost),
            ( mde flg suc fst    cost),( mde flg suc fst    cost)``.
            It replaces the header "( mde flg suc fst    cost)" with corresponding "mde" value i.e.
            "mac cur def change fl mde1 mde35 mde3 mde4 mde5"
            
            ``mde*`` is list of dictionaries having ``suc``, ``fst`` and ``cost`` as keys and their corresponding 
            values as values.
        = Examples =
        |         =Keyword=     | =Nodeq= |            =mac=            |   =data=    |                                       =Comment=                           |
        | `Get Data From Nodeq` |    10   |                             | data=mde1   | This will return list of dict data for mde1 for the provided nodeq table  |
        | `Get Data From Nodeq` |    10   | mac=00:13:50:ff:fe:70:85:10 | data=mde35  | This will return list of dict data for mde35 for the provided nodeq table |
            
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        if not isinstance(mac, str):
            self._logger().debug("'mac' must be a string but given {}".format(mac.__class__.__name__))
            raise TypeError("'mac' must be a string but given {}".format(mac.__class__.__name__))
            
        try:
            if(nodeq == '8'):   
                nodeq_table = self._get_8_nodeq(node, 'nodeq 8', secure_run)
                self._logger().info(nodeq_table) 
            elif(nodeq =='10'):
                nodeq_table = self._get_10_nodeq(node, 'nodeq 10', secure_run)
                self._logger().info(nodeq_table) 
            else:
                nodeq_table = self._get_nodeq(nodeq, node, secure_run)
                self._logger().info(nodeq_table)
        except Exception as e:
            self._logger().exception("Could not get data from nodeq 0: {}".format(e))
            raise Exception("Could not get data from nodeq 0: {}".format(e))
        else:
            if(nodeq_table == {}):
                self._logger().debug("nodeq table is empty")
                raise Exception("nodeq table is empty")
            try:
                if(mac.lower() != 'all' and data.lower() !='mac'):
                    mac_list = nodeq_table['mac']
                    for ind, mac_addr in enumerate(mac_list):
                        if(mac_addr.lower() == mac.lower()):
                            print(nodeq_table[data][ind])  
                            return nodeq_table[data][ind]
                else:
                    data_list= nodeq_table[data]
                    return data_list
            except KeyError as e:
                 self._logger().exception("Invalid data '{}'".format(data)) 
                 raise Exception("Invalid data '{}'".format(data))
    
    def verify_bad_nodeq_format(self, headers, header_sep = ' ', node=None, secure_run=True):
        """This verifies following things:
        - Nodeq should have only non-empty (any printable ASCII character except SPACE) value in node entries if present.
        - The headers should be as provided in ``headers``.
        - It should have at least 1 node entry.
        - The ``mac`` header values should have 8 alphanumeric pairs and each pair should be separated by ``:``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default headers are separated by single space, use ``header_sep`` for any other header separator.
        It does not affect the space between the words of a header name.
        
        Example:
        |          = keyword =      |  = headers =   | = header_sep = |
        | `Verify Bad Nodeq Format` | mac bootsinst  |                |
        | `Verify Bad Nodeq Format` | mac boots inst |                |
        | `Verify Bad Nodeq Format` | mac,boots,inst |  ,             |  
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.  
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:        
            nodeq_table = self._get_bad_nodeq(node, secure_run)
            self._logger().info(nodeq_table)
        except NotATableError:
            self._logger().exception("NotATableError")
            raise NotATableError("bad nodeq does not have the expected format")
        except Exception as e:
            self._logger().exception("Something went wrong: could not verify bad nodeq format: {}".format(e))
            raise Exception("Something went wrong: could not verify bad nodeq format: {}".format(e))
        else:
            if(nodeq_table == {}):
                return
            
            # simple logic for adding header separator
            # header_ = str(header_sep).join(nodeq_tables.keys())
            headers_ = ''
            for header in  nodeq_table.keys():
                headers_ += header + str(header_sep)
            if header_sep != '':
                index = -1*len(header_sep)
                headers_ = headers_[:index]
            
            if headers != 'mac bootsinst' and headers_ != headers:
                self._logger().info("headers NOT matching:\nheaders in nodeq: {}\nProvided headers: {}".format(headers_, headers))
                raise AssertionError("headers NOT matching:\nheaders in nodeq: {}\nProvided headers: {}".format(headers_, headers))
            
            try:
                self._verify_mac_format(nodeq_table['mac'])
            except ValueError:
                pass
            except KeyError:
                self._logger().exception("header mac is missing in bad nodeq")
                raise KeyError("header mac is missing in bad nodeq")
            
    def _get_bad_nodeq(self, node, secure_run):
        """This returns a python-like dictionary from the output of net mgr command
        ``bad_nodeq``. It assumes that string of header names is ``mac bootsinst``,
        where ``boots`` and ``inst`` are two separate headers.
        """    
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' ' + 'bad_nodeq'
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            if(output.strip() == ''):
                return {} 
                           
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[1:]
                        
            # remove empty lines
            while('' in output_):
                output_.remove('')
            
            # remove spaces in a value
            tmp = []
            for line in output_:
                line = re.sub(': +', ':', line)
                tmp.append(line)
            output_ = tmp
            
            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp
            
            # handle no gap header names
            headers = output_[0]
            if headers == 'mac bootsinst':
                headers = 'mac boots inst'   
            output_[0] = headers
            
            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp
            
            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')
                    
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
                
            table = {column[0]:list(column[1:]) for column in zip(*output_)}
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)                        
    
    def verify_nodeq_format(self, nodeq, headers, header_sep = ' ', node=None, secure_run=True):
        """This verifies following things:
        - Nodeq should have only non-empty (any printable ASCII character except SPACE) value in node entries if present.
        - The headers should be as provided in ``headers``.
        - It should have at least 1 node entry.
        - The ``mac`` header values should have 8 alphanumeric pairs and each pair should be separated by ``:``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        ``nodeq`` is nodeq table's value from 0 to 12 both inclusive.
        
        By default headers are separated by single space, use ``header_sep`` for any other header separator.
        It does not affect the space between the words of a header name.
        
         = Example =
        |      = keyword =      | = nodeq = |     = headers =         | = header_sep = |
        | `Verify Nodeq Format` |   5       |  mac keyid sa_id state  |                |
        | `Verify Nodeq Format` |   5       |  ${headers}             |                |
        | `Verify Nodeq Format` |   5       |  mac,keyid,sa_id,state  |  ,             |  
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.  
        
        ``Note:`` There are few assumption:
        - ``Nodeq 8:`` It assumes that there are 2 special headers named ``hold bin`` and ``switch time`` having space between their words. 
        - ``Nodeq 10:`` It assumes the headers to be in the form of \
        ``mac cur def change fl ( mde flg suc fst    cost),( mde flg suc fst    cost),( mde flg suc fst    cost),( mde flg suc fst    cost),( mde flg suc fst    cost)``.\
        It replaces the header ``( mde flg suc fst    cost)`` with corresponding ``mde`` value i.e. ``mac cur def change fl mde1 mde35 mde3 mde4 mde5``.\
        ``mde*`` is list of dictionaries having ``suc``, ``fst`` and ``cost`` as keys and their corresponding values as values. 
        
        """
        
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:        
            nodeq_table = self._get_nodeq(nodeq, node, secure_run)
            self._logger().info(nodeq_table)
        except NotATableError:
            self._logger().exception("NotATableError")
            raise NotATableError("nodeq {} does not have the expected format".format(nodeq))
        except AssertionError:
            self._logger().exception("nodeq {} does not have expected format".format(nodeq))
            raise AssertionError("nodeq {} does not have expected format".format(nodeq))
        except ValueError as e:
            self._logger().exception(e)
            raise ValueError(e)
        except Exception as e:
            self._logger().exception("Something went wrong: could not verify nodeq {} format: {}".format(nodeq, e))
            raise Exception("Something went wrong: could not verify nodeq {} format: {}".format(nodeq, e))
        else:
            if(nodeq_table == {}):
                self._logger().debug("nodeq {} is empty".format(nodeq))
                raise Exception("nodeq {} is empty".format(nodeq))
            
            # simple logic for adding header separator
            # header_ = str(header_sep).join(nodeq_tables.keys())
            headers_ = ''
            for header in  nodeq_table.keys():
                headers_ += header + str(header_sep)
            if header_sep != '':
                index = -1*len(header_sep)
                headers_ = headers_[:index]
                
            # handle headers visibility for nodeq 10
            headers10 = ''
            if str(nodeq) == '10':
                headers10 = re.sub('mde\d+', '(mde suc fst cost)', headers_)
            
            if headers_ != headers and headers10 != headers:
                self._logger().info("headers NOT matching:\nheaders in nodeq: {}\nProvided headers: {}".format(headers_, headers))
                raise AssertionError("headers NOT matching:\nheaders in nodeq: {}\nProvided headers: {}".format(headers_, headers))
            
            try:
                self._verify_mac_format(nodeq_table['mac'])
            except ValueError:
                self._logger().exception("No node entry in nodeq %s" %nodeq)
                raise ValueError("No node entry in nodeq %s" %nodeq)
            except KeyError:
                self._logger().exception("header mac is missing in nodeq %s" %nodeq)
                raise KeyError("header mac is missing in nodeq %s" %nodeq)
            
    def _verify_mac_format(self,macs):
        """This takes a list of strings and verifies if a pair of chars in each value in the list is separated by a ':'.
        """  
        if not isinstance(macs, list):
            macs = [macs]
        
        if macs == []:
            raise ValueError
            
        for mac in macs:
            if len(mac.split(':')) != 8:
                self._logger().info("mac {} not in format".format(mac))
                raise Exception("mac {} not in format".format(mac))
                          
    
    def _get_nodeq(self, nodeq, node = None, secure_run=True):
        """This returns the nodeq ``nodeq`` table as python-like dictionary for the node ``node``
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """  
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            nodeq = int(nodeq)
            if(nodeq < 0 or nodeq > 12):
                self._logger().debug("ValueError")
                raise ValueError("nodeq must be between 0-12 inclusive")
        except ValueError:
            self._logger().exception("nodeq must be between 0-12 inclusive")
            raise ValueError("nodeq must be between 0-12 inclusive") 
        
        tablename = 'nodeq ' + str(nodeq)
        try:
            if nodeq == 8:
                nodeq_t = self._get_8_nodeq(node, tablename, secure_run)
            elif nodeq == 10:
                nodeq_t = self._get_10_nodeq(node, tablename, secure_run)
            else:
                nodeq_t = self._get_table(node, tablename, secure_run)
            # self._print_dict_as_table(nodeq) 
            self._logger().info(nodeq_t)
            return nodeq_t 
        except NotATableError:
            self._logger().exception("NotATableError")
            raise NotATableError
        except AssertionError:
            raise AssertionError
    
    def _get_column_sep_indexes(self, string):
        """This returns the list of indexes in the string ``string`` which can be used to put a separator in the string ``headers``.
        """
        spacefound = False
        twospacefound = False
        sep_indexes = []
        for i in range(len(string)):
            char = string[i]
            if(twospacefound and char == ' '):
                continue
            
            if(twospacefound and char != ' '):
                sep_indexes.append(i)
                twospacefound = False
                spacefound = False
                            
            if(spacefound and char == ' '):
                twospacefound = True
                
            if(spacefound and char != ' '):
                spacefound = False
            
            if(char == ' '):
                spacefound = True
        return sep_indexes
    
    def _add_padding(self, line, padding_len):
        """This adds ``padding_len`` spaces in the string ``line``.
        """
        for i in range(padding_len):
            line += ' '
        return line
    
    def _add_column_sep(self, sep, line, sep_ind_list, headers_len):
        """This adds ``sep`` to string ``line`` at all indexes in ``sep_ind_list``. 
        """
        diff = headers_len - len(line)
        if(diff > 0):
            line = self._add_padding(line, diff)
        first_ind = sep_ind_list[0]
        # ind == 0 is never occurring situation
        line_ = line[:first_ind]
        for i in range(1, len(sep_ind_list)):
            ind = sep_ind_list[i]
            prev_ind = sep_ind_list[i-1]
            line_ += sep + line[prev_ind:ind]
        last_ind = sep_ind_list[-1]
        line_ += sep + line[last_ind:len(line)]
        return line_
    
    def _get_table_containing_empty_values(self, node, tablename, secure_run):
        """
        This makes and returns the dictionary of the given table ``tablename``.
        The ``tablename`` is supposed to be a name of a net mgr command which outputs 
        a table-like string considering the first line of the output is excluded.
        Otherwise it will raise ``NotATableError``.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            if(output.strip() == ''):
                return {}     
            
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[1:]
                            
            # remove empty lines
            while('' in output_):
                output_.remove('')  
                
            headers = output_[0].strip()
            headers_len = len(output_[0])
            sep_ind_list = self._get_column_sep_indexes(headers)
            
            VAR_SEP = '0_SEP_0'
            
            tmp = []
            for line in output_:
                line = self._add_column_sep(VAR_SEP, line, sep_ind_list, headers_len)
                tmp.append(line)
            output_ = tmp

            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(VAR_SEP)
                tmp.append(line)
            output_ = tmp

            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')                
             
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
             
            tmp = []
            for row in output_:
                tmp_row = []
                for column in row:
                    column = column.strip()
                    tmp_row.append(column)
                tmp.append(tmp_row)
            output_ = tmp
            
            table = {column[0]:list(column[1:]) for column in zip(*output_)}
            return table
            
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError                   
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)    
 
    def _get_8_nodeq(self, node, tablename, secure_run):
        """
        This makes and returns the dictionary of the given table ``tablename``.
        ``tablename`` must be ``nodeq 8``.
        Note: It assumes that there are 2 special headers named ``hold bin`` and ``switch time`` 
        having space between their words. 
        No value in the table-like string should be empty.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            if(output.strip() == ''):
                return {} 
                        
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[1:]
            
            # remove empty lines
            while('' in output_):
                output_.remove('')
            
            # remove spaces in a value
            tmp = []
            for line in output_:
                line = re.sub(': +', ':', line)
                tmp.append(line)
            output_ = tmp
            
            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp
            
            # handle headers names with spaces
            headers = output_[0]
            headers = re.sub('hold bin','hold_bin', headers)
            headers = re.sub('switch time','switch_time', headers)
            output_[0] = headers
             
            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp
            
            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')
            
            # make modofied headers to original headers again
            tmp = []
            for index, a_header in enumerate(output_[0]):
                if a_header == 'hold_bin':
                    output_[0][index] = 'hold bin'
                if a_header == 'switch_time':
                    output_[0][index] = 'switch time'
            
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
                
            table = {column[0]:list(column[1:]) for column in zip(*output_)}
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
     
    def _put_separator_for_nodeq_10(self, string, sep):
        """This method is specifically used for ::meth:: _get_10_nodeq.
        This returns a string after putting separator ``sep`` at appropriate places.
        """
        string = re.sub('\),', ' ', string)
        string = re.sub('\)', ' ', string)
        string = re.sub('\(', sep, string)
        string = re.sub(' +',' ', string)
        
        try:
            first_sep_index = string.index(sep)
            str_without_sep = string[:first_sep_index].strip()
            str_with_sep = string[first_sep_index:]
        except ValueError:
            str_without_sep = string.strip()
            str_with_sep = ''
        string = re.sub(' ', sep, str_without_sep) + str_with_sep
        return string.strip()
    
    def _handle_modes(self, nodeq_10_row):
        """This method is specifically used in ::meth:: _get_10_nodeq.
        This returns a list converting ``mde suc fst cost`` header to 
        corresponding ``mde`` value (e.g. mde1, mde35) in case of headers and making a list of 
        dictionaries having `suc``, ``fst`` and ``cost`` as keys and their corresponding
        values as values for the corresponding ``mde`` in case of node entries. 
        """ 
        list_without_modes = nodeq_10_row[:5]
        if list_without_modes[0] == 'mac':
            return list_without_modes + ['mde1', 'mde35', 'mde3', 'mde4', 'mde5']
        list_with_modes = nodeq_10_row[5:]
        
        len_list_with_modes = len(list_with_modes)
        mde_dict_tmp = {'suc':'', 'fst':'', 'cost':''}
        
        mde_list_of_dict = []
        for i in range(5):
            if len_list_with_modes > i:
                mde_list_tmp = list_with_modes[i].split(' ')
                if len(mde_list_tmp) != 4:
                    raise AssertionError
                mde_dict_tmp['suc'] = mde_list_tmp[1]
                mde_dict_tmp['fst'] = mde_list_tmp[2]
                mde_dict_tmp['cost'] = mde_list_tmp[3]
                mde_list_of_dict.append(mde_dict_tmp)
            else:
                mde_list_of_dict.append({})
        return list_without_modes + mde_list_of_dict
        
               
    def _get_10_nodeq(self, node, tablename, secure_run):
        """
        This returns the python-like dictionary of the given table ``tablename``.
        ``tablename`` must be ``nodeq 10``.
        
        It assumes the headers to be in the form of 
        ``mac cur def change fl ( mde flg suc fst    cost),( mde flg suc fst    cost),( mde flg suc fst    cost),
        ( mde flg suc fst    cost),( mde flg suc fst    cost)``.
        It replaces the header "( mde flg suc fst    cost)" with corresponding "mde" value i.e.
        "mac cur def change fl mde1 mde35 mde3 mde4 mde5"
        
        ``mde*`` is list of dictionaries having ``suc``, ``fst`` and ``cost`` as keys and their corresponding 
        values as values. 
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)

            if(output.strip() == ''):
                return {} 
                        
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[1:]
            
            # remove empty lines
            while('' in output_):
                output_.remove('')
            
            # remove spaces in a value
            SEP = ' 0_SEP_0 '
            tmp = []
            for line in output_:
                line = self._put_separator_for_nodeq_10(line, SEP)
                tmp.append(line)
            output_ = tmp
            
            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp
             
            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(SEP)
                tmp.append(line)
            output_ = tmp
            
            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')
            
            # handle mde suc fst cost
            tmp = []
            for alist in output_:
                alist = self._handle_modes(alist)
                tmp.append(alist)
            output_ = tmp
            
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
                
            table = {column[0]:list(column[1:]) for column in zip(*output_)}
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError
        except AssertionError:
            raise AssertionError
                
    def _get_table(self, node, tablename, secure_run):
        """
        This makes and returns the python-like dictionary of the given table ``tablename``.
        The ``tablename`` is supposed to be a name of a net mgr command which outputs 
        a table-like string considering the first line of the output is excluded.
        Otherwise it will raise ``NotATableError``. 
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        ``Note:`` It assumes that the header names and their corresponding values are separated 
        by at least 1 space. No value in the table-like string should be empty.
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            #self._logger().info(output)
            if(output.strip() == ''):
                return {} 
                        
            # split into lines/rows and remove any unwanted or bad sequence words from output
            output_ = output.split('\n')
            self._logger().info(output_)
            for vals in output_:
                if 'Node Queue. ' in vals:
                    node_count=re.search('(\d+) ', vals)
                    self._logger().debug(node_count.group(0))
                    header='Node Queue. '+node_count.group(0)+'total nodes'
                    self._logger().debug(header)
                    val= output_.index(header)
                    self._logger().debug(val)
                    output_=output_[val:] ##added to resolve bug-2137735
            output_ = output_[1:]
            
            # remove empty lines
            while('' in output_):
                output_.remove('')
            
            # remove spaces in a value
            tmp = []
            for line in output_:
                line = re.sub(': +', ':', line)
                tmp.append(line)
            output_ = tmp
            
            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp
            
            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp
            
            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
                
            table = {column[0]:list(column[1:]) for column in zip(*output_)}
            self._logger().debug(table)
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)      
    
    def _print_dict_as_table(self, table_as_dict): 
        """This prints the dictionary as table.
        """ 
        if(not isinstance(table_as_dict, dict)):
            raise NotADictionaryError
        for row in zip(*([key] + list(value) for key, value in table_as_dict.items())):
            print(*row)
                
    def enable_single_mac_discovery(self, macid, node=None, secure_run = True):
        """This keyword enables the single mac discovery of provided node and mac id.
        
        This takes 1 mandatory argument ``macid``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |            =Keyword=          |         =Mac ID=        |     =Node=     |                               =Comment=                           |
        | `Enable Single Mac Discovery` | 00:13:50:05:00:7f:97:fb | 0001:0045:0a26 | This will enable single mac discovery for given Node and Mac id   |
        | `Enable Single Mac Discovery` | 00:13:50:05:00:7f:97:fb |                | This will enable single mac discovery for default Node and Mac id |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' mlme_disc_mac ' + macid
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Single Mac Discovery is not enabled for node {} and mac id {}".format(node, macid))
                self._logger().info(output)
                raise Exception("Single Mac Discovery is not enabled for node {} and mac id {}".format(node, macid))
            else:
                return 'Ok'
            
    def mlme_restart_aggressive_discovery(self, node=None, secure_run = True):
        """This keyword enables the single mac discovery of provided node and mac id.
              
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |            =Keyword=                |     =Node=     |                               =Comment=                      |
        | `MLME Restart Aggressive Discovery` | 0001:0045:0a26 | This will mlme restart aggressive discovery for given Node   |
        | `MLME Restart Aggressive Discovery` |                | This will mlme restart aggressive discovery for given Node   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' mlme_restart_aggr_disc'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("MLME Restart Aggressive Discovery is not successful for node {}".format(node))
                self._logger().info(output)
                raise Exception("MLME Restart Aggressive Discovery is not successful for node {}".format(node))
            else:
                return 'Ok'
            
    def enable_dev_mode_discovery(self, macid, node=None, secure_run = True):
        """This keyword enables the dev mode discovery of provided node and mac id.
        
        This takes 1 mandatory argument ``macid``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |            =Keyword=        |         =Mac ID=        |     =Node=     |                             =Comment=                           |
        | `Enable Dev Mode Discovery` | 00:13:50:05:00:7f:97:fb | 0001:0045:0a26 | This will enable dev mode discovery for given Node and Mac id   |
        | `Enable Dev Mode Discovery` | 00:13:50:05:00:7f:97:fb |                | This will enable dev mode discovery for default Node and Mac id |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' mlme_disc_mac ' + macid + ' enable900'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Dev Mode Discovery is not enabled for node {} and mac id {}".format(node, macid))
                self._logger().info(output)
                raise Exception("Dev Mode Discovery is not enabled for node {} and mac id {}".format(node, macid))
            else:
                return 'Ok'
    
    def get_timesync_enabled_status(self, node=None, secure_run = True):
        """This keyword gets the timesync enabled status of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``1`` or ``0`` on success.
        
        = Examples =
        |             =Keyword=          |     =Node=     |                       =Comment=                        |
        | `Get Timesync Enabled Status`  | 0001:0045:0a26 | This will get Timesync enabled status for given Node   |
        | `Get Timesync Enabled Status`  |                | This will get Timesync enabled status for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf timesync ts_enable'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Timesync enabled status")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Time Sync Enabled is set to )\d+', output)
            if(match):
                TimeSyncStatus = match.group(0)
                self._logger().debug('Time Sync Enabled Status: {}'.format(TimeSyncStatus))
            else:
                self._logger().debug("Exception occurred while getting Time Sync Enabled status: {}".format(output))
                raise Exception("Exception occurred while getting Time Sync Enabled status: {}".format(output))
        return TimeSyncStatus
    
    def set_timesync_enabled_status(self, timesync_status, node=None, secure_run = True):
        """This keyword sets the timesync enabled status of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |             =Keyword=          | =TimeSync Status= |     =Node=     |                           =Comment=                        |
        | `Set Timesync Enabled Status`  |         1         | 0001:0045:0a26 | This will set Timesync status as enabled for given Node    |
        | `Set Timesync Enabled Status`  |         0         |                | This will set Timesync status as disabled for default Node |
        
        TimeSync status should be either 0(disable) or 1 (enable).
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            TimeSync_Status = int(timesync_status)
        except ValueError:
            self._logger().exception("Timesync status must be either integer or string-convertible-to-integer")
            raise Exception("Timesync status must be either integer or string-convertible-to-integer")
         
        if (not (TimeSync_Status == 0 and TimeSync_Status == 1) ):
            self._logger().debug("Invalid TimeSync_Status. TimeSync_Status must be either 0 or 1")
            raise Exception("Invalid TimeSync_Status. TimeSync_Status must be either 0 or 1") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting TimeSync Enabled Status")
            command = net_mgr_and_node + ' conf timesync ts_enable ' + str(TimeSync_Status)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Setting TimeSync Enabled Status failed: {}".format(e))
            raise Exception("Setting TimeSync Enabled Status failed: {}".format(e))
        return output
    
    def purge_saved_nodes(self, node=None, secure_run=True):
        """This keyword clears the saved nodes from persistent memory of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |       =Keyword=     |     =Node=     |                                 =Comment=                                |
        | `Purge Saved Nodes` | 0001:0045:0a26 | This will clears the saved nodes from persistent memory for given Node   |
        | `Purge Saved Nodes` |                | This will clears the saved nodes from persistent memory for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' mlme_purge_saved_nodes'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Purge Saved nodes failed for node {}".format(node))
                self._logger().info(output)
                raise Exception("Purge Saved nodes failed for node {}".format(node))
            else:
                return 'Ok'
            
    def get_mlme_restore_opt(self, node=None, secure_run = True):
        """This keyword gets the mlme restore operations of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=      |     =Node=     |                          =Comment=                     |
        | `Get MLME Restore Opt` | 0001:0045:0a26 | This will get Mlme restore Operations for given Node   |
        | `Get MLME Restore Opt` |                | This will get Mlme restore Operations for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme restore_opt'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting MLME Restore Operations Value")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Raw value: )(.*)', output)
            if(match):
                Mlme_restore_opt_val = match.group(0)
                self._logger().debug('Mlme Restore Opt Value: {}'.format(Mlme_restore_opt_val))
            else:
                self._logger().debug("Exception occurred while getting MLME Restore Operations Value: {}".format(output))
                raise Exception("Exception occurred while getting MLME Restore Operations Value: {}".format(output))
        return Mlme_restore_opt_val
    
    def set_mlme_restore_opt(self, restore_opt_val, node=None, secure_run = True):
        """This keyword sets the mlme restore operations of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=       | =Restore Opt Val= |     =Node=     |                        =Comment=                       |
        | `Set MLME Restore Opt`  |       0x100       | 0001:0045:0a26 | This will set Mlme restore Operations for given Node   |
        | `Set MLME Restore Opt`  |       0x000       |                | This will set Mlme restore Operations for default Node |
        
        Range for Restore Opt Val is 0 to 0xffff.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")  
        
        if (not (restore_opt_val >= str(0) and restore_opt_val.casefold() <= str(0xffff)) ):
            self._logger().debug("Invalid MLME Restore Opt Value. MLME Restore Opt Value must be 0 <= restore_opt_val <= 0xffff")
            raise Exception("Invalid MLME Restore Opt Value. MLME Restore Opt Value must 0 <= restore_opt_val <= 0xffff") 
                                            
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting MLME Restore Opt")
            command = net_mgr_and_node + ' conf mlme restore_opt ' + str(restore_opt_val)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting MLME Restore Opt failed for node {}".format(node))
                self._logger().info(output)
                raise Exception("Setting MLME Restore Opt failed for node {}".format(node))
            else:
                return 'Ok'
            
    def save_nodes(self, node = None, secure_run = True):
        """
        This keyword saves the node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        
        This returns ``Ok`` (case sensitive) on success.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' mlme_save_nodes'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Save nodes process could not complete: {}".format(e))
            raise Exception("Save nodes process could not complete: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Node '{}' is not saved".format(node))
                self._logger().info(output)
                raise Exception("Node '{}' is not saved".format(node))
            else:
                return 'Ok'
            
    def delete_all_nodes(self, node = None, secure_run = True):
        """
        This keyword deletes all the node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        
        This returns ``Ok`` (case sensitive) on success.
        
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nodeq_drop_node all'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Delete all nodes process could not complete: {}".format(e))
            raise Exception("Delete all nodes process could not complete: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Node '{}' is not deleted".format(node))
                self._logger().info(output)
                raise Exception("Node '{}' is not deleted".format(node))
            else:
                return 'Ok'
            
    def show_nodeq_whitelist(self, data, node = None, secure_run = True):
        """This keyword gives the ``data`` from nodeq whitelist for provided node.
         
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        Below are the ``data`` values supported:
        
        - ``1`` OR ``device_count`` for device count in whitelist
        - ``2`` OR ``mac_addr_list`` for list of mac addresses in whitelist
        - ``0`` OR ``all`` for all above (1-2) values) as a python like-tuple
        = Examples =
        |         =Keyword=      |     =data=     |    =Node=     |                                    =Comment=                            |
        | `Show Nodeq Whitelist` |       1        |0001:0045:0a26 | This will get value of `data` `1` from nodeq whitelist for given Node   |
        | `Show Nodeq Whitelist` |       all      |               | This will get value of data `all` from nodeq whitelist for default Node |
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nodeq_whitelist show'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:        
            new_list=[]    
            out_list=output.split('\n')
            for val in out_list:
                if val !='':
                    new_list.append(val)
            new_list=[x.strip(' ') for x in new_list]
                    
            device_count = re.search('(\d+) ',new_list[0]).group()
            print(device_count)
            if int(device_count) == 0:
                mac_addrs = new_list[0]
            else:
                addr_list = new_list[1:]
                mac_addrs=[x.strip(' ') for x in addr_list]
            
            if str(data) == '0' or str(data).lower() == 'all':
                return tuple(new_list)
             
            if str(data) == '1' or str(data).lower() == 'device_count':
                return device_count
             
            if str(data) == '2' or str(data).lower() == 'mac_addr_list':
                return mac_addrs
             
    def write_nodeq_whitelist(self, mac_ids, node = None, secure_run = True):
        """This keyword writes ``mac_ids`` as whitelisted nodeq for the provided node.
        
        This takes 1 mandatory argument ``mac_ids`` which will be provided 
        as space separated for multiple mac ids.
         
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |          =Keyword=      |        =mac_ids=        |     =Node=     |                                    =Comment=                            |
        | `Write Nodeq Whitelist` |         1:2:3:4         | 0001:0045:0a26 | This will write nodeq whiltelist for the mac_id value for given Node    |
        | `Write Nodeq Whitelist` | 01:12:23:44 13:14:15:16 |                | This will write nodeq whiltelist for the mac_id values for default Node |
         
        This returns ``Ok`` (case sensitive) on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nodeq_whitelist write ' + mac_ids
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Nodeq whitelist write process could not complete: {}".format(e))
            raise Exception("Nodeq whitelist write process could not complete: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Node '{}' is not whitelisted for provided mac Ids: {}".format(node, mac_ids))
                self._logger().info(output)
                raise Exception("Node '{}' is not whitelisted for provided mac Ids: {}".format(node, mac_ids))
            else:
                return 'Ok'
            
    def reset_nodeq_whitelist(self, node = None, secure_run = True):
        """This keyword resets/deletes the whitelisted mac_ids for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |          =Keyword=      |    =Node=      |                         =Comment=                 |
        | `Reset Nodeq Whitelist` | 0001:0045:0a26 | This will reset nodeq whiltelist for given Node   |
        | `Reset Nodeq Whitelist` |                | This will reset nodeq whiltelist for default Node |
         
        This returns ``Ok`` (case sensitive) on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nodeq_whitelist write'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Nodeq whitelist write reset process could not complete: {}".format(e))
            raise Exception("Nodeq whitelist write reset process could not complete: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Nodeq whitelist write reset process failed for provided node: {}".format(node))
                self._logger().info(output)
                raise Exception("Nodeq whitelist write reset process failed for provided node: {}".format(node))
            else:
                return 'Ok'           
    
    def get_mlme_nodeq_hi_lvl(self, node = None, secure_run = True):
        """This keyword gets the high level percentage nodes on nodeq for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |          =Keyword=      |    =Node=      |                              =Comment=                         |
        | `Get MLME Nodeq Hi Lvl` | 0001:0045:0a26 | This will get the high level % nodes on nodeq for given Node   |
        | `Get MLME Nodeq Hi Lvl` |                | This will get the high level % nodes on nodeq for default Node |
         
        This returns ``High level percentage value`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_nodeq_hi_lvl'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Mlme Nodeq High level percentage")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME hi level at which we cull nodes from queue is set to )\d+', output)
            if(match):
                HiLevelPerc = match.group(0)
                self._logger().debug('Mlme Nodeq High level percentage: {} percent'.format(HiLevelPerc))
            else:
                self._logger().debug("Exception occurred while getting Mlme Nodeq High level percentage: {}".format(output))
                raise Exception("Exception occurred while getting Mlme Nodeq High level percentage: {}".format(output))
        return HiLevelPerc 
    
    def set_mlme_nodeq_hi_lvl(self, hi_lvl_perc, node=None, secure_run = True):
        """This keyword sets the high level percentage nodes on nodeq of provided node.
        
        This takes 1 mandatory argument ``hi_lvl_perc``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |          =Keyword=       | =Hi Lvl Perc= |     =Node=     |                           =Comment=                        |
        | `Set MLME Nodeq Hi Lvl`  |        87     | 0001:0045:0a26 | This will set high level % nodes on nodeq for given Node   |
        | `Set MLME Nodeq Hi Lvl`  |        25     |                | This will set high level % nodes on nodeq for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Hi_Lvl_Perc = int(hi_lvl_perc)
        except ValueError:
            self._logger().exception("High Level percentage must be either integer or string-convertible-to-integer")
            raise Exception("High Level percentage must be either integer or string-convertible-to-integer")
         
        if (not (Hi_Lvl_Perc >= 5 and Hi_Lvl_Perc <= 100) ):
            self._logger().debug("Invalid High Level percentage. High Level percentage must be 5 <= Hi_Lvl_Perc <= 100")
            raise Exception("Invalid High Level percentage. High Level percentage must 5 <= Hi_Lvl_Perc <= 100") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting MLME Nodeq High Level percentage")
            command = net_mgr_and_node + ' conf mlme mlme_nodeq_hi_lvl ' + str(Hi_Lvl_Perc)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Setting MLME Nodeq High Level percentage failed: {}".format(e))
            raise Exception("Setting MLME Nodeq High Level percentage failed: {}".format(e))
        return output
    
    def get_mlme_nodeq_low_lvl(self, node = None, secure_run = True):
        """This keyword gets the percentage of nodeq length that cull for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |          =Keyword=       |    =Node=      |                                   =Comment=                             |
        | `Get MLME Nodeq Low Lvl` | 0001:0045:0a26 | This will get the percentage of nodeq length that cull for given Node   |
        | `Get MLME Nodeq Low Lvl` |                | This will get the percentage of nodeq length that cull for default Node |
         
        This returns ``Low level percentage value`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_nodeq_low_lvl'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Mlme Nodeq Low level percentage")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME level to which we cull node to when nodeq gets large is set to )\d+', output)
            if(match):
                LowLevelPerc = match.group(0)
                self._logger().debug('Mlme Nodeq Low level percentage: {} percent'.format(LowLevelPerc))
            else:
                self._logger().debug("Exception occurred while getting Mlme Nodeq Low level percentage: {}".format(output))
                raise Exception("Exception occurred while getting Mlme Nodeq Low level percentage: {}".format(output))
        return LowLevelPerc 
    
    def set_mlme_nodeq_low_lvl(self, low_lvl_perc, node=None, secure_run = True):
        """This keyword sets the percentage of nodeq length that cull for provided node.
        
        This takes 1 mandatory argument ``low_lvl_perc``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |          =Keyword=        | =Low Lvl Perc= |     =Node=     |                                =Comment=                            |
        | `Set MLME Nodeq Low Lvl`  |        87      | 0001:0045:0a26 | This will set percentage of nodeq length that cull for given Node   |
        | `Set MLME Nodeq Low Lvl`  |        25      |                | This will set percentage of nodeq length that cull for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Low_Lvl_Perc = int(low_lvl_perc)
        except ValueError:
            self._logger().exception("Low Level percentage must be either integer or string-convertible-to-integer")
            raise Exception("Low Level percentage must be either integer or string-convertible-to-integer")
         
        if (not (Low_Lvl_Perc >= 0 and Low_Lvl_Perc <= 100) ):
            self._logger().debug("Invalid Low Level percentage. Low Level percentage must be 0 <= Low_Lvl_Perc <= 100")
            raise Exception("Invalid Low Level percentage. Low Level percentage must 0 <= Low_Lvl_Perc <= 100") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting MLME Nodeq Low Level percentage")
            command = net_mgr_and_node + ' conf mlme mlme_nodeq_low_lvl ' + str(Low_Lvl_Perc)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Setting MLME Nodeq Low Level percentage failed: {}".format(e))
            raise Exception("Setting MLME Nodeq Low Level percentage failed: {}".format(e))
        return output
    
    def get_mlme_max_keep_tx_tries(self, node = None, secure_run = True):
        """This keyword gets Max number of attempts to send keeps to a node before it is
         dropped for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |            =Keyword=         |    =Node=      |                                              =Comment=                                             |
        | `Get MLME Max Keep Tx Tries` | 0001:0045:0a26 | This will get Max number of attempts to send keeps to a node before it is dropped for given Node   |
        | `Get MLME Max Keep Tx Tries` |                | This will get Max number of attempts to send keeps to a node before it is dropped for default Node |
        
        This returns ``Max attempt to send keep pkt`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_max_keep_tx_tries'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Max number of attempts to send keeps to a node before it is dropped")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Max attempts to send keep pkt to a node before it is dropped is set to )\d+', output)
            if(match):
                MaxAttemptCount = match.group(0)
                self._logger().debug('Max number of attempts to send keeps to a node before it is dropped: {}'.format(MaxAttemptCount))
            else:
                self._logger().debug("Exception occurred while getting Max number of attempts to send keeps to a node: {}".format(output))
                raise Exception("Exception occurred while getting Max number of attempts to send keeps to a node: {}".format(output))
        return MaxAttemptCount 
    
    def set_mlme_max_keep_tx_tries(self, max_keep_tx_tries, node=None, secure_run = True):
        """This keyword sets the Max number of attempts to send keeps to a node before it is
         dropped for provided node.
        
        This takes 1 mandatory argument ``max_keep_tx_tries``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |             =Keyword=        | =Max Keep Tx Tries= |     =Node=     |                                              =Comment=                                           |
        | `Set MLME Max Keep Tx Tries` |          87         | 0001:0045:0a26 | This will get Max Number of attempts to send keeps to node before it is dropped for given Node   |  
        | `Set MLME Max Keep Tx Tries` |          25         | 0001:0045:0a26 | This will get Max Number of attempts to send keeps to a node before it is dropped for given Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Max_Keep_Tx_Tries = int(max_keep_tx_tries)
        except ValueError:
            self._logger().exception("Max Keep Tx Tries must be either integer or string-convertible-to-integer")
            raise Exception("Max Keep Tx Tries must be either integer or string-convertible-to-integer")
         
        if (not (Max_Keep_Tx_Tries >= 1 and Max_Keep_Tx_Tries <= 128) ):
            self._logger().debug("Invalid Max Keep Tx Tries. Max Keep Tx Tries must be 1 <= Max_Keep_Tx_Tries <= 128")
            raise Exception("Invalid Max Keep Tx Tries. Max Keep Tx Tries must 1 <= Max_Keep_Tx_Tries <= 128") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Max number of attempts to send keeps to a node before it is dropped")
            command = net_mgr_and_node + ' conf mlme mlme_max_keep_tx_tries ' + str(Max_Keep_Tx_Tries)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Setting Max number of attempts to send keeps to a node failed: {}".format(e))
            raise Exception("Setting Max number of attempts to send keeps to a node failed: {}".format(e))
        return output
    
    def get_mlme_nbor_aggr_duration(self, node = None, secure_run = True):
        """This keyword gets Duration in seconds of aggr nbor qry period for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |            =Keyword=          |    =Node=      |                                   =Comment=                                |
        | `Get MLME Nbor Aggr Duration` | 0001:0045:0a26 | This will get duration in seconds of aggr nbor qry period for given Node   |
        | `Get MLME Nbor Aggr Duration` |                | This will get duration in seconds of aggr nbor qry period for default Node |
         
        This returns ``MLME Neighbor aggr duration in seconds`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_nbor_aggr_dur'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting MLME Neighbor Aggressive Duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME nbor aggr qry duration is set to )\d+', output)
            if(match):
                Nbor_Aggr_Duration = match.group(0)
                self._logger().debug('MLME nbor aggr qry duration is set to {} seconds'.format(Nbor_Aggr_Duration))
            else:
                self._logger().debug("Exception occurred while getting MLME Neighbor Aggressive Duration: {}".format(output))
                raise Exception("Exception occurred while getting MLME Neighbor Aggressive Duration: {}".format(output))
        return Nbor_Aggr_Duration 
    
    def set_mlme_nbor_aggr_duration(self, nbor_aggr_duration, node=None, secure_run = True):
        """This keyword sets Duration in seconds of aggr nbor qry period for provided node.
        
        This takes 1 mandatory argument ``nbor_aggr_duration``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |             =Keyword=         | =Max Keep Tx Tries= |     =Node=     |                                                =Comment=                                           |
        | `Set MLME Nbor Aggr Duration` |          87         | 0001:0045:0a26 | This will get Max number of attempts to send keeps to a node before it is dropped for given Node   | 
        | `Set MLME Nbor Aggr Duration` |          25         |                | This will get Max number of attempts to send keeps to a node before it is dropped for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Nbor_Aggr_Duration = int(nbor_aggr_duration)
        except ValueError:
            self._logger().exception("MLME Neighbor Aggressive Duration must be either integer or string-convertible-to-integer")
            raise Exception("MLME Neighbor Aggressive Duration must be either integer or string-convertible-to-integer")
         
        if (not (Nbor_Aggr_Duration >= 60 and Nbor_Aggr_Duration <= 60000) ):
            self._logger().debug("Invalid MLME Neighbor Aggressive Duration. MLME Neighbor Aggressive Duration must be 60 <= Nbor_Aggr_Duration <= 60000")
            raise Exception("Invalid MLME Neighbor Aggressive Duration. MLME Neighbor Aggressive Duration must 60 <= Nbor_Aggr_Duration <= 60000") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting MLME Neighbor Aggressive Duration")
            command = net_mgr_and_node + ' conf mlme mlme_nbor_aggr_dur ' + str(Nbor_Aggr_Duration)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Setting MLME Neighbor Aggressive Duration failed: {}".format(e))
            raise Exception("Setting MLME Neighbor Aggressive Duration failed: {}".format(e))
        return output
    
    def set_quick_restore(self, qr_value, node = None, secure_run = True):
        """This sets the srt quick restore value to ``qr_value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Quick Restore` | qr_value=1 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf srt quick_restore ' + str(qr_value)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set srt quick restore: {}".format(output))
            else:
                return 'Ok'
            
    def get_quick_restore(self, node = None, secure_run = True):
        """This returns the srt quick restore value of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Quick Restore` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf srt quick_restore'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Quick restore failed: {}".format(e))
        else:
            match = re.search('restore performance is set to (\d+)', output)
            if(match):
                value = match.group(1)
                self._logger().debug('restore performance is set to: {}'.format(value))
                return value
            else:
                self._logger().debug("quick restore value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("quick restore value not found")
            
    def set_mlme_max_li_out(self, value, node = None, secure_run = True):
        """This sets the maximum number of outstanding link info packets to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Mlme Max Li Out` | value=2 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_max_li_out ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set mlme_max_li_out.\n{}".format(output))
            else:
                return 'Ok'
            
            
    def get_mlme_max_li_out(self, node = None, secure_run = True):
        """This returns the maximum number of outstanding link info packets of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Mlme Max Li Out` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_max_li_out'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('Maximum # of outstanding link info packets is set to (\d+)', output)
            if(match):
                value = match.group(1)
                self._logger().debug('Maximum # of outstanding link info packets is set to: {}'.format(value))
                return value
            else:
                self._logger().debug("mlme_max_li_out value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("mlme_max_li_out value not found")
                       
    def set_mlme_nbor_aggr_rate(self, value, node = None, secure_run = True):
        """This sets the neighbor aggregation query rate to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Mlme Nbor Aggr Rate` | value=13000 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_nbor_aggr_rate ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set mlme_nbor_aggr_rate.\n{}".format(output))
            else:
                return 'Ok'
                   
    def get_mlme_nbor_aggr_rate(self, node = None, secure_run = True):
        """This returns the neighbor aggregation query rate of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Mlme Nbor Aggr Rate` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_nbor_aggr_rate'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('MLME nbor aggr qry rate is set to (\d+) msecs', output)
            if(match):
                value = match.group(1)
                self._logger().debug('neighbor aggregation query rate is set to: {}'.format(value))
                return value
            else:
                self._logger().debug("mlme_nbor_aggr_rate value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("mlme_nbor_aggr_rate value not found")
                        
    def set_mlme_sched_rate_rsp(self, value, node = None, secure_run = True):
        """This sets the MLME scheduler rate rsp to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Mlme Sched Rate Rsp` | value=1 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_sched_rate_rsp ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set mlme_sched_rate_rsp.\n{}".format(output))
            else:
                return 'Ok'
            
            
    def get_mlme_sched_rate_rsp(self, node = None, secure_run = True):
        """This returns the MLME scheduler rate rsp of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Mlme Sched Rate Rsp` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_sched_rate_rsp'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('MLME scheduler rate rsp is set to (\d+) pkts/s', output)
            if(match):
                value = match.group(1)
                self._logger().debug('MLME scheduler rate rsp is set to {} pkts/s'.format(value))
                return value
            else:
                self._logger().debug("mlme_sched_rate_rsp value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("mlme_sched_rate_rsp value not found")
                       
    def set_mlme_sched_rate(self, value, node = None, secure_run = True):
        """This sets the MLME scheduler rate to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Mlme Sched Rate` | value=1 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_sched_rate ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set mlme_sched_rate.\n{}".format(output))
            else:
                return 'Ok'
            
            
    def get_mlme_sched_rate(self, node = None, secure_run = True):
        """This returns the MLME scheduler rate of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Mlme Sched Rate` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_sched_rate'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('MLME scheduler rate is set to (\d+) pkts/s', output)
            if(match):
                value = match.group(1)
                self._logger().debug('neighbor scheduler rate is set to: {}'.format(value))
                return value
            else:
                self._logger().debug("mlme_sched_rate value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("mlme_sched_rate value not found")
            
    def set_node_max_prefer_pcnt(self, value, node = None, secure_run = True):
        """This sets the Maximum % of nodes to request from neighbors after restart is set to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Node Max Prefer Pcnt` | value=50 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme node_max_prefer_pcnt ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set node_max_prefer_pcnt.\n{}".format(output))
            else:
                return 'Ok'
            
            
    def get_node_max_prefer_pcnt(self, node = None, secure_run = True):
        """This returns the Maximum % of nodes to request from neighbors after restart of ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Node Max Prefer Pcnt` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme node_max_prefer_pcnt'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('Maximum % of nodes to request from neighbors after restart is set to (\d+) %', output)
            if(match):
                value = match.group(1)
                self._logger().debug('Maximum % of nodes to request from neighbors after restart is set to: {} %'.format(value))
                return value
            else:
                self._logger().debug("node_max_prefer_pcnt value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("node_max_prefer_pcnt value not found")
            
    def set_mac_base_backoff(self, value, node = None, secure_run = True):
        """This sets the MAC base backoff to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Mac Base Backoff` | value=50 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_base_backoff ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set mac_base_backoff.\n{}".format(output))
            else:
                return 'Ok'
            
            
    def get_mac_base_backoff(self, node = None, secure_run = True):
        """This returns the MAC base backoff of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Mac Base Backoff` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_base_backoff'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('MAC base backoff is set to (\d+) msecs', output)
            if(match):
                value = match.group(1)
                self._logger().debug('MAC base backoff is set to: {} msecs'.format(value))
                return value
            else:
                self._logger().debug("mac_base_backoff value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("mac_base_backoff value not found")
            
    def set_mac_cl_backoff(self, value, node = None, secure_run = True):
        """This sets the MAC CL backoff to ``value`` on node ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Set Mac CL Backoff` | value=2 |
        
        On success, this returns ``Ok``.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_cl_backoff ' + str(value)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Ok') == -1):
                raise Exception("Could not set mac_cl_backoff.\n{}".format(output))
            else:
                return 'Ok'
            
            
    def get_mac_cl_backoff(self, node = None, secure_run = True):
        """This returns the MAC CL backoff of node.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
       
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Example:
        
        | `Get Mac CL Backoff` |
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_cl_backoff'
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('MAC CL backoff is set to (\d+) msecs', output)
            if(match):
                value = match.group(1)
                self._logger().debug('MAC CL backoff is set to: {} msecs'.format(value))
                return value
            else:
                self._logger().debug("mac_cl_backoff value not found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("mac_cl_backoff value not found")
            
    def power_on_ap_or_node(self,socket):
        """This powers on AP/Node based on given ``socket``. 
        
        ``NOTE: This depends on the shell script which should be available on the server. e.g. ./Pi1-socket1-ON.sh.``
        """
        try:     
            command = "./Pi1-%s-ON.sh" % str(socket).lower()
            self._logger().info(command)
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except:
            self._logger().exception("could not power on AP")
            raise
        
    def power_off_ap_or_node(self,socket):
        """This powers off AP/Node based on given ``socket``. 
        
        ``NOTE: This depends on the shell script which should be available on the server. e.g. ./Pi1-socket1-OFF.sh.``
        """
        try:  
            command = "./Pi1-%s-OFF.sh" % str(socket).lower()
            self._logger().info(command)
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except:
            self._logger().exception("could not power off AP")
            raise
    def _get_modestat(self, node, tablename, secure_run):
        """
        This makes and returns the dictionary of the given table ``tablename``.
        ``tablename`` must be ``nodeq 8``.
        Note: It assumes that there are 2 special headers named ``hold bin`` and ``switch time`` 
        having space between their words. 
        No value in the table-like string should be empty.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            if(output.strip() == ''):
                return {} 
                        
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[1:]

            # remove empty lines
            while('' in output_):
                output_.remove('')

            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp

            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp

            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')
            '''
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
            '''

            output = output_[:-4]

            table = {column[0]:list(column[1:]) for column in zip(*output)}
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
			
    def get_modestat_show(self, modeid='all', data='modeid', node = None, secure_run = True):
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        if not isinstance(modeid, str):
            self._logger().debug("'modeid' must be a string but given {}".format(modeid.__class__.__name__))
            raise TypeError("'modeid' must be a string but given {}".format(modeid.__class__.__name__))
            
        try:
            modestat_table = self._get_modestat(node, 'modestat show', secure_run)
            self._logger().info(modestat_table) 
        except Exception as e:
            self._logger().exception("Could not get data from modestat show {}".format(e))
            raise Exception("Could not get data from modestat show: {}".format(e))
        else:
            if(modestat_table == {}):
                self._logger().debug("modestat show table is empty")
                raise Exception("modestat show table is empty")
            try:
                if(modeid.lower() != 'all' and data.lower() !='modeid'):
                    modeid_list = modestat_table['modeid']
                    for ind, mode_id in enumerate(modeid_list):
                        if(mode_id == modeid):
                            print(modestat_table[data][ind])  
                            return modestat_table[data][ind]
                else:
                    data_list= modestat_table[data]
                    return data_list
            except KeyError as e:
                 self._logger().exception("Invalid data '{}'".format(data)) 
                 raise Exception("Invalid data '{}'".format(data))
				 
    def _get_modechange_stat(self, node, tablename, secure_run):

        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            if(output.strip() == ''):
                return {} 
						
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[-4:]
            # remove empty lines

            while('' in output_):
                output_.remove('')
            # remove multiple spaces between values

            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp

            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp

			# remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')

            table = dict(output_)
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
    def get_modechange_stat_show(self, data=None, node = None, secure_run = True):
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")          
        try:
            modestat_table = self._get_modechange_stat(node, 'modestat show', secure_run)
            self._logger().info(modestat_table)
            data_list= modestat_table[data]
            return data_list
        except Exception as e:
            self._logger().exception("Could not get data from modestat show {}".format(e))
            raise Exception("Could not get data from modestat show: {}".format(e))
