"""
Unique frame filters are filter which is common for each unique frame set by keyword ``Set Unique Frame`` and 
provides frames and frame count data.

Please find details of unique frame filters for each frame below:
|    =UniqueFrameFilter=    |                                                  =Filter=                                                                                  |
|    RTA BROADCAST          | ((genx.rfmac.fctrl.dst_present == 0 && genx.rfmac.fctrl.src_present == 1) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 6 &&\
                              genx.dlltlv.dll_length == 0)) && (genx.mactlv.mac_tlv_t == 1) && ((genx.mactlv.mac_tlv_type == 0) && (genx.mactlv.srt.protocol == 0x01))   |
|    RTA UNICAST            | ((genx.rfmac.fctrl.dst_present == 0 && genx.rfmac.fctrl.src_present == 1) && (genx.dlltlv.dll_tlv_t == 0) &&  (genx.mactlv.mac_tlv_t == 1)\
                              && ((genx.mactlv.mac_tlv_type == 0) && (genx.mactlv.srt.protocol == 0x01))                                                                 |
|    SLOW BEACON            | ((genx.rfmac.fctrl == 0x02 && genx.rfmac.fctrl.dst_present == 0 && genx.rfmac.fctrl.src_present == 1) &&  (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 1 && genx.dlltlv.dll_length == 2) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 6 &&\
                               genx.dlltlv.dll_length == 0))                                                                                                             |
|    FAST BEACON            | ((genx.rfmac.fctrl == 0x02 && genx.rfmac.fctrl.dst_present == 0 && genx.rfmac.fctrl.src_present == 1) &&  (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 1 && genx.dlltlv.dll_length == 2) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 7 &&\
                               genx.dlltlv.dll_length == 0))                                                                                                             |
|    EVAL SCHED             | ((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0 ) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 2 &&\
                              genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 1 &&\
                               genx.mactlv.mlmetlv.longtlv.type == 3 && genx.mactlv.type_mask == 0x00020000))                                                            |
|    EVAL ACK SCHED         | ((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0 ) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 2 &&\
                              genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 1 &&\
                               genx.mactlv.mlmetlv.longtlv.type == 3 && genx.mactlv.type_mask == 0x00040000))                                                            |
|    NREG                   | ((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 2 &&\
                              genx.dlltlv.dll_length == 3) && (genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 3) && (genx.mactlv.version == 0x02 &&\
                               genx.mactlv.srt.protocol == 0x02))                                                                                                        |    
|    NREG ACK               | (genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) &&\
                              (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) && (genx.mactlv.version_proto_id == 0x13) && (genx.mactlv.version == 0x02)&&\
                               (genx.mactlv.srt.protocol == 0x03)                                                                                                        |
|    DLI PROTO ROUTING      | ((genx.rfmac.fctrl == 0x01 && genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) &&\
                               (genx.mactlv.version_proto_id == 0x13 && genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 0x03))                                |
| DLI TIME SYNC REQ RSP TLV | ((genx.rfmac.fctrl == 0x01 && genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) &&\
                              (genx.mactlv.version_proto_id == 0x13 && genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 0x03) &&\
                              (genx.mactlv.dli_has_tlv == 1) && (genx.mactlv.tlv_id == 0x02 && genx.mactlv.reserved == 00) &&\
                              (genx.mactlv.type == 2 && genx.mactlv.version == 0x01))                                                                                    |
|    DLI PAYLOAD TLV        | ((genx.rfmac.fctrl == 0x01 && genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) &&\
                              (genx.mactlv.version_proto_id == 0x13 && genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 0x03) &&\
                              (genx.mactlv.dli_has_tlv == 1) && (genx.mactlv.tlv_id == 0x01 && genx.mactlv.reserved == 00))                                              |
|   MLME LI AGGRESSIVE\
    DISCOVERY               | (genx.rfmac.fctrl.src_present == 1 && genx.rfmac.fctrl.dst_present == 0) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 1)\
                              && (genx.mactlv.mlmetlv.tlv.t == 0 && genx.mactlv.mlmetlv.shorttlv.type == 64)                                                             |
|   MLME LI UPSTREAM\
    DISCOVERY               | (genx.rfmac.fctrl.src_present == 1 && genx.rfmac.fctrl.dst_present == 0) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 1)\
                              && (genx.mactlv.mlmetlv.tlv.t == 0 && genx.mactlv.mlmetlv.shorttlv.type == 64)&& (genx.mactlv.litlv == 0x11 &&\
                              genx.litlv.disc_flags == 0x01)                                                                                                             |
|  MLME LI REBUILD NODEQ    | ( genx.rfmac.fctrl.src_present == 1 && genx.rfmac.fctrl.dst_present == 0) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 1)\
                              && (genx.mactlv.mlmetlv.tlv.t == 0 && genx.mactlv.mlmetlv.shorttlv.type == 64)&& (genx.mactlv.litlv == 0x11 &&\
                              genx.litlv.disc_flags == 0x10)                                                                                                             |
|    MLME LI RSP QRY        | (genx.rfmac.fctrl.dst_present == 1) && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 2)\
                              && (genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1) && (genx.mactlv.mac_tlv_type == 1) &&\
                              (genx.mactlv.mlmetlv.tlv.t == 0) && (genx.mactlv.mlmetlv.shorttlv.type == 66)                                                              |
|    MLME LI RSP            | (genx.rfmac.fctrl.dst_present == 1) && (genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 2)\
                              && (genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1) && (genx.mactlv.mac_tlv_type == 1) &&\
                              (genx.mactlv.mlmetlv.tlv.t == 0) && (genx.mactlv.mlmetlv.shorttlv.type == 65)                                                              |
|    DNS RESPONSE           | (((((genx.rfmac.fctrl.dst_present == 1)) && (genx.rfmac.fctrl.src_present == 0)) && (genx.dlltlv.dll_type == 2))&&\
                              (genx.mactlv.version_proto_id == 0x16) && (genx.mactlv.mac_tlv_type == 0)&&(dns.flags.response == 1)) && (udp.srcport == 53)&&\
                              (genx.mactlv.mac_tlv_type == 4)                                                                                                            |
|    TUPD                   | (genx.rfmac.fctrl.dst_present == 1) && (genx.rfmac.fctrl.src_present == 1) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 1)\
                              && (genx.dlltlv.dll_length == 2) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 2) && (genx.dlltlv.dll_length == 3)&&\
                              (genx.mactlv.mac_tlv_t == 1) && (genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 0) &&\
                             (genx.mactlv.mlmetlv.shorttlv.type == 69)                                                                                                   |
|    DNS REQUEST            | (((((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_type == 2 &&\
                              genx.mactlv.mac_tlv_type == 0)) && (genx.mactlv.version_proto_id == 0x16))) && (udp.dstport == 53)) && (dns.flags.response == 0)&&\
                              (genx.mactlv.mac_tlv_type == 4)                                                                                                            |
|    NBOR QRY TLV           | (genx.rfmac.fctrl.dst_present == 1) && (genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 2)\
                              && (genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1) && (genx.mactlv.mac_tlv_type == 1) &&\
                              (genx.mactlv.mlmetlv.tlv.t == 1) && (genx.mactlv.mlmetlv.longtlv.type == 7)                                                                |
|    NBOR RSP TLV           | (genx.rfmac.fctrl.dst_present == 1) && (genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0) && (genx.dlltlv.dll_type == 2)\
                              && (genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1) && (genx.mactlv.mac_tlv_type == 1) &&\
                              (genx.mactlv.mlmetlv.tlv.t == 1) && (genx.mactlv.mlmetlv.longtlv.type == 4)                                                                |
|    KEEP SCHED             | ((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0 ) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 2 &&\
                              genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 1 &&\
                               genx.mactlv.mlmetlv.longtlv.type == 3 && genx.mactlv.type_mask == 0x00008000))                                                            |
|    KEEP ACK SCHED         | ((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0 ) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 2 &&\
                              genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 1 &&\
                               genx.mactlv.mlmetlv.longtlv.type == 3 && genx.mactlv.type_mask == 0x00010000))                                                            |   
|    CULL SCHED             | ((genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0 ) && (genx.dlltlv.dll_tlv_t == 0 && genx.dlltlv.dll_type == 2 &&\
                              genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 1 &&\
                               genx.mactlv.mlmetlv.longtlv.type == 3 && genx.mactlv.type_mask == 0x00400000))                                                            |
|    DLI PROTO TRACE        | ((genx.rfmac.fctrl == 0x01 && genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) &&\
                               (genx.mactlv.version_proto_id == 0x17 && genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 0x07))                             |
|    DLI PROTO TIMESYNC     | ((genx.rfmac.fctrl == 0x01 && genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) &&\
                               (genx.mactlv.version_proto_id == 0x18 && genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 0x08))                          |
|    DLI PROTO IP           | ((genx.rfmac.fctrl == 0x01 && genx.rfmac.fctrl.dst_present == 1 && genx.rfmac.fctrl.src_present == 0) && (genx.dlltlv.dll_tlv_t == 0 &&\
                              genx.dlltlv.dll_type == 2 && genx.dlltlv.dll_length == 3) && (genx.mactlv.mac_tlv_t == 1 && genx.mactlv.mac_tlv_type == 0) &&\
                               (genx.mactlv.version_proto_id == 0x16 && genx.mactlv.dli_version == 0x01 && genx.mactlv.proto_id == 0x06))                                |
|    MLME LI MAC BCAST      | ((genx.rfmac.fctrl.src_present == 1 && genx.rfmac.fctrl.dst_present == 0) && (genx.mactlv.mac_tlv_t == 1 &&\
                              genx.mactlv.mac_tlv_type == 1) && (genx.mactlv.mlmetlv.tlv.t == 0 && genx.mactlv.mlmetlv.shorttlv.type == 73))                             |                            

"""