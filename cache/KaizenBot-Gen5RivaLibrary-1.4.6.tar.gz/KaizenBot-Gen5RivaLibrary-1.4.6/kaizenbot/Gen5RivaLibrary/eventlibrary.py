# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from kaizenbot.logging_robot import Loggers
import os
from kaizenbot.connection import Connection
import csv, re
from pathlib import Path
from time import gmtime, strftime, localtime

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class EventLibrary:
    
    def __init__(self):
        pass
    
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError
    
    def disable_event(self, eventID, node = None, secure_run = True):
        """This keyword disables the event or events for the provided node IP.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` (case sensitive) on success.
        
        = Examples =
        |     =Keyword=   |  =eventID=  |      =node=    |                   =Comment=                        |
        | `Disable Event` | all         | 0001:0045:0a26 | This will disable all event                        |
        | `Disable Event` | 240         | 0001:0045:0a26 | This will disable event 240                        |
        | `Disable Event` | 239,240,250 | 0001:0045:0a26 | This will disable events 239,240,250               |
        | `Disable Event` | 239         |                | This will take default node and disable event 239  |
        | `Disable Event` | mlme        |                | This will take default node and disable event mlme |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        if(isinstance(eventID, list)):
            eventID = str(eventID)
        eventID = eventID.replace(' ','')
        eventID = eventID.replace('[','')
        eventID = eventID.replace(']','')
        eventID = eventID.lower()
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            EventID = re.search(r'\d+', eventID)
            if (EventID != None):
                command = net_mgr_and_node + ' evstatus ['+eventID+']:off'
            else:
                command = net_mgr_and_node + ' evstatus '+eventID+':off'
                
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
        except Exception as e:
            self._logger().exception("Disabling event failed: {}".format(e))
            raise Exception("Disabling event failed: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Disable Event failed: {}".format(output))
                raise Exception("Disable Event failed: {}".format(output))
            else:
                self._logger().info('Disabled event successfully: {}'.format(eventID))
                self._logger().debug(output)
            return 'Ok'

    def enable_event(self, eventID, node = None, secure_run = True):
        """This keyword enables the event or events for the provided node IP.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``Ok`` (case sensitive) on success.
        
        = Examples =
        |     =Keyword=   |  =eventID=  |      =node=    |                     =Comment=                     |
        | `Enable Event`  | all         | 0001:0045:0a26 | This will enable all event                        |
        | `Enable Event`  | 240         | 0001:0045:0a26 | This will enable event 240                        |
        | `Enable Event`  | 239,240,250 | 0001:0045:0a26 | This will enable events 239,240,250               |
        | `Enable Event`  | 239         |                | This will take default node and enable event 239  |
        | `Enable Event`  | mlme        |                | This will take default node and enable event mlme |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        if(isinstance(eventID, list)):
            eventID = str(eventID)
        eventID = eventID.replace(' ','')
        eventID = eventID.replace('[','')
        eventID = eventID.replace(']','')
        eventID = eventID.lower()
        output = 'Fail'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            EventID = re.search(r'\d+', eventID)
            if (EventID != None):
                command = net_mgr_and_node + ' evstatus ['+eventID+']:on'
            else:
                command = net_mgr_and_node + ' evstatus '+eventID+':on'
                
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Enable Event failed: {}".format(e))
            raise Exception("Enable Event failed: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Enable Event failed: {}".format(output))
                raise Exception("Enable Event failed: {}".format(output))
            else:
                self._logger().info('Enabled event successfully: {}'.format(eventID))
                self._logger().debug(output)
            return 'Ok'
    
    def verify_enabled_event(self, eventID, Event, node = None, secure_run = True):
        """This keyword takes eventID as mandatory argument and verifies
        that the provided eventID is enabled or not for the provided node IP.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``True`` on success.
        
        = Examples =
        |         =Keyword=       |  =eventID=  |         =Event=        |    =node=      |                                     =Comment=                                |
        | `Verify Enabled Event`  |    240      |      MAC TX BEACON     | 0001:0045:0a26 | This will verify MAC TX BEACON Event for 240 Event ID for provided node      |
        | `Verify Enabled Event`  |    239      |  MAC FAST BEACON EVENT |                | This will verify MAC FAST TX BEACON Event for 239 Event ID for default node  |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        result_flag = False
        try:
            if(eventID == ''):
                self._logger().debug("No NIC IP provided by User to execute command")
                raise Exception("No NIC IP provided by User to execute command")
            else:
                if(secure_run):
                    net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
                else:
                    net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                    
                command = net_mgr_and_node + ' evstatus'
                output = Connection.execute_command(self, command)
                self._logger().debug(output)
                self._logger().info('Executed command for NIC with IP: {}'.format(node))
                if Event in output:
                    self._logger().info("Verified event {} is enabled for event ID: {}".format(Event, eventID))
                    result_flag = True
                else:
                    result_flag = False
                    self._logger().info(output)
                    self._logger().debug("Failed to verify event in event status: {}".format(output))
                    raise Exception("Failed to verify event in event status: {}".format(output))
        except Exception as e:
            self._logger().exception("Exception occurred in verifying enabled event: {}".format(e))
            raise Exception("Exception occurred in verifying enabled event: {}".format(e))
        return result_flag
    
    def verify_enabled_events(self, eventIDs, node = None, secure_run = True):
        """This keyword takes eventIDs as mandatory argument and verifies
        that the provided eventIDs are enabled or not for the provided node IP.
        User need to provide eventIDs as list
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``True`` on success.
        
        = Examples =
        |         =Keyword=        |  =eventIDs=  |    =node=      |                 =Comment=                   |
        | `Verify Enabled Events`  | [240, 239]   | 0001:0045:0a26 | This will verify eventIDs for provided node |
        | `Verify Enabled Events`  | [240, 239]   |                | This will verify eventIDs for default node  |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        result_flag = False
        try:
            if(eventIDs == [] or eventIDs ==''):
                self._logger().debug("No NIC IP provided by User to execute command")
                raise Exception("No NIC IP provided by User to execute command")
            else:
                if(secure_run):
                    net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
                else:
                    net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                    
                command = net_mgr_and_node + ' evstatus'
                output = Connection.execute_command(self, command)
                self._logger().info('Executed command for NIC with IP: {}'.format(node))
                self._logger().info(output)
                for data in eventIDs:
                    if str(data) in output:
                        self._logger().debug("Verified event {} is enabled.".format(str(data)))
                        result_flag = True
                    else:
                        result_flag = False
                        self._logger().debug("Failed to verify event in event status: {}".format(output))
                        raise Exception("Failed to verify event in event status: {}".format(output))
        except Exception as e:
            self._logger().exception("Exception occurred in verifying enabled event: {}".format(e))
            raise Exception("Exception occurred in verifying enabled event: {}".format(e))    
        else:
            self._logger().info("Verified events {} are enabled.".format(eventIDs))
            return result_flag
    

    def capture_event_log(self, filename, event=None, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the event log for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        Any specific event can be given using ``event``. ``event`` is new in version 0.6.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the event log.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=        |  =Filename= | =event= |                   =Filter=                   |      =node=    |  =ignore_case= |                                             =Comment=                                     |
        | `Capture Event Log`  | TC123_step1 |         | filter=MAC TX BEACON: Success AND type=slow  | 0001:0045:0a26 |      True      | This will capture event log for filetred data as TC123_step1_evtlog.csv for provided node |
        | `Capture Event Log`  | TC124_step5 |         | filter=MAC TX BEACON: Success                | 0001:0045:0a26 |      False     | This will capture event log for filetred data as TC124_step5_evtlog.csv for provided node |
        | `Capture Event Log`  | TC234_Step7 |         |                                              | 0001:0045:0a26 |                | This will capture event log as TC243_step7_evtlog.csv for provided node                   |
        | `Capture Event Log`  | TC234_Step4 |         |                                              |                |                | This will capture event log as TC243_step4_evtlog.csv for provided node                   |
        | `Capture Event Log`  | TC234_Step4 |  dns    |                                              |                |                | This will capture dns event log as TC243_step4_evtlog.csv for provided node               |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        event = ' ' + event if event else ''
            
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' evtlog' + event + filter_cmd

            output = Connection.execute_command(self, command)
            self._logger().debug(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_evtlog_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
        
    def capture_nlog(self, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the nlog for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the nlog.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=   |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                              |
        | `Capture nlog`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture nlog for filtered data as TC123_step1_nlog.csv for provided node |
        | `Capture nlog`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture nlog for filtered data as TC124_step5_nlog.csv for provided node |
        | `Capture nlog`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture nlog as TC243_step7_nlog.csv for provided node                   |
        | `Capture nlog`  | TC234_Step4 |                             |                |                | This will capture nlog as TC243_step4_nlog.csv for provided node                   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nlog show' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_nlog_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def capture_nexthop_table(self, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the nexthop table for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the nexthop table.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=            |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                                          |
        | `Capture nexthop table`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture nexthop table for filtered data as TC123_step1_nexthop.csv for provided node |
        | `Capture nexthop table`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture nexthop table for filtered data as TC124_step5_nexthop.csv for provided node |
        | `Capture nexthop table`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture nexthop table as TC243_step7_nexthop.csv for provided node                   |
        | `Capture nexthop table`  | TC234_Step4 |                             |                |                | This will capture nexthop table as TC243_step4_nexthop.csv for provided node                   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nexthop show' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_nexthop_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def capture_bad_nodeq(self, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the bad nodeq for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the bad nodeq.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=        |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                                        |
        | `Capture Bad Nodeq`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture bad nodeq for filtered data as TC123_step1_bad_nodeq.csv for provided node |
        | `Capture Bad Nodeq`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture bad nodeq for filtered data as TC124_step5_bad_nodeq.csv for provided node |
        | `Capture Bad Nodeq`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture bad nodeq as TC243_step7_bad_nodeq.csv for provided node                   |
        | `Capture Bad Nodeq`  | TC234_Step4 |                             |                |                | This will capture bad nodeq as TC243_step4_bad_nodeq.csv for provided node                   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' bad_nodeq' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_bad_nodeq_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def capture_nodeq_whitelist(self, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the nodeq whitelist for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the nodeq whitelist.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=              |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                                                    |
        | `Capture Nodeq Whitelist`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture nodeq whitelist for filtered data as TC123_step1_nodeq_whitelist.csv for provided node |
        | `Capture Nodeq Whitelist`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture nodeq whitelist for filtered data as TC124_step5_nodeq_whitelist.csv for provided node |
        | `Capture Nodeq Whitelist`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture nodeq whitelist as TC243_step7_nodeq_whitelist.csv for provided node                   |
        | `Capture Nodeq Whitelist`  | TC234_Step4 |                             |                |                | This will capture nodeq whitelist as TC243_step4_nodeq_whitelist.csv for provided node                   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nodeq_whitelist show' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_nodeq_whitelist_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def capture_trnet_log(self, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the trnet log for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the trnet logs.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=        |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                                |
        | `Capture trnet log`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture trnet for filtered data as TC123_step1_trnet.csv for provided node |
        | `Capture trnet log`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture trnet for filtered data as TC124_step5_trnet.csv for provided node |
        | `Capture trnet log`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture trnet as TC243_step7_trnet.csv for provided node                   |
        | `Capture trnet log`  | TC234_Step4 |                             |                |                | This will capture trnet as TC243_step4_trnet.csv for provided node                   |
          
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' trnet show log' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_trnet_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def capture_nodeq(self, nodeq, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the nodeq ``nodeq`` for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the nodeq.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=    |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                                |
        | `Capture nodeq`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture nodeq for filtered data as TC123_step1_nodeq.csv for provided node |
        | `Capture nodeq`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture nodeq for filtered data as TC124_step5_nodeq.csv for provided node |
        | `Capture nodeq`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture nodeq as TC243_step7_nodeq.csv for provided node                   |
        | `Capture nodeq`  | TC234_Step4 |                             |                |                | This will capture nodeq as TC243_step4_nodeq.csv for provided node                   |
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            nodeq = int(nodeq)
            if(nodeq < 0 or nodeq > 12):
                self._logger().debug("ValueError")
                raise ValueError("nodeq must be between 0-12 inclusive")
        except ValueError:
            self._logger().exception("nodeq must be between 0-12 inclusive")
            raise ValueError("nodeq must be between 0-12 inclusive")        
        
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' nodeq ' + str(nodeq) + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_nodeq_%s_%s.csv" % (str(nodeq),strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def capture_stats(self, stat, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the stat ``stat`` for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the stats.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=    |  =Filename= |         =Filter=            |      =node=    |  =ignore_case= |                                             =Comment=                                |
        | `Capture stats`  | TC123_step1 | filter=string1 AND string2  | 0001:0045:0a26 |      True      | This will capture stats for filtered data as TC123_step1_stats.csv for provided node |
        | `Capture stats`  | TC124_step5 | filter=string               | 0001:0045:0a26 |      False     | This will capture stats for filtered data as TC124_step5_stats.csv for provided node |
        | `Capture stats`  | TC234_Step7 |                             | 0001:0045:0a26 |                | This will capture stats as TC243_step7_stats.csv for provided node                   |
        | `Capture stats`  | TC234_Step4 |                             |                |                | This will capture stats as TC243_step4_stats.csv for provided node                   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")       
        
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' stat ' + str(stat) + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_stat_%s_%s.csv" % (str(stat),strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def verify_all_events_from_log(self, filename, *events):
        """This keyword verifies availability of all events from the captured logs for the provided node IP.
        
        ``filename`` is mandatory argument which can be used from either output of ``capture_xxx`` method.  
        xxx can be event_log, nlog, nexthop show etc or by providing the filename from 'Logs' folder.
        
        ``*events`` is mandatory argument which takes one or multiple events and verifies presence of all in log.
        
        This returns ``True`` on success if all events are available in captured log file.
        
        = Examples =
        |            =Keyword=         |    =Filename=   |                   =*Events=             |                                =Comment=                               |
        | `Verify All Events From Log` | TC123_step1.csv | MAC TX BEACON    success    type=slow   | This will verify provided events in each row of TC123_step1_evtlog.csv |
        | `Verify All Events From Log` | TC124_step5.csv | MAC TX BEACON    success                | This will verify provided events in each row of TC124_step5_evtlog.csv |
        """
        fields =[]
        if os.path.exists(os.path.normpath(DestDir) +'/' + filename):
            self._logger().info("Verified file exists")
        else:
            self._logger().debug("Failed to find file in Output Folder")
            raise Exception("Failed to find file in Output Folder")
        with open(os.path.normpath(DestDir) +'/' + filename, 'r') as file1:
            line = file1.readlines()
        for element in line:
            for event in events:
                if event in element:
                    result = True
                else:
                    result = False
                    self._logger().debug("Failed to verify events from log")
                    raise Exception("Failed to verify events from log")
        return result
    
    def get_timestamp_from_event_log(self, filename, count, filter = None, ignore_case = True):
        """This keyword gets timestamp for each event from event log.
        
        ``filename`` is mandatory argument which can be used from output of ``capture_xxx`` method.  
        xxx can be event_log, nlog, nexthop show etc.
        
        ``count`` is mandatory argument which is used to get ``count`` number of timestamps from event log.
        
        ``filter`` is optional argument which takes specific event for which timestamp need to be checked.
        
        This returns ``list of timestamp`` on success if events are available in captured log file for provided ``count``.
        
        = Examples =
        |              =Keyword=         |    =Filename=   | =count= |                    =filter=                 | =ignore_case= |                                   =Comment=                                |
        | `Get Timestamp From Event Log` | TC123_step1.csv |    4    | filter=MAC TX BEACON: Success AND type=slow |      True     | This will get timestamp for provided count and filter from TC124_step5.csv |
        | `Get Timestamp From Event Log` | TC124_step5.csv |    2    | filter=MAC TX BEACON: Success AND type=slow |      False    | This will get timestamp for provided count and filter from TC124_step5.csv |
        | `Get Timestamp From Event Log` | TC124_step5.csv |    2    |                                             |               | This will get timestamp for provided count from TC124_step5.csv            |
        """
        try:
            count = int(count)
        except ValueError as error:
            self._logger().exception("'count' must be integer or string-convertible-to-integer")            
            raise Exception("'count' must be integer or string-convertible-to-integer")
        
        if os.path.exists(os.path.normpath(DestDir) +'/' + filename):
            self._logger().info("Verified file exists")
        else:
            self._logger().error("No file {} in {}".format(filename, DestDir))
            raise FileNotFoundError("No file {} in {}".format(filename, DestDir))
        
        with open(os.path.normpath(DestDir) +'/' + filename, 'r') as file1:       
            loglines = file1.readlines()
            file1.close()
        
        search_str = '(.*:\s+)([\d]+\.[\d]+)'
        
        if(filter is not None):
            search_tokens = filter.split(' AND ')
            for token in search_tokens:
                search_str += '(.*)' + '(' + token + ')'   
        c = 0
        timestamp_list = []
    
        for line in loglines:
           
            if(c == count):
                break
            if(ignore_case):
                match=re.findall(search_str, line, re.IGNORECASE)
            else:
                match=re.findall(search_str, line)
            if(len(match) > 0):
                timestamp_list.append(match[0][1])    
                c = c + 1
        if(len(timestamp_list) > 0 and c < count):
            self._logger().debug("less than {} timestamps captured".format(count))
            raise Exception("less than {} timestamps captured".format(count))
        timestamp_list.reverse()
        return timestamp_list
    
    def calculate_timestamp_difference(self, *timestamp_list):
        """This keyword will calculate timestamp difference for provided timestamps list.
        
        ``timestamp_list`` is mandatory argument which can be used from output of ``get_timestamp_from_event_log`` method 
         or user can provide list of timestamp.
        
        This returns ``list of timestamp difference`` on success if timestamp list is provided with data.
        
        = Examples =
        |              =Keyword=           |           =timestamp_list=            |                            =Comment=                           |
        | `Calculate Timestamp Difference` | [671.249360, 971.249360, 1271.249360] | This will calculate difference and provide output as [300,300] |
        """
        timediff = []
        if(not timestamp_list):
            self._logger().debug("No timestamps given")
            raise Exception("No timestamps given")
        
        if((len(timestamp_list)==1) and isinstance(timestamp_list[0], list)):
            timestamp_list=timestamp_list[0]
        else:
            timestamp_list=list(timestamp_list)
            
        if(len(timestamp_list) == 1):
            self._logger().debug("Need at least 2 timestamps; got only 1")
            self._logger().info(timestamp_list)
            raise Exception("Need at least 2 timestamps; got only 1")
        
        try:
            float_list = [float(x) for x in timestamp_list]
            for i in range(0, len(float_list)-1):
                timedi = float_list[i+1]-float_list[i]
                timediff.append(round(timedi))
            self._logger().info(timediff)
        except ValueError:
            self._logger().exception("timestamps must be numbers")
            self._logger().info(timestamp_list)
            raise Exception("timestamp must be numbers")
        return timediff
    
    def clear_event(self, node = None, secure_run = True):
        """This keyword clears the event of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``Ok`` (case sensitive) on success.
        
        = Examples =
        |    =Keyword=  |     =node=     |               =Comment=                 |
        | `Clear Event` | 0001:0045:0a26 | This will clear event for provided node |
        | `Clear Event` |                | This will clear event for default node  |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' event clear'
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: {} successfully'.format(node))
        except Exception as e:
            self._logger().exception("clear event failed: {}".format(e))
            raise Exception("clear event failed: {}".format(e))
        
        else:
            if(output.find('Ok') == -1):
                return 'Fail'
            else:
                return 'Ok'
            
    def capture_event(self, filename, filter = None, node = None, ignore_case=False, secure_run = True):
        """This keyword captures the event for the provided node IP and saves it in a file.
        
        ``filename`` is mandatory argument to save the file with provided name in =csv= format.  
        
        This takes 2 optional arguments ``node`` and ``filter``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the event.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``filename`` of the captured file on success which can be used by other methods
         to verify data from captured file.
        
        = Examples =
        |     =Keyword=    |  =Filename= |                   =Filter=                   |      =node=    |  =ignore_case= |                                         =Comment=                                     |
        | `Capture Event`  | TC123_step1 | filter=MAC TX BEACON: Success AND type=slow  | 0001:0045:0a26 |      True      | This will capture event for filetred data as TC123_step1_evtlog.csv for provided node |
        | `Capture Event`  | TC124_step5 | filter=MAC TX BEACON: Success                | 0001:0045:0a26 |      False     | This will capture event for filetred data as TC124_step5_evtlog.csv for provided node |
        | `Capture Event`  | TC234_Step7 |                                              | 0001:0045:0a26 |                | This will capture event as TC243_step7_evtlog.csv for provided node                   |
        | `Capture Event`  | TC234_Step4 |                                              |                |                | This will capture event as TC243_step4_evtlog.csv for provided node                   |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' event' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("Nothing To Capture: {}".format(output))
            self._logger().info(output)
            raise Exception("Nothing To Capture: {}".format(output))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filepath = os.path.join(DestDir, filename +"_event_%s.csv" % (strftime("%Y-%m-%d_%Hh-%Mm-%Ss", localtime())))
            f=open(filepath,"w", newline='')
            f.write(output)
            filename = Path(filepath).name
            f.close()
            # make it relative
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("could not capture log: {}".format(e))
            raise Exception("could not capture log: {}".format(e))
        return filename
    
    def clear_stat(self, stat_type, node=None, secure_run = True):
        """This keyword clears the stat ``stat_type`` of provided node.
        
        This takes 1 mandatory argument ``stat_type``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |   =Keyword=  | =Stat Type= |     =Node=     |                     =Comment=                    |
        | `Clear Stat` |    dns      | 0001:0045:0a26 | This will clear dns stat values for given Node   |
        | `Clear Stat` |    srt      |                | This will clear srt stat values for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Clearing {} stat values".format(stat_type))
            command = net_mgr_and_node + ' stat ' +str(stat_type) + ' clear'
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception("Clearing of {} stat failed. Output is {]".format(stat_type, e))
            raise Exception("Clearing of {} stat failed. Output is {]".format(stat_type, e))
        return output
    
    def verify_events_from_log(self, filename, *events):
        """This keyword verifies availability of provided events from the captured logs for the provided node IP.
        
        ``filename`` is mandatory argument which can be used from either output of ``capture_xxx`` method.  
        xxx can be event_log, nlog, nexthop show etc or by providing the filename from 'Logs' folder.
        
        ``*events`` is mandatory argument which takes one or multiple events and verifies presence of all in log.
        
        This returns ``True`` on success if all events are available in captured log file.
        
        = Examples =
        |          =Keyword=       |    =Filename=   |               =*Events=            |                                =Comment=                               |
        | `Verify Events From Log` | TC123_step1.csv | MAC TX BEACON    MLME EVT    SRT   | This will verify provided events in any row of TC123_step1_evtlog.csv |
        | `Verify Events From Log` | TC124_step5.csv | MAC TX BEACON    NODE LOCK         | This will verify provided events in any row of TC124_step5_evtlog.csv |
        """
        fields =[]
        if os.path.exists(os.path.normpath(DestDir) +'/' + filename):
            self._logger().info("Verified file exists")
        else:
            self._logger().info("Failed to find file in Output Folder")
            raise Exception("Failed to find file in Output Folder")
        
        try:
            with open(os.path.normpath(DestDir) +'/' + filename, 'rt') as file1:
                reader=csv.reader(file1)
                for lines in reader:
                    self._logger().info(lines)
                    for event in events:
                        if event in lines[0]:
                            result = True
                        elif ('No Events to Dump' in lines[0]):
                            result=False   
                        elif not event in lines[0]:
                            continue                         
                        else:
                            break
                            result = False
                            self._logger().debug("Failed to verify events from log")
                            raise Exception("Failed to verify events from log")
        except:
            self._logger().exception("Failed to verify events from log")
            raise Exception("Failed to verify events from log")
        else:
            if(result is not None):
                return result
            else:
                self._logger().debug("Failed to verify events from log: {}".format(lines[0]))
                raise Exception("Failed to verify events from log: {}".format(lines[0]))
    