from kaizenbot.server import Server
from kaizenbot.logging_robot import Loggers
from robot.libraries.BuiltIn import BuiltIn
import re, os, time, hashlib
from pathlib import Path
from kaizenbot.exceptions import MACNotFoundError, NodeUnreachableError

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

log_obj = Loggers()
logger = log_obj.get_logger('KaizenBot')

class G5RNode:
    def __init__(self, ip, username, password, logger=None):
        self.ip = ip
        self.username = username
        self.password = password
        self.server_handle = None   
        self.logger=logger 
        
    def _logger(self):
        #log_obj = Loggers()
        #logger = log_obj.get_logger('KaizenBot')
        if logger:
            return logger
        else:
            raise Exception("logger is empty")  
        
    def login(self):
        """This creates a server object
        """
        self.server_handle = Server(self.ip, self.username, self.password)
        
    def logout(self):
        """This closes all open connections
        """
        if(not self.server_handle):
            return
        if(self.server_handle.scpclient):
            self.server_handle.scpclient.close()
        if(self.server_handle.client):
            self.server_handle.client.close()
            
    def is_up(self):
        """This tries to login to node and execute ``echo hello`` command.
        If the command runs successfully, It returns ``True`` otherwise ``False``.
        """
        
        try:
            output = self.execute_command('echo hello')
            self._logger().debug(output)
            if(output.find('hello') != -1):    # if(output == 'hello\n')
                return True
        except Exception as e:
            self._logger().exception(e)
            return False
    
    def new_session(self):
        try:
            self.login()
        except Exception as e:
            self.logout()
            self._logger().exception("Could not start session: {}".format(e))
            raise Exception("Could not start session: {}".format(e))        
            
    def restart_session(self):
        try:
            self.logout()
            self.login()
        except Exception as e:
            self.logout()
            self._logger().exception("Could not restart session: {}".format(e))
            raise Exception("Could not restart session: {}".format(e))
                
    def execute_command(self, command):
        """This executes command ``command`` on the node.
        """
        try:
            if(self.server_handle):
                self._logger().debug("Executing command '{}'".format(command))
                return self.server_handle._execute_command(command)
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)
        
    def put_file(self, file, remote_dest):
        """This copies the file ``file`` from the local machine to ``remote_dest`` on the node.
        """
        try:
            if(self.server_handle):     
                self.server_handle._put_file(file, remote_dest)
        except Exception as e:
            self._logger().exception("Copy failed. Error: " + str(e))
            raise RuntimeError(e)
        
    def file_exists(self, file):
        """This checks if file ``file`` exists on the node.
        In such case, it returns ``True`` otherwise ``False``.
        """
        try:
            if(self.server_handle):  
                return self.server_handle._file_exists(file)
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)
            
    def directory_exists(self, dir):
        """This checks if directory ``dir`` exists on the node.
        In such case, it returns ``True`` otherwise ``False``.
        """
        try:
            if(self.server_handle):  
                return self.server_handle._dir_exists(dir)
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)
            
    def is_bare(self):
        """This is not used but it has been kept for future use.
        This search for the word ``davinci`` in the output of modversion.sh and
        returns ``True`` if it is found otherwise ``False``. 
        """
        self._logger().debug("checking if node is bare")
        try:
            output = self.execute_command('modversion.sh')
            #self._logger().debug(output)
            if(output.find('Gen5RivaMeter') == -1 or not output.find('AsicMeter') == -1):
                return True
            return False
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)  

    #def is_upgraded(self, A7_toBeUpgraded, rf_toBeUpgraded):
    def is_upgraded(self, A7_toBeUpgraded):    ##updated as per latest file name change
        """This checks if node is bare and A7 version is already up-to-date.
        In this case. It returns ``True`` otherwise ``False``. 
        """
        self._logger().debug("checking if node is already upgraded")
        if( not self.is_bare() and
            A7_toBeUpgraded == self.get_A7_version()): #and 
            #rf_toBeUpgraded == self.get_rf_version()):
            return True
        return False    
        
    def get_rf_version(self):
        """This returns the rf/dsp version.
        """
        self._logger().debug("Fetching RF/DSP version")
        try:
            output = self.execute_command('pib -gn /rf_mac/hardcoded/system/sys_app_version --raw')
            self._logger().info(output)
            RFVersion=output.split('_')[2]
            if(RFVersion):
                self._logger().debug(RFVersion)
                return RFVersion
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
            
    def get_A7_version(self):
        """This returns the A7 version.
        """
        self._logger().debug("Fetching A7 version")
        try:
            output = self.execute_command('TransactionProcess --event="MUSE_V1;ReadLid;ILID_SYSTEM_FW_VERSION"')
            self._logger().info(output)
            match = re.search('String=(.*)', output)
            if(match):
                FW_Version = match.group(1)
                self._logger().debug(FW_Version) 
            return str(FW_Version)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
    
    def logmodversion(self):
        """This function can be used to log the output of modversion.sh
        """
        self._logger().debug("logging output of modversion.sh")
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
                
            if self.is_up():
                output = self.execute_command('modversion.sh')
                self._logger().debug(output)
            else:
                output = "Node %s is not up; could not execute modversion.sh" % self.ip
                self._logger().debug(output)
            filename = 'modversion_' + time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())+ '.txt'
            filepath = os.path.join(DestDir, filename)
            f=open(filepath,"w", newline='')
            f.write(output)
            f.close()
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)
        
    def logimprovhelper(self, improvhelper_waittime):
        """This function can be used to log the output of ImProvHelper.sh
        """
        try:
            improvhelper_waittime = int(improvhelper_waittime)
        except ValueError:
            self._logger().exception("'improvhelper_waititme':{} must be integer or string-convertible-to-integer".format(improvhelper_waittime))
            raise ValueError("'improvhelper_waititme':{} must be integer or string-convertible-to-integer".format(improvhelper_waittime))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            output = ''
            if(self.server_handle):
                chan = self.server_handle._invoke_shell()
                chan.send('ImProvHelper.sh\n')
                time.sleep(improvhelper_waittime)
                chan.send(chr(3))
                while(chan.recv_ready()):
                    data = chan.recv(1024)
                    output += data.decode()
                    self._logger().debug(output)
                chan.close()
            filename = 'ImProvHelper_' + time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())+ '.txt'
            filepath = os.path.join(DestDir, filename)
            f=open(filepath,"w", newline='')
            f.write(output)
            f.close()
            print("*HTML* <a href={}>{}</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)
            
    def A7_upToDate(self, A7_version_toBeUpgraded):
        """This checks if A7 is already up-to-date.
        """
        if A7_version_toBeUpgraded == self.get_A7_version():
            return True
        return False
    
    #This keyword is not needed as per latest build filename    
    def _dsp_rf_upToDate(self, rf_version_toBeUpgraded):
        """It checks if the dsp is already up-to-date.
        """
        if rf_version_toBeUpgraded == self.get_rf_version():
            return True
        return False
        
    def wait_until_up(self, retry, interval):
        """This checks for ``retry`` seconds with the interval of ``interval`` seconds after each retry that if ``node`` is up and is being accessed.
        It passes if ``node``is up and exits. It fails if ``node`` is not up after the ``retry`` seconds.
        
        Example:
        
        | = Keyword =     | = retry = | = interval = | = comment =                                                                 |
        | `Wait Until Up` | retry=600 | interval=90  | # at every 90 seconds for 600 seconds, check for node to be  up will happen |
        """
        starttime = time.time()
        self._logger().debug(starttime)
        try:
            retry = int(retry)
        except ValueError:
            self._logger().exception("'retry' must be either integer or string-convertible-to-integer")
            raise Exception("'retry' must be either integer or string-convertible-to-integer")

        try:
            interval = int(interval)
        except ValueError:
            self._logger().exception("'interval' must be either integer or string-convertible-to-integer")
            raise Exception("'interval' must be either integer or string-convertible-to-integer")
        
        timepassed = 0
        while(not self.is_up() and timepassed < retry):
            time.sleep(interval-1)
            try:
                self.restart_session()
            except Exception:
                pass
            timepassed = time.time()-starttime
            self._logger().debug(timepassed)
            self._logger().debug(retry)
        if(timepassed > retry):
            self._logger().debug("node '{}' is not up".format(self.ip))
            raise NodeUnreachableError("node '{}' is not up".format(self.ip))
    
    def wait_until_meter_reboots(self):
        """This checks that if ``node`` is rebooted or not after Upgrade.
        It passes if ``node`` reboots and comes out. It fails if ``node`` is not 
        reboot even after the 1200 seconds.
        
        Example:
        
        |        = Keyword =         |  = comment =                                                              |
        | `Wait Until Meter Reboots` | at every 10 seconds for 1200 seconds, checks for node to be go for reboot |
        """
        starttime = time.time()
        self._logger().debug(starttime)
        interval=10
        
        timepassed = 0
        while(timepassed < 1200): ##checking if meter is still not rebooted after 20 mins
            time.sleep(interval)
            try:
                output = self.server_handle._execute_command('echo hello', timeout=60)
                self._logger().debug(output)
                if(output.find('hello') != -1): 
                    timepassed = time.time()-starttime
                    self._logger().debug(timepassed)
                    continue
            except Exception as e:
                self._logger().exception(e)
                try:
                    if 'An existing connection was forcibly closed by the remote host' in str(e):
                        output = self.execute_command('echo hello')
                        self._logger().info(output)
                        if(output.find('hello') != -1): 
                            self._logger().info("Check for SSH exception")
                except Exception as e:
                    if 'SSH session not active' in str(e):
                        self._logger().info("Meter Rebooted")
                return False
        
        if(timepassed > 1200):
            self._logger().debug("node '{}' is not rebooted yet after 20 minutes".format(self.ip))
            raise NodeUnreachableError("node '{}' is not rebooted yet after 20 minutes".format(self.ip))
            
    def wait_forever(self):
        """This is not used but It has been kept for future use.
        This waits until node is not up.
        """
        while not self.is_up():
            pass
        
    def _A7_version_toBeUpgraded(self, filestr):
        """
        This fetches A7 version from coldstart package file name.
        """
        match = re.search('signed-Test_FWDL_ColdStart_SecureBoot_FW(\d+\.\d+\.\d+\.\d+)', filestr)
        if(match):
            self._logger().debug(match.group(1))
            return match.group(1)
        return 'info not available'
        
    def _rf_version_toBeUpgraded(self, filestr):
        """
        This fetches rf/dsp version from coldstart package file name.
        """
        match = re.search('signed-Test_FWDL_ColdStart_SecureBoot_FW(\d+\.\d+\.\d+\.\d+)_RF(\d+\.\d+\.\d+)', filestr)
        if(match):
            self._logger().debug(match.group(2))
            return match.group(2)
        return 'info not available'
        
    def _set_eVTUnsigned8(self): 
        """This checks and sets the value of eVTUnsigned8 if it is not.
        """
        try:   
            output = self.execute_command('LoadMonitorInit --verify | grep -i metrology')
            self._logger().debug(output)
            if(output.find('eVTUnsigned8=1') == -1):
                self.execute_command('FactoryDataWriter --lid ILID_METROLOGY_NO_BASE_PRESENT eVTUnsigned8 1')
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)          
        
    def _coldstart_package_install(self, file, dir):
        """This does coldstart package installation.
        ``file`` is coldstart package and ``dir`` is directory where ``file`` is to be copied on node.
        """
        if(not os.path.isfile(file)):
            self._logger().debug("file '{}' not found".format(file))
            raise FileNotFoundError("file '{}' not found".format(file))
        if(not self.directory_exists(dir)):
            self._logger().debug("Directory '{}' does not exist".format(dir))
            raise Exception("Directory '{}' does not exist".format(dir))
        try:
            checksum_local= hashlib.md5(open(file,'rb').read()).hexdigest()
            self._logger().info("Checksum of file in local: {}".format(checksum_local))
            file_size_local= Path(file).stat().st_size
            self._logger().info("Build File Size in local: {}".format(file_size_local))
            self._logger().info("copying file '{}' to directory '{}'".format(file, dir))
            self.put_file(file, dir)
            file = os.path.basename(file)
            file = dir + '/' + file     # it is os specific (an unix-based system) path
            checksum= self.execute_command('md5sum '+ file)
            checksum_meter= (checksum.split(' '))[0]
            self._logger().info("Checksum of file copied in meter: {}".format(checksum_meter))
            file_size_meter= self.execute_command('stat -c %s '+ file)
            self._logger().info("Build File Size in meter: {}".format(file_size_meter))
            if (int(file_size_local) == int(file_size_meter)):
                if (str(checksum_local) == str(checksum_meter)):
                    self._logger().info("File copied successfully in meter")
                    BuiltIn().log_to_console("File copied successfully in meter")
            else:
                self._logger().debug("File is not copied in meter. File size of build in local: {} and file size of build copied in meter: {}".format(file_size_local, file_size_meter))
                raise Exception("File is not copied in meter. File size of build in local: {} and file size of build copied in meter: {}".format(file_size_local, file_size_meter))
            # testing if file exists
            output = self.execute_command('test -e /usr/bin/HashAuthentication && echo 1 || echo 0')
            if(output.find('1') != -1):     # if(output == '1\n'):
                self.execute_command('rm /usr/bin/HashAuthentication')
                
            ##Installing cold start package
            output = self.execute_command('Helper-CmdList.sh -f {}'.format(file))
            self._logger().info(output)
            time.sleep(2)
            chan = self.execute_command('ps | grep ImProv')
            #time.sleep(1)
            self._logger().debug(chan)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)      
    
    def upgrade_g5r(self, coldstart_file, copy_coldstart_file_to,  converter_file, copy_converter_file_to, wait_after_coldstart_install, improvhelper_waittime, skip_gmr=False):
        """This upgrades the Gen5Riva node.
        
        ``coldstart`` is the path to the coldstart package file in the local machine.
        
        ``copy_coldstart_to`` is the directory on the node ``node`` where the ``coldstart`` has to be copied.
        
        ``converter_file`` is the path to the file in local machine which will be used to convert the Riva nodes to Gen5 Riva nodes. 
        
        ``copy_converter_file_to`` is the directory on the node ``node`` where the ``converter_file`` has to be copied.
        
        ``improvhelper_waittime`` can be given to wait after the "ImPorvHelper.sh" command is initiated. By default it is ``120`` seconds.
        
        This keyword does not require connection to any server.
        """
        try:
            self.new_session()
            
            A7_version_toBeUpgraded = self._A7_version_toBeUpgraded(coldstart_file)
            A7_Version_before_upgrade = self.get_A7_version()
            DSP_Version_before_upgrade = self.get_rf_version()
            #rf_version = self._rf_version_toBeUpgraded(coldstart_file) # Not needed as per latest build file name
            self._logger().info("\nUpgrading node {} ...".format(self.ip))
            self._logger().info("current A7 version: {}".format(A7_Version_before_upgrade))
            self._logger().info("current DSP version: {}".format(DSP_Version_before_upgrade))
            self._logger().info("upgrading with A7 version: {}".format(A7_version_toBeUpgraded))
            #self._logger().info("upgrading with DSP version: {}".format(rf_version)) # Not needed as per latest build file name
            
            BuiltIn().log_to_console("\nUpgrading node {} ...".format(self.ip))
            BuiltIn().log_to_console("current A7 version: {}".format(A7_Version_before_upgrade))
            BuiltIn().log_to_console("current DSP version: {}".format(DSP_Version_before_upgrade))
            BuiltIn().log_to_console("upgrading with A7 version: {}".format(A7_version_toBeUpgraded))
            #BuiltIn().log_to_console("upgrading with DSP version: {}".format(rf_version))   # Not needed as per latest build file name
            
            wait_after_coldstart_install_ = wait_after_coldstart_install.split(':')
            if len(wait_after_coldstart_install_) != 2:
                msg = "wait_after_coldstart_install must be in the format 'retry:interval'"
                msg += "\nretry,interval must be convertible to integer"
                self._logger().debug(msg)
                raise ValueError(msg)
            
            try:
                retry = int(wait_after_coldstart_install_[0])
                interval = int(wait_after_coldstart_install_[1])
            except ValueError:
                msg = "wait_after_coldstart_install must be in the format 'retry:interval'\nretry,interval must be convertible to integer"
                self._logger().exception(msg)
                raise Exception(msg)      
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            filename = 'UpgradeDetails.txt'
            filepath = os.path.join(DestDir, filename)
            f=open(filepath,"w", newline='\n')
            if self.is_upgraded(A7_version_toBeUpgraded):
                self._logger().info('node {} already up-to-date'.format(self.ip))
                BuiltIn().log_to_console('node {} already up-to-date'.format(self.ip))
                f.write("\nNode {} is already up-to-date".format(self.ip))
                f.close()
                #self.logmodversion()
                return
            if self.is_bare():
                self._logger().info('{} is bare node'.format(self.ip))
                self._logger().info('Conversion started')
                
                BuiltIn().log_to_console('{} is bare node'.format(self.ip))
                BuiltIn().log_to_console('Conversion started')
                try:
                    self._coldstart_package_install(converter_file,copy_converter_file_to)
                except Exception as e:
                    self._logger().exception(e)
                    raise RuntimeError(e)
                else:
                    self._logger().info("Checking meter connectivity when upgrade is in process")
                    output = self.wait_until_meter_reboots()
                    self._logger().debug(output)
                    self._logger().info('Meter Going through reboot')
                    BuiltIn().log_to_console('Meter Going through reboot')
                    
                    self._logger().info('wait upto %s seconds' % str(retry))
                    BuiltIn().log_to_console('wait upto %s seconds' % str(retry)) 
                    
                    self.wait_until_up(retry, interval)
                    
                    self._logger().info('Conversion completed')
                    BuiltIn().log_to_console('Conversion completed')
                    
                try:                
                    self.restart_session()
                except Exception:
                    self._logger().exception("node '{}' is still not up".format(self.ip))
                    raise Exception("node '{}' is still not up".format(self.ip))
            
            try:
                self._logger().info('installing coldstart package...')
                BuiltIn().log_to_console('installing coldstart package...')
                self._coldstart_package_install(coldstart_file, copy_coldstart_file_to)
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
            self._logger().info("Checking meter connectivity when upgrade is in process")
            output = self.wait_until_meter_reboots()
            self._logger().debug(output)
            self._logger().info('Meter Going through reboot')
            BuiltIn().log_to_console('Meter Going through reboot')
            self._logger().info('wait upto %s seconds' % str(retry))
            BuiltIn().log_to_console('wait upto %s seconds' % str(retry)) 
            
            self.wait_until_up(retry, interval)
            
            try:
                self.restart_session()
            except Exception:
                self._logger().exception("node '{}' is still not up".format(self.ip))
                raise NodeUnreachableError("node '{}' is still not up".format(self.ip))
            
            """ Check LID for FW version after firmware Upgrade"""  
            A7_version_after_upgrade = self.get_A7_version()
            self._logger().info("Firmware Version After Upgrade: {}".format(A7_version_after_upgrade))
            if A7_version_toBeUpgraded == A7_version_after_upgrade:# and self.dsp_rf_upToDate(rf_version):
                self._logger().info('coldstart package successfully installed')
                BuiltIn().log_to_console('coldstart package successfully installed') 
                self._logger().info("node '{}' successfully upgraded".format(self.ip))
                BuiltIn().log_to_console("node '{}' successfully upgraded".format(self.ip))  
            else:
                self._logger().info('something went wrong; could not install coldstart package')
                f.write("\nNode {} upgrade failed. Please check /mnt/pouch/LifeBoatLogs/ImProv.txt".format(self.ip))
                f.close()
                raise Exception('something went wrong; could not install coldstart package')
            self._logger().info('checking if build is rolled back. Wait for 5 minutes')
            time.sleep(300)
            A7_version_after_upgrade = self.get_A7_version()
            if A7_version_after_upgrade == A7_Version_before_upgrade:
                self._logger().info('Build rolled back to old version')
                f.write("\nNode {} rolled back to old build version. Please check /mnt/pouch/LifeBoatLogs/ImProv.txt".format(self.ip))
                f.close()
                raise Exception('Node {} rolled back to old build version; please check /mnt/pouch/LifeBoatLogs/ImProv.txt'.format(self.ip))
            else:
                f.write("\nNode {} upgraded successfully".format(self.ip))
                f.close()
        except NodeUnreachableError:
            self._logger().exception("Node is not reachable")
            raise Exception("Node is not reachable")                
        except Exception as e:
            self.logimprovhelper(improvhelper_waittime)
            self._logger().exception(e)
            raise Exception(e)
        finally:
            self.logmodversion()
            ##checking if gmr_skip is set to true for 1.2.1 builds
            if skip_gmr==True:
                file1='/usr/share/itron/PreInstall/HANAgent_1.1.10.*_TS.tar.gz'
                if os.path.exists(file1):
                    self.execute_command('rm /usr/share/itron/PreInstall/HANAgent_1.1.10.*_TS.tar.gz')
            self.logout()
                
class G5NNode:
    def __init__(self):
        pass

    def _last_known_good_image(self, node):
        """Implementation is incomplete.
        """
        try:
            command = 'net_mgrS -d ' + node + ' image list'
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('Last Known Good Image: (.*)', output)
            if(match):
                lkgi = match.group(1)
                self._logger().debug(lkgi)
            else:
                self._logger().exception("Last Known Good Image Not Found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("Last Known Good Image Not Found")
            return lkgi  
        
    def _currently_running_image(self, node, type = 'flash'):
        """Implementation is incomplete.
        """
        try:
            command = 'net_mgrS -d ' + node + ' image list'
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(type == 'flash'):
                match = re.search('Currently Running Image \(flash\): (.*)', output)
            else:
                match = re.search('Currently Running Image \(mem\): (.*)', output)
            if(match):
                cri = match.group(1)
                self._logger().debug(cri)
            else:
                self._logger().debug("Currently Running Image Not Found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("currently Running Image Not Found")
            return cri  
        
    def _image0(self, node):
        """Implementation is incomplete.
        """
        try:
            command = 'net_mgrS -d ' + node + ' image list'
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('Image #0: (.*) ', output)
            if(match):
                im0 = match.group(1)
                self._logger().debug(im0)
            else:
                self._logger().debug("Image0 Not Found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("Image0 Not Found")
            return im0   
        
    def _image1(self, node):
        """Implementation is incomplete.
        """
        try:
            command = 'net_mgrS -d ' + node + ' image list'
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('Image #1: (.*) ', output)
            if(match):
                im1 = match.group(1)
                self._logger().debug(im1)
            else:
                self._logger().debug("Image1 Not Found")
                self._logger().info("Command Output: \n%s" % output)
                raise Exception("Image1 Not Found")
            return im1        

    def _get_non_running_image(self, node):
        """Implementation is incomplete.
        """
        im_flash = self._currently_running_image(node, 'flash')
        im_mem = self._currently_running_image(node, 'mem')
        try:
            assert im_flash == im_mem
        except AssertionError:
            raise Exception('Should be equal\nCurrently Running Image (flash): {}\nCurrently Running Image (mem): {}'.format(im_flash, im_mem))
        
        im0 = self._image0(node)
        im1 = self._image1(node)
        self._logger().debug(im0)
        self._logger().debug(im1)
        if(im_flash != im0):
            return im0
        else:
            return im1   

    def _remove_non_running_image(self, node):
        """Implementation is incomplete.
        """
        try:
            im_to_remove = self._get_non_running_image(node)
            command = 'net_mgrS -d ' + node + ' image remove ' + im_to_remove
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().debug(im_to_remove)
            self._logger().info('Executed command for NIC with IP: %s' %node)
            return im_to_remove
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)   
    
    def _upload_image(self, node, imagepath):
        """Implementation is incomplete.
        """
        try:
            im_to_remove = self._get_non_running_image(node)
            command = 'net_mgrS -d ' + node + ' image upload ' + imagepath
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
            self._logger().debug(im_to_remove)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
    def _restart_now(self, node):
        """Implementation is incomplete.
        """
        try:
            command = 'net_mgrS -d ' + node + ' restart now'
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
    
    def _setboot(self,node, image1, image2, force = False):
        """Implementation is incomplete.
        """
        if(force):
            force = ' force'
        else:
            force = ''
        try:
            im_to_remove = self._get_non_running_image(node)
            self._logger().debug(im_to_remove)
            command = 'net_mgrS -d ' + node + ' image setboot ' + image1 + ' ' + image2 + force
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
    
    def _is_ap(self, node):
        """Implementation is incomplete.
        """
        try:
            command = 'net_mgrS -d ' + node + ' devinfo'
            output = Connection.execute_command(self,command)
            self._logger().debug(output)
            self._logger().info('Executed command for NIC with IP: %s' %node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output.find('Network Role: Access Point') != -1):
                return True
            else:
                return False
        
    def _get_image(self, node):
        """Implementation is incomplete.
        """
        common_prefix = '/shared/release/firmware/'
        if self._is_ap:
            imagepath = os.path.join(common_prefix, 'daily-builds') #need to change join way
        else:
            imagepath = os.path.join(common_prefix, 'released')
        
    def upgrade_g5n(self, node, image):
        """Implementation is incomplete.
        """
        image_lkgi = self._last_known_good_image(node)
        self._remove_non_running_image(node)
        self._upload_image(node, image)
        self._setboot(node, image_lkgi, image, True)
        self._restart_now(node)
        
        
class APNode:
    def __init__(self, ip):
        pass
        
    def upgrade_ap(self, build_file):
        raise NotImplementedError

