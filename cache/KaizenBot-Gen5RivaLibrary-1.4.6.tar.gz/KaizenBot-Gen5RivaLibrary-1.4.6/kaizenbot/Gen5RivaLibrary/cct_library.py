# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""
from kaizenbot.logging_robot import Loggers 
from kaizenbot.kbotdbserver_psql import KBotDBServer
from kaizenbot.Misc.kbotdbconfig import DB_Dict
from .gen5rivalibrary import Gen5RivaLibrary
import cx_Oracle

class CCT_Library:

    #cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_21_3")  #install oracle instantclient and uncomment this during running it from local - windows
    cx_Oracle.init_oracle_client(lib_dir=r"/opt/oracle/instantclient_21_4")  # uncomment this during running it from Pipeline - linux

    def __init__(self):
        self.URI = None
        self.db_name = None
        self.db_user = None
        self.db_pwd = None
        self._kzobj = None

    @property
    def _server(self):
        self.URI = 'kaizenbot.itron.com:5432'
        self.db_name = DB_Dict[self.URI]['gen5cctschema']['db_name']
        self.db_user = DB_Dict[self.URI]['gen5cctschema']['db_user']
        self.db_pwd = DB_Dict[self.URI]['gen5cctschema']['db_pwd']
        self._kzobj=KBotDBServer(self.db_name,self.db_user,self.db_pwd,self.URI.split(':')[0],self.URI.split(':')[1])

    def _logger(self):
        return Gen5RivaLibrary()._logger()

    def update_pon_prn_table(self, build, pon, prn, topo, table, rel='local'):
        """
        This keyword will update the pon_prn_ELG/pon_prn_LG table in PostgreSql DB with inputs provided
        Five Arguments Build, Pon percentage, Prn percentage, Topology, Table are given next to the keyword.
        So that DB will be updated as per these values and latest best results are also updated using these values
        Using these inputs, table updates with best_pon_percent, best_pon_build, best_prn_percent, best_prn_build

        ``Build``           - build on which test is executed
        ``Pon``             - Pon percentage
        ``Prn``             - Prn percentage
        ``Topology``        - Topology selection
        ``Table``           - ELG/LG Type
        ``rel``(optional)   - release of this build. i.e alpha1 or beta2 etc.

        = Example: =
        |       = Keyword =        | = Build = | = Pon = |  = Prn = |       = Topology =        | = Table = | = Release = |
        |  `Update Pon Prn Table`  |  10.4.331 |  50.35  |   80.5   |  Multi-Hop-0dbm-Topology  |    ELG    |             |
        |  `Update Pon Prn Table`  |  10.4.332 |   60    |   80.45  |  SY-16Hop-Mesh-Topology   |    LG     |    alpha1   |
        |  `Update Pon Prn Table`  |  10.4.333 |   70.4  |   83.5   |  Multi-Hop-0dbm-Topology  |    ELG    |    beta2    |

        """

        pon = float(pon)
        prn = float(prn)
        self._server
        cur_serial_num=self._kzobj.runquery('SELECT last_value FROM gen5cctschema.pon_prn_%s_serial_num_seq'%table).fetchall()[0][0]
        if int(cur_serial_num) > 1:
            query1="SELECT best_pon_prcnt,best_pon_build,best_prn_prcnt,best_prn_build from gen5cctschema.pon_prn_%s where serial_num=(%d)"%(table,cur_serial_num)
            val = self._kzobj.runquery(query1).fetchall()
            pre_pon,pre_pon_build,pre_prn,pre_prn_build = val[0]
            tmp_pon = pre_pon if pre_pon >= pon else pon
            tmp_prn = pre_prn if pre_prn >= prn else prn
            tmp_pon_build = build if tmp_pon == pon else pre_pon_build
            tmp_prn_build = build if tmp_prn == prn else pre_prn_build
        else:
            tmp_pon = pon
            tmp_prn = prn
            tmp_pon_build, tmp_prn_build = (build, build)

        query2="""insert into gen5cctschema.pon_prn_%s 
        (build_version,pon_prcnt,prn_prcnt,topology,release,best_pon_prcnt,best_pon_build,best_prn_prcnt,best_prn_build) values 
        ('%s',%f,%f,'%s','%s',%f,'%s',%f,'%s')"""%(table,build,pon,prn,topo[:-4],rel,tmp_pon,tmp_pon_build,tmp_prn,tmp_prn_build)
        return self._kzobj.runquery(query2)

    def get_best_pon_result(self,table):
        """
        This keyword fetch the best results related to Pon based on previous runs
        Output of this keyword is Best Pon Percentage, Build and Topology on which it was achieved

        = Example: =
        |      = Keyword =         | = Table = |
        |   `Get Best Pon Result`  |    ELG    |
        |   `Get Best Pon Result`  |    LG     |

        Return value will be tuple of four values(Best PON Percentage, Best PON Build, Topology, Release)
        """
        self._server
        pon_query="""select best_pon_prcnt,best_pon_build,topology,release from gen5cctschema.pon_prn_%s where serial_num=(SELECT last_value FROM gen5cctschema.pon_prn_%s_serial_num_seq)"""%(table,table)
        return self._kzobj.runquery(pon_query).fetchall()[0]

    def get_best_prn_result(self,table):
        """
        This keyword fetch the best results related to Prn based on previous runs
        Output of this keyword is Best Prn Percentage, Build and Topology on which it was achieved

        = Example: =
        |        = Keyword =        | = Table = |
        |   `Get Best Prn Result`   |    ELG    |
        |   `Get Best Prn Result`   |    LG     |

        Return value will be tuple of four values(Best PRN Percentage, Best PRN Build, Topology, Release)

        """
        self._server
        prn_query="""select best_prn_prcnt,best_prn_build,topology,release from gen5cctschema.pon_prn_%s where serial_num=(SELECT last_value FROM gen5cctschema.pon_prn_%s_serial_num_seq)"""%(table,table)
        return self._kzobj.runquery(prn_query).fetchall()[0]

    def Fetch_AMMReadInfo_from_DB(self,db,network_id,read_type=None,job_id=None,reads_count=None,pass_percent_threshold=None,pass_percent=None):
        """
        This keyword will print the status of the reads and return the Flag status True/False based on the input provided
        Two mandatory arguments (db_obj and network id should be given) and remaining are optinoal arguments next to the keyword.
        If network id other than 'acca' or 'feb3' then 3rd and 4th arguments are given as mandatory fields(3rd arg : type_of_read i.e
        ping/data/nic_event, 4th arg : job_id)

        ``db``                      - AMM DB configuration
        ``network_id``              - Network id/SSID
        ``read_type``               - Ping/Data/Nic_event
        ``job_id``                  - Job id of read type
        ``reads_count``             - No. of reads to fetch
        ``pass_percent_threshold``  - Max Percentage required for pass_percent in list of reads
        ``pass_percent``            - Percentage of reads

        = Example: =
        |          = Keyword =          |   = db =   | = network_id = | = read_type = | = job_id = | = reads_count = | = pass_percent_threshold = | = pass_percent = |
        |  `Fetch AMMReadInfo From DB`  |  ${db_obj} |      acca      |    ${None}    |  ${None}   |     ${None}     |          ${None}           |     ${None}      |
        |  `Fetch AMMReadInfo From DB`  |  ${db_obj} |      accb      |     ping      |    722     |     ${None}     |            90              |       100        |
        |  `Fetch AMMReadInfo From DB`  |  ${db_obj} |      acca      |    ${None}    |  ${None}   |        70       |          ${None}           |       95         |
        |  `Fetch AMMReadInfo From DB`  |  ${db_obj} |      feb3      |     ping      |    722     |     ${None}     |          ${None}           |       100        |
        |  `Fetch AMMReadInfo From DB`  |  ${db_obj} |      abcd      |     data      |    724     |        50       |            85              |       98         |
        |  `Fetch AMMReadInfo From DB`  |  ${db_obj} |      feb3      |   nic_event   |    723     |        50       |            95              |       100        |

        """
        #print("db = ",db)
        cred,read_params_acca,read_params_feb3=db
        if network_id.lower() == 'acca':
            read_params = read_params_acca
        elif network_id.lower() == 'feb3':
            read_params = read_params_feb3
        else:
            if not (read_type and job_id):
                print("Job Id and Read type are mandatory to pass input")
                self._logger().info("Job Id and Read type are mandatory to pass input")
                return False
            else:
                read_params = read_params_acca
                read_params[read_type][0] = job_id

        if not read_type:
            read = read_params
            for key,value in read.items():
                if not (reads_count or pass_percent_threshold or pass_percent):
                    reads_count = value[1]
                    pass_percent_threshold = value[2]
                    pass_percent = value[3]
                elif reads_count and not (pass_percent_threshold or pass_percent):
                    value[1] = reads_count
                elif pass_percent_threshold and not (pass_percent or reads_count):
                    value[2] = pass_percent_threshold
                elif pass_percent and not (pass_percent_threshold or reads_count):
                    value[3] = pass_percent
                elif (reads_count and pass_percent_threshold) and not pass_percent:
                    value[1] = reads_count
                    value[2] = pass_percent_threshold
                elif (reads_count and pass_percent) and not pass_percent_threshold:
                    value[1] = reads_count
                    value[3] = pass_percent
                elif (pass_percent_threshold and pass_percent) and not reads_count:
                    value[2] = pass_percent_threshold
                    value[3] = pass_percent
                else:
                    value[1] = reads_count
                    value[2] = pass_percent_threshold
                    value[3] = pass_percent

        else:
            read={}
            read[read_type] = read_params[read_type]  # read['ping'] = read_params['ping']; read['ping'] = [722,200,90,100]
            if not(job_id or reads_count or pass_percent_threshold or pass_percent):
                job_id = read[read_type][0]
                reads_count = read[read_type][1]
                pass_percent_threshold = read[read_type][2]
                pass_percent = read[read_type][3]
            elif job_id and not(reads_count or pass_percent_threshold or pass_percent):
                read[read_type][0] = job_id
            elif reads_count and not (job_id or pass_percent_threshold or pass_percent):
                read[read_type][1] = reads_count
            elif pass_percent_threshold and not (job_id or reads_count or pass_percent):
                read[read_type][2] = pass_percent_threshold
            elif pass_percent and not (job_id or reads_count or pass_percent_threshold):
                read[read_type][3] = pass_percent
            elif (job_id and reads_count) and not (pass_percent_threshold or pass_percent):
                read[read_type][0] = job_id
                read[read_type][1] = reads_count
            elif (job_id and pass_percent_threshold) and not (reads_count or pass_percent):
                read[read_type][0] = job_id
                read[read_type][2] = pass_percent_threshold
            elif (job_id and pass_percent) and not (reads_count or pass_percent_threshold):
                read[read_type][0] = job_id
                read[read_type][3] = pass_percent
            elif (job_id and reads_count and pass_percent_threshold) and not pass_percent:
                read[read_type][0] = job_id
                read[read_type][1] = reads_count
                read[read_type][2] = pass_percent_threshold
            elif (job_id and reads_count and pass_percent) and not pass_percent_threshold:
                read[read_type][0] = job_id
                read[read_type][1] = reads_count
                read[read_type][3] = pass_percent
            elif (job_id and pass_percent_threshold and pass_percent) and not reads_count:
                read[read_type][0] = job_id
                read[read_type][2] = pass_percent_threshold
                read[read_type][3] = pass_percent
            elif (reads_count and pass_percent_threshold) and not (job_id or pass_percent):
                read[read_type][1] = reads_count
                read[read_type][2] = pass_percent_threshold
            elif (reads_count and pass_percent) and not (job_id or pass_percent_threshold):
                read[read_type][1] = reads_count
                read[read_type][3] = pass_percent
            elif (reads_count and pass_percent_threshold and pass_percent) and not job_id:
                read[read_type][1] = reads_count
                read[read_type][2] = pass_percent_threshold
                read[read_type][3] = pass_percent
            elif (pass_percent_threshold and pass_percent) and not (job_id or reads_count):
                read[read_type][2] = pass_percent_threshold
                read[read_type][3] = pass_percent
            else:
                read[read_type][0] = job_id
                read[read_type][1] = reads_count
                read[read_type][2] = pass_percent_threshold
                read[read_type][3] = pass_percent

        conn = cx_Oracle.connect(cred['username'],cred['password'],cred['dsn'])

        try:
            with conn.cursor() as cursor:
                flag_list=[]
                for key,value in read.items():
                    query = "select MEMBER_FAILED,MEMBER_CNT from "+ cred['db_instance'] +".UIQ_JOB_EXEC where JOB_ID = '"+ str(value[0]) +"' and MEMBER_CNT=MEMBER_REPORTED order by schedule_begin_ts DESC FETCH FIRST "+ str(value[1]) +" ROWS ONLY"
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    list_row_percentage=[((x[1]-x[0])/x[1])*100 for x in rows]
                    No_of_reads_count_percent=len([x for x in list_row_percentage if x >= int(value[3])])
                    percent_validation = (No_of_reads_count_percent/(int(value[1])))*100
                    print("{} Reads : {}% of {} reads are {}% reads, Percentage 100% is {}/{} times, b/w 95-99% is {}/{} times, b/w 91-95% is {}/{} times, less than 90% is {}/{} times".format(key,percent_validation,value[1],value[3],list_row_percentage.count(100.0),value[1],len(list(x for x in list_row_percentage if 95<=x<100)),value[1],len(list(x for x in list_row_percentage if 90<=x<95)),value[1],len(list(x for x in list_row_percentage if x<90)),value[1]))
                    self._logger().info("{} Reads : {}% of {} reads are {}% reads, Percentage 100% is {}/{} times, b/w 95-99% is {}/{} times, b/w 91-95% is {}/{} times, less than 90% is {}/{} times".format(key,percent_validation,value[1],value[3],list_row_percentage.count(100.0),value[1],len(list(x for x in list_row_percentage if 95<=x<100)),value[1],len(list(x for x in list_row_percentage if 90<=x<95)),value[1],len(list(x for x in list_row_percentage if x<90)),value[1]))
                    if pass_percent_threshold:
                        if percent_validation >= int(pass_percent_threshold):
                            flag_list.append(True)
                        else:
                            flag_list.append(False)
        except Exception as e:
            self._logger().exception(e)
        finally:
            if False in flag_list:
                return False
            else:
                return True
            conn.close()


cct_library = CCT_Library