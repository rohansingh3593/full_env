# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
import re, os, time
from kaizenbot.connection import Connection
from kaizenbot.logging_robot import Loggers
from kaizenbot.exceptions import NotATableError, MACNotFoundError

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

def _to_str_list(string, sep = ','):
    """This converts str, int,list of ints, string-like-list of ints and string-like-list of strs to list of strs.
    1 --> ['1'] #int
    '1' --> ['1']    #str
    "1,2,3" --> ['1','2','3']    #str
    [1,2,3] --> ['1','2','3']    #list of ints
    ['1','2','3'] --> ['1','2','3']    # list of strs
    "[1,2,3]" --> ['1','2','3']    #string-like-list of ints
    "['1','2','3']" --> ['1','2','3']    #string-like-list of strs
    
    It also handles extra separators ``sep``.
    ",1,2,,3," --> ['1','2','3']
    """
    if isinstance(string, (str,int)):
        string = str(string)
        string = string.replace(' ', '')
        string = string.replace('[', '')
        string = string.replace(']', '')
        string = string.replace("'", '')   # string = string.replace('\'', '')
        string = string.replace('"','')
        string = string.split(sep)
        while('' in string):
            string.remove('')
            
    elif isinstance(string, list):
        tmp = []
        for each_str in string:
            tmp.append(str(each_str))
        string = tmp
        
    else:
        raise TypeError
    
    return string


class Utils:
    def __init__(self):
        pass  
    
    def _logger(self):
        raise NotImplementedError 
    
    def reboot_g5r_node(self):
        """This reboots the G5R node.
        """
        try:   
            command = '/sbin/reboot'
            output = self.execute_command(command)
        except Exception as e:
            self._logger().exception("Could not reboot: {}".format(e))
            raise Exception("Could not reboot: {}".format(e)) 
        
    def write_factory_data(self, lid_name, eVTUnsigned, lid_value): 
        """This keyword can be used to define any LID for G5R node.
        ``lid_name`` is the name of the LID.
        ``eVTUnsigned`` is the value of eVTUnsigned.
        ``lid_value`` is the value for the LID ``lid_name``.
        
        Example:
        
        | = keyword =          | = lid_name =           | = eVTUnsigned = | = lid_value = |
        | `Write Factory Data` | ILID_GX_PHY_START_WORD | 16              | 6461          |  
        """    
        try:   
            command = 'FactoryDataWriter --lid ' + lid_name + ' eVTUnsigned' + eVTUnsigned + ' ' + str(lid_value)
            output = self.execute_command(command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Factory data write failed: {}".format(e))
            raise Exception("Factory data write failed: {}".format(e))
    
    def get_mac_of_g5r_node(self, sep = ''):
        """This returns the MAC of G5R node.
        
        ``sep`` is empty string by default. It can be provided to separate a pair of characters of MAC address.
        
        Example:
        
        | = keyword =           | = sep= |       =output=            |
        | `Get MAC OF G5R Node` | sep=:  | # 00:07:81:09:02:49:AD:D7 |
        | `Get MAC OF G5R Node` |        | # 000781090249ADD7        |
        
        """
        try:   
            output = self.execute_command('Helper-CmdList.sh -r ILID_NETWORK_MAC')
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search('\w+',output)
            if(match):
                mac = match.group(0)
                prev_ind = 2
                mac_ = mac[0:prev_ind]
                for i in range(4, len(mac)+1, 2):
                    mac_ += sep + mac[prev_ind:i]
                    prev_ind = i
                
                self._logger().info("MAC: {}".format(mac_))
                return mac_ 
   
            else:  
                self._logger().debug("MAC is not found")  
                raise MACNotFoundError("MAC is not found")
            
    def get_ipv6(self, interface = 'rf0', first_hextet = None):
        """This returns a python-like list of all ipv6 for the interface ``interface``.
        Default value of interface is ``rf0``, but it can be provided by user.
        If ``first_hextet`` is provided, only the ipv6 matching the first hextet are returned. 
        
        Example:
        
        | `Get ipv6` | first_hextet=fd59 | # ['FD59:4C3E:4420:0009:0213:5005:00F7:150B'] |
        
        This keyword is supportable only on unix-based servers.
        """
        
        try:
            command = '/sbin/ifconfig '+ interface + ' | grep -i inet6'
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(not first_hextet):
                ipv6 = re.findall('inet6 addr: (.*)/',output)
                if(ipv6 == []):
                    self._logger().debug("No ipv6 found for interface '{}'".format(interface))
                    raise Exception("No ipv6 found for interface '{}'".format(interface))
                return ipv6
            else:
                ipv6 = re.findall('inet6 addr: ({}.*)/'.format(first_hextet.lower()), output, re.I)
                if(ipv6 == []):
                    self._logger().debug("No matching ipv6 found for interface '{}' having first hextet '{}'".format(interface, first_hextet))
                    raise Exception("No matching ipv6 found for interface '{}' having first hextet '{}'".format(interface, first_hextet))
                return ipv6
            
    def get_A7_version_from_modversion(self):
        """This returns the A7 version of G5R node.
        """      
        try:
            major_num = None
            minor_num = None
            build_num = None
            revision_num = None
            
            output = Connection.execute_command(self,'modversion.sh')
            self._logger().info(output)
            
            match = re.search('\nMajor Number: (.*)', output)
            if(match):
                major_num = match.group(1)
            match = re.search('\nMinor Number: (.*)', output)
            if(match):
                minor_num = match.group(1)
            match = re.search('\nBuild Number: (.*)', output)
            if(match):
                build_num = match.group(1)
            match = re.search('\nRevision Number: (.*)', output)
            if(match):
                revision_num = match.group(1)
            
            a7_version = str(major_num) + '.' + str(minor_num) + '.' + str(build_num) + '.' + str(revision_num)
            if('None' not in a7_version):
                return a7_version
            else:
                if not os.path.isdir(DestDir):
                    os.mkdir(DestDir)
                output = Connection.execute_command(self,'modversion.sh')
                filename = 'modversion_' + time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())+ '.txt'
                filepath = os.path.join(DestDir, filename)
                f=open(filepath,"w", newline='')
                f.write(output)
                f.close()
                print("*HTML* <a href={}>{}</a>".format(filepath,filename))
                self._logger().debug("Could not fetch A7 version")
                raise Exception("Could not fetch A7 version")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

    def get_dsp_version_from_modversion(self):
        """This returns the DSP version of G5R node.
        """
        try:
            output = Connection.execute_command(self,'modversion.sh')
            self._logger().info(output)
            
            match = re.search('\nRF MAC +version: (.*) ', output)
            if(match):
                return match.group(1)
            else:
                if not os.path.isdir(DestDir):
                    os.mkdir(DestDir)
                output = Connection.execute_command(self,'modversion.sh')
                filename = 'modversion_' + time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())+ '.txt'
                filepath = os.path.join(DestDir, filename)
                f=open(filepath,"w", newline='')
                f.write(output)
                f.close()
                print("*HTML* <a href={}>{}</a>".format(filepath,filename))
                self._logger().debug("Could not fetch DSP/RF MAC version")
                raise Exception("Could not fetch DSP/RF MAC version")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)   
    
    def ping_6(self, ipv6, count = 5, interval = 1, packetsize = 56, return_type = 3, interface = '', device = 'waseca'):
        """This resembles the unix-ping6 except this supports only a few options.
        By default ``count`` is 5, ``interval`` is 1 sec, ``packetsize`` is 56 byte, ``interface`` is None and ``device`` is waseca.
        New values can be provided with the keyword.
        
        It supports following return types:
        - ``1`` OR ``tx_pkt`` for number of packets transmitted
        - ``2`` OR ``rx_pkt`` for number of packets received 
        - ``3`` OR ``succ_rate`` for the success percentage
        - ``4`` OR ``total_time`` for total time the in ms
        - ``5`` OR ``rtt_min`` for minimum RTT in ms
        - ``6`` OR ``rtt_avg`` for average RTT in ms
        - ``7`` OR ``rtt_max`` for maximum RTT in ms
        - ``8`` OR ``rtt_mdev`` for standard deviation in ms
        - ``0`` OR ``all`` will return data for all return types (1-8) as python-tuple.
        
        If timeout occurs (in absence of any response) and RTT statistics is not generated and 
        ``return_type`` falls under RTT statistics category, a python-like ``None`` is returned.
        
        Default return type is ``3`` for backward compatibility.
        ``return_type`` is new in version 0.5
        
        Example:
        
        | =keyword= |              =ipv6=                | =count=  | =interval= |  =packetsize=  | =return_type=       | =interface=         | =device=            |                              =output=                                                                                   |
        | `ping 6`  | fd59:4c3e:4420:9:213:5000:249:add1 |          |            |                |                     |                     |                     | Performs ping6 on waseca with default values of count, interval, packetsize and returns success percentage              |
        | `ping 6`  | fd59:4c3e:4420:9:213:5000:249:add1 | count=20 | interval=2 | packetsize=120 |                     |                     |                     | Performs ping6 on waseca  with provided values of count, interval, packetsize  and returns success percentage           |
        | `ping 6`  | fd59:4c3e:4420:9:213:5000:249:add1 | count=20 | interval=2 | packetsize=120 | return_type=6       |                     |                     | Performs ping6 on waseca  with provided values of count, interval, packetsize  and returns average rtt                  |
        | `ping 6`  | fd59:4c3e:4420:9:213:5000:249:add1 | count=20 | interval=2 | packetsize=120 | return_type=rtt_avg | interface=eth0      | device=waseca       | Performs ping6 on waseca  with provided values of count, interval, packetsize,interface  and returns average rtt        | 
        | `ping 6`  | fd59:4c3e:4420:9:213:5000:249:add1 | count=20 | interval=2 | packetsize=120 | return_type=rtt_avg | interface=rf0       | device=node         | Performs ping6 on node SSH with provided values of count, interval, packetsize,interface and returns average rtt        | 
        """
        try:
            count = int(count)
        except ValueError:
            count = 5
        
        try:
            interval = int(interval)
        except ValueError:
            interval = 1
            
        try:
            packetsize = int(packetsize)
        except ValueError:
            packetsize = 56  
            
        try:
            interface = str(interface)
        except ValueError:
            interface = ''
                       
        try:
            device = str(device)
        except ValueError:
            device = 'waseca'
            
        try:
            if interface == '':
                command = 'ping6 ' + ipv6 + ' -c ' + str(count) + ' -i ' + str(interval) + ' -s ' + str(packetsize)
            else:
                command = 'ping6 ' + ipv6 + ' -c ' + str(count) + ' -i ' + str(interval) + ' -s ' + str(packetsize) + ' -I ' + str(interface)
            
            if device == 'node':
                command = '/sbin/' + command
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: %s' %ipv6)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:        
            if(output.find('unknown host') != -1):
                self._logger().debug('unknown host {}: provide valid ipv6'.format(ipv6))
                raise Exception('unknown host {}: provide valid ipv6'.format(ipv6))
            
            match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (\d+)ms\s*rtt min/avg/max/mdev = (\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+) ms', output)
            if not match:
                match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (/d+)ms', output)
            
            if(match):
                rets = []
                for i in range(8):
                    try:
                        rets.append(match.group(i+1))
                    except IndexError:
                        rets.append(None)
                
                if str(return_type) == '0' or str(return_type).lower() == 'all':
                    rets[2] = str(100 - int(rets[2]))
                    return tuple(rets)
                
                if str(return_type) == '1' or str(return_type).lower() == 'tx_pkt':
                    return rets[0]
                
                if str(return_type) == '2' or str(return_type).lower() == 'rx_pkt':
                    return rets[1]
                    
                if str(return_type) == '3' or str(return_type).lower() == 'succ_rate':
                    success_perc = 100 - int(rets[2])
                    return str(success_perc)
                    
                if str(return_type) == '4' or str(return_type).lower() == 'total_time':
                    return rets[3]
                    
                if str(return_type) == '5' or str(return_type).lower() == 'rtt_min':
                    return rets[4]
                    
                if str(return_type) == '6' or str(return_type).lower() == 'rtt_avg':
                    return rets[5]
                    
                if str(return_type) == '7' or str(return_type).lower() == 'rtt_max':
                    return rets[6]
                    
                if str(return_type) == '8' or str(return_type).lower() == 'rtt_mdev':
                    return rets[7]
                    
            else:
                self._logger().debug("something went wrong, could not perform ping6")
                self._logger().info(output)
                raise Exception("something went wrong, could not perform ping6")
            
    def ping(self, ipv4, count = 5, interval = 1, packetsize = 56, return_type = 3):
        """This resembles the unix-ping except this supports only a few options.
        By default ``count`` is 5, ``interval`` is 1 sec and ``packetsize`` is 56 byte.
        New values can be provided with the keyword.
        
        It supports following return types:
        - ``1`` OR ``tx_pkt`` for number of packets transmitted
        - ``2`` OR ``rx_pkt`` for number of packets received 
        - ``3`` OR ``succ_rate`` for the success percentage
        - ``4`` OR ``total_time`` for total time the in ms
        - ``5`` OR ``rtt_min`` for minimum RTT in ms
        - ``6`` OR ``rtt_avg`` for average RTT in ms
        - ``7`` OR ``rtt_max`` for maximum RTT in ms
        - ``8`` OR ``rtt_mdev`` for standard deviation in ms
        - ``0`` OR ``all`` will return data for all return types (1-8) as python-tuple.
        
        If timeout occurs (in absence of any response) and RTT statistics is not generated and 
        ``return_type`` falls under RTT statistics category, a python-like ``None`` is returned.
        
        Default return type is ``3`` for backward compatibility.
        ``return_type`` is new in version 0.5
        
        Example:
        
        | =keyword= |     =ipv4=    | =count=  | =interval= |  =packetsize=  | =return_type=       |                              =output=                                                            |
        | `ping`    | 10.21.100.225 |          |            |                |                     | Performs ping with default values of count, interval, packetsize and returns success percentage  |
        | `ping`    | 10.21.100.225 | count=20 | interval=2 | packetsize=120 |                     | Performs ping with provided values of count, interval, packetsize and returns success percentage |
        | `ping`    | 10.21.100.225 | count=20 | interval=2 | packetsize=120 | return_type=6       | Performs ping with provided values of count, interval, packetsize and returns average rtt        |
        | `ping`    | 10.21.100.225 | count=20 | interval=2 | packetsize=120 | return_type=rtt_avg | Performs ping with provided values of count, interval, packetsize and returns average rtt        |
        """
        try:
            count = int(count)
        except ValueError:
            count = 5
        
        try:
            interval = int(interval)
        except ValueError:
            interval = 1
            
        try:
            packetsize = int(packetsize)
        except ValueError:
            packetsize = 56 
           
        try:
            command = 'ping ' + ipv4 + ' -c ' + str(count) + ' -i ' + str(interval) + ' -s ' + str(packetsize)
            output = Connection.execute_command(self,command)
            self._logger().info('Executed command for NIC with IP: %s' %ipv4)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:        
            if(output.find('unknown host') != -1):
                self._logger().debug('unknown host {}: provide valid ipv4'.format(ipv4))
                raise Exception('unknown host {}: provide valid ipv4'.format(ipv4))
            
            match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (\d+)ms\s*rtt min/avg/max/mdev = (\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+) ms', output)
            if not match:
                match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (/d+)ms', output)
     
            if(match):
                rets = []
                for i in range(8):
                    try:
                        rets.append(match.group(i+1))
                    except IndexError:
                        rets.append(None)
                
                if str(return_type) == '0' or str(return_type).lower() == 'all':
                    rets[2] = str(100 - int(rets[2]))
                    return tuple(rets)
                
                if str(return_type) == '1' or str(return_type).lower() == 'tx_pkt':
                    return rets[0]
                
                if str(return_type) == '2' or str(return_type).lower() == 'rx_pkt':
                    return rets[1]
                    
                if str(return_type) == '3' or str(return_type).lower() == 'succ_rate':
                    success_perc = 100 - int(rets[2])
                    return str(success_perc)
                    
                if str(return_type) == '4' or str(return_type).lower() == 'total_time':
                    return rets[3]
                    
                if str(return_type) == '5' or str(return_type).lower() == 'rtt_min':
                    return rets[4]
                    
                if str(return_type) == '6' or str(return_type).lower() == 'rtt_avg':
                    return rets[5]
                    
                if str(return_type) == '7' or str(return_type).lower() == 'rtt_max':
                    return rets[6]
                    
                if str(return_type) == '8' or str(return_type).lower() == 'rtt_mdev':
                    return rets[7]
            else:
                self._logger().debug("something went wrong, could not perform ping")
                self._logger().info(output)
                raise Exception("something went wrong, could not perform ping")
     
    def simultaneous_ping(self, list_of_ipv4, count = 5, interval = 1, packetsize = 56, return_type = 'rtt_avg'):
        """This simultaneously pings all the ipv4 in the list ``list_of_ipv4``. It internally uses the unix-ping and supports only a few options.
        By default ``count`` is 5, ``interval`` is 1 sec and ``packetsize`` is 56 byte.
        New values can be provided with the keyword.
        
        It supports following return types:
        - ``1`` OR ``tx_pkt`` for number of packets transmitted
        - ``2`` OR ``rx_pkt`` for number of packets received 
        - ``3`` OR ``succ_rate`` for the success percentage
        - ``4`` OR ``total_time`` for total time the in ms
        - ``5`` OR ``rtt_min`` for minimum RTT in ms
        - ``6`` OR ``rtt_avg`` for average RTT in ms
        - ``7`` OR ``rtt_max`` for maximum RTT in ms
        - ``8`` OR ``rtt_mdev`` for standard deviation in ms
        - ``0`` OR ``all`` will return data for all return types (1-8) as python-tuple.
        
        If timeout occurs (in absence of any response) and RTT statistics is not generated and 
        ``return_type`` falls under RTT statistics category, a python-like ``None`` is returned.
        
        Default return type is ``rtt_avg``.
        
        Example:
        
        | =keyword=             |  =ipv4=  | =count=  | =interval= |  =packetsize=  | =return_type=       |                              =output=                                                            |
        | `Simultaneouus Ping`  | n1,n2,n3 |          |            |                |                     | Performs ping with default values of count, interval, packetsize and returns success percentage  |
        | `Simultaneouus Ping`  | n1,n2,n3 | count=20 | interval=2 | packetsize=120 |                     | Performs ping with provided values of count, interval, packetsize and returns success percentage |
        | `Simultaneouus Ping`  | n1,n2,n3 | count=20 | interval=2 | packetsize=120 | return_type=6       | Performs ping with provided values of count, interval, packetsize and returns average rtt        |
        | `Simultaneouus Ping`  | n1,n2,n3 | count=20 | interval=2 | packetsize=120 | return_type=rtt_avg | Performs ping with provided values of count, interval, packetsize and returns average rtt        |
        """
        try:
            count = int(count)
        except ValueError:
            count = 5
        
        try:
            interval = int(interval)
        except ValueError:
            interval = 1
            
        try:
            packetsize = int(packetsize)
        except ValueError:
            packetsize = 56 
        
        list_of_ipv4 = _to_str_list(list_of_ipv4)
        
        channels = []
        
        for ipv4 in list_of_ipv4:
            command = 'ping ' + ipv4 + ' -c ' + str(count) + ' -i ' + str(interval) + ' -s ' + str(packetsize)
            ishell_obj = Connection.open_interactive_shell(self)
            chan_temp = ishell_obj.chan
            chan_temp.send(command + '\n')
            time_to_wait = count*max((interval-1), 1)
            time.sleep(time_to_wait)
            channels.append(chan_temp)
        
        out_dict = {}
        msg = ''
        for i, chan in enumerate(channels):
            output = ''
            while(not chan.recv_ready()):
                pass
            
            ttime = count*3          # max retry/rtt time in case of no response is considered as around 3 sec
            elapsed = 0
            match = None
            while(not match and elapsed<=ttime):
                time.sleep(1.1)
                elapsed += 1
                while(chan.recv_ready()):
                    data = chan.recv(1024)
                    output += data.decode()
                
                if(output.find('unknown host') != -1):
                    msg += 'unknown host {}: provide valid ipv4'.format(list_of_ipv4[i])
                    self._logger().warning(msg)
                    break
                
                match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (\d+)ms\s*rtt min/avg/max/mdev = (\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+) ms', output)
                if not match:
                    match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (\d+)ms', output)
            chan.close()
            if(match):
                rets = []
                for j in range(8):
                    try:
                        rets.append(match.group(j+1))
                    except IndexError:
                        rets.append(None)
                
                if str(return_type) == '0' or str(return_type).lower() == 'all':
                    rets[2] = str(100 - int(rets[2]))
                    out_dict[list_of_ipv4[i]] = tuple(rets)
                
                if str(return_type) == '1' or str(return_type).lower() == 'tx_pkt':
                    out_dict[list_of_ipv4[i]] = rets[0]
                
                if str(return_type) == '2' or str(return_type).lower() == 'rx_pkt':
                    out_dict[list_of_ipv4[i]] = rets[1]
                    
                if str(return_type) == '3' or str(return_type).lower() == 'succ_rate':
                    success_perc = 100 - int(rets[2])
                    out_dict[list_of_ipv4[i]] = str(success_perc)
                    
                if str(return_type) == '4' or str(return_type).lower() == 'total_time':
                    out_dict[list_of_ipv4[i]] = rets[3]
                    
                if str(return_type) == '5' or str(return_type).lower() == 'rtt_min':
                    out_dict[list_of_ipv4[i]] = rets[4]
                    
                if str(return_type) == '6' or str(return_type).lower() == 'rtt_avg':
                    out_dict[list_of_ipv4[i]] = rets[5]
                    
                if str(return_type) == '7' or str(return_type).lower() == 'rtt_max':
                    out_dict[list_of_ipv4[i]] = rets[6]
                    
                if str(return_type) == '8' or str(return_type).lower() == 'rtt_mdev':
                    out_dict[list_of_ipv4[i]] = rets[7]
                    
            elif elapsed > ttime:
                out_dict[list_of_ipv4[i]] = None
                msg += 'ping timed out for node {}'.format(list_of_ipv4[i]) + '\n'
                self._logger().warning(msg)
                self._logger().info(output)
            else:
                out_dict[list_of_ipv4[i]] = None
                msg += "something went wrong, could not perform ping" + '\n'
                self._logger().warning(msg)
                self._logger().info(output)
        return out_dict
    
    def simultaneous_ping6(self, list_of_ipv6, count = 5, interval = 1, packetsize = 56, return_type = 'rtt_avg'):
        """This simultaneously pings all the ipv6 in the list ``list_of_ipv6``. It internally uses the unix-ping6 and supports only a few options.
        By default ``count`` is 5, ``interval`` is 1 sec and ``packetsize`` is 56 byte.
        New values can be provided with the keyword.
        
        It supports following return types:
        - ``1`` OR ``tx_pkt`` for number of packets transmitted
        - ``2`` OR ``rx_pkt`` for number of packets received 
        - ``3`` OR ``succ_rate`` for the success percentage
        - ``4`` OR ``total_time`` for total time the in ms
        - ``5`` OR ``rtt_min`` for minimum RTT in ms
        - ``6`` OR ``rtt_avg`` for average RTT in ms
        - ``7`` OR ``rtt_max`` for maximum RTT in ms
        - ``8`` OR ``rtt_mdev`` for standard deviation in ms
        - ``0`` OR ``all`` will return data for all return types (1-8) as a python-tuple.
        
        If timeout occurs (in absence of any response) and RTT statistics is not generated and 
        ``return_type`` falls under RTT statistics category, a python-like ``None`` is returned.
        
        Default return type is ``rtt_avg``.
        
        Example:
        
        | =keyword=             |     =ipv4=    | =count=  | =interval= |  =packetsize=  | =return_type=       |                              =output=                                                            |
        | `Simultaneous Ping6`  |  n1,n2,n3,n4  |          |            |                |                     | Performs ping with default values of count, interval, packetsize and returns success percentage  |
        | `Simultaneous Ping6`  |  n1,n2,n3,n4  | count=20 | interval=2 | packetsize=120 |                     | Performs ping with provided values of count, interval, packetsize and returns success percentage |
        | `Simultaneous Ping6`  |  n1,n2,n3,n4  | count=20 | interval=2 | packetsize=120 | return_type=6       | Performs ping with provided values of count, interval, packetsize and returns average rtt        |
        | `Simultaneous Ping6`  |  n1,n2,n3,n4  | count=20 | interval=2 | packetsize=120 | return_type=rtt_avg | Performs ping with provided values of count, interval, packetsize and returns average rtt        |
        """
        try:
            count = int(count)
        except ValueError:
            count = 5
        
        try:
            interval = int(interval)
        except ValueError:
            interval = 1
            
        try:
            packetsize = int(packetsize)
        except ValueError:
            packetsize = 56 
        
        list_of_ipv6 = _to_str_list(list_of_ipv6)
        
        channels = []
        
        for ipv6 in list_of_ipv6:
            command = 'ping6 ' + ipv6 + ' -c ' + str(count) + ' -i ' + str(interval) + ' -s ' + str(packetsize)
            ishell_obj = Connection.open_interactive_shell(self)
            chan_temp = ishell_obj.chan
            chan_temp.send(command + '\n')
            time_to_wait = count*max((interval-1), 1)
            time.sleep(time_to_wait)
            channels.append(chan_temp)
        
        out_dict = {}
        msg = ''
        for i, chan in enumerate(channels):
            output = ''
            while(not chan.recv_ready()):
                pass
            
            ttime = count*3          # max retry/rtt time in case of no response is considered as around 3 sec
            elapsed = 0
            match = None
            while(not match and elapsed<=ttime):
                time.sleep(1.1)
                elapsed += 1
                while(chan.recv_ready()):
                    data = chan.recv(1024)
                    output += data.decode()
                
                if(output.find('unknown host') != -1):
                    msg += 'unknown host {}: provide valid ipv6'.format(list_of_ipv6[i])
                    self._logger().warning(msg)
                    break
                
                match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (\d+)ms\s*rtt min/avg/max/mdev = (\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+)/(\d+\.\d+) ms', output)
                if not match:
                    match = re.search('(\d+) packets transmitted, (\d+) received, (\d+)% packet loss, time (\d+)ms', output)
            chan.close()
            if(match):
                rets = []
                for j in range(8):
                    try:
                        rets.append(match.group(j+1))
                    except IndexError:
                        rets.append(None)
                
                if str(return_type) == '0' or str(return_type).lower() == 'all':
                    rets[2] = str(100 - int(rets[2]))
                    out_dict[list_of_ipv6[i]] = tuple(rets)
                
                if str(return_type) == '1' or str(return_type).lower() == 'tx_pkt':
                    out_dict[list_of_ipv6[i]] = rets[0]
                
                if str(return_type) == '2' or str(return_type).lower() == 'rx_pkt':
                    out_dict[list_of_ipv6[i]] = rets[1]
                    
                if str(return_type) == '3' or str(return_type).lower() == 'succ_rate':
                    success_perc = 100 - int(rets[2])
                    out_dict[list_of_ipv6[i]] = str(success_perc)
                    
                if str(return_type) == '4' or str(return_type).lower() == 'total_time':
                    out_dict[list_of_ipv6[i]] = rets[3]
                    
                if str(return_type) == '5' or str(return_type).lower() == 'rtt_min':
                    out_dict[list_of_ipv6[i]] = rets[4]
                    
                if str(return_type) == '6' or str(return_type).lower() == 'rtt_avg':
                    out_dict[list_of_ipv6[i]] = rets[5]
                    
                if str(return_type) == '7' or str(return_type).lower() == 'rtt_max':
                    out_dict[list_of_ipv6[i]] = rets[6]
                    
                if str(return_type) == '8' or str(return_type).lower() == 'rtt_mdev':
                    out_dict[list_of_ipv6[i]] = rets[7]
                    
            elif elapsed > ttime:
                out_dict[list_of_ipv6[i]] = None
                msg += 'ping timed out for node {}'.format(list_of_ipv6[i]) + '\n'
                self._logger().warning(msg)
                self._logger().info(output)
            else:
                out_dict[list_of_ipv6[i]] = None
                msg += "something went wrong, could not perform ping" + '\n'
                self._logger().warning(msg)
                self._logger().info(output)
        return out_dict
    
    def ping_start(self, source, dest, count = 5, interval=1, size=56, secure_run = True):
        """This keyword is wrapper of net mgr's ping start command.
        ``source`` is the source node and ``dest`` is destination node. 
         
        This returns the reference id if ping starts successfully otherwise -1 is returned.
        
        Example:
        | `Ping Start` | ${node1}  | ${node2} |
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        """ 
        try:
            count = int(count)
        except ValueError:
            count = 5
            
        net_mgr = 'net_mgrS -d ' if secure_run else 'net_mgr -d '
        
        command = net_mgr + source + ' ping start ' + dest + ' ' + str(count) + ' ' + str(interval) + ' ' + str(size)
        try:
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().debug(e)
            raise Exception(e)
        else:
            match = re.search('Ping started with reference: (\d+)',output)
            if match:
                return match.group(1)
            else:
                return -1
            
    def ping_stop(self, source, ref, secure_run = True):
        """This keyword is wrapper of net mgr's ping stop.
        ``source`` is the source node.
        ``ref`` is the returned value of `Ping Start`.
        
        This returns ``Ok`` if successful.
        
        Example:
        | `Ping Stop` | fd59::1234 | ${ref} | 
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        """
        net_mgr = 'net_mgrS -d ' if secure_run else 'net_mgr -d '
        command = net_mgr + source + ' ping stop ' + str(ref)
        try:
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if output.find('Ok') != -1:
                self._logger().info('ping with reference %s stopped' % str(ref))
                return 'Ok'
            
            if output.find('No pings in progress') != -1:
                self._logger().info('No pings in progress with reference %s' % str(ref))
                return 'Ok'
            
    def ping_delete(self, source, ref, secure_run = True):
        """This keyword is wrapper of net mgr's ping delete.
        ``source`` is the source node.
        ``ref`` is the returned value of `Ping Start`.
        
        This returns ``Ok`` if successful.
        
        Example:
        | `Ping Delete` | fd59::1234 | ${ref} | 
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        """
        net_mgr = 'net_mgrS -d ' if secure_run else 'net_mgr -d '
        command = net_mgr + source + ' ping delete ' + str(ref)
        try:
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if output.find('Ok') != -1:
                self._logger().info('ping with reference %s deleted' % str(ref))
                return 'Ok'
            
            if output.find('No pings in progress') != -1:
                self._logger().info('No pings in progress with reference %s' % str(ref))
                return 'Ok'  
            
    def ping_clear(self, source, secure_run = True):
        """This keyword is wrapper of net mgr's ping delete.
        ``source`` is the source node.
        
        This returns ``Ok`` if successful.
        
        Example:
        | `Ping Clear` | fd59::1234 |
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        """
        net_mgr = 'net_mgrS -d ' if secure_run else 'net_mgr -d '
        command = net_mgr + source + ' ping clear'
        try:
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if output.find('Ok') != -1:
                self._logger().info('All pings stopped and cleared')
                return 'Ok'
        
    def ping_show(self, source, ref, secure_run = True):
        """This keyword is wrapper of net mgr's ping show.
        ``source`` is the source node.
        ``ref`` is the returned value of `Ping Start`.
        
        This returns a 9-items python-like list: [Ref, Addr, Active, TxPkt, RxPkt, Dups, MinRTT, AvgRTT, MaxRTT]
        This returns python-like empty list if no ping is associated with provided reference id.
        
        Example:
        | `Ping Show` | fd59::1234 | ${ref} | 
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        """
        net_mgr = 'net_mgrS -d ' if secure_run else 'net_mgr -d '
        command = net_mgr + source + ' ping show ' + str(ref)
        try:
            output = Connection.execute_command(self,command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:   
            if output.find('No pings in progress') != -1:
                self._logger().info('No pings in progress with reference %s' % str(ref))
                return []
            
            try:
                output = output.split('\n')[1]
                output = re.sub(' +', ' ', output)
                return output.strip().split(' ')
            except IndexError:
                self._logger().exception('Unexpected output for ping show')
                raise RuntimeError('Unexpected output for ping show')
    
    def ping_list(self, source, secure_run = True):
        """This keyword is wrapper of net mgr's ping show.
        ``source`` is the source node.
        
        This returns a python-like dictionary having the reference ids as key and 8-items python-like list as values: 
        {Ref: [Addr, Active, TxPkt, RxPkt, Dups, MinRTT, AvgRTT, MaxRTT], 
        Ref: [Addr, Active, TxPkt, RxPkt, Dups, MinRTT, AvgRTT, MaxRTT]}
        
        This returns python-like empty dictionary if no reference id is active.
        
        Example:
        | `Ping Show` | fd59::1234 | ${ref} | 
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        """
        net_mgr = 'net_mgrS -d ' if secure_run else 'net_mgr -d '
        command = net_mgr + source + ' ping list'
        try:
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            output_orig = output
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:   
            if output.find('No pings in progress') != -1:
                self._logger().info('No pings in progress')
                return {}
            
            output = output.split('\n')[:-1]
            
            tmp = []
            for line in output:
                line = re.sub(' +', ' ', line)
                tmp.append(line.strip().split(' '))
            output = tmp
            
            table_header_len = len(output[0])
            for alist in output:
                if(table_header_len != len(alist)):
                    self._logger().info(output_orig)
                    raise NotATableError('Unexpected output of ping list')
                
            table = {column[0]:list(column[1:]) for column in zip(*output)}
            return table       
            
    def get_all_timestamps_from_string(self, string, format = '%Y-%m-%d %H:%M:%S'):
        """This keyword returns a python-like list of timestamps 
        matching the format ``format`` in the given string ``string``.
        
        This returns empty python-like list when no match is found.
        
        ``format`` supports 2 kinds:
        - ``Custom Timestamps:`` resembles the python [https://docs.python.org/3/library/datetime.html#strftime-strptime-behavior|datetime.strptime] format. But only supports 6 directives i.e. %Y, %m, %d, %H, %M, %S. 
        - ``Epoch Time:`` Epoch time is the time in seconds since the [https://en.wikipedia.org/wiki/Unix_time|UNIX epoch] i.e. 00:00:00.000 (UTC) 1 January 1970.
        
        Default value of ``format`` is ``%Y-%m-%d %H:%M:%S``.
        
        Example:
        
        | = keyword =                      | = string =  | = format =               |
        | `Get All Timestamps From String` | ${mystring} | format=%Y-%m-%d_%H-%M-%S |
        | `Get All Timestamps From String` | ${mystring} | format=epoch             |
        """
        try:
            modifier = ['%Y', '%m', '%d', '%H', '%M', '%S']
            value = ['\\\\d{4}', '\\\\d{2}', '\\\\d{2}', '\\\\d{2}', '\\\\d{2}', '\\\\d{2}']
            if(format.lower() == 'epoch'):
                regex = r'(\d{10,13})'
            else:
                regex = format
                for i in range(len(modifier)):
                    regex = re.sub(modifier[i], value[i], regex)                
            return re.findall(regex, string)
        except Exception as e:
            self._logger().exception("Could not fetch timestamps: {}".format(e))
            raise Exception("Could not fetch timestamps: {}".format(e))
        
    def rf_ping(self, ipv6, mac_ids, data, count = 1, payload = 100, priority = 4, strict_forward=False, forced_reverse=False, mac_addr_route=None):
        """This returns value for ``data`` from the rf_ping output. Also, this returns 
        ``Timed out`` for invalid mac_id and ``Failed to trace the complete route`` error message 
        from route trace of output
        
        This takes 3 mandatory arguments ``ipv6``, ``mac_ids`` and ``data``.
        
        By default ``count`` is 1, ``payload`` is 100, ``priority`` is 4, ``strict_forward`` 
        is False and ``forced_reverse`` is `False`.
        
        ``strict_forward`` set to `True` sets ``-s`` and ``forced_reverse`` set to `True` 
        sets ``-f`` in the rfping command. 
        
        ``mac_addr_route`` is mac address from route trace for which user need to check tan,
        retries and rssi values
        
        =Note=: ``strict_forward`` need to be set to ``True`` if we are setting ``forced_reverse`` to ``True``.
        =Note=: ``mac_addr_route`` need to be set if we are getting ``tan``,``retries`` or ``rssi`` value for
        a particular mac address from route trace.
        
        New values can be provided with the keyword.
        
        Below are the ``data`` values supported:
        
        - ``0`` OR ``all`` for all output data as string
        - ``1`` OR ``pkts_sent`` for sent packet count
        - ``2`` OR ``pkts_recvd`` for received packet count
        - ``3`` OR ``flags`` for flags
        - ``4`` OR ``bytes`` for bytes data 
        - ``5`` OR ``seq`` for sequence
        - ``6`` OR ``ttl`` for ttl value
        - ``7`` OR ``addr_count`` for address count
        - ``8`` OR ``cur_off`` for cur off
        - ``9`` OR ``rtt`` for rtt data
        - ``10`` OR ``priority`` for priority value
        - ``11`` OR ``rtt_max`` for rtt max data
        - ``12`` OR ``rtt_min`` for rtt min data
        - ``13`` OR ``rtt_avg`` for rtt avg data
        - ``14`` OR ``route_trace`` for route_trace data
        - ``15`` OR ``dst_mac_addr`` for destination/hop MAC address
        - ``16`` OR ``tan_route_mac_addr`` for getting tan value of particular mac address from route trace
        - ``17`` OR ``retries_route_mac_addr`` for getting retries value of particular mac address from route trace
        - ``18`` OR ``rssi_route_mac_addr`` for getting rssi value of particular mac address from route trace
        
        Example:
        
        | =keyword= |                   =ipv6=                |     =data=    | =count= |  =payload=  | =priority= | =strict_forward= | =forced_reverse= |     =mac_addr_route=    |                       =mac_ids=                 |                       =command=                    |       =comment=        |    
        | `RFPing`  | FD59:4C3E:4420:0009:0213:5005:00F7:1506 |     data=1    |         |             |            |                  |                  |                         | 00:13:50:05:00:7f:97:fb 00:13:50:02:00:0b:99:bc | rf_ping -d <ipv6> -c 1 -l 255 -r 4 <mac_ids>       |
        | `RFPing`  | FD59:4C3E:4420:0009:0213:5005:00F7:1506 |  data=rtt_avg | count=5 | payload=150 | priority=1 | True             |                  |                         | 00:13:50:05:00:7f:97:fb                         | rf_ping -d <ipv6> -c 5 -l 150 -r 1 -s <mac_ids>    |
        | `RFPing`  | FD59:4C3E:4420:0009:0213:5005:00F7:1506 | data=priority | count=3 | payload=200 | priority=2 | True             | True             |                         | 00:13:50:05:00:7f:97:fb                         | rf_ping -d <ipv6> -c 3 -l 200 -r 2 -s -f <mac_ids> |
        | `RFPing`  | FD59:4C3E:4420:0009:0213:5005:00F7:1506 | data=16       | count=3 | payload=200 | priority=2 | True             | True             | 00:13:50:02:00:0b:99:bc | 00:13:50:05:00:7f:97:fb 00:13:50:02:00:0b:99:bc | rf_ping -d <ipv6> -c 3 -l 200 -r 2 -s -f <mac_ids> | This will provide tan\
                                                                                                                                                                                                                                                                                           for provided mac addr   |
                 
        """

        try:
            count = int(count)
        except ValueError:
            count = 2
         
        try:
            payload = int(payload)
            if (not(payload >=0 and payload <=255)):
                self._logger().debug("Invalid Payload. Payload must be 0 <= payload <=255")
                raise Exception("Invalid Payload. Payload must be 0 <= payload <= 255")
        except ValueError:
            payload = 255
             
        try:
            priority = int(priority)
            if (not(priority >=1 and priority <=5)):
                self._logger().debug("Invalid Priority. Priority must be 1 <= priority <= 5")
                raise Exception("Invalid Priority. Priority must be 1 <= priority <= 5")
        except ValueError:
            priority = 4
                
        try:
            if (strict_forward == True and forced_reverse == False):
                command = 'rf_ping -d ' + ipv6 + ' -c ' + str(count) + ' -l ' + str(payload) + ' -r ' + str(priority) + ' -s ' + str(mac_ids)
                self._logger().info(command)
                output = Connection.execute_command(self,command)
                self._logger().info('Executed command for NIC with IP: %s' %ipv6)
                self._logger().info(output)
            elif(forced_reverse == True and strict_forward == True):
                command = 'rf_ping -d ' + ipv6 + ' -c ' + str(count) + ' -l ' + str(payload) + ' -r ' + str(priority) + ' -s -f ' + str(mac_ids)
                self._logger().info(command)
                output = Connection.execute_command(self,command)
                self._logger().info('Executed command for NIC with IP: %s' %ipv6)
                self._logger().info(output)
            elif(forced_reverse == True and strict_forward == False):
                self._logger().debug("Please set 'strict_forward' to 'True', if 'forced_reverse' is set to 'True'")
                raise Exception("Please set 'strict_forward' to 'True', if 'forced_reverse' is set to 'True'")
            else:
                command = 'rf_ping -d ' + ipv6 + ' -c ' + str(count) + ' -l ' + str(payload) + ' -r ' + str(priority) + ' ' + str(mac_ids)
                self._logger().info(command)
                output = Connection.execute_command(self,command)
                self._logger().info('Executed command for NIC with IP: %s' %ipv6)
                self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else: 
            #self._logger().info(output)       
            if(output.find('unknown host') != -1):
                self._logger().debug('unknown host {}: provide valid ipv6'.format(ipv6))
                raise Exception('unknown host {}: provide valid ipv6'.format(ipv6))
             
            invalid_ping_message = 'Timed out'
            failure_message = 'Failed to trace the complete route'
             
            '''Verifying packet sent and received count in output'''
            out_list=[]
            if invalid_ping_message in output:
                '''Checking for failure condition'''
                self._logger().info("Failure occurred in RF Ping: {}".format(invalid_ping_message))
                return invalid_ping_message + " displayed in route trace" 
            elif failure_message in output:
                '''Checking for failure condition'''
                self._logger().info("Failure occurred in RF Ping: {}".format(failure_message))
                return failure_message + " displayed in route trace"
            
            pkt_sent = re.search('(\d+) pkts sent', output)
            out_list.append(None if not pkt_sent else pkt_sent.group(1))
            
            pkt_recvd = re.search(', (\d+) pkts recvd', output)
            out_list.append(None if not pkt_recvd else pkt_recvd.group(1))
            
            flags = re.search(' flags=(.*), seq=', output, re.I)
            out_list.append(None if not flags else flags.group(1))
            
            bytes_data = re.search('(\d+) bytes from', output, re.I)
            out_list.append(None if not bytes_data else bytes_data.group(1))
            
            sequence = re.search(' seq=(\d+),', output, re.I)
            out_list.append(None if not sequence else sequence.group(1))
            
            ttl_data = re.search(' ttl=(\d+),', output, re.I)
            out_list.append(None if not ttl_data else ttl_data.group(1))
            
            address_count = re.search(' addr_cnt=(\d+),', output, re.I)
            out_list.append(None if not address_count else address_count.group(1))
            
            cur_off = re.search(' cur_off=(\d+),', output, re.I)
            out_list.append(None if not cur_off else cur_off.group(1))
            
            rtt_data = re.search(' rtt=(\d+)', output, re.I)
            out_list.append(None if not rtt_data else rtt_data.group(1))
            
            priority = re.search(' prio=(\d+)', output, re.I)
            out_list.append(None if not priority else priority.group(1))
            
            rtt_max = re.search('rtt_max=(\d+) ms', output, re.I)
            out_list.append(None if not rtt_max else rtt_max.group(1))
            
            rtt_min = re.search('rtt_min=(\d+) ms', output, re.I)
            out_list.append(None if not rtt_min else rtt_min.group(1))
            
            avg_rtt = re.search('rtt_avg=(\d+) ms', output, re.I)
            out_list.append(None if not avg_rtt else avg_rtt.group(1))
            
            dst_mac_addr = re.search(r'(?:[0-9a-fA-F]:?){16}', output, re.I)
            out_list.append(None if not dst_mac_addr else dst_mac_addr.group(0))
                     
            route_trace = re.findall('-> (.*) ', output, re.M)
            output_mac_list=[]
            if(route_trace):
                for values in route_trace[:int(len(route_trace)/count)]:
                    val=values.split(',', maxsplit=1)[0]
                    output_mac_list.append(val)
            
            if (mac_addr_route is not None):
                if '=-' in output:
                    route_data=re.findall(r''+mac_addr_route.casefold()+', tan=(\d+) us, retries=(\d+), rssi=(-\d+) dbm',output)
                else:
                    route_data=re.findall(r''+mac_addr_route.casefold()+', tan=(\d+) us, retries=(\d+), rssi=(\d+) dbm',output)
                
                tan_mac_addr = str(route_data[0][0])+' us'
                retries_mac_addr = str(route_data[0][1])
                rssi_mac_addr =  str(route_data[0][2])+' dbm'
            
            if str(data) == '0' or str(data).lower() == 'all':
                return output
            
            if str(data) == '1' or str(data).lower() == 'pkts_sent':
                return out_list[0]
            
            if str(data) == '2' or str(data).lower() == 'pkts_recvd':
                return out_list[1]
            
            if str(data) == '3' or str(data).lower() == 'flags':
                return out_list[2]
            
            if str(data) == '4' or str(data).lower() == 'bytes':
                return out_list[3]
            
            if str(data) == '5' or str(data).lower() == 'seq':
                return out_list[4]
            
            if str(data) == '6' or str(data).lower() == 'ttl':
                return out_list[5]
            
            if str(data) == '7' or str(data).lower() == 'addr_count':
                return out_list[6]
            
            if str(data) == '8' or str(data).lower() == 'cur_off':
                return out_list[7]
            
            if str(data) == '9' or str(data).lower() == 'rtt':
                return out_list[8]
            
            if str(data) == '10' or str(data).lower() == 'priority':
                return out_list[9]
            
            if str(data) == '11' or str(data).lower() == 'rtt_max':
                return out_list[10]
            
            if str(data) == '12' or str(data).lower() == 'rtt_min':
                return out_list[11]
            
            if str(data) == '13' or str(data).lower() == 'rtt_avg':
                return out_list[12]
            
            if str(data) == '14' or str(data).lower() == 'route_trace':
                return output_mac_list
            
            if str(data) == '15' or str(data).lower() == 'dst_mac_addr':
                return out_list[13]
            
            if str(data) == '16' or str(data).lower() == 'tan_route_mac_addr':
                return tan_mac_addr
            
            if str(data) == '17' or str(data).lower() == 'retries_route_mac_addr':
                return retries_mac_addr
            
            if str(data) == '18' or str(data).lower() == 'rssi_route_mac_addr':
                return rssi_mac_addr
            
    def get_mac_addr_of_ipv6(self, ipv6):
        """This keyword give the mac address of provided ipv6
        """
        ipv6parts = ipv6.split(":") 
        macParts=[]
        for ipv6part in ipv6parts[-4:]:
            while len(ipv6part) < 4:
                ipv6part = "0" + ipv6part
            macParts.append(ipv6part[:2])
            macParts.append(ipv6part[-2:])

        # modify parts to match MAC value
        macParts[0] = "%02x" % (int(macParts[0], 16) ^ 2)
     
        return ":".join(macParts)

    def set_fake_link_qual(self, fake_link_qual, node = None, secure_run = True):
        """
        Author: Banoth Saikumar
        
        This keyword sets the Fake Link Quality of provided node
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``fake_link_qual`` .
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |  =Keyword=            | = fake_link_qual = |  =node=        |                            =Comment=                      |
        | `Set Fake Link Qual`  |   60               | 0013:0000:0034 | This will set provided Fake Link Quality for given Node   |
        | `Set Fake Link Qual`  |   60               |                | This will set provided Fake Link Quality for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            FakeLinkQual = int(fake_link_qual)
        except ValueError:
            logger.debug("Fake Link Qual must be either integer or string-convertible-to-integer")
            raise Exception("Fake Link Qual must be either integer or string-convertible-to-integer")
         
        if (not (FakeLinkQual >= 0 and FakeLinkQual <= 100) ):
            self._logger().exception("Invalid Fake Link Qual. Fake Link Qual must be greater than equal 0 and less than equal 100")
            raise Exception("Invalid Fake Link Qual. Fake Link Qual must be greater than equal 0 and less than equal 100") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Fake Link Qual")
            command = net_mgr_and_node + ' conf srt fake_link_qual ' + str(FakeLinkQual)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Fake Link Qual failed: {}".format(e))
            raise Exception("Setting Fake Link Qual failed: {}".format(e))
        return output
        
    def get_fake_link_qual(self, node = None, secure_run = True):
        """
        Author: Banoth Saikumar
        
        This keyword sets the Fake Link Quality of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Fake info tx percent`` on success.

        = Examples =
        |  =Keyword=            |  =node=        |                            =Comment=             |
        | `Get Fake Link Qual`  | 0013:0000:0034 | This will get Fake Link Quality for given Node   |
        | `Get Fake Link Qual`  |                | This will get Fake Link Quality for default Node |
        
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Getting Fake Link Qual")
            command = net_mgr_and_node + ' conf srt fake_link_qual | awk ' + "'" + '{print $8}' + "'"
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Getting Fake Link Qual failed: {}".format(e))
            raise Exception("Getting Fake Link Qual failed: {}".format(e))
        return output
    
    def fetch_ipv6_sysif(self, node=None, mhome=3, secure_run=True):

        """This keyword is wrapper of net mgr's sysif show rf0.

        Keyword will  take optional  argument ``mhome``  and valid range for the ``mhome`` are 1,3,4 and 9. 
        Default value of ``mhome`` is 3.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``.

        = Example =
        | =keyword=          |                   =node=                 |  =mhome=     |      =Comments=            |
        | `fetch_ipv6_sysif` |                                          |              | return mhome3 ipv6 address |
        | `fetch_ipv6_sysif` | FD59:4C3E:4420:0009:0213:5005:00F7:1506  |              | return mhome3 ipv6 address |
        | `fetch_ipv6_sysif` | 10.21.101.62                             | mhome=3      | return mhome3 ipv6 address |
        | `fetch_ipv6_sysif` | FD59:4C3E:4420:0009:0213:5005:00F7:1506  | mhome=4      | return mhome4 ipv6 address |
        | `fetch_ipv6_sysif` | 10.21.101.62                             | mhome=1      | return mhome1 ipv6 address |
        | `fetch_ipv6_sysif` | 10.21.101.62                             | mhome=9      | return mhome9 ipv6 address |

        This returns the node's mhome address based on value provided by the user . If value is not provided for mhome
        it will return default mhome-3 address.

        Author : Srinivas
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            if (secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                try:
                    mhome = int(mhome)
                except ValueError :
                        self._logger().exception("mhome value must be either integer or string-convertible-to-integer")
                        raise Exception("mhome value must be either integer or string-convertible-to-integer")
            if (not (mhome >= 1 and mhome <= 4 and mhome != 2  and mhome != 9 )):
                self._logger().debug("Invalid mhome value. Valid  Supported   mhome values shall be  1 ,3 , 4 and 9")
                raise Exception("Invalid mhome value. Valid  mhome addresses shall  be 1 ,3 , 4 and 9")

            command = net_mgr_and_node + ' sysif show rf0'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Ipv6 mhome address")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'Multihome address ' + str(mhome) + ': (.*)/(\d+)', output)
            if (match):
                 ipv6 = match.group(1)
                 self._logger().info("Ipv6 address : {}".format(output))
            else:
                 self._logger().debug("Exception occurred while getting ipv6 address: {}".format(output))
                 raise Exception("Exception occurred while getting ipv6: {}".format(output))
            return ipv6
            
    def get_utility_attr_substation(self, node=None, secure_run=False):
        """
        This keyword gets the   Substation   value configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

         A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        = Examples =
        |           =Keyword=                  |     =Node=     |                           =Comment=                 |
        | `Get Utility Attr Substation `       | 0001:0045:0a26 | This will get the   substation value given Node     |
        | `Get Utility Attr Substation `       |                | This will get the substation value for default Node |

        This returns the node's ``substation`` value in seconds on success.
       
        Author :Srinivas K S            
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme  node_substation'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting   substation value  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)', output)
            if (match):
                substation = match.group(0)
                self._logger().info('substation value{}'.format(output))
            else:
                self._logger().debug("Exception occurred while getting substation  value  {}".format(output))
                raise Exception("Exception occurred while getting substation value {}".format(output))
            return substation

    def set_utlity_attr_substation(self,substation, node=None, secure_run=False):
        """
        This keyword sets the substation value provided by the node IP

        This takes 1 mandatory argument ``substation`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=                   | =substation=           |  =Node=        |                          =Comment=                         |
        | `Set Utility Atrr Substation`  |       100              | 0013:0000:0034 | This will set provided value for Substation for the Node   |
        | `Set Utiltiy Attr Substation`  |       65535            |                | This will set provided value for Substation  the Node      |

        Range for  Substation value is 0 to 4294967295.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.
        Author :Srinivas K S

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            substation = int(substation)

        except ValueError:
            self._logger().exception("substation   value must be either hex or string-convertible-to-hex")
            raise Exception("substation value must be either hex or string-convertible-to-hex")

        if (not (substation >= 0 and substation <= 4294967295)):
            self._logger().debug(
                "Invalid substion value. value  must be 0 <= substation <=4294967295")
            raise Exception(
                "Invalid substation value.  value must be 0 <= substation <=4294967295")

        try:
            self._logger().info("Setting  substation value ")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme node_substation  ' + str(substation)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Substation value failed: {}".format(e))
            raise Exception("Setting Substation  value failed: {}".format(e))
        return output

    def get_utility_attr_feeder(self, node=None, secure_run=False):
        """
        This keyword gets the   ``feeder``   value configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

         A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        = Examples =
        |           =Keyword=         |     =Node=     |                        =Comment=                   |
        | `Get Utility Attr Feeder `  | 0001:0045:0a26 | This will get the   Feeder value given Node        |
        | `Get Utility Attr Feeder `  |                | This will get the Feeder value for default Node    |

        This returns the node's ``Feeder`` value in seconds on success.
        Author :Srinivas K S
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme node_feeder'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting   Feeder value  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)', output)
            if (match):
                feeder = match.group(0)
                self._logger().info('Feeder value{}'.format(output))
            else:
                self._logger().debug("Exception occurred while getting Feeder  value  {}".format(output))
                raise Exception("Exception occurred while getting Feeder value {}".format(output))
            return feeder

    def set_utlity_attr_feeder(self,feeder, node=None, secure_run=False):
        """This keyword sets the feeder value provided by the node IP

        This takes 1 mandatory argument ``feeder`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=               | =feeder=           |  =Node=        |                          =Comment=                    |
        | `Set Utility Atrr Feeder`  |       100          | 0013:0000:0034 | This will set provided value for Feeder  for the Node |
        | `Set Utiltiy Attr Feeder`  |       65535        |                | This will set provided value for  Feeder  the Node    |

        Range for  Transformer value is 0 to 4294967295.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.
        Author : Srinivas

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            feeder = int(feeder)

        except ValueError:
            self._logger().exception("feeder record value must be either hex or string-convertible-to-hex")
            raise Exception("feeder  record value must be either hex or string-convertible-to-hex")

        if (not (feeder >= 0 and feeder <= 4294967295)):
            self._logger().debug(
                "Invalid feeder  value.feeder value  must be 0 <= feeder <=4294967295")
            raise Exception(
                "Invalid feeder value. feeder record value must be 0 <= feeder <=4294967295")

        try:
            self._logger().info("Setting  feeder value ")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme node_feeder  ' + str(feeder)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Feeder value failed: {}".format(e))
            raise Exception("Setting Feeder value  value failed: {}".format(e))
        return output

    def get_utility_attr_lateral(self, node=None, secure_run=False):
        """
        This keyword gets the   ``lateral``   value configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

         A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        = Examples =
        |           =Keyword=          |     =Node=     |                       =Comment=                     |
        | `Get Utility Attr Lateral `  | 0001:0045:0a26 | This will get the  Lateral value given Node         |
        | `Get Utility Attr Lateral `  |                | This will get the Lateral value for default Node    |

        This returns the node's ``Lateral`` value in seconds on success.

        Author :Srinivas
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme node_lateral'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting   lateral value  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)', output)
            if (match):
                lateral = match.group(0)
                self._logger().info('lateral value{}'.format(output))
            else:
                self._logger().debug("Exception occurred while getting lateral  value  {}".format(output))
                raise Exception("Exception occurred while getting lateral value {}".format(output))
            return lateral

    def set_utlity_attr_lateral(self,lateral, node=None, secure_run=False):
        """
        This keyword sets the lateral value provided by the node IP

        This takes 1 mandatory argument ``lateral`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=                    | =lateral=           |  =Node=        |                          =Comment=                       |
        | `Set Utility Atrr  Lateral`     |       100           | 0013:0000:0034 | This will set provided value for lateral  for the Node   |
        | `Set Utiltiy Attr Lateral`      |       65535         |                | This will set provided value for lateral the Node        |

        Range for  lateral value is 0 to 4294967295.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.
        Author :Srinivas K S

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            lateral= int(lateral)

        except ValueError:
            self._logger().exception("lateral  record value must be either hex or string-convertible-to-hex")
            raise Exception("lateral  record value must be either hex or string-convertible-to-hex")

        if (not (lateral >= 0 and lateral <= 4294967295)):
            self._logger().debug(
                "Invalid lateral  value.lateral value  must be 0 <= lateral <=4294967295")
            raise Exception(
                "Invalid  lateral value. lateral record value must be 0 <= lateral <=4294967295")

        try:
            self._logger().info("Setting  lateral value ")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme node_lateral ' + str(lateral)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Transformer failed: {}".format(e))
            raise Exception("Setting Transformer  value failed: {}".format(e))
        return output

    def get_utility_attr_transformer(self, node=None, secure_run=False):
        """
        This keyword gets the   Feeder   value configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

         A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        = Examples =
        |           =Keyword=              |     =Node=     |                       =Comment=                         |
        | `Get Utility Attr transformer `  | 0001:0045:0a26 | This will get the  transformer value given Node         |
        | `Get Utility Attr transformer `  |                | This will get the   transformer value for default Node  |

        This returns the node's ``transformer`` value in seconds on success.
        Author :Srinivas K S
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme node_xfr '
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting   transformer value  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)', output)
            if (match):
                transformer = match.group(0)
                self._logger().info('transformer value{}'.format(output))
            else:
                self._logger().debug("Exception occurred while getting transformer  value  {}".format(output))
                raise Exception("Exception occurred while getting transformer value {}".format(output))
            return  transformer

    def set_utlity_attr_transformer(self,transformer,node=None,secure_run=False):
        """
        This keyword sets the transformer value provided by the node IP

        This takes 1 mandatory argument ``transformer`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=                    | =transformer=           |  =node=        |                          =Comment=                         |
        | `Set Utility Atrr Transformer`  |       100               | 0013:0000:0034 | This will set provided value for Transformer  for the Node |
        | `Set Utiltiy Attr Transformer`  |       65535             |                | This will set provided value for Transformer  the Node     |

        Range for  Transformer value is 0 to 4294967295.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        Author : Srinivas

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            transformer=int(transformer)

        except ValueError:
            self._logger().exception("transformer  record value must be either hex or string-convertible-to-hex")
            raise Exception("transformer  record value must be either hex or string-convertible-to-hex")

        if (not (transformer >= 0 and transformer <= 4294967295)):
            self._logger().debug("Invalid transformer  value.Transformer value  must be 0 <= transformer <=4294967295")
            raise Exception("Invalid transformer value. Transformer record value must be 0 <= transformer <=4294967295")

        try:
            self._logger().info("Setting  Transformer value ")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme node_xfr  '+ str(transformer)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting Transformer failed: {}".format(e))
            raise Exception("Setting Transformer  value failed: {}".format(e))
        return output


    def fetch_util_attr_neighbour(self,node=None,util_attr='ap',secure_run=False):

        """
        Keyword will  take optional  argument ``util_attr``  and valid range for the ``util_attr`` are ap or substation
        or feeder or lateral or transformer .

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``.

        = Example =
        |        =keyword=             |   =node=           |  =util_attr=           |      =Comments=                                             |
        | `Fetch  Util Attr Neighbour` |   10.21.100.248    |  util_attr=ap          | return list of ap as mentioned below in step-1              |
        | `Fetch  Util Attr Neighbour` |   10.21.100.248    |  util_attr=substation  | return dict of  mac and substation as mentioned in step 2   |
        | `Fetch  Util Attr Neighbour` |   10.21.100.248    |  util_attr=feeder      | return dict of  mac and feeder as mentioned in step 3       |
        | `Fetch  Util Attr Neighbour` |   10.21.100.248    |  util_attr=lateral     | return dict of  mac and lateral as mentioned in step 4      |
        | `Fetch  Util Attr Neighbour` |   10.21.100.248    |  util_attr=transformer | return dict of  mac and transformer as mentioned in step 5  |

        This returns the  list or dictionary  based on following input

            1. If input is ap --> return the list of  mac address of AP/BBD of nodeq2 having device type 2

            2. If it is substation --> return the dictionary of mac address and substation values of neighbours having
               dev type(15/91) which has different value other DUT's substation value

            3  If it is feeder --> return the dictionary of mac address and feeder values of neighbours having
               dev type(15/91) which has different value other DUT's feeder value

            4.  If it is lateral --> return the dictionary of mac address and lateral values of neighbours having
               dev type(15/91) which has different value other DUT's lateral value

            5. If it is transformer --> return the dictionary of mac address and transformer values of neighbours having
               dev type(15/91) which has different value other DUT's transformer value

            By default keyword will use utlity_input as ap and return the list of mac address of AP/BBD of nodeq2
            having device type 2


        Author : Srinivas
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            if (secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node

            try:
                util_attr = str(util_attr).lower()

            except ValueError :
                self._logger().exception("util_attr value must be  string convertible")
                raise Exception("util_attr value must be  string convertible")
                        

            if (not (util_attr == 'ap' or  util_attr == 'substation' or util_attr == 'feeder' or util_attr == 'lateral' or util_attr == 'transformer' )):
                self._logger().debug("Invalid utility attribute value. Valid Supported values shall be  ap  or substation or feeder or lateral  or transformer")
                raise Exception("Invalid utility attribute value. Valid range : ap  or substation or feeder or lateral  or transformer")

            if util_attr == 'ap' :

                command = net_mgr_and_node + ' nodeq 2 | awk  \'$9 == 2 {print $1}\'  '

            elif   util_attr == 'substation' :
                self._logger().info("Getting utility attribute-substation value-configured")
                dut_substation=self.get_utility_attr_substation(node=node)
                command= net_mgr_and_node + ' nodeq 2 | awk  \'$9 != 2 {print $1,"\t" $2}\' |grep -iEv \'node|mac\' '

            elif   util_attr == 'feeder' :
                self._logger().info("Getting utility attribute-feeder value-configured")
                dut_feeder=self.get_utility_attr_feeder(node=node)
                command= net_mgr_and_node + ' nodeq 2 | awk  \'$9 != 2 {print $1,"\t" $3}\' |grep -iEv \'node|mac\' '

            elif   util_attr == 'lateral' :
                self._logger().info("Getting utility attribute-lateral value-configured")
                dut_lateral=self.get_utility_attr_lateral(node=node)
                command= net_mgr_and_node + ' nodeq 2 | awk  \'$9 != 2 {print $1,"\t" $4}\' |grep -iEv \'node|mac\' '

            elif   util_attr == 'transformer' :
                self._logger().info("Getting utility attribute-transformer value-configured")
                dut_transformer=self.get_utility_attr_transformer(node=node)
                command= net_mgr_and_node + ' nodeq 2 | awk  \'$9 != 2 {print $1,"\t" $5}\' |grep -iEv \'node|mac\' '


            output=Connection.execute_command(self,command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting nodes deatils  using nodeq 2 {}'.format(node))



        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

        else:
            if util_attr == 'ap':
                result = [string for string in output.replace(':', '').split('\n') if string != ""]
                return result

            elif util_attr == 'substation':

                list1=output.replace(':', '').split()
                keys=list1[::2]
                values=list1[1::2]
                dict={}
                for i in range(0,len(keys)):
                    if (int(dut_substation) != int(values[i][2::],16) ):
                        dict[keys[i]]=values[i]
                return dict

            elif util_attr == 'feeder':

                list1=output.replace(':', '').split()
                keys=list1[::2]
                values=list1[1::2]
                dict={}
                for i in range(0,len(keys)):
                    if (int(dut_feeder) != int((values[i][2::]),16 )):
                        dict[keys[i]]=values[i]
                return dict

            elif util_attr == 'lateral':

                list1=output.replace(':', '').split()
                keys=list1[::2]
                values=list1[1::2]
                dict={}
                for i in range(0,len(keys)):
                    if (int(dut_lateral) != int((values[i][2::]),16 )):
                        dict[keys[i]]=values[i]
                return dict

            elif util_attr == 'transformer':

                list1 = output.replace(':', '').split()
                keys = list1[::2]
                values = list1[1::2]
                dict = {}
                for i in range(0, len(keys)):
                    if (int(dut_transformer) != int((values[i][2::]),16)):
                        dict[keys[i]] = values[i]
                return dict

    def set_flickerInSecs_xml(self, flicker_time, node=None):

        """
        This keyword sets the flickerInsecs value in XML FILE ``/usr/share/itron/Customer/UIQ/InitialConfig.xml``

        This takes 1 mandatory argument ``flickerInsec`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``output of transcation command`` on success.

        = Examples =
        |    =Keyword=                    | =flicker_time=           |  =node=        |                          =Comment=                                      |
        | `Set FlickerInSecs XML`         |       100                | 0013:0000:0034 | This will set flickerInsecs value in XML FILE of target to 100          |
        | `Set FlickerInSecs XML`         |       3600               |                | This will sset flickerInsecs value in XML FILE to target node to 3600   |

        Range for  flicker value is 0 to 3600.
        
        Author : Srinivas

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            flicker_time = int(flicker_time)

        except ValueError:
            self._logger().exception(" flicker value must be  integer")
            raise Exception("flicker value must be  integer")

        if (not (flicker_time >= 0 and flicker_time <= 3600)):
            self._logger().debug("Invalid flicker value. value  must be 0 <=flicker_time <=3600")
            raise Exception("Invalid flicker value. value  must be 0 <=flicker_time <=3600")

        try:
            self._logger().info("Modifing the  FlickerInSecs value in XML  ")

            command = "sed -i 's/flickerInSecs=\".*\"/flickerInSecs=\"%s\"/' /usr/share/itron/Customer/UIQ/InitialConfig.xml" % flicker_time

            output = Connection.execute_command(self, command)

            self._logger().info("Performing the transcation process to get value reflected as part of Config  ")

            command1 = 'TransactionProcess --event=\"MUSE_V1;Reconfigure;/usr/share/itron/Customer/UIQ/InitialConfig.xml\"'
            output1 = Connection.execute_command(self, command1)

            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output1)

        except Exception as e:
            self._logger().exception("Setting Transformer failed: {}".format(e))
            raise Exception("Setting Transformer  value failed: {}".format(e))


        return output1



    def fetch_rssi_list(self, node=None, secure_run=False):

        """
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``.

        = Example =
        |        =keyword=     |   =node=             |             =Comments=                            |
        | `Fetch  RSSI List `  |   10.21.100.1        |  return dict of mac adress and RSSI of nieghbours |

        This returns the  list or dictionary  of mac address and corresponding RSSI of neighbours based on nodeq 0.

        Author : Srinivas K s
        """

        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            if (secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node

            command = net_mgr_and_node + ' nodeq 0 | awk  \'{print $1,"\t" $11}\' |grep -iEv \'node|mac\' '
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting node\'s mac address and rssi  details  from  nodeq 0 {}'.format(node))


        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

        else:
            try :
                list1 = output.replace(':', '').split()
                keys = list1[::2]
                values = list1[1::2]
                dict = {}

            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)

            for i in range(0,len(keys)):

                dict[keys[i]] = values[i]

            return dict

    def fetch_rssi_list_neighbours(self,utility_attr,node=None,secure_run=False):

        """
        This keyword takes one mandatory argument ``utility_attr`` which is tuple/list of mac address.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``.

        = Example =
        |        =keyword=              |   =utility_attr= | =node=             |             =Comments=                                             |
        | `Fetch  RSSI List Neighbours` |    list_nodes    |  10.21.100.248     | return dict of mac adress and RSSI of nieghbours for mac requested |

        Note List_nodes indicated as part of utility_attr shall be list or tuple of mac address of nodes.

        This returns the  list or dictionary  of mac address and corresponding RSSI of neighbours requested by user list.

        Author : Srinivas
        """

        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            if (secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node

            command = net_mgr_and_node + ' nodeq 0 | awk  \'{print $1,"\t" $11}\' |grep -iEv \'node|mac\' '
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting node\'s mac address and rssi  details  from  nodeq 0 {}'.format(node))

        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

        else:

            try :

                list1 = output.replace(':','').split()
                keys = list1[::2]
                values = list1[1::2]
                dict = {}
                utility_attr = list(utility_attr)
                # Replacing colons to empty
                utility_attr = [entry.replace(':', '') for entry in utility_attr]

            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)



        for i in range(0,len(keys)):
            try:
                if keys[i] in utility_attr:
                    dict[keys[i]] = values[i]

            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)

        return dict