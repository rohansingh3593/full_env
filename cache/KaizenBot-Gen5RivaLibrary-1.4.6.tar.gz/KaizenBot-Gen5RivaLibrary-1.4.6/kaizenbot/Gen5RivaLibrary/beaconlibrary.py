# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in Connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""

import os, re
from kaizenbot.logging_robot import Loggers
from kaizenbot.connection import Connection

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class BeaconLibrary:
    
    def __init__(self):
        pass
    
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError
    
    def get_slow_beacon_rate(self, node = None, secure_run = True):
        """This keyword gets the slow beacon rate of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``BeaconRate` on success.
        
        = Examples =
        |         =Keyword=       |    =NodeIP=    |                =Comment=                         |
        | `Get Slow Beacon Rate`  | 0001:0045:0a26 | This will get slow beacon rate for given Node    |
        | `Get Slow Beacon Rate`  |                | This will get slow beacon rate for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_tx_beacon_rate'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Slow Beacon rate")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MAC beacon transmission rate is set to )\d+', output)
            if(match):
                BeaconRate = match.group(0)
                self._logger().debug("Slow Beacon Rate: {}".format(BeaconRate))
            else:
                self._logger().debug("Exception occurred while getting slow beacon rate: {}".format(output))
                raise Exception("Exception occurred while getting slow beacon rate: {}".format(output))
        return BeaconRate
    
    def get_fast_beacon_rate(self, node = None, secure_run = True):
        """This keyword gets the fast beacon rate of provided node IP
        after performing the calculation i.e. 
        fast beacon rate = slow beacon rate value/fast beacon period value
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``BeaconRate`` on success.
        
        = Examples =
        |         =Keyword=       |    =NodeIP=    |                =Comment=                         |
        | `Get Fast Beacon Rate`  | 0001:0045:0a26 | This will get fast beacon rate for given Node    |
        | `Get Fast Beacon Rate`  |                | This will get fast beacon rate for default Node  |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            output1 = self.get_slow_beacon_rate(node, secure_run)
            output2 = self.get_fast_beacon_period(node, secure_run)
            output = round( int(output1)/int(output2))
            self._logger().info("Fast Beacon Rate: {}".format(output))
        except Exception as e:
            self._logger().exception("Getting fast beacon rate failed: {}".format(e))
            raise Exception("Getting fast beacon rate failed: {}".format(e))
        else:
            return str(output)
    
    def get_fast_beacon_period(self, node = None, secure_run=True):
        """This keyword gets the fast beacon period of provided node IP
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``BeaconPeriod`` on success.
        
        = Examples =
        |         =Keyword=         |    =NodeIP=    |                   =Comment=                       |
        | `Get Fast Beacon Period`  | 0001:0045:0a26 | This will get fast beacon period for given Node   |
        | `Get Fast Beacon Period`  |                | This will get fast beacon period for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
            
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_fast_beacon_period'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Fast Beacon Period")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MAC fast beacon period is set to )\d+',output)
            if(match):
                BeaconPeriod = match.group(0)
                self._logger().debug("Fast Beacon Period: {}".format(BeaconPeriod))
            else:
                self._logger().debug("fast beacon period not found: {}".format(output))
                raise Exception("fast beacon period not found: {}".format(output))
            return BeaconPeriod
    
    def set_slow_beacon_rate(self, beaconrate, node = None, secure_run = True):
        """This keyword sets the slow beacon rate of provided node IP
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=       | =Beacon Rate=  |  =NodeIP=      |                          =Comment=                         |
        | `Set Slow Beacon Rate`  |       300      | 0013:0000:0034 | This will set provided slow beacon rate for given Node     |
        | `Set Slow Beacon Rate`  |       310      |                | This will set provided slow beacon rate for default Node   |
        
        Range for Beacon Rate is 15-1800.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            BeaconRate = int(beaconrate)
        except ValueError:
            self._logger().exception("slow beacon rate must be either integer or string-convertible-to-integer")
            raise Exception("slow beacon rate must be either integer or string-convertible-to-integer")
         
        if (not (BeaconRate >= 15 and BeaconRate <= 1800) ):
            self._logger().debug("Invalid Beacon Rate. Beacon Rate must be 15 <= beaconrate <=1800")
            raise Exception("Invalid Beacon Rate. Beacon Rate must be 15 <= beaconrate <= 1800") 
                          
        try:
            self._logger().info("Setting Beacon Rate for Slow Beacon Type")
            
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mac mac_tx_beacon_rate ' + str(BeaconRate)
            
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting slow beacon rate failed: {}".format(e))
            raise Exception("Setting slow beacon rate failed: {}".format(e))
        return output
    
    def set_fast_beacon_period(self, beaconperiod, node = None, secure_run = True):
        """This keyword sets the fast beacon period of provided node IP
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=         | =Beacon Period= |      =node=    |                            =Comment=                        |
        | `Set Fast Beacon Period`  |       10        | 0013:0000:0034 | This will set provided fast beacon period for given Node    |
        | `Set Fast Beacon Period`  |       90        |                | This will set provided fast beacon period for default Node  |
        
        Range for Beacon Period is 1-100.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            BeaconPeriod = int(beaconperiod)
        except ValueError:
            self._logger().exception("beacon period must be either integer or string-convertible-to-integer")
            raise Exception("beacon period must be either integer or string-convertible-to-integer")
        
        if (not (BeaconPeriod >= 1 and BeaconPeriod <= 100)): ##fix for Bug-2012930
            self._logger().debug("Invalid Beacon Period. Beacon Period must be 1 <= beaconperiod <=100")
            raise Exception("Invalid Beacon Period. Beacon Period must be 1 <= beaconperiod <=100")
                
        try:
            self._logger().info("Setting Beacon Period for Fast Beacon Type")
            
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mac mac_fast_beacon_period ' + str(BeaconPeriod)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting fast beacon period failed: {}".format(e))
            raise Exception("Setting fast beacon period failed: {}".format(e))
        return output
        