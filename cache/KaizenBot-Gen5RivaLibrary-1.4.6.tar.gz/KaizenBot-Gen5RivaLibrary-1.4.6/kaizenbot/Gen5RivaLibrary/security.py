# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from kaizenbot.logging_robot import Loggers
import os, re
from kaizenbot.connection import Connection
from .nodelibrary import NodeLibrary
from kaizenbot.exceptions import NotATableError, NotADictionaryError

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class Security:
    
    def __init__(self):
        pass
    
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError
    
    def get_security_level(self, node = None, secure_run = True):
        """This keyword gets MLME security level bit field for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |        =Keyword=     |    =Node=      |                           =Comment=                          |
        | `Get Security Level` | 0001:0045:0a26 | This will get MLME security level bit field for given Node   |
        | `Get Security Level` |                | This will get MLME security level bit field for default Node |
         
        This returns ``MLME Neighbor aggr duration in seconds`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme sec_level'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting MLME Security Level")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME security level is set to:)(.*)', output)
            if(match):
                Security_Level = match.group(0)
                self._logger().debug('MLME Security Level: {}'.format(Security_Level))
            else:
                self._logger().debug("Exception occurred while getting MLME Security Level: {}".format(output))
                raise Exception("Exception occurred while getting MLME Security Level: {}".format(output))
        return Security_Level 
    
    def set_security_level(self, sec_level, node=None, secure_run = True):
        """This keyword sets MLME security level bit field for provided node.
        
        This takes 1 mandatory argument ``sec_level``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=    | =Sec Level= |     =Node=     |                           =Comment=                          |
        | `Set Security Level` |     0x07    | 0001:0045:0a26 | This will set MLME security level bit field for given Node   |
        | `Set Security Level` |     0x0f    |                | This will set MLME security level bit field for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting MLME Security Level")
            command = net_mgr_and_node + ' conf mlme sec_level ' + str(sec_level)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting MLME Security Level failed: {}".format(output))
            raise Exception("Setting MLME Security Level failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting MLME Security Level for Node '{}' failed.Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting MLME Security Level for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
    
    def get_certs_sdump(self, cert_id, data=None, filter = None, node = None, ignore_case=False, force_dump=False, secure_run = True):#####REVISIT AGAIN -> INCOMPLETE
        """This keyword Short Dump the cert idx only for provided node.
        
        This takes 1 mandatory argument ``cert_id``. Current supported ``cert_id`` are 2 and 4.
        
        This takes 3 optional arguments ``node``, ``data`` and ``filter``.
        
        ``data`` value take sdump data from user for which `pid` is required and this should be used without filter.
        ``data`` is applicable only for ``sdump 4``.
        
        ``filter`` is optional argument which takes data which need to be filtered while capturing the event log.
        Filter is applied on each line and only matching lines will be captured. 
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
        
        ``force_dump`` is set to ``False`` by default and this can be set to ``True`` if we have to get the sdump
        data by force.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        Below are the ``data`` values supported:
        
        - ``0`` OR ``all`` for all output data as string
        - ``1`` OR ``dyn_ecboca_rd`` for getting PID having certificate with DYN and CN=ECBOCA_RD
        - ``2`` OR ``dyn_nm_rd`` for getting PID having certificate with DYN and CN=NM_RD
        - ``3`` OR ``dyn_ecboca_priv`` for getting PID having certificate with DYN and CN=ECBOCA_PRIV
        - ``4`` OR ``dyn_nm1245`` for getting PID having certificate with DYN and CN=NM1245
        - ``5`` OR ``dl_ssnmac`` for getting PID having certificate with DL and SSNMAC
        - ``6`` OR ``dl_dlca`` for getting PID having certificate with DL and CN=DLCA
        - ``7`` OR ``op_operator`` for getting PID having certificate with OP and CN=Operator Root
        - ``8`` OR ``bc_ssnmac`` for getting PID having certificate with BC and SSNMAC
        - ``9`` OR ``mfg_mfg0607`` for getting PID having certificate with MFG and CN=MFG0607
        - ``10`` OR ``root_ssn`` for getting PID having certificate with root and CN=SSN Root Certificate
        
        This returns following output on success.
        1. for sdump 4 without filter => Output is as mentioned in data values supported above
        2. for sdump 4 with filter => Output will be return as a string
        3. for sdump 2 with and without filter => Output will be return as a string
        
        = Examples =
        |       =Keyword=   | =Cert ID= | =Data= |   =Filter=  | =Ignore_case= | =force_dump= |     =Node=     |                                        =Comment=                                     |
        | `Get Certs Sdump` |     4     |    1   |             |               |              | 0001:0045:0a26 | This will get PID for DYN and CN=ECBOCA_RD certificate for given Node                |
        | `Get Certs Sdump` |     4     |    1   |             |               |  True        | 0001:0045:0a26 | This will get PID for DYN and CN=ECBOCA_RD certificate for given Node by force sdump |
        | `Get Certs Sdump` |     4     |        | DYN NM1425  |      True     |              | 0001:0045:0a26 | This will get output as string for provided filter data for given Node               |
        | `Get Certs Sdump` |     4     |    0   |             |               |              | 0001:0045:0a26 | This will get complete output as string for sdump 4 for given Node                   |
        | `Get Certs Sdump` |     2     |        |     DL      |      False    |              |                | This will get complete output as string for sdump 2 for default Node                 |
        | `Get Certs Sdump` |     2     |        |             |               |              |                | This will get complete output as string for sdump 2 for default Node                 |
        | `Get Certs Sdump` |     2     |        |             |               |  True        |                | This will get complete output as string for sdump 2 for default Node by force sdump  |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Cert_ID = int(cert_id)
        except ValueError:
            self._logger().exception("Cert ID must be either integer or string-convertible-to-integer")
            raise Exception("Cert ID must be either integer or string-convertible-to-integer")
        
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            if (force_dump == False):
                command = net_mgr_and_node + ' certs sdump ' + str(Cert_ID) + filter_cmd
            else:
                command = net_mgr_and_node + ' certs sdump ' + str(Cert_ID) + ' --force ' + filter_cmd
            
            output = Connection.execute_command(self, command)
            
            out_list=[]
                
            if(' ' in output):
                output_=re.sub('  +', ' ', output)
                 
            self._logger().info(output_)
            if (not 'Request timed out' in output_):
                dyn_ecboca_rd = re.search('Pid:(0?[x]?\w+) DYN \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=ECBOCA_RD,OU=sweng,O=SSN,C=US', output_)
                out_list.append(None if not dyn_ecboca_rd else dyn_ecboca_rd.group(1))
                
                dyn_nm_rd = re.search('Pid:(0?[x]?\w+) DYN \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=NM_RD,OU=sweng,O=SSN,C=US', output_)
                out_list.append(None if not dyn_nm_rd else dyn_nm_rd.group(1))
                
                dyn_ecboca_priv = re.search('Pid:(0?[x]?\w+) DYN \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=ECBOCA_PRIV,OU=sweng,O=SSN,C=US', output_)
                out_list.append(None if not dyn_ecboca_priv else dyn_ecboca_priv.group(1))
                
                dyn_nm1245 = re.search('Pid:(0?[x]?\w+) DYN \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=NM1245,OU=sweng,O=SSN,C=US', output_)
                out_list.append(None if not dyn_nm1245 else dyn_nm1245.group(1))
                
                dl_ssnmac = re.search('Pid: (0?[x]?\w+) DL \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) SSNMAC=', output_)
                out_list.append(None if not dl_ssnmac else dl_ssnmac.group(1))
                
                dl_dlca = re.search('Pid: (0?[x]?\w+) DL \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=DLCA,OU=sweng,O=SSN,C=US', output_)
                out_list.append(None if not dl_dlca else dl_dlca.group(1))
                
                op_operator = re.search('Pid: (0?[x]?\w+) OP \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=Operator Root,OU=sweng,O=SSN,C=US', output_)
                """Enhancement for CN=OPERATOR if Blackacre certificate
                Author: Varun Kaundinya 
                """
                if (not op_operator):
                    op_operator = re.search('Pid: (0?[x]?\w+) OP \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=OPERATOR,OU=Blackacre,O=SSN,C=US', output_)
                """Enhancement end
                """
                out_list.append(None if not op_operator else op_operator.group(1))
                
                bc_ssnmac = re.search('Pid: (0?[x]?\w+) BC \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) SSNMAC=', output_)
                out_list.append(None if not bc_ssnmac else bc_ssnmac.group(1))
                
                mfg_mfg0607 = re.search('Pid: (0?[x]?\w+) MFG \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=MFG0607,OU=MFG,O=SSN,C=US', output_)
                out_list.append(None if not mfg_mfg0607 else mfg_mfg0607.group(1))
                
                root_ssn = re.search('Pid: (0?[x]?\w+) root \((\d+) bytes\): (\d+)(\d+)(\d+)(\d+)-(\d+)(\d+)-(\d+)(\d+) CN=SSN Root Certificate,O=Silver Spring Networks,C=US', output_)
                out_list.append(None if not root_ssn else root_ssn.group(1))
            else:
                raise Exception("Error occurred while getting sdump 4 data: {}".format(output))
            
            if (filter_cmd == '' and str(cert_id) == '4' and data is not None):
                if str(data) == '0' or str(data).lower() == 'all':
                    return output
                
                if str(data) == '1' or str(data).lower() == 'dyn_ecboca_rd':
                    return out_list[0]
                
                if str(data) == '2' or str(data).lower() == 'dyn_nm_rd':
                    return out_list[1]
                
                if str(data) == '3' or str(data).lower() == 'dyn_ecboca_priv':
                    return out_list[2]
                
                if str(data) == '4' or str(data).lower() == 'dyn_nm1245':
                    return out_list[3]
                
                if str(data) == '5' or str(data).lower() == 'dl_ssnmac':
                    return out_list[4]
                
                if str(data) == '6' or str(data).lower() == 'dl_dlca':
                    return out_list[5]
                
                if str(data) == '7' or str(data).lower() == 'op_operator':
                    return out_list[6]
                
                if str(data) == '8' or str(data).lower() == 'bc_ssnmac':
                    return out_list[7]
                
                if str(data) == '9' or str(data).lower() == 'mfg_mfg0607':
                    return out_list[8]
                
                if str(data) == '10' or str(data).lower() == 'root_ssn':
                    return out_list[9]
            elif(filter_cmd != '' and str(cert_id) == '4'):
                return output
            
            elif(str(cert_id) == '2'):
                return output
            else:
                return output
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Error observed while getting sdump data: {}".format(e))
        
    def certs_erase(self, pid, node=None, secure_run = True):
        """This keyword remove cert with Private ID <PID> from the Cache for provided node.
        
        This takes 1 mandatory argument ``pid``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |   =Keyword=   |   =PID=  |     =Node=     |                                 =Comment=                                   |
        | `Certs Erase` | 0x200001 | 0001:0045:0a26 | This will remove cert with Private ID <PID> from the Cache for given Node   |
        | `Certs Erase` | 0x200001 |                | This will remove cert with Private ID <PID> from the Cache for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Removing cert with Private ID <PID> from the Cache")
            command = net_mgr_and_node + ' certs erase ' + str(pid)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Removing cert with Private ID <PID> from the Cache failed: {}".format(output))
            raise Exception("Removing cert with Private ID <PID> from the Cache failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Removing cert with Private ID <PID> from the Cache for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Removing cert with Private ID <PID> from the Cache for Node '{}' failed.Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def certs_sync(self, node=None, secure_run = True):
        """This keyword Writes the valid persistent entries to the device flash for provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |   =Keyword=  |     =Node=     |                                    =Comment=                                      |
        | `Certs Sync` | 0001:0045:0a26 | This will Write the valid persistent entries to the device flash for given Node   |
        | `Certs Sync` |                | This will Write the valid persistent entries to the device flash for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Writes the valid persistent entries to the device flash")
            command = net_mgr_and_node + ' certs sync'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Certificate Sync failed: {}".format(output))
            raise Exception("Certificate Sync failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Certificate Sync for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Certificate Sync for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def get_mlme_ignore_prom_netID(self, node = None, secure_run = True):
        """This keyword gets MLME ignore promiscuous network ID for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |            =Keyword=          |    =Node=      |                              =Comment=                            |
        | `Get MLME Ignore Prom Net ID` | 0001:0045:0a26 | This will get MLME ignore promiscuous network ID for given Node   |
        | `Get MLME Ignore Prom Net ID` |                | This will get MLME ignore promiscuous network ID for default Node |
         
        This returns ``MLME ignore promiscuous network ID as 0 or 1`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme mlme_ignore_prom_net_id'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting MLME ignore promiscuous network ID")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME ignore promiscuous network ID is set to )\d+', output)
            if(match):
                Prom_NWID = match.group(0)
                self._logger().debug('MLME ignore promiscuous network ID: {}'.format(Prom_NWID))
            else:
                self._logger().debug("Exception occurred while getting MLME ignore promiscuous network ID: {}".format(output))
                raise Exception("Exception occurred while getting MLME ignore promiscuous network ID: {}".format(output))
        return Prom_NWID 
    
    def set_mlme_ignore_prom_netID(self, ignore_prom_NWID, node=None, secure_run = True):
        """This keyword sets MLME ignore promiscuous network ID for provided node.
        
        This takes 1 mandatory argument ``ignore_prom_NWID``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |            =Keyword=          | =ignore prom NWID= |     =Node=     |                               =Comment=                           |
        | `Set MLME Ignore Prom Net ID` |         0          | 0001:0045:0a26 | This will set MLME ignore promiscuous network ID for given Node   |
        | `Set MLME Ignore Prom Net ID` |         1          |                | This will set MLME ignore promiscuous network ID for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Ignore_Prom_NWID = int(ignore_prom_NWID)
        except ValueError:
            self._logger().exception("NREG Ack Max Try Counter for Tentative route must be either integer or string-convertible-to-integer")
            raise Exception("NREG Ack Max Try Counter for Tentative route must be either integer or string-convertible-to-integer")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting MLME ignore promiscuous network ID")
            command = net_mgr_and_node + ' conf mlme mlme_ignore_prom_net_id ' + str(Ignore_Prom_NWID)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting MLME ignore promiscuous network ID failed: {}".format(output))
            raise Exception("Setting MLME ignore promiscuous network ID failed: {}".format(output))
        return output
    
    def set_time(self, delta_seconds, node=None, secure_run = True):
        """This keyword sets the time to current unix time + off (signed seconds)
        + an optional delay (signed seconds) for provided node.
        
        This takes 1 mandatory argument ``delta_seconds``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |  =Keyword= | =Delta Seconds= |     =Node=     |                                       =Comment=                                     |
        | `Set Time` |        20       | 0001:0045:0a26 | This will set the time to current unix time + off (signed seconds) for given Node   |
        | `Set Time` |         1       |                | This will set the time to current unix time + off (signed seconds) for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Delta_Seconds = int(delta_seconds)
        except ValueError:
            self._logger().exception("Delta Seconds must be either integer or string-convertible-to-integer")
            raise Exception("Delta Seconds must be either integer or string-convertible-to-integer")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting the time to current unix time + off (signed seconds)")
            command = net_mgr_and_node + ' time set_time ' + str(Delta_Seconds)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting the time to current unix time + off (signed seconds) failed: {}".format(output))
            raise Exception("Setting the time to current unix time + off (signed seconds) failed: {}".format(output))
        return output
    
    def get_nm_sec_ndxp_server(self, node = None, secure_run = True):
        """This keyword gets Publication server ipv6 for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |           =Keyword=      |    =Node=      |                                  =Comment=                                |
        | `Get NM Sec Ndxp Server` | 0001:0045:0a26 | This will get Node data exchange publication server ipv6 for given Node   |
        | `Get NM Sec Ndxp Server` |                | This will get Node data exchange publication server ipv6 for default Node |
         
        This returns ``Node data exchange publication server ipv6`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf nm_sec ndxp_server'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Publication Server Details")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Node data exchange publication server is set to )(.*)', output)
            if(match):
                Pub_Server = match.group(0)
                self._logger().debug('Publication Server: {}'.format(Pub_Server))
            else:
                self._logger().debug("Exception occurred while getting Publication Server Details: {}".format(output))
                raise Exception("Exception occurred while getting MLME Publication Server Details: {}".format(output))
        return Pub_Server
    
    def set_nm_sec_ndxp_server(self, ndxp_server, node=None, secure_run = True):
        """This keyword sets Node data exchange publication server for provided node.
        
        This takes 1 mandatory argument ``ndxp_server``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |           =Keyword=      |  =ndxp_server= |     =Node=     |                                 =Comment=                                 |
        | `Set NM Sec Ndxp Server` | 0001:0045:0a26 | 0001:0045:0a26 | This will set Node data exchange publication server ipv6 for given Node   |
        | `Set NM Sec Ndxp Server` | 0001:0045:0a26 |                | This will set Node data exchange publication server ipv6 for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Publication Server Details")
            command = net_mgr_and_node + ' conf nm_sec ndxp_server ' + str(ndxp_server)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Publication Server Details failed: {}".format(output))
            raise Exception("Setting Publication Server Details failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Publication Server Details for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Publication Server Details for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def get_nm_sec_eb_duration(self, node = None, secure_run = True):
        """This keyword gets Time (minutes) for which the node's ephemeral key is valid for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |           =Keyword=      |    =Node=      |                                         =Comment=                               |
        | `Get NM Sec EB Duration` | 0001:0045:0a26 | This will get Time for which the node's ephemeral key is valid for given Node   |
        | `Get NM Sec EB Duration` |                | This will get Time for which the node's ephemeral key is valid for default Node |
         
        This returns ``Time for which the node's ephemeral key is valid in minutes`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf nm_sec eb_duration'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Time for which the node's ephemeral key is valid")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Lifetime given to an ephemeral key - must be > 7/8 nm_sec_eb_rollover is set to )(\d+)', output)
            if(match):
                Eb_Duration = match.group(0)
                self._logger().debug("Time for which the node's ephemeral key is valid: {} minutes".format(Eb_Duration))
            else:
                self._logger().debug("Exception occurred while getting time for which the node's ephemeral key is valid: {}".format(output))
                raise Exception("Exception occurred while getting time for which the node's ephemeral key is valid: {}".format(output))
        return Eb_Duration 
    
    def set_nm_sec_eb_duration(self, eb_duration, node=None, secure_run = True):
        """This keyword sets MLME security level bit field for provided node.
        
        This takes 1 mandatory argument ``eb_duration``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |           =Keyword=      |  =EB Duration= |     =Node=     |                                       =Comment=                                 |
        | `Set NM Sec Ndxp Server` | 0001:0045:0a26 | 0001:0045:0a26 | This will set Time for which the node's ephemeral key is valid for given Node   |
        | `Set NM Sec Ndxp Server` | 0001:0045:0a26 |                | This will set Time for which the node's ephemeral key is valid for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            Eb_Duration = int(eb_duration)
        except ValueError:
            self._logger().exception("EB Duration must be either integer or string-convertible-to-integer")
            raise Exception("EB Duration must be either integer or string-convertible-to-integer")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Time for which the node's ephemeral key is valid")
            command = net_mgr_and_node + ' conf nm_sec eb_duration ' + str(Eb_Duration)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Time for which the node's ephemeral key is valid failed: {}".format(output))
            raise Exception("Setting Time for which the node's ephemeral key is valid failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Time for which the node's ephemeral key is valid for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Time for which the node's ephemeral key is valid for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def get_nm_sec_eb_rollover(self, node = None, secure_run = True):
        """This keyword gets Minutes before expiration of old ephemeral key that node will create new key for the provided node.
        
        This takes 1 optional argument ``node``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |           =Keyword=      |    =Node=      |                                      =Comment=                                       |
        | `Get NM Sec EB Rollover` | 0001:0045:0a26 | This will get Time before ephemeral key expires to create a new one for given Node   |
        | `Get NM Sec EB Rollover` |                | This will get Time before ephemeral key expires to create a new one for default Node |
         
        This returns ``Time before ephemeral key expires to create a new one in minutes`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf nm_sec eb_rollover'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Time before ephemeral key expires to create a new one")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Time before ephemeral key expires to create a new one - must be < 7/8 \*\ nm_sec_eb_duration is set to )(\w+)', output)
            if(match):
                Eb_Rollover = match.group(0)
                self._logger().debug("Time before ephemeral key expires to create a new one: {} minutes".format(Eb_Rollover))
            else:
                self._logger().debug("Exception occurred while getting time before ephemeral key expires to create a new one: {}".format(output))
                raise Exception("Exception occurred while getting time before ephemeral key expires to create a new one: {}".format(output))
        return Eb_Rollover
    
    def set_nm_sec_eb_rollover(self, eb_rollover, node=None, secure_run = True):
        """This keyword sets Minutes before expiration of old ephemeral key that node will create new key for provided node.
        
        This takes 1 mandatory argument ``eb_rollover``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |           =Keyword=      |  =EB Rollover= |     =Node=     |                                          =Comment=                                   |
        | `Set NM Sec EB Rollover` | 0001:0045:0a26 | 0001:0045:0a26 | This will set Time before ephemeral key expires to create a new one for given Node   |
        | `Set NM Sec EB Rollover` | 0001:0045:0a26 |                | This will set Time before ephemeral key expires to create a new one for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            Eb_Rollover = int(eb_rollover)
        except ValueError:
            self._logger().exception("EB Rollover must be either integer or string-convertible-to-integer")
            raise Exception("EB Rollover must be either integer or string-convertible-to-integer")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Time before ephemeral key expires to create a new one")
            command = net_mgr_and_node + ' conf nm_sec eb_rollover ' + str(Eb_Rollover)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Time before ephemeral key expires to create a new one failed: {}".format(output))
            raise Exception("Setting Time before ephemeral key expires to create a new one failed: {}".format(output))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting Time before ephemeral key expires to create a new one for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting Time before ephemeral key expires to create a new one for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def certs_own(self, node=None, secure_run = True):
        """This keyword Checks which certificate chains for provided node has.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Certificate Details`` on success.
        
        = Examples =
        |   =Keyword= |     =Node=     |                             =Comment=                          |
        | `Certs Own` | 0001:0045:0a26 | This will Checks which certificate chains the given node has   |
        | `Certs Own` |                | This will Checks which certificate chains the default node has |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Check which certificate chains node has")
            command = net_mgr_and_node + ' certs own'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Check which certificate chains node has failed: {}".format(output))
            raise Exception("Check which certificate chains node has failed: {}".format(output))
        else:
            if(output == ''):
                self._logger().debug("Check which certificate chains node '{}' has failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Check which certificate chains node '{}' has failed. Output is {}".format(node, output))
            else:
                return output
            
    def get_time_local_data(self, data, node = None, secure_run = True):
        """This keyword returns time in "local" format for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``data``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        Below are the ``data`` values supported:
        
        - ``0`` OR ``all`` for all output data as string
        - ``1`` OR ``hr_min_sec`` for hr:min:sec data
        - ``2`` OR ``day_of_month`` for Day of Month data
        - ``3`` OR ``month`` for Month (start at 1) data
        - ``4`` OR ``year`` for Year data 
        - ``5`` OR ``day_of_week`` for Day of week (sun == 0) data
        - ``6`` OR ``dst_on`` for DST on data
        - ``7`` OR ``dst_off`` for DST off (0, gmt-changes) data
        - ``8`` OR ``timezone`` for Time zone offset (sec) data
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |         =Keyword=     |    =Node=      |                      =Comment=                        |
        | `Get Time Local Data` | 0001:0045:0a26 | This will get time in "local" format for given Node   |
        | `Get Time Local Data` |                | This will get time in "local" format for default Node |
         
        This returns ``time in "local" format`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' time local'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Time in 'local' format")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output == ''):
                self._logger().debug("Getting time in 'local format for Node '{}' has failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Getting time in 'local format for Node '{}' has failed. Output is {}".format(node, output))
            else:
                out_list=[]
                
                if(' ' in output):
                    output_=re.sub('  +', ' ', output)
                    
                self._logger().info(output_)
                
                hr_min_sec_data = re.search('hr:min:sec (.*)', output_)
                out_list.append(None if not hr_min_sec_data else hr_min_sec_data.group(1))
                
                day_data = re.search('Day of month (\d+)', output_)
                out_list.append(None if not day_data else day_data.group(1))
                
                month_data = re.search('Month \(start at 1\) (\d+)', output_)
                out_list.append(None if not month_data else month_data.group(1))
                
                year_data = re.search('Year (\d+)', output_)
                out_list.append(None if not year_data else year_data.group(1))
                
                day_of_week_data = re.search('Day of week \(sun == 0\) (\d+)', output_)
                out_list.append(None if not day_of_week_data else day_of_week_data.group(1))
                
                dst_on_data = re.search('DST on (\d+)', output_)
                out_list.append(None if not dst_on_data else dst_on_data.group(1))
                
                dst_off_data = re.search('DST off \(0, gmt-changes\) (\d+)', output_)
                out_list.append(None if not dst_off_data else dst_off_data.group(1))
                
                timezone_data = re.search('Time zone offset \(sec\) (\d+)', output_)
                out_list.append(None if not timezone_data else timezone_data.group(1))
                
                if str(data) == '0' or str(data).lower() == 'all':
                    return output
            
                if str(data) == '1' or str(data).lower() == 'hr_min_sec':
                    return out_list[0]
                
                if str(data) == '2' or str(data).lower() == 'day_of_month':
                    return out_list[1]
                
                if str(data) == '3' or str(data).lower() == 'month':
                    return out_list[2]
                
                if str(data) == '4' or str(data).lower() == 'year':
                    return out_list[3]
                
                if str(data) == '5' or str(data).lower() == 'day_of_week':
                    return out_list[4]
                
                if str(data) == '6' or str(data).lower() == 'dst_on':
                    return out_list[5]
                
                if str(data) == '7' or str(data).lower() == 'dst_off':
                    return out_list[6]
                
                if str(data) == '8' or str(data).lower() == 'timezone':
                    return out_list[7]
                
    def get_time_state_data(self, data, node = None, secure_run = True):
        """This keyword returns the ts_state variable for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This takes 1 mandatory argument ``data``.
          
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        Below are the ``data`` values supported:
        
        - ``0`` OR ``all`` for all output data as string
        - ``1`` OR ``version`` for Version data
        - ``2`` OR ``in_sync`` for in_sync data
        - ``3`` OR ``sync`` for sync data
        - ``4`` OR ``refresh`` for Refresh data 
        - ``5`` OR ``now`` for Now data
        - ``6`` OR ``drift`` for Drift data
        - ``7`` OR ``accuracy_at_sync`` for accuracy at sync data
        - ``8`` OR ``current_accuracy`` for Current Accuracy data
        - ``9`` OR ``time_flags`` for Time Flags data
        - ``10`` OR ``time_source_type`` for Time Source Type data
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |         =Keyword=     |    =Node=      |                   =Comment=                      |
        | `Get Time State Data` | 0001:0045:0a26 | This will get ts_state variable for given Node   |
        | `Get Time State Data` |                | This will get ts_state variable for default Node |
         
        This returns ``ts_state variable`` on success.
         
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' time state'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting ts_state variable")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            if(output == ''):
                self._logger().debug("Getting ts_state variable for Node '{}' has failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Getting ts_state variable for Node '{}' has failed. Output is {}".format(node, output))
            else:
                out_list=[]
                
                if(' ' in output):
                    output_=re.sub('  +', ' ', output)
                    
                self._logger().info(output_)
                
                version_data = re.search('Version: (\d+)', output_)
                out_list.append(None if not version_data else version_data.group(1))
                
                in_sync_data = re.search('in_sync: (\w+)', output_)
                out_list.append(None if not in_sync_data else in_sync_data.group(1))
                
                sync_data = re.search('sync (.*)', output_)
                out_list.append(None if not sync_data else sync_data.group(1))
                
                refresh_data = re.search('refresh (.*)', output_)
                out_list.append(None if not refresh_data else refresh_data.group(1))
                
                now_data = re.search('now (.*)', output_)
                out_list.append(None if not now_data else now_data.group(1))
                
                drift_data = re.search('drift (\d+)', output_)
                out_list.append(None if not drift_data else drift_data.group(1))
                
                accuracy_at_sync_data = re.search('accuracy at sync (\d+\.\d+)', output_)
                out_list.append(None if not accuracy_at_sync_data else accuracy_at_sync_data.group(1))
                
                current_accuracy_data = re.search('current accuracy (\d+\.\d+)', output_)
                out_list.append(None if not current_accuracy_data else current_accuracy_data.group(1))
                
                timeflags_data = re.search('time flags (\w+)', output_)
                out_list.append(None if not timeflags_data else timeflags_data.group(1))
                
                timesourcetype_data = re.search('time source type: (.*)', output_)
                out_list.append(None if not timesourcetype_data else timesourcetype_data.group(1))
                
                if str(data) == '0' or str(data).lower() == 'all':
                    return output
            
                if str(data) == '1' or str(data).lower() == 'version':
                    return out_list[0]
                
                if str(data) == '2' or str(data).lower() == 'in_sync':
                    return out_list[1]
                
                if str(data) == '3' or str(data).lower() == 'sync':
                    return out_list[2]
                
                if str(data) == '4' or str(data).lower() == 'refresh':
                    return out_list[3]
                
                if str(data) == '5' or str(data).lower() == 'now':
                    return out_list[4]
                
                if str(data) == '6' or str(data).lower() == 'drift':
                    return out_list[5]
                
                if str(data) == '7' or str(data).lower() == 'accuracy_at_sync':
                    return out_list[6]
                
                if str(data) == '8' or str(data).lower() == 'current_accuracy':
                    return out_list[7]
                
                if str(data) == '9' or str(data).lower() == 'time_flags':
                    return out_list[8]
                
                if str(data) == '10' or str(data).lower() == 'time_source_type':
                    return out_list[9]
    
    def get_nm_sec_eb_show_all(self, node=None, secure_run = True):
        """This keyword shows all ephemeral blobs for provided node has.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``all ephemeral blobs`` on success.
        
        = Examples =
        |         =Keyword=        |     =Node=     |                           =Comment=                     |
        | `Get NM Sec EB Show All` | 0001:0045:0a26 | This will show all ephemeral blobs for the given node   |
        | `Get NM Sec EB Show All` |                | This will show all ephemeral blobs for the default node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("shows all ephemeral blobs")
            command = net_mgr_and_node + ' nm_sec_eb show_all'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Showing all ephemeral blobs has failed: {}".format(output))
            raise Exception("Showing all ephemeral blobs has failed: {}".format(output))
        else:
            if(output == ''):
                self._logger().debug("Showing all ephemeral blobs for node '{}' has failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Showing all ephemeral blobs for node '{}' has failed. Output is {}".format(node, output))
            else:
                return output            
    
    