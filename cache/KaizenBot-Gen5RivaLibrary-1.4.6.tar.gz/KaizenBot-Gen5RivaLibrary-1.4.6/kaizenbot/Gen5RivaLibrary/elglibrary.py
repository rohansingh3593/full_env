# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
  Author:   Varun Kaundinya (keywords: get_mlme_lg_conf, set_mlme_lg_conf, get_mlme_dev_info, 
            set_mlme_dev_info, get_max_lg_server, set_max_lg_server, get_lg_bbd_query_rate, 
            set_lg_bbd_query_rate, get_elg_molf_period, set_elg_molf_period, get_elg_partial_period, 
            set_elg_partial_period, get_lg_momentary_outage_length, set_lg_momentary_outage_length,
            get_lg_bundle_period, set_lg_bundle_period, get_lg_bundle_random_window, set_lg_bundle_random_window,
            get_last_gasp_statistics, get_el_data_range, get_last_gasp_records, get_el_data)
            
            Rashmi Tumkur Nagabhushana (keywords:get_lg_number_of_pon,get_lg_max_eld_clients,set_lg_number_of_pon,
            set_lg_max_eld_clients)

            Srinivas (keywords:get_lg_eld_sfp_listen ,set_lg_eld_sfp_listen,get_lg_sfp_fwd_rand ,set_lg_sfp_fwd_rand
            ,get_lg_eld_max_bundle_rec,set_lg_eld_max_bundle_rec)           
"""

from kaizenbot.logging_robot import Loggers
import os, re
from kaizenbot.connection import Connection
from .nodelibrary import NodeLibrary

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class ELGLibrary:
    def __init__(self):
        pass
    
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError
   
    def get_mlme_lg_conf(self, node = None, secure_run = False):
        """
        This keyword gets the MLME LG configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=         |     =Node=     |                           =Comment=                      |
        | `Get Mlme Lg Conf`    | 0001:0045:0a26 | This will get the MLME LG Config value for given Node    |
        | `Get Mlme Lg Conf`    |                | This will get the MLME LG Config value for default Node  |
         
        This returns the node's ``mlme_lg_cfg`` value on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg mlme_lg_cfg'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting MLME LG Config for {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting MLME LG Config: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)', output)
          if(match):
            mlme_lg_cfg = match.group(0)
            self._logger().info('MLME LG Config is {}'.format(mlme_lg_cfg))
          else:
            self._logger().debug("Exception occurred while getting MLME LG Config {}".format(output))
            raise Exception("Exception occurred while getting MLME LG Config {}".format(output))
          return mlme_lg_cfg
  
    def set_mlme_lg_conf(self, lg_conf, node = None, secure_run = False):
        """
        This keyword sets the MLME LG configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``lg_conf``. 
        Valid values for ``lg_conf`` is either 0,1 or 2
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=         | =lg_conf= |     =Node=     |                           =Comment=                      |
        | `Set Mlme Lg Conf`    |     1     | 0001:0045:0a26 | This will set the MLME LG Config value for given Node    |
        | `Set Mlme Lg Conf`    |     0     |                | This will set the MLME LG Config value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg mlme_lg_cfg ' + str(lg_conf)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting LG config as {}'.format(lg_conf))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting MLME LG Config: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting LG config for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting LG config as {} for Node '{}' failed. Output is {}".format(lg_conf, node, output))
            else:
                return 'Ok'
  
    def get_mlme_dev_info(self, node = None, secure_run = True):
        """
        This keyword gets the MLME Device Info configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=         |     =Node=     |                           =Comment=                          |
        | `Get Mlme Dev Info`   | 0001:0045:0a26 | This will get the MLME Device Information for given Node     |
        | `Get Mlme Dev Info`   |                | This will get the MLME Device Information for default Node   |
         
        This returns the node's ``mlme_dev_info`` value on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme mlme_dev_info'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting MLME Device Info for {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting MLME Dev Info: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)', output)
          if(match):
            mlme_dev_info = match.group(0)
            self._logger().info('MLME LG Device Info is {}'.format(mlme_dev_info))
          else:
            self._logger().debug("Exception occurred while getting MLME LG MLME Device Info {}".format(output))
            raise Exception("Exception occurred while getting MLME LG Device Info {}".format(output))
          return mlme_dev_info
   
    def set_mlme_dev_info(self, dev_info, node = None, secure_run = True):
        """
        This keyword sets the MLME Dev Info configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``dev_info``. 
        Valid values for ``dev_info`` is either 0,1 or 2
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=          |  =mlme_dev_info=     |     =Node=     |                           =Comment=                     |
        | `Set Mlme Dev Info`    |       1              | 0001:0045:0a26 | This will set the MLME Dev Info value for given Node    |
        | `Set Mlme Dev Info`    |       0              |                | This will set the MLME Dev Info value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme mlme_dev_info ' + str(dev_info)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting MLME Dev Info as {}'.format(dev_info))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting MLME Dev Info: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting MLME Dev Info for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting MLME Dev Info for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
            
    def get_max_lg_server(self, node = None, secure_run = False):
        """
        This keyword gets the maximum LG servers to register as configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=         |     =Node=     |                           =Comment=                                  |
        | `Get Max LG Server`   | 0001:0045:0a26 | This will get the maximum LG servers to register for given Node      |
        | `Get Max LG Server`   |                | This will get the maximum LG servers to register for default Node    |
         
        This returns the node's ``mlme_lg_max_reg`` value on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg mlme_lg_max_reg'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting maximum LG server to register {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting MLME LG Max Reg: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)', output)
          if(match):
            mlme_lg_max_reg = match.group(0)
            self._logger().info('MLME LG Max Reg is {}'.format(mlme_lg_max_reg))
          else:
            self._logger().debug("Exception occurred while getting MLME LG Max Reg {}".format(output))
            raise Exception("Exception occurred while getting MLME LG Max Reg {}".format(output))
          return mlme_lg_max_reg

    def set_max_lg_server(self, max_lg_server, node = None, secure_run = False):
        """
        This keyword sets the Max LG server configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``max_lg_server``. 
        Valid values for ``max_lg_server`` is from 0 - 2
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=          |  =max_lg_server=     |     =Node=     |                           =Comment=                     |
        | `Set Max LG Server`    |     1                | 0001:0045:0a26 | This will set the MLME Dev Info value for given Node    |
        | `Set Max LG Server`    |     0                |                | This will set the MLME Dev Info value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg mlme_lg_max_reg ' + str(max_lg_server)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting LG Max Servers as {}'.format(max_lg_server))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting MLME LG Max Reg: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting LG Max Servers for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting LG Max Servers for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
    
    def get_lg_bbd_query_rate(self, node = None, secure_run = False):
        """
        This keyword gets the BBD query rate in ELG as configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=             |     =Node=     |                           =Comment=                      |
        | `Get LG BBD Query Rate`   | 0001:0045:0a26 | This will get the LG BBD query rate for given Node       |
        | `Get LG BBD Query Rate`   |                | This will get the LG BBD query rate for default Node     |
         
        This returns the node's ``mlme_lg_bbd_query_rate`` value in seconds on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg mlme_lg_bbd_qry_rate'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting LG BBD Neighbor Query Rate {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting MLME LG BBD Qry Rate: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)(?= seconds)', output)
          if(match):
            mlme_lg_bbd_qry_rate = match.group(0)
            self._logger().info('LG BBD Neighbor Query Rate is {} seconds'.format(mlme_lg_bbd_qry_rate))
          else:
            self._logger().debug("Exception occurred while getting MLME LG BBD Qry Rate {}".format(output))
            raise Exception("Exception occurred while getting MLME LG BBD Qry Rate {}".format(output))
          return mlme_lg_bbd_qry_rate

    def set_lg_bbd_query_rate(self, bbd_qry_rate, node = None, secure_run = False):
        """
        This keyword sets the LG BBD Query Rate configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``bbd_qry_rate`` in seconds. Value between 300 - 65535
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=              |  =bbd_qry_rate=      |     =Node=     |                           =Comment=                     |
        | `Set LG BBD Query Rate`    |     2000             | 0001:0045:0a26 | This will set the LG BBD Query Rate value for given Node    |
        | `Set LG BBD Query Rate`    |     3000             |                | This will set the LG BBD Query Rate value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg mlme_lg_bbd_qry_rate ' + str(bbd_qry_rate)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting LG BBD Query Rate as {} seconds'.format(bbd_qry_rate))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting MLME LG BD Qry Rate: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting LG BBD Query Rate for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting LG BBD Query Rate for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'

    def get_elg_molf_period(self, node = None, secure_run = False):
            
        """
        This keyword gets the ELG MOLF period configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=         |     =Node=     |                           =Comment=                  |
        | `Get ELG MOLF Period` | 0001:0045:0a26 | This will get the ELG MOLF period for given Node     |
        | `Get ELG MOLF Period` |                | This will get the ELG MOLF period for default Node   |
         
        This returns the node's ``elg_molf_period`` value in seconds on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg lg_eld_molf'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting ELG MOLF Period {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting ELG MOLF Period: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)(?= seconds)', output)
          if(match):
            elg_molf_period = match.group(0)
            self._logger().info('ELG MOLF Period  {} seconds'.format(elg_molf_period))
          else:
            self._logger().debug("Exception occurred while getting ELG MOLF Period  {}".format(output))
            raise Exception("Exception occurred while getting ELG MOLF Period {}".format(output))
          return elg_molf_period
 
    def set_elg_molf_period(self, molf_period, node = None, secure_run = False):
        """
        This keyword sets the ELG MOLF Period configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``molf_period`` in seconds. Value between 0 - 300
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=            |  =molf_period=        |     =Node=     |                           =Comment=                       |
        | `Set ELG MOLF Period`    |     60                | 0001:0045:0a26 | This will set the ELG MOLF Period value for given Node    |
        | `Set ELG MOLF Period`    |     150               |                | This will set the ELG MOLF Period value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg lg_eld_molf ' + str(molf_period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting ELG MOLF Period as {} seconds'.format(molf_period))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting ELG MOLF Period: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting ELG MOLF Period for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting ELG MOLF Period for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
     
    def get_elg_partial_period(self, node = None, secure_run = False):   
        """
        This keyword gets the ELG partial period configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``. 
        = Examples =
        |     =Keyword=             |     =Node=     |                           =Comment=                          |
        | `Get ELG Partial Period`  | 0001:0045:0a26 | This will get the ELG Partial period for given Node          |
        | `Get ELG Partial Period`  |                | This will get the ELG Partial period for default Node        |
         
        This returns the node's ``lg_partial_period`` value in milliseconds on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg lg_eld_elf_partial_time'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting ELG Partial Period for {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting ELG Partial Period: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)(?= milliseconds)', output)
          if(match):
            elg_partial_period = match.group(0)
            self._logger().info('ELG Partial Period {} milliseconds'.format(elg_partial_period))
          else:
            self._logger().debug("Exception occurred while getting ELG Partial Period  {}".format(output))
            raise Exception("Exception occurred while getting ELG Partial Period {}".format(output))
          return elg_partial_period

    def set_elg_partial_period(self, partial_period, node = None, secure_run = False):
        """
        This keyword sets the ELG Partial Period configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``partial_period`` in seconds. Value between 500 - 65535
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=               |  =partial_period=        |     =Node=     |                           =Comment=                          |
        | `Set ELG Partial Period`    |     2000              | 0001:0045:0a26 | This will set the ELG Partial Period value for given Node    |
        | `Set ELG Partial Period`    |     3000              |                | This will set the ELG Partial Period value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg lg_eld_elf_partial_time ' + str(partial_period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting ELG Partial Period as {} milliseconds'.format(partial_period))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting ELG Partial Period: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting ELG Partial Period for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting ELG Partial Period for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'

    def get_lg_momentary_outage_length(self, node = None, secure_run = False):
        """
        This keyword gets the LG Momentary Outage Length configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |           =Keyword=               |     =Node=     |                           =Comment=                            |
        | `Get LG Momentary Outage Length`  | 0001:0045:0a26 | This will get the LG Momentary Outage Length for given Node    |
        | `Get LG Momentary Outage Length`  |                | This will get the LG Momentary Outage Length for default Node  |
         
        This returns the node's ``lg_momentary_outage_len`` value in seconds on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg lg_momentary_outage_len'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting LG Momentary Outage Length {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting LG Momentary Outage Length: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)(?= seconds)', output)
          if(match):
            lg_momentary_period = match.group(0)
            self._logger().info('LG Momentary Outage Length {} seconds'.format(lg_momentary_period))
          else:
            self._logger().debug("Exception occurred while getting LG Momentary Outage Length  {}".format(output))
            raise Exception("Exception occurred while getting LG Momentary Outage Length {}".format(output))
          return lg_momentary_period

    def set_lg_momentary_outage_length(self, momentary_length, node = None, secure_run = False):
        """
        This keyword sets the LG Momentary Outage Length configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``momentary_length`` in seconds. Value between 0 - 255
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=                       |  =momentary_length=   |     =Node=     |                           =Comment=                                  |
        | `Set LG Momentary Outage Length`    |     10                | 0001:0045:0a26 | This will set the LG Momentary Outage Length value for given Node    |
        | `Set LG Momentary Outage Length`    |     10                |                | This will set the LG Momentary Outage Length value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg lg_momentary_outage_len ' + str(momentary_length)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting LG Momentary Outage Length as {} seconds'.format(momentary_length))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting LG Momentary Outage Length: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting LG Momentary Outage Length for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting LG Momentary Outage Length for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
   
    def get_lg_bundle_period(self, node = None, secure_run = False):
        """
        This keyword gets the LG Bundle Time configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |           =Keyword=     |     =Node=     |                           =Comment=                  |
        | `Get LG Bundle Period`  | 0001:0045:0a26 | This will get the LG Bundle Period for given Node    |
        | `Get LG Bundle Period`  |                | This will get the LG Bundle Period for default Node  |
         
        This returns the node's ``mlme_lg_bundle_period`` value in seconds on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg mlme_lg_bundle_period'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting LG Bundle Period {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting LG Bundle Period: {} seconds".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)', output)
          if(match):
            lg_bundle_period = match.group(0)
            self._logger().info('LG Bundle Period  {}'.format(lg_bundle_period))
          else:
            self._logger().debug("Exception occurred while getting LG Bundle Period {} seconds".format(output))
            raise Exception("Exception occurred while getting LG Bundle Period {}".format(output))
          return lg_bundle_period
         
    def set_lg_bundle_period(self, bundle_period, node = None, secure_run = False):
        """
        This keyword sets the LG Bundle Random Window configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``bundle_period`` in seconds. Value between 0-255
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=             |  =bundle_period=    |     =Node=     |                           =Comment=                        |
        | `Set LG Bundle Period`    |       16          | 0001:0045:0a26 | This will set the LG Bundle Period value for given Node    |
        | `Set LG Bundle Period`    |       12          |                | This will set the LG Bundle Period value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg mlme_lg_bundle_period ' + str(bundle_period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting LG Bundle Period as {} seconds'.format(bundle_period))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting LG Bundle Period: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting LG Bundle Period for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting LG Bundle Period for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'
    
    def get_lg_bundle_random_window(self, node = None, secure_run = False):
        """
        This keyword gets the LG Bundle Random Window Time configured for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |           =Keyword=            |     =Node=     |                           =Comment=                         |
        | `Get LG Bundle Random Window`  | 0001:0045:0a26 | This will get the LG Bundle Random Window for given Node    |
        | `Get LG Bundle Random Window`  |                | This will get the LG Bundle Random Window for default Node  |
         
        This returns the node's ``lg_eld_bund_win_time```` value in milliseconds on success.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' conf mlme_lg lg_eld_bund_win_time'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting LG Bundle Random Window {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting LG Bundle Random Window: {}".format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)(?= milliseconds)', output)
          if(match):
            lg_bundle_rand_win = match.group(0)
            self._logger().info('LG Bundle Random Window {} milliseconds'.format(lg_bundle_rand_win))
          else:
            self._logger().debug("Exception occurred while getting LG Bundle Random Window  {}".format(output))
            raise Exception("Exception occurred while getting LG Bundle Random Window {}".format(output))
          return lg_bundle_rand_win
          
    def set_lg_bundle_random_window(self, bundle_random_window, node = None, secure_run = False):
        """
        This keyword sets the LG Bundle Random Window configuration for the provided node.
        
        This takes 1 optional argument ``node``.
        
        And this takes 1 mandatory argument ``bundle_random_window`` in milliseconds. Value between 500 - 65535
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |     =Keyword=                    |  =bundle_random_window=  |     =Node=     |                           =Comment=                               |
        | `Set LG Bundle Random Window`    |         500              | 0001:0045:0a26 | This will set the LG Bundle Random Window value for given Node    |
        | `Set LG Bundle Random Window`    |         600              |                | This will set the LG Bundle Random Window value for default Node  |
         
        This returns ``Ok`` on success.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme_lg lg_eld_bund_win_time ' + str(bundle_random_window)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Setting LG Bundle Random Window as {} milliseconds'.format(bundle_random_window))
        except Exception as e:
            self._logger().exception(e)
            raise Exception("Exception occurred while setting LG Bundle Random Window: {}".format(e))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Setting LG Bundle Random Window for Node '{}' failed. Output is {}".format(node, output))
                self._logger().info(output)
                raise Exception("Setting LG Bundle Random Window for Node '{}' failed. Output is {}".format(node, output))
            else:
                return 'Ok'

    def get_last_gasp_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword gets the last gasp statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=        | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Get Last Gasp Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Get Last Gasp Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Get Last Gasp Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |
        | `Get Last Gasp Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
            
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting Last Gasp statistics data from net manager")
            command = net_mgr_and_node + ' last_gasp stat' + filter_cmd
            self._logger().info("Getting Last Gasp statistics data from net manager {} ", format (command))
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                self._logger().info(output)
                output_ = re.split('\n', output)
                while('' in output_):
                    output_.remove('')
                tmp = []
                tmp1 = []
                
                for line in output_:
                    line_ = line.strip()
                    if ("Last Gasp Statistics:" == line_):
                        a = [line_]
                    elif ("" == line_):
                        continue
                    else:
                        a = line_.strip().split(' ', 1)
                    tmp.append(a)
    
                if (only_header == True):
                    for item in tmp:
                        if ("Last Gasp Statistics:" == item[0]):
                            tmp1.append(item[0])
                        else:
                             tmp1.append(item[1])
                    return tmp1 
                return tmp
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
   
    def get_el_data_range (self, node = None, secure_run = False):
        """
        This keyword gets the range for el_data for the provided node.
        
        This takes 1 optional argument ``node``.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |           =Keyword=  |      =Node=     |                    =Comment=                      |
        | `Get El Data Range`  |  0001:0045:0a26 | This will get the El Data Range for given Node    |
        | `Get El Data Range`  |                 | This will get the El Data Range for default Node  |
         
        This returns the node's ``el_data range`` as a list value on success. Maximum is the first element Minimum is second element.
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' el_data range'  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting EL Data Range {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting EL Data Range : {}".format(e))
        else:
          maxi = re.search(r'(?<=Max seqnum )(.*)', output)
          mini = re.search(r'(?<=Min seqnum )(.*)', output)
          if (maxi):
            if (mini):
              rand = [maxi.group(0), mini.group(0)]
              el_range = rand
          if (el_range):
            self._logger().info('EL data range is {} to {}'.format(el_range[0], el_range[1]))
          else:
            self._logger().debug("Exception occurred while getting EL Data range {}".format(output))
            raise Exception("Exception occurred while getting EL Data range {}".format(output))
          return el_range
          
    def get_lg_number_of_pon(self, node = None, secure_run=False):
        """
        This keyword gets the LG number of power outage notifications of provided node IP
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.    
        = Examples =
        |         =Keyword=         |    =NodeIP=    |                   =Comment=                                            |
        | `Get LG Number Of PON`    | 0001:0045:0a26 | This will get LG number of power outage notifications for given Node   |
        | `Get LG Number Of PON`    |                | This will get LG number of power outage notifications for default Node |
        
        This returns ``lg_number_of_pon`` on success.
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if(secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg lg_num_pons'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting LG Number of PON")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception('Error while running the command {}'.format(e))
        else:
          match = re.search(r'(?<=is set to )\d+', output)
          if(match):
                lg_number_of_pon = match.group(0)
                self._logger().debug("LG Number Of PON: {}".format(lg_number_of_pon))
          else:
                self._logger().debug("LG Number Of PON not found: {}".format(output))
                raise Exception("LG Number Of PON not found: {}".format(output))
          return lg_number_of_pon
 
    def get_lg_max_eld_clients(self, node = None, secure_run=False):
        """
        This keyword gets the LG max ELD clients of provided node IP
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported. 
        = Examples =
        |         =Keyword=           |    =NodeIP=    |                   =Comment=                       |
        | `Get LG Max Eld Clients`    | 0001:0045:0a26 | This will get LG max ELD clients for given Node   |
        | `Get LG Max Eld Clients`    |                | This will get LG max ELD clients for default Node |
        
        This returns ``lg_max_eld_clients`` on success.
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")  
        try:
            if(secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg mlme_lg_max_eld_clients'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting LG Max Eld Clients")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception('Error while running the command {}'.format(e))
        else:
          match = re.search(r'(?<=is set to )(.*)(?= nodes)', output)
          if(match):
                lg_max_eld_clients = match.group(0)
                self._logger().info("LG Max Eld Clients: {}".format(lg_max_eld_clients))
          else:
                self._logger().debug("LG Max Eld Clients not found: {}".format(output))
                raise Exception("LG Max Eld Clients not found: {}".format(output))
          return lg_max_eld_clients 
            
    def set_lg_number_of_pon(self, lg_num_pons, node = None, secure_run = False):
        """This keyword sets the LG number of power outage notifications of provided node IP
        
        This takes 1 mandatory argument ``lg_num_pons`` and 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=       | =LG Number Of PON=  |  =NodeIP=      |                          =Comment=                                                |
        | `Set LG Number Of PON`  |       3             | 0013:0000:0034 | This will set provided LG number of power outage notifications for given Node     |
        | `Set LG Number Of PON`  |       2             |                | This will set provided LG number of power outage notifications for default Node   |
        
        Range for LG Number Of PON is 0-3.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported. 
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            lg_num_pons = int(lg_num_pons)
        except ValueError:
            self._logger().exception("LG Number Of PON must be either integer or string-convertible-to-integer")
            raise Exception("LG Number Of PON must be either integer or string-convertible-to-integer")
         
        if (not (lg_num_pons >= 0 and lg_num_pons <= 3) ):
            self._logger().debug("Invalid LG Number Of PON. LG Number Of PON must be 0 <= lg_num_pons <=3")
            raise Exception("Invalid LG Number Of PON. LG Number Of PON must be 0 <= lg_num_pons <= 3") 
                          
        try:
            self._logger().info("Setting LG Number Of PON")
            
            if(secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg lg_num_pons ' + str(lg_num_pons)
            
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting LG Number Of PON failed: {}".format(e))
            raise Exception("Setting LG Number Of PON failed: {}".format(e))
        return output
        
    def set_lg_max_eld_clients(self, lg_max_eld_clients, node = None, secure_run = False):
        """This keyword sets the LG max ELD clients of provided node IP
        
        This takes 1 mandatory argument ``lg_max_eld_clients`` and 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
       
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=         | =LG max ELD clients= |  =NodeIP=      |                          =Comment=                           |
        | `Set LG max ELD clients`  |       64             | 0013:0000:0034 | This will set provided LG max ELD clients for given Node     |
        | `Set LG max ELD clients`  |       63             |                | This will set provided LG max ELD clients for default Node   |
        
        Range for LG max ELD clients is 1-255.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported. 
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            lg_max_eld_clients = int(lg_max_eld_clients)
        except ValueError:
            self._logger().exception("LG max ELD clients must be either integer or string-convertible-to-integer")
            raise Exception("LG max ELD clients must be either integer or string-convertible-to-integer")
         
        if (not (lg_max_eld_clients >= 1 and lg_max_eld_clients <= 255) ):
            self._logger().debug("Invalid LG max ELD clients. LG max ELD clients must be 1 <= lg_max_eld_clients <=255")
            raise Exception("Invalid LG max ELD clients. LG max ELD clients must be 1 <= lg_max_eld_clients <= 255") 
                          
        try:
            self._logger().info("Setting LG max ELD clients")
            
            if(secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg mlme_lg_max_eld_clients ' + str(lg_max_eld_clients)
            
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting LG max ELD clients failed: {}".format(e))
            raise Exception("Setting LG max ELD clients failed: {}".format(e))
        return output        
       
    def get_last_gasp_records (self, count, only_header=False, node = None, secure_run = False):
        """
        This keyword gets the 'n' count of last records for last gasp for the provided node.
        
        This takes 2 optional arguments ``node`` and ``only_header``. By default ``only_header`` is set as ``False`` and can be changed explicitly.
        
        This takes 1 mandatory argument ``count`` which is the count of most recent last gasp records needed.
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |           =Keyword=      |     =count=   |  =only_header= |     =Node=     |                           =Comment=                           |
        | `Get Last Gasp Records`  |       10      |    False       | 0001:0045:0a26 | This will get the last 10 Last Gasp records  for given Node   |
        | `Get Last Gasp Records`  |       20      |    False       |                | This will get the last 20 Last Gasp records for default Node  |
        | `Get Last Gasp Records`  |       20      |    True        |                | This will get the header list of records for default Node     |
               
        This returns the node's ``last_gasp last <count>`` records on success. It is returned in the form of a list of list of lists. 
        Each record is a list of a list. And the record follows the format [``value``, ``Header``, ``opt value1``, ``opt value 2``]
        
        Only_header provides header list without values 
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' last_gasp last ' + str(count)  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting Last Gasp Records {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting Last Gasp Records : {}".format(e))
        else:
            fin_result = [[[]]]
            fin_header = []
            sec_bypass = 0
            flag_bypass = 0
            cnt = 0
            work = re.split('Record #', output)
            for raw_rec in work:
                fin_rec = [[]]
                if (raw_rec == ''):
                    continue
                rec = re.split('\n[?\s]+', raw_rec.strip('\n'))
                rec[0] = rec[0].strip(':') + " Record number"
                for line in rec: 
                    if (1 == sec_bypass):
                        fin_rec[len(fin_rec)-1].append(line)
                        sec_bypass = 0
                        continue
                    if ((0 != cnt) and (1 == flag_bypass)):
                        fin_rec[len(fin_rec)-1].append(line.split(' ', 1)[1])
                        cnt = cnt - 1 
                        if (cnt == 0):
                            flag_bypass = 0
                        continue
                    line_list = line.split(' ', 1)
                    if (('0' != line_list[0]) and ("seconds" in line_list[1])):
                        sec_bypass = 1
                        
                    if (('0x0' != line_list[0]) and ("flags" in line_list[1])):
                        cnt = bin(int(line_list[0], 16))[2:].count("1")
                        flag_bypass = 1
                    if (fin_rec[0]!=[]):
                        fin_rec.append(line_list)
                    else:
                        fin_rec[0]=line_list

                if (fin_result[0]!=[[]]):
                    fin_result.append(fin_rec)
                else:
                    fin_result[0]=fin_rec

            if (only_header == True):
                for samp_rec in fin_result[0]:
                    fin_header.append(samp_rec[1])
                return fin_header
            else:
                return fin_result
                
    
    def get_el_data (self, range, event_type=None, node = None, secure_run = False):
        """
        This keyword gets the el_data for the range provided for the concerned node.
          
        This takes 1 mandatory argument ``range`` which is the range of el_data needed. The format is "<Min> <Max>" is space separated values 
            
        This takes 2 optional arguments ``node`` and ``event_type``. By default ``event_type`` is set as ``None``. It can be changed explicitly to
        the four following supported events:
        EL_EVENT_NIC_POWER_DOWN
        EL_EVENT_NIC_POWER_UP
        EL_EVENT_NIC_MOMENTARY
        EL_EVENT_MLME_LG_REG_FAILURE
        If no event_type is provided, then only seq number, event type and event time are provided for all other events except above.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
         
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
         
        By default, secure net mgr command ``net_mgr`` is used, it can be changed by providing a true value to ``secure_run``. 
        = Examples =
        |   =Keyword=    |     =range=   |    =event_type=              |     =Node=     |                           =Comment=                          |
        | `Get El Data`  |    30 40      |    EL_EVENT_NIC_POWER_DOWN   | 0001:0045:0a26 | This will get el_data from 30 to 40 for for power down event |
        | `Get El Data`  |    20 30      |    EL_EVENT_NIC_POWER_UP     |                | This will get el_data from 20 to 30 for power up events      |
        | `Get El Data`  |               |                              |                | This will get all el_data in the range for default Node      |
               
        This returns the node's ``el_data`` records on success. It is returned in the form of a list of list of lists. 
        Each el_data is a list of a list. And the el_data follows the format depending on the event_type
        """
        node = node or self.get_current_node()
        if(not node):
          self._logger().debug("No NIC IP provided by User to execute command")
          raise Exception("No NIC IP provided by User to execute command")
        try:
          if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
          else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
          command = net_mgr_and_node + ' el_data read ' + str(range)  
          output = Connection.execute_command(self, command)
          self._logger().info(output)
          self._logger().info('Executed command for NIC with IP: {}'.format(node))
          self._logger().info('Getting EL_Data {}'.format(node))
        except Exception as e:
          self._logger().exception(e)
          raise Exception("Exception occurred while getting EL_data : {}".format(e))
        else:
            fin_result = [[[]]]
            events = re.split("Event ", output)
            ev_type = ''
            if (event_type is not None): 
                ev_type = str(event_type)
            for eve in events:
                if "seqnum" not in eve:
                    events.remove(eve)
            for eve in events:
                ev_struct = [[]]    
                event_list = re.split('\n', eve)
                title = re.split(', ', event_list[0])
                ev_struct.append(['Seq num', title[0].split(' ', 1)[1]])
                ev_struct.append(['Event Type', title[1]])
                #Edited to adjust to the new el_Data read output - 11/17/2021 - @vkaundin
                #ev_struct.append(['Timestamp', title[2].split(' ')[1], title[2].split('is ')[1]])
                self._logger().debug('Title of the el_data event: {}'.format(title[1]))
             
                if (ev_type in str(title[1])):
                    if [] in ev_struct:
                        ev_struct.remove([])
                    if "EL_EVENT_NIC_POWER_DOWN" in title[1]:
                        ev_struct.append(['System Went Down at', event_list[1].split('Down at ')[1]])
                        ev_struct.append(['Seconds since reboot', event_list[2].split(': ')[1]])
                        ev_struct.append(['Reboots', event_list[3].split(': ')[1]])
                        ev_struct.append(['Detector Type', event_list[4].split(': ')[1]])
                        ev_struct.append(['Status', event_list[5].split(': ')[1]])
                    elif "EL_EVENT_NIC_POWER_ON" in title[1]:
                        ev_struct.append(['Firmware Version', event_list[2].split('= ')[1]])
                        ev_struct.append(['Reboot Count', event_list[3].split('= ')[1]])
                    elif "EL_EVENT_NIC_MOMENTARY" in title[1]:
                        ev_struct.append(['Description', event_list[1].strip(' ')])
                        ev_struct.append(['First time at', event_list[2].split('is ')[1]])
                        ev_struct.append(['Last time at', event_list[3].split('is ')[1]])
                        ev_struct.append(['Meter PF', re.search(r'pf cnt (.*?),', event_list[4]).group(1)])
                        ev_struct.append(['Zero_x', re.search(r'x cnt (.*?),', event_list[4]).group(1)])
                        ev_struct.append(['Both', event_list[4].split('both ')[1]])
                    elif "EL_EVENT_MLME_LG_REG_FAILURE" in title[1]:
                        ev_struct.append(['Reboot Counter', event_list[1].split('= ')[1]])
                        ev_struct.append(['Number of BBD', event_list[2].split('= ')[1]])
                        ev_struct.append(['Number of Registrations', event_list[3].split('= ')[1]])
                        ev_struct.append(['Registration State', event_list[4].split('= ')[1]])
                    fin_result.append(ev_struct)
                    self._logger().debug('El_data event in detail: {}'.format(ev_struct))
            if [[]] in fin_result:
                fin_result.remove([[]])
                if (fin_result == [[[]]]):
                    self._logger().debug("Exception occurred while getting EL Data {}".format(fin_result))
                    raise Exception("Exception occurred while getting EL Data range {}".format(fin_result)) 
            self._logger().debug('El_data for given range: {}'.format(fin_result))
            return fin_result

    def set_lg_eld_sfp_listen(self, lg_eld_sfp_listen, node=None, secure_run=False):
        """This keyword sets the LG SFP  of provided node IP

        This takes 1 mandatory argument ``lg_eld_sfp_listen`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=             |  =lg_eld_sfp_listen=  |  =NodeIP=      |                          =Comment=                                 |
        | `Set Lg Eld Sfp Listen`  |       0               | 0013:0000:0034 | This will set provided value for  LG SFP Lisetn value for the Node |
        | `Set Lg Eld Sfp Listen`  |       1000            |                | This will set provided value for  LG SFP Lisetn value for the Node |

        Range for LG ELG  SFP listen value is 0-1000.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            lg_eld_sfp_listen = int(lg_eld_sfp_listen)
        except ValueError:
            self._logger().exception("LG SFP listen value must be either integer or string-convertible-to-integer")
            raise Exception("LG SFP listen value must be either integer or string-convertible-to-integer")

        if (not (lg_eld_sfp_listen >= 0 and lg_eld_sfp_listen <= 1000)):
            self._logger().debug("Invalid SFP listen value. SFP listen valu must be 0 <= lg_sp_listen_value <=1000")
            raise Exception("Invalid SFP listen value. SFP listen valu must be 0 <= lg_sp_listen_value <=1000")

        try:
            self._logger().info("Setting LG SP Listen Value")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg lg_eld_sfp_listen ' + str(lg_eld_sfp_listen)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting LG SFP listen value failed: {}".format(e))
            raise Exception("Setting LG SFP listen value failed: {}".format(e))
        return output

    def get_lg_eld_sfp_listen(self, node=None, secure_run=False):
        """
        This keyword gets the LG ELD  SFP listen value configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        = Examples =
        |           =Keyword=                   |     =Node=     |                           =Comment=                |
        | `Get Lg Eld  Sfp Listen`              |  10.21.100.203 |  This will get the LG SFP for given Node           |
        | `Get Lg Eld Sfp Listen`               |                |  This will get the LG SFP window for default Node  |

        This returns the node's ``lg_eld_sfp period`` value in seconds on success.

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg lg_eld_sfp_listen'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting LG lg_eld_sfp_listen  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)(?= milliseconds)', output)
            if (match):
                lg_sfp_listen = match.group(0)
                self._logger().info('LG ELD SFP listen window  {}'.format(lg_sfp_listen))
            else:
                self._logger().debug("Exception occurred while getting LG  SFP listen window  {}".format(output))
                raise Exception("Exception occurred while getting LG SFP listen window {}".format(output))
            return lg_sfp_listen

    def set_lg_sfp_fwd_rand(self, lg_sfp_fwd_rand, node=None, secure_run=False):
        """This keyword sets the LG SFP forward random value of provided node IP

        This takes 1 mandatory argument ``lg_sfp_fwd_rand`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=           | =lg_sfp_fwd_rand=    |  =NodeIP=      |                          =Comment=                                             |
        | `Set Lg Sfp fwd_rand`  |       0              | 0013:0000:0034 | This will set provided value for  LG SFP Forward Random value  for the Node    |
        | `Set Lg Sfp fwd_rand`  |       100            |                | This will set provided value for  LG SFP Forward Random value for the Node     |

        Range for LG SFP forward random listen value is 0-100.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            lg_sfp_fwd_rand=int(lg_sfp_fwd_rand)
        except ValueError:
            self._logger().exception("LG SFP forward random value must be either integer or string-convertible-to-integer")
            raise Exception("LG SFP forward listen must be either integer or string-convertible-to-integer")

        if (not (lg_sfp_fwd_rand >= 0 and lg_sfp_fwd_rand <= 100)):
            self._logger().debug("Invalid SFP  forward Random  value. SFP forward random value  must be 0 <= lg_sfp_fwd_rand <=100")
            raise Exception("Invalid SFP forward random value. SFP forward random value must be 0 <= lg_sfp_fwd_rand <=100")

        try:
            self._logger().info("Setting LG SFP forward random value ")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf mlme_lg lg_eld_sfp_fwd_rand ' + str(lg_sfp_fwd_rand)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting LG SFP forward random value failed: {}".format(e))
            raise Exception("Setting LG SFP forward random value failed: {}".format(e))
        return output

    def get_lg_sfp_fwd_rand(self, node=None, secure_run=False):
        """
        This keyword gets the LG SFP Forward random  value configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

         A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        = Examples =
        |           =Keyword=      |     =Node=     |                           =Comment=                               |
        | `Get Lg  SFP Fwd Rand `  | 0001:0045:0a26 | This will get the LG SFP  forward random value given Node        |
        | `Get Lg SFP Fwd  Rand `  |                | This will get the LG SFP forward randome value for default Node  |

        This returns the node's ``lg_sfp_forward_random`` value in seconds on success.
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                command = net_mgr_and_node + ' conf mlme_lg  lg_eld_sfp_fwd_rand'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting   LG sfp forward rand  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)(?= milliseconds)', output)
            if (match):
                lg_sfp_fwd_rand = match.group(0)
                self._logger().info('LG ELD SFP forward random value  {}'.format(lg_sfp_fwd_rand))
            else:
                self._logger().debug("Exception occurred while getting LG  SFP forward value  {}".format(output))
                raise Exception("Exception occurred while getting LG SFP forward value {}".format(output))
            return lg_sfp_fwd_rand

    def set_lg_eld_max_bundle_rec(self,lg_eld_max_bundle_rec, node=None, secure_run=False):
        """This keyword sets the LG ELD SFP MAX BUNDLE value provided by the node IP

        This takes 1 mandatory argument ``lg_eld_max_bundle_rec`` and 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        This returns ``Ok`` on success.

        = Examples =
        |    =Keyword=                  | =lG_max_bundle_rec=  |  =NodeIP=      |                          =Comment=                                           |
        | `Set Lg Eld  Max Bundle Rec`  |       0              | 0013:0000:0034 | This will set provided value for  Lg Elg  Max Bundle Rec value  for the Node |
        | `Set Lg Eld  Max Bundle Rec`  |       100            |                | This will set provided value for  Lg Elg  Max Bundle Rec for the Node        |

        Range for LG SFP forward random listen value is 0-100.

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, net mgr command ``net_mgr`` is used, net_mgrS is not supported.

        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")

        try:
            lg_eld_max_bundle_rec=int(lg_eld_max_bundle_rec)
        except ValueError:
            self._logger().exception("Lg Eld Max Bundle  record value must be either integer or string-convertible-to-integer")
            raise Exception("Lg Elg Max Bundle record value must be either integer or string-convertible-to-integer")

        if (not (lg_eld_max_bundle_rec >= 0 and lg_eld_max_bundle_rec <= 100)):
            self._logger().debug("Invalid SFP  Max bundle record  value. LG ELD Max bundle record value  must be 0 <= lg_eld_max_bundle_rec <=100")
            raise Exception("Invalid SFP Max bundle record value. LG ELD Max bundle record value must be 0 <= lg_eld_max_bundle_rec <=100")

        try:
            self._logger().info("Setting LG ELD Max bundle record value ")

            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' conf  mlme_lg lg_eld_max_bund_rec '+ str(lg_eld_max_bundle_rec)

            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("Setting ELG Max Bundle Record  failed: {}".format(e))
            raise Exception("Setting ELG Max Bundle Record  value failed: {}".format(e))
        return output

    def get_lg_eld_max_bundle_rec(self, node=None, secure_run=False):
        """
        This keyword gets the LG max bundle records configured for the provided node.

        This takes 1 optional argument ``node``.

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.

        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        = Examples =
        |           =Keyword=                   |     =Node=     |                           =Comment=                      |
        | `Get Lg Eld  Max Bundle rec`          | 10.21.100.203  | This will get the LG  Max bundle record                  |
        | `Get Lg Eld Max Bundle rec`           |                | This will get the LG Max bundle record for default Node  |

        This returns the node's ``lg_max_bundle_rec`` value in seconds on success.
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        try:
            if (secure_run):
                self._logger().info("net_mgrS not supported, executing net_mgr")
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node

            command = net_mgr_and_node + ' conf mlme_lg lg_eld_max_bund_rec'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info('Getting   LG sfp forward rand  {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=is set to )(.*)', output)
            if (match):
                lg_max_bundle_rec = match.group(0)
                self._logger().info('LG max bundle record  {}'.format(lg_max_bundle_rec))
            else:
                self._logger().debug("Exception occurred while getting LG max bundle record{}".format(output))
                raise Exception("Exception occurred while getting LG  max bundle record {}".format(output))
            return lg_max_bundle_rec

