# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from kaizenbot.connection import Connection 
from kaizenbot.logging_robot import Loggers
import os, re
from platform import system
from pathlib import Path

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

SRT_FrameOrMessage = ['RTA BROADCAST', 'RTA UNICAST', 'SLOW BEACON', 'EVAL SCHED', 'FAST BEACON', 'EVAL ACK SCHED',
                      'NREG', 'NREG ACK', 'NBOR QRY TLV', 'NBOR RSP TLV','DLI PROTO ROUTING','DLI TIME SYNC REQ RSP TLV',
                      'DLI PAYLOAD TLV', 'MLME LI AGGRESSIVE DISCOVERY', 'MLME LI UPSTREAM DISCOVERY', 'MLME LI REBUILD NODEQ',
                      'MLME LI RSP QRY', 'MLME LI RSP', 'DNS RESPONSE', 'KEEP SCHED', 'KEEP ACK SCHED', 'CULL SCHED', 
                      'TUPD', 'DNS REQUEST', 'DLI PROTO TRACE', 'DLI PROTO TIMESYNC', 'DLI PROTO IP', 'MLME LI MAC BCAST', 
                      'MLME LG CTRL BEACON', 'MLME LG CTRL INFO', 'MLME LG BUNDLE', 'MLME FAST RESTORE INFO', 'MLME FAST RESTORE BUNDLE', 'LAST GASP']

IS_LESS_THAN_OR_EQUAL_TO = {'op_str':' is less than or equal to ', 'op_with_spaces':'< =', 'op_without_spaces':'<=', 'op_value':' <= '}
IS_LESS_THAN = {'op_str':' is less than ', 'op_with_spaces':' < ', 'op_without_spaces':'<', 'op_value':' < ' }
IS_GREATER_THAN_OR_EQUAL_TO = {'op_str':' is greater than or equal to ', 'op_with_spaces':'> =', 'op_without_spaces':'>=', 'op_value':' >= '}
IS_GREATER_THAN = {'op_str':' is greater than ', 'op_with_spaces':' > ', 'op_without_spaces':'>', 'op_value':' > '}
IS_NOT = {'op_str':' is not ', 'op_with_spaces':'! =', 'op_without_spaces':'!=', 'op_value':' != '}
IS = {'op_str':' is ', 'op_with_spaces':'= =', 'op_without_spaces':'==', 'op_value':' == '} 
ops = [IS_LESS_THAN_OR_EQUAL_TO, IS_LESS_THAN, IS_GREATER_THAN_OR_EQUAL_TO, IS_GREATER_THAN, IS_NOT, IS]


class TSharkLibrary:
    
    def __init__(self, pcap_file = None):
        self.pcap_file = pcap_file
        self.base_frame = None
        
    def _logger(self):
        raise NotImplementedError
        
    @property    
    def tshark_cmd(self):    
        if( Connection().get_os_name() is 'nt'):
            return 'tshark.exe'
        else:
            return 'tshark'
        
    def set_pcap_file(self,pcap_file):
        """ This keyword sets the pcap file at test suite level.
        
        If this keyword is used multiple times, it will overwrite the previous pcap files.
        """
        self.pcap_file = pcap_file
    
    def set_unique_frame(self, frametype):
        """This keyword sets the unique frame for the provided ``frametype``.
        
        This takes 1 mandatory argument ``frametype``, which is case-insensitive.
        
        All supported ``frametype`` are mentioned below:
        Frametype = ['RTA BROADCAST', 'RTA UNICAST', 'SLOW BEACON', 'EVAL SCHED', 'FAST BEACON', 'EVAL ACK SCHED',
                      'NREG', 'NREG ACK', 'NBOR QRY TLV', 'NBOR RSP TLV','DLI PROTO ROUTING','DLI TIME SYNC REQ RSP TLV',
                      'DLI PAYLOAD TLV', 'MLME LI AGGRESSIVE DISCOVERY', 'MLME LI UPSTREAM DISCOVERY', 'MLME LI REBUILD NODEQ',
                      'MLME LI RSP QRY', 'MLME LI RSP', 'DNS RESPONSE', 'KEEP SCHED', 'KEEP ACK SCHED', 'CULL SCHED', 
                      'TUPD', 'DNS REQUEST', 'DLI PROTO TRACE', 'DLI PROTO TIMESYNC', 'DLI PROTO IP', 'MLME LI MAC BCAST', 'LAST GASP']
                      
        The ``frametype`` will be set at test suite level where the keyword is used
        
        If this keyword is used multiple times, it will overwrite the previous ``frametype``.
        
        = Examples =
        |       =Keyword=    |  =frametype=  | 
        | `Set Unique Frame` | RTA BROADCAST | 
        | `Set Unique Frame` |   EVAL SCHED  | 
        """
        if(frametype.upper() not in SRT_FrameOrMessage):
            self._logger().debug("Invalid frametype {}".format(frametype))
            raise Exception("Invalid frametype {}".format(frametype))
        self.base_frame = frametype.upper()
    
    def join_filter(self, filter1, filter2, concat = 'AND'):
        """This keyword joins the two filter provided using concat option.
        
        This takes 2 mandatory arguments ``filter1`` and ``filter2``.
        
        ``concat`` is set to ``AND`` by default but 'OR' can be provided as ``concat``. Both ``AND`` and 
        ``OR`` are case sensitive. If any string other than ``AND`` or ``OR`` is provided in ``concat`` 
        then ``concat`` is set as ``AND``.
        
        This keyword returns the joined filter string i.e. (filter1 && filter2) or (filter1 || filter2)
        based on ``concat`` provided.
        
        = Examples =
        |    =Keyword=  | =filter1= | =filter2= |  =concat=  |      =output=     |                                          |
        | `Join Filter` |   a = 1   |   b <= 2  |            | (a = 1 && b <= 2) |                                          |
        | `Join Filter` |   a = 1   |   b <= 2  |     OR     | (a = 1 || b <= 2) |                                          |
        | `Join Filter` |   a = 1   |   b <= 2  |     or     | (a = 1 && b <= 2) | --> OR is case sensitive in this method  |
        | `Join Filter` |   a = 1   |   b <= 2  |     abcd   | (a = 1 && b <= 2) |                                          |
        """
        if(concat == 'AND'):
            op = ' && '
        elif(concat == 'OR'):
            op = ' || '
        else:
            op = ' && '
        return '(' + filter1 +  op  + filter2 + ')'
        
    def join_all_filters(self, concat, *filters):
        """This keyword joins two or more than two filters using concat option.
        
        This takes 1 mandatory argument concat which user has to provide. 
        option to provide in concat is ``AND `` and ``OR`` (both are case-sensitive)
        
        If user provides only one filter then it will return same filter.
        
        This keyword returns the joined filter string i.e. (filter1 && filter2 && filter3) or
        (filter1 || filter2 || filter3) based on ``concat`` provided
        
        = Examples =
        |       =Keyword=    | =filter1= | =filter2= | =filter2= |  =concat=  |           =output=          |
        | `Join All Filters` |  a == 1   |   b <= 2  |   c > 4   |    AND     | (a == 1 && b <= 2 && c > 4) |
        | `Join All Filters` |  a == 1   |   b <= 2  |   c > 4   |     OR     | (a == 1 || b <= 2 || c > 4) | 
        """
        if(not filters):
            self._logger().debug("No filters provided")
            raise Exception("No filters provided")
        
        if(concat == 'AND'):
            op = ' && '
        else:
            op = ' || '
            
        ffilter = ''    
        concat_count = 0
        try:     
            if (len(filters) ==1):
                ffilter = filters[0]
            for filter in filters:
                concat_count += 1
                ffilter += filter
                if( concat_count < len(filters) ):
                    ffilter += op
        except Exception as e:
            self._logger().exception("Could not join filters: %s" %e)
            raise Exception("Could not join filters: %s" %e)
        else:
            return '(' + ffilter + ')'
    
    def _format_filter_str(self, filter_str):
        """
        This method formats the filter for the provided string.
        """
        if (filter_str ==''):
            self._logger().debug("No filter string provided to format")
            raise Exception("No filter string provided to format")
        try:
            filter_str = filter_str.strip()
            filter_str = re.sub(' +', ' ', filter_str)
            for op in ops:
                filter_str = re.sub(op.get('op_without_spaces', 'IGNORE_CASE'), op.get('op_value', 'IGNORE_CASE'), filter_str)
            filter_str = re.sub(' +', ' ', filter_str)
            for op in ops:
                filter_str = re.sub(op.get('op_str', 'IGNORE_CASE'), op.get('op_value', 'IGNORE_CASE'), filter_str)
            filter_str = re.sub(' +', ' ', filter_str)
            for op in ops:
                filter_str = re.sub(op.get('op_with_spaces', 'IGNORE_CASE'), op.get('op_value', 'IGNORE_CASE'), filter_str)
            filter_str = re.sub(' +', ' ', filter_str)
        except Exception as e:
            self._logger().exception("Exception occurred in format filter str: {}".format(e))
            raise Exception
        else:
            return filter_str
        
    def _get_filter(self, filter_str):
        """
        This method gets the filter for the provided string. This method does not consider
        filter_str with logical operators (AND and OR) and considers only NOT operator provided 
        at the start of string.

        It supports only 3 cases:
            a. single value i.e 2
            b. three values i.e. a is 0
            c. four values i.e. NOT a is 0
            
        Example:
            filter_str = a is 0
            output is (a == 0)
            filter_str = a is 0 AND b is 0
            output will be exception at this point.
        """
        negate = ''
        onlyfieldvalue = False
        fieldname = ''
        op = ''
        fieldvalue = ''
        if (filter_str == ''):
            self._logger().info("got empty filter")
            self._logger().debug("got empty filter")
            raise Exception
        try:
            filter_str = self._format_filter_str(filter_str)
            filter_str = filter_str.strip()
            filter_as_list = filter_str.split(' ')
            while('' in filter_as_list):
               filter_as_list.remove('')
            if( len(filter_as_list) == 1):
                onlyfieldvalue = True
                fieldname = ''
                op = '.'
                fieldvalue = filter_as_list[0]
            elif(len(filter_as_list) == 3):
                fieldname = filter_as_list[0]
                op = ' ' +filter_as_list[1] + ' '
                fieldvalue = filter_as_list[2]
            elif(len(filter_as_list) == 4):
                if(filter_as_list[0] == 'NOT'):
                    negate = '!'
                fieldname = filter_as_list[1]
                op = ' ' + filter_as_list[2] + ' '
                fieldvalue = filter_as_list[3]
            else:
                self._logger().debug("Invalid string for filter creation '{}'". format(filter_str.strip()))
                raise Exception("Invalid string for filter creation '{}'". format(filter_str.strip()))
        except Exception as e:
            self._logger().exception("Exception in get filter: %s" %e)
            raise Exception
        finally:
            return negate, onlyfieldvalue, fieldname + op + fieldvalue    
    
    def _put_bracket(self,string):
        """
        This method puts bracket for the provided string by separating string and logical
        operators except any string is already provided with brackets. 
            
        Example:
            filter_str = a is 0 AND NOT (b is 2 AND c is 4)
            output is a is 0 BRACKET AND NOT BRACKET  BRACKET b is 2 AND c is 4
        """
        new_string = ''
        bracket = False
        skipword = False
        word = ''
        prev_word = ''
        prev_index = 0
        string += ' '
        try:
            for char_i in range(len(string)):
                if(string[char_i] != ' '):
                    word += string[char_i]
                    continue
                elif(not bracket and word == 'NOT'):
                    if(prev_word == 'AND' or prev_word == 'OR'):
                        skipword = True
                        new_string = new_string[:-8] + 'NOT BRACKET ' # 8 is len('BRACKET') + len(' ') 
                elif(not bracket and (word == 'AND' or word == 'OR')):
                    i = char_i - len(word)
                    skipword = True
                    new_string += ' BRACKET ' + word + ' BRACKET '
                    prev_index = char_i+1
                elif(word == 'BRACKET'):
                    bracket = not bracket
                if(not skipword):
                    new_string += ' ' + word
                prev_word = word
                word = ''
                skipword = False
        except Exception as e:
            self._logger().exception("Exception occurred in put filter : {}".format(e))
            raise Exception
        return new_string
    
    def _create_filter(self, parent_filter, where, sub_field = None):
        """
        This method creates filter for the provided argument string ``where`` and 
        parent_filter is prefixed in final filter.
        
        This method takes 2 mandatory arguments ``parent_filter`` and ``where``.
        
        This methods takes one optional argument ``sub_field`` which gets added 
        after ``parent_filter`` and before ``where``
            
        = Examples =
        |       =Keyword=    | =parent_filter= |            =where=       | =sub_field=  |            =output=          |
        | `_ CREATE FILTER`  |    genx.rfmac   |  NOT (a is 1 AND b is 1) |     fctrl    | !((genx.rfmac.fctrl.a == 1)\ 
                                                                                            && (genx.rfmac.fctrl.b ==1))|
        | `_ CREATE FILTER`  |    genx.rfmac   |  a is 1                  |              |      (genx.rfmac.a ==1)      |
        """
        where_orig = where
        where = re.sub(' +', ' ', where)
        where = where.strip()
        where = re.sub('\(', ' BRACKET ', where)
        where = re.sub('\)', ' BRACKET ', where)
        where = self._put_bracket(where)
        where = where.strip() 
        where = re.sub(' +', ' ', where)  
        where = where.split('BRACKET')
        while('' in where):
            where.remove('')
        while(' ' in where):
            where.remove(' ')
        ffilter = ''
        try:    
            for where_str in where:
                where_str = where_str.strip()
                if(where_str == 'NOT'):
                    ffilter += '!'
                elif(where_str == 'AND'):
                    ffilter += ' && '
                elif(where_str == 'OR'):
                    ffilter += ' || '
                elif(where_str == 'AND NOT'):
                    ffilter += ' && !'
                elif(where_str == 'OR NOT'):
                    ffilter += ' || !'
                else:
                    filter_ = self._create_filter2(parent_filter, where_str, sub_field)
                    if('||' in filter_):
                        ffilter += '(' + filter_ + ')'
                    elif('&&' in filter_):
                        ffilter += '(' + filter_ + ')'
                    else:
                        ffilter += filter_
            ffilter = ffilter.strip()
            ffilter = re.sub(' +', ' ', ffilter)
        except Exception as e:
            self._logger().exception("Exception occurred in create filter : {}".format(e))
            self._logger().exception("Invalid filter string: '{}".format(where_orig))
            raise Exception("Invalid filter string: '{}'".format(where_orig))
        return ffilter
        
    def _create_filter2(self, parent_filter, where, sub_field = None):
        """
        This method creates filter for the provided argument string ``where`` and 
        parent_filter is prefixed in final filter.
        
        This method takes 2 mandatory arguments ``parent_filter`` and ``where``.
        
        This methods takes one optional argument ``sub_field`` which gets added 
        after ``parent_filter`` and before ``where``
            
        = Examples =
        |       =Keyword=    | =parent_filter= |  =where=   |  =sub_field= |         =output=          |
        | `_ CREATE FILTER2` |    genx.rfmac   |  a is 1    |     fctrl    | (genx.rfmac.fctrl.a == 1) |
        | `_ CREATE FILTER2` |    genx.rfmac   |  a is 1    |              |     (genx.rfmac.a ==1)    |
        """
        ffilter = ''
        try:
            where_ands = where.split(' AND ')
            _and = 0
            for where_and in where_ands:
                _and += 1
                
                where_ors = where_and.split(' OR ')
                _or = 0
                for where_or in where_ors:
                    filter = parent_filter
                    _or += 1
                    negate, onlyfieldvalue, filter_ = self._get_filter(where_or)
                    if(sub_field):
                        filter += '.' + sub_field
                    if(onlyfieldvalue):
                        if(filter == ''):
                            filter_ = filter_[1:]
                        filter = negate + '(' + filter + filter_ + ')'
                    else:
                        filter = negate + '(' + filter + '.' + filter_ + ')'
                    if( _or < len(where_ors) ):
                        filter += ' || '
                    ffilter += filter
                    filter = ''
                if( _and < len(where_ands) ):
                    filter += ' && '
                ffilter += filter
        except Exception as e:
            self._logger().exception("Exception occurred in create filter : {}".format(e))
            raise Exception
        return ffilter.strip()
    
    def create_filter(self, where):
        """This keyword creates and return filter for argument string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators : [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |     =Keyword=   |                  =where=           |                =output=             |
        | `Create Filter` | a is 1 AND NOT (b <= 3 OR c is 5)  | (a == 1) && !((b <= 2) || (c == 5)) |
        | `Create Filter` | a is less than 5                   | (a < 5)                             | 
        | `Create Filter` | a.b.c == 5                         | (a.b.c == 5)                        | 
        | `Create Filter` | a.b.c                              | (a.b.c)                             | 
        
        """
        parent_filter = ''
        return self._create_filter(parent_filter, where, sub_field=None)
        
    def create_genx_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |       =Keyword=      |    =where=         |  =sub_field=  |                 =output=                   |
        | `Create Genx Filter` | a is 1 AND b is 3  |               | (genx.a == 1) && (genx.b == 3)             |
        | `Create Genx Filter` | a is 1 AND b is 3  | rfmac         | (genx.rfmac.a == 1) && (genx.rfmac.b == 3) | 
        | `Create Genx Filter` | a                  | rfmac         | (genx.rfmac.a)                             | 

        """
        parent_filter = 'genx'
        return self._create_filter(parent_filter, where, sub_field)
    
    def create_genx_rfmac_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.rfmac`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |           =Keyword=        |    =where=         | =sub_field=  |                          =output=                      |
        | `Create Genx Rfmac Filter` | a is 1 AND b is 3  |              | (genx.rfmac.a == 1) && (genx.rfmac.b == 3)             |
        | `Create Genx Rfmac Filter` | a is 1 AND b is 3  | fctrl        | (genx.rfmac.fctrl.a == 1) && (genx.rfmac.fctrl.b == 3) |
        | `Create Genx Rfmac Filter` | a                  | fctrl        | (genx.rfmac.fctrl.a)                                   | 

        """
        parent_filter = 'genx.rfmac'
        return self._create_filter(parent_filter, where, sub_field)
        
    def create_genx_rfmac_fctrl_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.rfmac.fctrl`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |              =Keyword=           |    =where=        | =sub_field=  |                          =output=                      |
        | `Create Genx rfmac fctrl Filter` | a is 1 AND b is 3 |              | (genx.rfmac.fctrl.a == 1) && (genx.rfmac.fctrl.b == 3) |
        | `Create Genx rfmac fctrl Filter` | a is 1            | src_present  | (genx.rfmac.fctrl.src_present.a == 1)                  | 
        | `Create Genx rfmac fctrl Filter` | a                 | src_present  | (genx.rfmac.fctrl.src_present.a)                       | 
        
        """
        parent_filter = 'genx.rfmac.fctrl'
        return self._create_filter(parent_filter, where, sub_field)

    def create_genx_phy_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.phy`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |         =Keyword=        |    =where=        | =sub_field=  |              =output=                  |
        | `Create Genx Phy Filter` | a is 1 AND b is 3 |              | (genx.phy.a == 1) && (genx.phy.b == 3) |
        | `Create Genx Phy Filter` | a is 1            | src_present  | (genx.phy.src_present.a == 1)          | 
        | `Create Genx Phy Filter` | a                 | src_present  | (genx.phy.src_present.a)               | 
        
        """
        parent_filter = 'genx.phy'
        return self._create_filter(parent_filter, where, sub_field)
    
    def create_genx_litlv_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.litlv`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |            =Keyword=       |    =where=        | =sub_field=  |                   =output=                 |
        | `Create Genx Litlv Filter` | a is 1 AND b is 3 |              | (genx.litlv.a == 1) && (genx.litlv.b == 3) |
        | `Create Genx Litlv Filter` | a is 1            | src_present  | (genx.litlv.src_present.a == 1)            | 
        | `Create Genx Litlv Filter` | a                 | src_present  | (genx.litlv.src_present.a)                 | 
        
        """
        parent_filter = 'genx.litlv'
        return self._create_filter(parent_filter, where, sub_field)            
        
    def create_genx_dlltlv_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.dlltlv`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |            =Keyword=        |    =where=        | =sub_field=  |                     =output=                 |
        | `Create Genx Dlltlv Filter` | a is 1 AND b is 3 |              | (genx.dlltlv.a == 1) && (genx.dlltlv.b == 3) |
        | `Create Genx Dlltlv Filter` | a is 1            | src_present  | (genx.dlltlv.src_ present.a == 1)            | 
        | `Create Genx Dlltlv Filter` | a                 | src_present  | (genx.dlltlv.src_ present.a)                 | 
        
        """
        parent_filter = 'genx.dlltlv'
        return self._create_filter(parent_filter, where, sub_field)
        
    def create_genx_mactlv_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.mactlv`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |            =Keyword=        |    =where=        | =sub_field=  |                    =output=                  |
        | `Create Genx Mactlv Filter` | a is 1 AND b is 3 |              | (genx.mactlv.a == 1) && (genx.mactlv.b == 3) |
        | `Create Genx Mactlv Filter` | a is 1            | mlmetlv      | (genx.mactlv.mlmetlv.a == 1)                 | 
        | `Create Genx Mactlv Filter` | a                 | mlmetlv      | (genx.mactlv.mlmetlv.a)                      | 
        
        """
        parent_filter = 'genx.mactlv'
        return self._create_filter(parent_filter, where, sub_field)
        
    def create_genx_mactlv_mlmetlv_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.mactlv.mlmetlv`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |                =Keyword=            |    =where=        | =sub_field=  |                            =output=                          |
        | `Create Genx Mactlv Mlmetlv Filter` | a is 1 AND b is 3 |              | (genx.mactlv.mlmetlv.a == 1) && (genx.mactlv.mlmetlv.b == 3) |
        | `Create Genx Mactlv Mlmetlv Filter` | a is 1            | src_present  | (genx.mactlv.mlmetlv.src_present.a == 1)                     | 
        | `Create Genx Mactlv Mlmetlv Filter` | a                 | src_present  | (genx.mactlv.mlmetlv.src_present.a)                          | 
        
        """
        parent_filter = 'genx.mactlv.mlmetlv'
        return self._create_filter(parent_filter, where, sub_field)
        
    def create_genx_mactlv_net_mgr_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.mactlv.net_mgr`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |                =Keyword=            |    =where=        | =sub_field=  |                            =output=                          |
        | `Create Genx Mactlv Net Mgr Filter` | a is 1 AND b is 3 |              | (genx.mactlv.net_mgr.a == 1) && (genx.mactlv.net_mgr.b == 3) |
        | `Create Genx Mactlv Net Mgr Filter` | a is 1            | src_present  | (genx.mactlv.net_mgr.src_present.a == 1)                     |
        | `Create Genx Mactlv Net Mgr Filter` | a                 | src_present  | (genx.mactlv.net_mgr.src_present.a)                          | 
        
        """
        parent_filter = 'genx.mactlv.net_mgr'
        return self._create_filter(parent_filter, where, sub_field)
        
    def create_genx_mactlv_sec_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.mactlv.sec`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |              =Keyword=          |    =where=        | =sub_field=  |                       =output=                       |
        | `Create Genx Mactlv Sec Filter` | a is 1 AND b is 3 |              | (genx.mactlv.sec.a == 1) && (genx.mactlv.sec.b == 3) |
        | `Create Genx Mactlv Sec Filter` | a is 1            | src_present  | (genx.mactlv.sec.src_present.a == 1)                 | 
        | `Create Genx Mactlv Sec Filter` | a                 | src_present  | (genx.mactlv.sec.src_present.a)                      | 
        
        """
        parent_filter = 'genx.mactlv.sec'
        return self._create_filter(parent_filter, where, sub_field)
    
    def create_genx_mactlv_srt_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.mactlv.srt`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |              =Keyword=          |    =where=        | =sub_field=  |                       =output=                       |
        | `Create Genx Mactlv Srt Filter` | a is 1 AND b is 3 |              | (genx.mactlv.srt.a == 1) && (genx.mactlv.srt.b == 3) |
        | `Create Genx Mactlv Srt Filter` | a is 1            | src_present  | (genx.mactlv.srt.src_present.a == 1)                 | 
        | `Create Genx Mactlv Srt Filter` | a                 | src_present  | (genx.mactlv.srt.src_present.a)                      | 
        
        """
        parent_filter = 'genx.mactlv.srt'
        return self._create_filter(parent_filter, where, sub_field)
        
    def create_genx_mactlv_fast_restore_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``genx.mactlv.fast_restore`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |                  =Keyword=               |    =where=        | =sub_field=  |                    =output=                   |
        | `Create Genx Mactlv Fast Restore Filter` | a is 1 AND b is 3 |              | (genx.mactlv.fast_restore.a == 1)\
                                                                                        && (genx.mactlv.fast_restore.b == 3)         |
        | `Create Genx Mactlv Fast Restore Filter` | a is 1            | src_present  | (genx.mactlv.fast_restore.src_present.a == 1) | 
        | `Create Genx Mactlv Fast Restore Filter` | a                 | src_present  | (genx.mactlv.fast_restore.src_present.a)      | 
        
        """
        parent_filter = 'genx.mactlv.fast_restore'
        return self._create_filter(parent_filter, where, sub_field) 
    
    def create_dns_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``dns`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |       =Keyword=     |    =where=        | =sub_field=  |           =output=           |
        | `Create Dns Filter` | a is 1 AND b is 3 |              | (dns.a == 1) && (dns.b == 3) |
        | `Create Dns Filter` | a is 1            | src_port     | (dns.src_port.a == 1)        | 
        | `Create Dns Filter` | a                 | src_port     | (dns.src_port.a)             | 
        
        """
        parent_filter = 'dns'
        return self._create_filter(parent_filter, where, sub_field) 
    
    def create_dns_flags_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``dns.flags`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |          =Keyword=        |    =where=        | =sub_field=  |           =output=                       |
        | `Create Dns Flags Filter` | a is 1 AND b is 3 |              | (dns.flags.a == 1) && (dns.flags.b == 3) |
        | `Create Dns Flags Filter` | a is 1            | src_port     | (dns.flags.src_port.a == 1)              | 
        | `Create Dns Flags Filter` | a                 | src_port     | (dns.flags.src_port.a)                   | 
        
        """
        parent_filter = 'dns.flags'
        return self._create_filter(parent_filter, where, sub_field) 
    
    def create_dns_count_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``dns.count`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |          =Keyword=        |    =where=        | =sub_field=  |           =output=                       |
        | `Create Dns Count Filter` | a is 1 AND b is 3 |              | (dns.count.a == 1) && (dns.count.b == 3) |
        | `Create Dns Count Filter` | a is 1            | src_port     | (dns.count.src_port.a == 1)              |
        | `Create Dns Count Filter` | a                 | src_port     | (dns.count.src_port.a)                   | 
        
        """
        parent_filter = 'dns.count'
        return self._create_filter(parent_filter, where, sub_field) 
     
    def create_udp_filter(self, where, sub_field = None):
        """This keyword creates and return filter for argument string ``where`` and 
        ``udp`` will always be added as prefix for the string ``where``.
        
        This takes 1 mandatory argument ``where`` which is basically string provided by user to create filter
        
        This takes 1 optional argument ``sub_field``. See example below.
        
        This supports various conditional operators and its english equivalent which are mentioned below.
        operators: [==, <=, >=, !=, <, >]
        == operator Details ==
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    <=      | is less than or equal to    |
        |    >=      | is greater than or equal to |
        |    <       | is less than                |
        |    >       | is greater than             |
        |    !=      | is not                      |
        
        = Examples =
        |       =Keyword=     |    =where=        | =sub_field=  |           =output=           |
        | `Create Udp Filter` | a is 1 AND b is 3 |              | (udp.a == 1) && (udp.b == 3) |
        | `Create Udp Filter` | a is 1            | dest_port    | (udp.dest_port.a == 1)       |
        | `Create Udp Filter` | a                 | dest_port    | (udp.dest_port.a)            | 

        """
        parent_filter = 'udp'
        return self._create_filter(parent_filter, where, sub_field)    
    
    def get_frame_count(self, filter = None, tshark_options = None, concat = 'AND', filter_unique_frame = True):
        """
        This keyword returns the frame count 
        This keyword needs pcap file. pcap file can be provided in two ways. 
            Way1: Set pcap file while importing library 
            Way2: call keyword ``set pcap file`` with pcap_file
            If pcap file is not provided it will raise an exception
        
        ``filter`` is optional argument 
        If ``filter`` is provided, it will be concatenated using ``concat`` option with filter for 
        unique frame set by keyword ``Set Unique Frame`` 
        
        ``tshark_options`` is optional argument 
        If ``tshark_options`` is provided, it will be added as it is. There is no need to provide
        display filter option here (-Y) as it is internally added.
        
        ``concat`` is ``AND`` by default. User can provide ``OR`` as concat option. Both are case sensitive and
         if anything else is provided it will be considered as ``AND``
         
         ``filter_unique_frame`` is ``True`` by default and it provides filter for unique frame.
         
        If ``filter`` is not provided, this keyword will get frame count for filter for unique frame.
        If in this case Unique frame is not set, it will raise an exception.
        
        If ``filter`` is provided and ``filter_unique_frame`` is set to ``False`` then this keyword will 
        give frame count for the provided ``filter``
        
        = Examples =
        Consider unique frame is set and filter for unique frame is "(genx.rfmac == 0x02)" 
        |      =Keyword=    |             =filter=            | =concat=  |  =filter_unique_frame= |                                    =comment=                               |
        | `Get Frame Count` | (genx.a == 1) && (genx.b == 3)  |           |                        | count will be for ((genx.rfmac == 0x02) && (genx.a == 1) && (genx.b == 3)) |
        | `Get Frame Count` |                                 |           |                        | count will be for (genx.rfmac == 0x02)                                     |
        | `Get Frame Count` | (genx.a == 1) && (genx.b == 3)  | OR        |                        | count will be for ((genx.rfmac == 0x02) || (genx.a == 1) && (genx.b == 3)) |
        | `Get Frame Count` | (genx.a == 1) && (genx.b == 3)  |           | False                  | count will be for (genx.a == 1) && (genx.b == 3)                           |
         
        Consider Unique frame is not set
        |      =Keyword=    |             =filter=            | =concat=  |  =filter_unique_frame= |           =comment=                              |
        | `Get Frame Count` | (genx.a == 1) && (genx.b == 3)  |           |                        | count will be for (genx.a == 1) && (genx.b == 3) |
        | `Get Frame Count` |                                 |           |                        | Exception will be thrown                         |
        | `Get Frame Count` | (genx.a == 1) && (genx.b == 3)  | OR        |                        | count will be for (genx.a == 1) && (genx.b == 3) |
        | `Get Frame Count` | (genx.a == 1) && (genx.b == 3)  |           | False                  | count will be for (genx.a == 1) && (genx.b == 3) |
         
        =Note=
            ``filter`` must be in the format of tshark accepted commands either user has to provide ``filter``or
            ``filter`` can be created using any ``create_*_filter`` keywords.
        """
        frame_count = -1
        if(not self.pcap_file):
            self._logger().debug("Pcap file is not provided by user")
            raise Exception("Pcap file is not provided by user")
        ffilter = ''
        if(filter is None):
            if(self.base_frame):
                ffilter = self._get_base_frame_filter(self.base_frame)
            else:
                self._logger().debug("Neither filter nor unique frame provided")
                raise Exception("Neither filter nor unique frame provided")
        else:
            if(filter_unique_frame is True and self.base_frame):
                bfilter = self._get_base_frame_filter(self.base_frame)
                ffilter = self.join_filter(bfilter, filter, concat)
            else:
                ffilter = filter
        try:
            if (tshark_options is not None):
                command = self.tshark_cmd + ' -r ' + '"' + self.pcap_file + '"' + ' ' + tshark_options +' -Y ' + '"' + ffilter + '"'
            else:
                command = self.tshark_cmd + ' -r ' + '"' + self.pcap_file + '"' +' -Y ' + '"' + ffilter + '"'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception:
            self._logger().exception(e)
            raise Exception(e)
        else:
            frame_count = output.count('\n')
            self._logger().info("Frame count: %d", frame_count)
        finally:
            return str(frame_count)
            
    def get_frames(self, filter=None, tshark_options=None, concat = 'AND', filter_unique_frame = True):
        """
        This keyword returns the frames 
        This keyword needs pcap file. pcap file can be provided in two ways. 
            Way1: Set pcap file while importing library 
            Way2: call keyword ``set pcap file`` with pcap_file
            If pcap file is not provided it will raise an exception 
        
        ``filter`` is optional argument 
        If ``filter`` is provided, it will be concatenated using ``concat`` option with filter for 
        unique frame set by keyword ``Set Unique Frame`` 
        
        ``tshark_options`` is optional argument 
        If ``tshark_options`` is provided, it will be added as it is. There is no need to provide
        display filter option here (-Y) as it is internally added.
        
        ``concat`` is ``AND`` by default. User can provide ``OR`` as concat option. Both are case sensitive and
         if anything else is provided it will be considered as ``AND``
         
         ``filter_unique_frame`` is ``True`` by default and it provides filter for unique frame.
         
        If ``filter`` is not provided, this keyword will get frame count for filter for unique frame.
        If in this case Unique frame is not set, it will raise an exception.
        
        If ``filter`` is provided and ``filter_unique_frame`` is set to ``False`` then this keyword will 
        give frame count for the provided ``filter``
        
        = Examples =
        Consider unique frame is set and filter for unique frame is "(genx.rfmac == 0x02)" 
        |  =Keyword=   |             =filter=            | =concat=  |  =filter_unique_frame= |                                    =comment=                                |
        | `Get Frames` | (genx.a == 1) && (genx.b == 3)  |           |                        | frames will be for ((genx.rfmac == 0x02) && (genx.a == 1) && (genx.b == 3)) |
        | `Get Frames` |                                 |           |                        | frames will be for (genx.rfmac == 0x02)                                     |
        | `Get Frames` | (genx.a == 1) && (genx.b == 3)  | OR        |                        | frames will be for ((genx.rfmac == 0x02) || (genx.a == 1) && (genx.b == 3)) |
        | `Get Frames` | (genx.a == 1) && (genx.b == 3)  |           | False                  | frames will be for (genx.a == 1) && (genx.b == 3)                           |
         
        Consider Unique frame is not set
        |  =Keyword=   |             =filter=            | =concat=  |  =filter_unique_frame= |                   =comment=                       |
        | `Get Frames` | (genx.a == 1) && (genx.b == 3)  |           |                        | frames will be for (genx.a == 1) && (genx.b == 3) |
        | `Get Frames` |                                 |           |                        | Exception will be thrown                          |
        | `Get Frames` | (genx.a == 1) && (genx.b == 3)  | OR        |                        | frames will be for (genx.a == 1) && (genx.b == 3) |
        | `Get Frames` | (genx.a == 1) && (genx.b == 3)  |           | False                  | frames will be for (genx.a == 1) && (genx.b == 3) |
         
        =Note=
            ``filter`` must be in the format of tshark accepted commands either user has to provide ``filter``or
            ``filter`` can be created using any ``create_*_filter`` keywords.
        """
        if(not self.pcap_file):
            self._logger().debug("Pcap file is not provided by user")
            raise Exception("Pcap file is not provided by user")
        ffilter = ''
        if(filter is None):
            if(self.base_frame):
                ffilter = self._get_base_frame_filter(self.base_frame)
            else:
                self._logger().debug("neither filter nor unique frame provided")
                raise Exception("neither filter nor unique frame provided")
        else:
            if(filter_unique_frame is True and self.base_frame):
                bfilter = self._get_base_frame_filter(self.base_frame)
                ffilter = self.join_filter(bfilter, filter, concat)
            else:
                ffilter = filter
        
        fl = []
        try:
            if (tshark_options is not None):
                command = self.tshark_cmd + ' -r ' + '"' + self.pcap_file + '"' + ' ' + tshark_options +' -Y ' + '"' + ffilter + '"'
            else:
                command = self.tshark_cmd + ' -r ' + '"' + self.pcap_file + '"' +' -Y ' + '"' + ffilter + '"'
            output = Connection.execute_command(self, command)
            self._logger().debug(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            fl = output.strip().splitlines()
            self._logger().debug(fl)
        finally:
            return fl
        
    def save_frames(self, filename,  filter=None, tshark_options = None, concat = 'AND', filter_unique_frame = True):
        """
        This keyword saves the frames in csv file
        This keyword needs pcap file. pcap file can be provided in two ways. 
            Way1: Set pcap file while importing library 
            Way2: call keyword ``set pcap file`` with pcap_file
            If pcap file is not provided it will raise an exception
        
        This keyword has 1 mandatory argument ``filename``.
        
        ``filter`` is optional argument 
        If ``filter`` is provided, it will be concatenated using ``concat`` option with filter for 
        unique frame set by keyword ``Set Unique Frame`` 
        
        ``tshark_options`` is optional argument 
        If ``tshark_options`` is provided, it will be added as it is. There is no need to provide
        display filter option here (-Y) as it is internally added.
        
        ``concat`` is ``AND`` by default. User can provide ``OR`` as concat option. Both are case sensitive and
         if anything else is provided it will be considered as ``AND``
         
         ``filter_unique_frame`` is ``True`` by default and it provides filter for unique frame.
         
        If ``filter`` is not provided, this keyword will get frame count for filter for unique frame.
        If in this case Unique frame is not set, it will raise an exception.
        
        If ``filter`` is provided and ``filter_unique_frame`` is set to ``False`` then this keyword will 
        give frame count for the provided ``filter``
        
        = Examples =
        Consider unique frame is set and filter for unique frame is "(genx.rfmac == 0x02)" 
        |  =Keyword=    |    =filename=   |            =filter=            | =concat=  |  =filter_unique_frame= |                        =comment=                               |
        | `Save Frames` | saveframe_Step1 | (genx.a == 1) && (genx.b == 3) |           |                        | frames will be saved for ((genx.rfmac == 0x02)\
                                                                                                                  && (genx.a == 1) && (genx.b == 3)) in saveframe_step1.csv      |
        | `Save Frames` | saveframe_Step1 |                                |           |                        | frames will be for (genx.rfmac == 0x02) in saveframe_step1.csv |
        | `Save Frames` | saveframe_Step1 | (genx.a == 1) && (genx.b == 3) | OR        |                        | frames will be for ((genx.rfmac == 0x02) || (genx.a == 1)\
                                                                                                                  && (genx.b == 3)) in saveframe_step1.csv                       |
        | `Save Frames` | saveframe_Step1 | (genx.a == 1) && (genx.b == 3) |           | False                  | frames will be for (genx.a == 1) && (genx.b == 3)\
                                                                                                                  in saveframe_step1.csv                                         |
         
        Consider Unique frame is not set
        |  =Keyword=    |    =filename=   |            =filter=             | =concat=  |  =filter_unique_frame= |                                     =comment=                                  |
        | `Save Frames` | saveframe_Step1 | (genx.a == 1) && (genx.b == 3)  |           |                        | frames will be saved for (genx.a == 1) && (genx.b == 3) in saveframe_step1.csv |
        | `Save Frames` | saveframe_Step1 |                                 |           |                        | Exception will be thrown                                                       |
        | `Save Frames` | saveframe_Step1 | (genx.a == 1) && (genx.b == 3)  | OR        |                        | frames will be saved for (genx.a == 1) && (genx.b == 3) in saveframe_step1.csv |
        | `Save Frames` | saveframe_Step1 | (genx.a == 1) && (genx.b == 3)  |           | False                  | frames will be saved for (genx.a == 1) && (genx.b == 3) in saveframe_step1.csv |
         
        =Note=
            ``filter`` must be in the format of tshark accepted commands either user has to provide ``filter``or
            ``filter`` can be created using any ``create_*_filter`` keywords.
        """
        try:
            output = self.get_frames(filter=None, tshark_options = tshark_options, concat='AND', filter_unique_frame=True)
            self._logger().debug(output)
        except Exception:
            self._logger().exception("save frames failed")
            raise Exception("save frames failed")
        
        try:
            filepath = os.path.join(DestDir, filename +".csv")
            f=open(filepath,"w", newline='')
            for val in output:
                f.write(val + '\n')
            filename = Path(filepath).name
            self._logger().debug(filename)
            f.close()
            print("*HTML* <a href={}>{}.log</a>".format(filepath,filename))
        except Exception as e:
            self._logger().exception("save frames failed: {}".format(e))
            raise exception("save frames failed: {}".format(e))
        return filename           
    
    def _get_base_frame_filter(self, frametype):
        """
        This keyword returns the filter for unique frame
        
        This keyword takes 1 mandatory argument ``frametype`` which is set by keyword ``Set Unique Frame``
        """
        if(frametype == 'RTA BROADCAST'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_length is 0 AND dll_type is 6')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND srt.protocol is 0x01')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
        
        elif(frametype == 'RTA UNICAST'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND srt.protocol is 0x01')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
        
        elif(frametype == 'SLOW BEACON'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x02')
            filter1=  self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_length is 2 AND dll_type is 1')
            filter3 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_length is 0 AND dll_type is 6')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3)
        ##updated as part of release v0.2-patch1
        elif(frametype == 'EVAL SCHED'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_length is 3 AND dll_type is 2')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_type is 1 AND type_mask is 0x00020000')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 3')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
        
        elif(frametype == 'FAST BEACON'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x02')
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_length is 2 AND dll_type is 1')
            filter3 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_length is 0 AND dll_type is 7')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3)
        ##updated as part of release v0.2-patch1
        elif (frametype == 'EVAL ACK SCHED'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_type is 1 AND type_mask is 0x00040000')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 3')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
        
        elif (frametype == 'NREG'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('dli_version is 0x01 AND proto_id is 3 AND version is 0x02 AND srt.protocol is 0x02')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
        
        elif (frametype == 'NREG ACK'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is 0x13 AND version is 0x02 AND srt.protocol is 0x03')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
        
        elif (frametype == 'DLI PROTO ROUTING'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is 0x13 AND dli_version is 0x01 AND proto_id is 0x03')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3)
        
        elif (frametype == 'DLI TIME SYNC REQ RSP TLV'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is 0x13 AND dli_version is 0x01 AND proto_id is 0x03')
            filter4 = self.create_genx_mactlv_filter('dli_has_tlv is 1 AND tlv_id is 0x02 AND reserved is 00 AND type is 2 AND version is 0x01')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3, filter4)
        
        elif (frametype == 'DLI PAYLOAD TLV'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter1 = self.create_genx_rfmac_fctrl_filter('0x01 AND src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is 0x13 AND dli_version is 0x01 AND proto_id is 0x03')
            filter4 = self.create_genx_mactlv_filter('dli_has_tlv is 1 AND tlv_id is 0x01 AND reserved is 00')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3, filter4) 
        ##updated as part of release v0.2-patch1
        elif (frametype == 'MLME LI AGGRESSIVE DISCOVERY'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 64')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
        ##updated as part of release v0.2-patch1
        elif (frametype == 'MLME LI UPSTREAM DISCOVERY'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 64')
            filter4 = self.create_genx_mactlv_filter('litlv is 0x11')
            filter5 = self.create_genx_litlv_filter('disc_flags is 0x01')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4, filter5)
        ##updated as part of release v0.2-patch1
        elif (frametype == 'MLME LI REBUILD NODEQ'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 64')
            filter4 = self.create_genx_mactlv_filter('litlv is 0x11')
            filter5 = self.create_genx_litlv_filter('disc_flags is 0x10')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4, filter5)     
        ##updated as part of release v0.2-patch1
        elif (frametype == 'MLME LI RSP QRY'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 66')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
        ##updated as part of release v0.2-patch1
        elif (frametype == 'MLME LI RSP'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 65')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
        
        elif (frametype == 'DNS RESPONSE'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_type is 2')
            filter3 = self.create_genx_mactlv_filter('version_proto_id is 0x16 AND mac_tlv_type is 0')
            filter4 = self.create_dns_filter('flags.response is 1')
            filter5 = self.create_udp_filter('srcport is 53')
            filter6 = self.create_genx_mactlv_filter('mac_tlv_type is 4')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4, filter5, filter6)
        ##updated as part of release v0.2-patch1
        elif (frametype == 'TUPD'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 1 AND dll_length is 2 AND dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 69')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
        
        elif (frametype == 'DNS REQUEST'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_type is 2')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_type is 0 AND version_proto_id is 0x16')
            filter4 = self.create_dns_filter('flags.response is 0')
            filter5 = self.create_udp_filter('dstport is 53')
            filter6 = self.create_genx_mactlv_filter('mac_tlv_type is 4')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4, filter5, filter6)
        ##updated as part of release v0.2-patch1    
        elif (frametype == 'NBOR QRY TLV'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 7')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
        ##updated as part of release v0.2-patch1
        elif (frametype == 'NBOR RSP TLV'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 4')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'KEEP SCHED'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_type is 1 AND type_mask is 0x00008000')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 3')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'KEEP ACK SCHED'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_type is 1 AND type_mask is 0x00010000')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 3')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'CULL SCHED'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_type is 1 AND type_mask is 0x00400000')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 3')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'DLI PROTO TRACE'):
            filter1 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter2 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter3 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter4 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is\
             0x17 AND dli_version is 0x01 AND proto_id is 0x07')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'DLI PROTO TIMESYNC'):
            filter1 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter2 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter3 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter4 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is\
             0x18 AND dli_version is 0x01 AND proto_id is 0x08')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'DLI PROTO IP'):
            filter1 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter2 = self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter3 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 2 AND dll_length is 3')
            filter4 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 0 AND version_proto_id is\
             0x16 AND dli_version is 0x01 AND proto_id is 0x06')
            filter = self.join_all_filters('AND', filter1, filter2, filter3, filter4)
            
        elif (frametype == 'MLME LI MAC BCAST'):
            filter1 = self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 73')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)    
        
        elif(frametype == 'MLME LG CTRL BEACON'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x02')
            filter1=  self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter2 = self.create_genx_dlltlv_filter('dll_tlv_t is 0 AND dll_type is 6')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter4 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 75')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3, filter4)
        
        elif(frametype == 'MLME LG CTRL INFO'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x03')
            filter1=  self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 1')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 75')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3)

        elif(frametype == 'MLME LG BUNDLE'):
            filter1=  self.create_genx_rfmac_fctrl_filter('dst_present is 1')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 8')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
        
        elif(frametype == 'MLME FAST RESTORE INFO'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x03')
            filter1=  self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 1')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 0 AND shorttlv.type is 74')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3)

        elif(frametype == 'MLME FAST RESTORE BUNDLE'):
            filter0 = self.create_genx_rfmac_filter('fctrl is 0x01')
            filter1=  self.create_genx_rfmac_fctrl_filter('src_present is 0 AND dst_present is 1')
            filter2 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 1')
            filter3 = self.create_genx_mactlv_mlmetlv_filter('tlv.t is 1 AND longtlv.type is 9')
            filter = self.join_all_filters('AND', filter0, filter1, filter2, filter3)
            
        elif(frametype == 'LAST GASP'):
            filter1 = self.create_genx_rfmac_filter('fctrl is 0x02')
            filter2=  self.create_genx_rfmac_fctrl_filter('src_present is 1 AND dst_present is 0')
            filter3 = self.create_genx_mactlv_filter('mac_tlv_t is 1 AND mac_tlv_type is 2')
            filter = self.join_all_filters('AND', filter1, filter2, filter3)
            
        return filter

        