# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""

from kaizenbot.server import Server
from kaizenbot.connection import Connection
from kaizenbot.logging_robot import Loggers
from robot.libraries.BuiltIn import BuiltIn
import re, os, time, hashlib
from pathlib import Path
from kaizenbot.exceptions import MACNotFoundError, NodeUnreachableError
from distutils.command.check import check

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class G5RFWFlash:
    def __init__(self):
        pass
    
    def _logger(self):
        raise NotImplementedError
        
    def is_node_bare(self):
        """This checks if the node is bare and returns ``True`` otherwise ``False``.
        Node is considered to be bare if string ``Gen5RivaMeter`` in the output of ``modversion.sh``
        is present or string ``AsicMeter`` is not present.
        """
        try:
            output = Connection.execute_command(self,'modversion.sh')
            if(output.find('Gen5RivaMeter') == -1 or not output.find('AsicMeter') == -1):
                return True
            return False
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
    def is_node_reachable(self):
        """This tries to execute ``echo hello`` command.
        If the command runs successfully, It returns ``True`` otherwise ``False``.
        """
        try:
            output = Connection.execute_command(self,'echo hello')
            self._logger().debug(output)
            if(output.find('hello') != -1):    # if(output == 'hello\n')
                return True
        except Exception as e:
            self._logger().debug("Node is not reachable")
            return False
    
    def node_should_be_reachable(self):
        """This fails if node is unreachable otherwise it returns ``Ok`` (case-sensitive).
        """
        if not self.is_node_reachable():
            raise NodeUnreachableError
        else:
            return 'Ok'
        
    def get_remote_file_checksum(self, file):
        """This returns the checksum of the given remote file.
        This expects the file to be present on the remote server.
        """
        try:
            checksum = Connection.execute_command(self, 'md5sum '+ file)
            self._logger().info(checksum)
            checksum = checksum.split(' ')[0]
            return checksum
        except Exception as e:
            self._logger().exception(e)
            raise
        
    def get_remote_file_size(self, file):
        """This returns the size of the given file.
        This expects the file to be present on the remote server.
        """
        try:
            size = Connection.execute_command(self, 'stat -c %s '+ file)
            self._logger().info(size)
            return size
        except Exception as e:
            self._logger().exception(e)
            raise       
 
    def flash_into_node(self, file):
        """This keyword uses the shell script ``Helper-CmdList.sh`` which must be on the remote server.
        """
        try:
            output = Connection.execute_command(self, 'Helper-CmdList.sh -f {}'.format(file))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise
        
    def get_local_file_checksum(self, file):
        """This returns the checksum of the given local file.
        """
        try:
            checksum = hashlib.md5(open(file,'rb').read()).hexdigest()
            self._logger().info(checksum)
            return checksum
        except Exception as e:
            self._logger().exception(e)
            raise 
        
    def get_local_file_size(self, file):
        """This returns the size of the given local file.
        """
        try:
            size = Path(file).stat().st_size
            self._logger().info(size)
            return size
        except Exception as e:
            self._logger().exception(e)
            raise
        
    def get_dsp_version(self):
        """This returns the rf/dsp version.
        """
        try:
            output = Connection.execute_command(self,'pib -gn /rf_mac/hardcoded/system/sys_app_version --raw')
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            dsp_version=output.split('_')[2]
            if dsp_version:
                self._logger().info("DSP Version: %s" % str(dsp_version))
                return dsp_version
            else:
                raise RuntimeError("Could not get DSP version\n{}".format(output))
                     
    def get_A7_version(self):
        """This returns the A7 version.
        """
        try:
            output = Connection.execute_command(self, 'TransactionProcess --event="MUSE_V1;ReadLid;ILID_SYSTEM_FW_VERSION"')
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)    
        else:
            match = re.search('String=(.*)', output)
            if(match):
                A7_version = match.group(1)
                self._logger().debug(A7_version) 
                return str(A7_version) 
            else:
                raise RuntimeError("Could not get A7 version\n{}".format(output)) 
            
 
    def capture_improvhelper(self, improvhelper_waittime, log=False):
        """This saves the output of ImProvHelper.sh to a file and returns file path.
        
        ``improvhelper_waittime`` is the time in seconds for ``ImProvHelper.sh`` to produce enough output data.
        
        A true value to ``log`` will also attach the file to logs.
        
        Example:

        | `Capture ImProvHelper` |  improvhelper_waittime=1200 |          |
        | `Capture ImProvHelper` |  improvhelper_waittime=1200 | log=True |
        
        """
        try:
            improvhelper_waittime = int(improvhelper_waittime)
        except ValueError:
            self._logger().exception("'improvhelper_waititme':{} must be integer or string-convertible-to-integer".format(improvhelper_waittime))
            raise ValueError("'improvhelper_waititme':{} must be integer or string-convertible-to-integer".format(improvhelper_waittime))
        
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            output = ''
            itr_actv_sh_obj = Connection.open_interactive_shell(self)
            chan = itr_actv_sh_obj.chan
            chan.send('ImProvHelper.sh\n')
            time.sleep(improvhelper_waittime)
            chan.send(chr(3))
            while(chan.recv_ready()):
                data = chan.recv(1024)
                output += data.decode()
                self._logger().debug(output)
            chan.close()
            filename = 'ImProvHelper_' + time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())+ '.txt'
            filepath = os.path.join(DestDir, filename)
            f=open(filepath,"w", newline='')
            f.write(output)
            f.close()
            if log:
                print("*HTML* <a href={}>{}</a>".format(filepath,filename))
            return filepath
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)   
        
    def wait_until_node_becomes_unreachable(self, waittime):
        """This waits until the node becomes unreachable.
        Becoming unreachable means the connection is forcibly closed by node and current SSH session becomes ``NOT ACTIVE``. 
        
        It raises an error if node is reachable even after ``waittime``.
         
        Example:

        | `Wait Until Node Becomes Unreachable` |  waittime=1200 |
        
        """
        try:
            waittime = int(waittime)
        except ValueError:
            self._logger().exception("'waititme':{} must be integer or string-convertible-to-integer".format(waittime))
            raise ValueError("'waititme':{} must be integer or string-convertible-to-integer".format(waittime))
        
        starttime = time.time()
        self._logger().debug(starttime)
        interval=10
        
        timepassed = 0
        while(timepassed < waittime):
            time.sleep(interval)
            timepassed = time.time()-starttime
            self._logger().debug(timepassed)
            try:
                output = Connection.execute_command(self, 'echo hello', timeout=60)
                self._logger().debug(output)
                if(output.find('hello') != -1): 
                    print("node is still reachable after {} seconds".format(str(round(timepassed))))
                    continue
            except Exception as e:
                try:
                    if 'An existing connection was forcibly closed by the remote host' in str(e):
                        output = Connection.execute_command(self, 'echo hello',timeout=60)
                        self._logger().info(output)
                        if(output.find('hello') != -1): 
                            self._logger().info("Check for SSH exception")
                except Exception as e:
                    if 'SSH session not active' in str(e):
                        self._logger().info("Meter Rebooted")
                        return 'Ok'
                    raise
                else:
                    self._logger().info(str(e))
                    raise Exception(e)
        
        if(timepassed > waittime):
            self._logger().debug("node is still reachable after {} seconds".format(str(waittime)))
            raise Exception("node is still reachable after {} seconds".format(str(waittime)))
        
    def capture_modversion(self, log=False):
        """This saves the output of ``modversion.sh`` to a file and returns file path.
        
        A true value to ``log`` will also attach the file to logs.
        
        Example:
        
        | `Capture Modversion` |          |
        | `Capture Modversion` | log=True |
         
        """
        try:
            if not os.path.isdir(DestDir):
                os.mkdir(DestDir)
            
            output = Connection.execute_command(self, 'modversion.sh')
            filename = 'modversion_' + time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())+ '.txt'
            filepath = os.path.join(DestDir, filename)
            f=open(filepath,"w", newline='')
            f.write(output)
            f.close()
            if log:
                print("*HTML* <a href={}>{}</a>".format(filepath,filename))
            return filepath
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)