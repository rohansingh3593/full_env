from .nodes import G5RNode, G5NNode, APNode
from kaizenbot.logging_robot import Loggers
from kaizenbot.connection import Connection
from robot.libraries.BuiltIn import BuiltIn
import os
import re
import time

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

class FWUpgradeLibrary:
    def __init__(self):
        pass      
    
    def _logger(self):
        raise NotImplementedError    
    
    def _upgrade(self, image, node = None):
        """The implementation of this keyword is incomplete.
        """
        node = node or self.get_current_node()
        if(not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            node_ = G5NNode()
            node_.upgrade_g5n(node, image)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
    def attach_file_to_log(self, file): 
        """This attaches the given file to log file.  
        """
        if not os.path.isfile(file):
            raise FileNotFoundError("File '{}' does not exist".format(file))
          
        filename = os.path.basename(file)    
        print("*HTML* <a href={}>{}</a>".format(file,filename))    
                
    def verify_g5r_node_is_up(self, node, username = 'root', password = 'itron'):
        """This checks if ``node`` is up and is being accessed.
        It fails if any exception occurs.
        Default username is ``root`` and default password is ``itron``. But new values can be provided.
        
        Note: It does not require any prior connection establishment, it establishes connection itself.
        """
        node_ = G5RNode(node, username, password, self._logger())
        if(not node_.is_up()):
            self._logger().info("node '{}' is not up".format(node))
            raise Exception("node '{}' is not up".format(node))
    
    def wait_until_node_is_up(self, node, retry = 300, interval = 60, username = 'root', password = 'itron'):
        """This checks for ``retry`` seconds with the interval of ``interval`` seconds after each retry that if ``node`` is up and is being accessed.
        It passes if ``node``is up and exits. It fails if ``node`` is not up after the ``retry`` seconds.
        
        Default ``retry`` is ``300`` seconds and default ``interval`` is ``60`` seconds.
        
        Default username is ``root`` and default password is ``itron``. But new values can be provided.
        
        Example:
        
        | = Keyword =             | = node =      | = retry = | = interval = | = comment =                                                                 |
        | `Wait Until Node Is Up` | 10.21.100.235 | retry=600 | interval=90  | # at every 90 seconds for 600 seconds, check for node to be  up will happen |
        | `Wait Until Node Is Up` | 10.21.100.235 |           |              | # at every 60 seconds for 300 seconds, check for node to be up will happen  |
        
        Note: It does not require any prior connection establishment, it establishes connection itself.
    
        """
        starttime = time.time()
        self._logger().info(starttime)
        node_ = G5RNode(node, username, password, self._logger())
        self._logger().info(node_)
        try:
            retry = int(retry)
        except ValueError:
            self._logger().exception("'retry' must be either integer or string-convertible-to-integer")
            raise Exception("'retry' must be either integer or string-convertible-to-integer")

        try:
            interval = int(interval)
        except ValueError:
            self._logger().exception("'interval' must be either integer or string-convertible-to-integer")
            raise Exception("'interval' must be either integer or string-convertible-to-integer")
        
        timepassed = 0
        while(not node_.is_up() and timepassed < retry):
            time.sleep(interval-1)
            try:
                node_.restart_session()
            except Exception:
                pass
            timepassed = time.time()-starttime
        
        if(timepassed > retry):
            self._logger().exception("node '{}' is not up".format(node))
            raise Exception("node '{}' is not up".format(node))
            

    def upgrade_g5r(self, 
                    node, 
                    coldstart_file, 
                    copy_coldstart_file_to,
                    converter_file, 
                    copy_converter_file_to,
                    wait_after_coldstart_install = '500:30', 
                    improvhelper_waittime = 120,
                    rerun = 1,
                    username = 'root', 
                    password = 'itron',skip_gmr=False):
        
        """This upgrades the Gen5Riva node.
        
        ``coldstart_file`` is the path to the coldstart package file in the local machine.
        
        ``copy_coldstart_file_to`` is the directory on the node ``node`` where the ``coldstart_file`` has to be copied.
        
        ``converter_file`` is the path to the file in local machine which will be used to convert the Riva nodes to Gen5 Riva nodes. 
        
        ``copy_converter_file_to`` is the directory on the node ``node`` where the ``converter_file`` has to be copied.
        
        ``wait_after_coldstart_install`` must be in the format ``retry:interval`` .
        Keyword checks for ``retry`` seconds with the interval of ``interval`` seconds after each retry that if ``node`` is up and is being accessed.
        It passes if ``node``is up. It fails if ``node`` is not up after the ``retry`` seconds.
        
        `wait_after_coldstart_install`` is new in version 0.4.
        
        ``improvhelper_waittime`` can be given to wait after the "ImPorvHelper.sh" command is initiated. By default it is ``120`` seconds.
        
        ``skip_gmr`` is set to False by default. This can be set to True.
        
        To run the keyword again if it fails use ``rerun``, by default ``rerun`` is 1.
        
        Example:
        
        | = keyword =       | = nodes =      |  = coldstart_file = | = copy_coldstart_file_to = |   = convereter_file = |\
         = copy_converter_file_to = | = wait_after_coldstart_install = | = improvhelper_waittime = | = rerun = | = username = | = password = |
        | `Upgrade G5R`     | 10.21.100.235  | ${build_file}       | /media/mmcblk0p1/          |   ${converter_file}   |\
         /media/mmcblk0p1           |     900:60                       |   180                     |  1        |  g5rroot     |    itron     |   
        | `Upgrade G5R`     | 10.21.100.235  | ${build_file}       | /media/mmcblk0p1/          |   ${converter_file}   |\
         /media/mmcblk0p1           |     300:60                       |    120                    |  2        | g5rroot      |    itron     |   
        
        Note: It does not require any prior connection establishment, it establishes connection itself.
        
        """
        if(os.name=='nt'):
            skip_gmr=skip_gmr
        else:
            skip_gmr = os.environ.get('KAIZENBOT_G5R_SKIP_GMR')
        self._logger().info("Skip GMR status: {}".format(skip_gmr))
        self._logger().info("Upgrading Node: {}".format(node))
        BuiltIn().log_to_console("Upgrading Node: {}".format(node))
        try:
            run = int(rerun) + 1
        except ValueError:
            self._logger().exception("rerun must be either integer or string-convertible-to-integer")
            raise ValueError("rerun must be either integer or string-convertible-to-integer")
        
        FAIL = True
        run_index = 1
        node_ = G5RNode(node, username, password)
   
        while(FAIL and run):
            self._logger().info("RUN: %s" % str(run_index))
            BuiltIn().log_to_console("RUN: %s" % str(run_index))
            try:
                node_.upgrade_g5r(coldstart_file, copy_coldstart_file_to, converter_file, copy_converter_file_to, str(wait_after_coldstart_install), improvhelper_waittime,skip_gmr)
            except Exception as e:
                msg = str(e)
                self._logger().info("FAIL: %s" %msg)
                BuiltIn().log_to_console("FAIL: %s" %msg)
                self._logger().exception(e)
            else:
                FAIL = False
            finally:
                run -= 1
                run_index += 1
                
        if FAIL:
            self._logger().debug(msg)
            raise Exception("LAST RUN: %s" %msg)
            
    def _upgrade_all_g5r(self, 
                        nodes, 
                        coldstart_file, 
                        copy_coldstart_file_to, 
                        converter_file,
                        copy_converter_file_to,
                        wait_after_coldstart_install = '900:0:0',
                        improvhelper_waittime = 120,
                        usernames = 'all_default', 
                        passwords = 'all_default'):
        
        """This upgrades all nodes ``nodes``. 
        
        ``coldstart_file`` is the path to the coldstart package file in the local machine.
        
        ``copy_coldstart_file_to`` is the directory on the node ``node`` where the ``coldstart file`` has to be copied.
        
        ``converter_file`` is the path to the file in local machine which will be used to convert the Riva nodes to Gen5 Riva nodes. 
        
        ``copy_converter_file_to`` is the directory on the node ``node`` where the ``converter_file`` has to be copied.
        
        ``wait_after_coldstart_install`` must be in the format ``initial_wait:retry:interval`` 
        where ``initial_wait`` is fixed wait after coldstart package install and ``retry`` is additional wait time. 
        Keyword checks for ``retry`` seconds with the interval of ``interval`` seconds after each retry that if ``node`` is up and is being accessed.
        It passes if ``node``is up. It fails if ``node`` is not up after the ``retry`` seconds. 
        
        ``wait_after_coldstart_install`` is new in version 0.4. 
             
        ``improvhelper_waittime`` can be given to wait after the "ImPorvHelper.sh" command is initiated. By default it is ``120`` seconds.
        
        ``all_default`` uses ``root`` as username and ``itron`` as password for all the nodes ``nodes``.
        
        Example:
        
        | = keyword =       | = nodes =      | = coldstart_file = | = copy_coldstart_file_to = | \
        = convereter_file = | = copy_converter_file_to = | = wait_after_coldstart_install = | = improvhelper_waittime = | = usernames =        |     = passwords = |
        | `Upgrade All G5R` | [node1, node2] | ${build_file}      | /media/mmcblk0p1/          | \
        {converter_file}    | /media/mmcblk0p1           |  900:600:60 |  60                  |                      |                   |
        | `Upgrade All G5R` | [node1, node2] | ${build_file}      | /media/mmcblk0p1/          | \
        {converter_file}    | /media/mmcblk0p1           |            |             | [root, genxroot] | [root, itron] |
        
        ``nodes``, ``usernames`` and ``passwords`` can be provided either as list i.e. [a,b,c] or comma separated values i.e. a,b,c
        In this case, length of all must be same.
        """
                    
        message = ''
        nodes = self._to_str_list(nodes)
            
        if(usernames == 'all_default'):
            usernames = ['root']*len(nodes)
        if(passwords == 'all_default'):
            passwords = ['itron']*len(nodes)
            
        usernames = self._to_str_list(usernames)
        passwords = self._to_str_list(passwords)    
        
        try:
            assert len(nodes) == len(usernames) == len(passwords)
        except AssertionError:
            self._logger().exception("Must be equal: length of nodes({}) == length of usernames({}) == length of passwords({})".format(len(nodes), len(usernames), len(passwords)))
            raise Exception("Must be equal: length of nodes({}) == length of usernames({}) == length of passwords({})".format(len(nodes), len(usernames), len(passwords)))
        
        for index, node in enumerate(nodes):
            try:
                node_ = G5RNode(node, usernames[index], passwords[index])
                self._logger().info(node+'|'+usernames[index]+'|'+passwords[index])
                node_.upgrade_g5r(coldstart_file, copy_coldstart_file_to, converter_file, copy_converter_file_to, str(wait_after_coldstart_install), improvhelper_waittime)
            except Exception as e:
                message += '\nwhile upgrading node {} ...'.format(node) + '\n'
                message += str(e)
                
        if(message != ''):
            self._logger().debug(message)
            raise Exception(message)


    def _to_str_list(self,string, sep = ','):
        """This converts str, int,list of ints, string-like-list of ints and string-like-list of strs to list of strs.
        1 --> ['1'] #int
        '1' --> ['1']    #str
        "1,2,3" --> ['1','2','3']    #str
        [1,2,3] --> ['1','2','3']    #list of ints
        ['1','2','3'] --> ['1','2','3']    # list of strs
        "[1,2,3]" --> ['1','2','3']    #string-like-list of ints
        "['1','2','3']" --> ['1','2','3']    #string-like-list of strs
        
        It also handles extra separators ``sep``.
        ",1,2,,3," --> ['1','2','3']
        """
        if isinstance(string, (str,int)):
            string = str(string)
            string = string.replace(' ', '')
            string = string.replace('[', '')
            string = string.replace(']', '')
            string = string.replace("'", '')   # string = string.replace('\'', '')
            string = string.replace('"','')
            string = string.split(sep)
            while('' in string):
                string.remove('')
                
        elif isinstance(string, list):
            tmp = []
            for each_str in string:
                tmp.append(str(each_str))
            string = tmp
            
        else:
            raise TypeError
        
        return string
        
