# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""

from .nodelibrary import NodeLibrary
from .beaconlibrary import BeaconLibrary
from .eventlibrary import EventLibrary
from kaizenbot.connection import Connection
from .version import VERSION
from .tsharklibrary import TSharkLibrary
from .fwupgradelibrary import FWUpgradeLibrary
from .g5rfwflash import G5RFWFlash
from .utils import Utils
from .netmanagerlibrary import NetManagerLibrary
from kaizenbot.azurelibrary import AzureLibrary
from .dnslibrary import DNSLibrary
from .timespectrumlibrary import TimeSpectrumLibrary
import sys
from robot.libraries.BuiltIn import BuiltIn
from kaizenbot.logging_robot import Loggers
from .security import Security
from .trapslibrary import TrapsLibrary
from .elglibrary import ELGLibrary


class Gen5RivaLibrary(BeaconLibrary, NodeLibrary, EventLibrary, Connection, TSharkLibrary, FWUpgradeLibrary, Utils,
                      AzureLibrary, NetManagerLibrary, DNSLibrary, Security, G5RFWFlash, TimeSpectrumLibrary,
                      TrapsLibrary, ELGLibrary):
    """Gen5RivaLibrary is a Robot Framework test library for gen5riva meters.
    
    This document explains how to use keywords provided by Gen5RivaLibrary.
    For information about installation, support, and more please visit the
    [https://itron.sharepoint.com/:t:/s/GFW-IVV/EfEir5666s5PvJTMPrPLJigBCRlSmMGIJncnmsxuob8zBA?e=x0mGlZ|README]
    
    For more information about Robot Framework, see http://robotframework.org.
    
    The library has the following main usages:
    - Executing commands on the gen5 riva meters (see `Execute Command`).
    - Validating different parameters from pcap file (see `Validating from Pcap`).
    - Upgrading firmware and running sanity on the gen5 riva meters. (see `Firmware Upgrade`)
    
    == Table of contents ==
    - `Net Manager Path`
    - `Logger Name`
    - `Connections`
    - `Executing commands`
    - `Validating from Pcap`
    - `Firmware Upgrade`
    - `Importing`
    - `Example`
    - `Shortcuts`
    - `Keywords`
    
    = Net Manager Path =
    In order to execute any command on waseca server, Gen5RivaLibrary requires
    net manager path where command will be executed.
    User need to provide net manager path in test suite then it will take specified 
    path else it will set the path to `/home/waseca/net_mgr` or /home/waseca/net_mgrS
    based on security settings and for `fsu` path will be set to '/usr/bin/net_mgr'
    
    In robot file, user need to provide net manager path as mentioned below:
    `*** Variables ***`
    ${NET_MGR}    /home/waseca/net_mgr
    ${NET_MGR_SECURE}    /home/waseca/net_mgrS
    ${FSU_NET_MGR}    /usr/bin/net_mgr
    
    = Logger Name =
    For generating tracelogs for all run, Gen5RivaLibrary requires
    name of project to display in the logging of tracelogs.
    User need to provide logger name in test suite then it will take specified 
    name else it will set the name to `Gen5RivaLibrary`
    
    In robot file, user need to provide net manager path as mentioned below:
    `*** Variables ***`
    ${PROJECT_NAME}    Gen5RivaLibrary
    
    = Connections =
    
    In order to execute any command on gen5 riva meters, Gen5RivaLibrary requires 
    a connection to the server where net mgr is hosted. see `Connect To Server`
    
    In order to start validating from pcap file, Gen5RivaLibrary requires a 
    connection to the server/PC where pcap file is stored. Gen5RivaLibrary 
    also requires wireshark with inbuilt tshark to be installed on the server.
    See `Validating from Pcap`.
    
    Only one connection can be active at a time. This means that most of the
    keywords only affect the active connection. Active connection can be
    changed with `Switch Connection`.
    
    = Executing commands =
    
    For executing commands on the server, Keyword `Execute Command` can be used.
    The command is executed in a new shell on the server,
    which means that possible changes to the environment
    (e.g. changing working directory, setting environment variables, etc.)
    are not visible to the subsequent keywords.
    
    = Validating from Pcap =
    This section gives brief information on how to validate data from Pcap file.
    
    == Setting Pcap File ==
    For validating data from pcap files, Gen5RivaLibrary requires a 
    connection to the server/PC where pcap file is stored.
    The path for pcap file can be set in either Test suite or Variables file.
    e.g. for pcap file
    ${pacp_file} = \\\\Users\\\\username\\\\Pcap Files\\\\abcd.pcap -> if pcap file is in Windows machine (add double backslash)
    ${pacp_file} = //home//username//Pcap Files//abcd.pcap -> if pcap file is in Linux machine
    
    pcap file can be provided to Test suites in two ways. 
            Way1: Set pcap file while importing library 
            Way2: call keyword `set pcap file` with pcap_file
            If pcap file is not provided it will raise an exception
    
    == Frame Format Verification == 
    For validating frame format related scenarios i.e. getting frame counts, getting frames or 
    saving frames data in csv using pcap file, we can use Unique frames filter for each Unique 
    frame set by `Set Unique Frame` keyword or user can create filters and execute same to get
    frames and frame count.
    
    === Creating Filters ===
    There are a number of keywords which can be used to create filters.
    One of the keyword is `Create Filter` which can be used to create filter which will be used to perform frame
    format verification scenarios.
    
        |     =Keyword=   |                 =where=            |                =output=             |
        | `Create Filter` | a is 1 AND NOT (b <= 3 OR c is 5)  | (a == 1) && !((b <= 2) || (c == 5)) |
        | `Create Filter` | a is less than 5                   | (a < 5)                             | 
        | `Create Filter` | a.b.c == 5                         | (a.b.c == 5)                        | 
        | `Create Filter` | a.b.c                              | (a.b.c)                             | 
    
    === Operator Details ===
    `Create Filter` keyword supports various conditional operators and its english equivalent which 
    are mentioned below.
        operators : [==, _<=_, >=, !=, <, >] and these are used to create filters
        | =Operator= |      =English Equivalent=   |  
        |    _==_    | is                          |
        |    _<=_    | is less than or equal to    |
        |    _>=_    | is greater than or equal to |
        |    _<_     | is less than                |
        |    _>_     | is greater than             |
        |    _!=_    | is not                      |
     
    === Unique Frames ===
    Unique frames data and count can be obtained by running base frame filter for Unique frame set by
    `Set Unique Frame` method. Please find details of base frame filter for each frame in provided
    link [https://itron.sharepoint.com/:u:/s/GFW-IVV/ESoCg3J_YAJAmdk_2yLzT0wBOFAIIalRS4qBH_xPpmbMuw?e=Zede4e|Unique Frames]
    
    = Firmware Upgrade =
    Keyword `Upgrade G5R` can be used to upgrade Gen5Riva node.
    
    = Example =
    
    | ***** Settings *****
    | Documentation          This example demonstrates executing commands on gen5 riva meters
    | ...                    and getting their output.
    | ...
    | ...                    Notice how connections are handled as part of the suite setup and
    | ...                    teardown. This saves some time when executing several test cases.
    |
    | Library                Gen5RivaLibrary    
    | Suite Setup            Connect To Waseca Server
    | Suite Teardown         `Close Connection To Server`
    |
    | ***** Variables *****
    | ${SERVER}              10.57.202.2
    | ${USERNAME}            waseca
    | ${PASSWORD}            23Silver$
    |
    | ***** Test Cases *****
    | Execute Command And Verify Output
    |     [Documentation]    Execute Command can be used to run commands on the gen5 riva meters.
    |     ...                The keyword returns the standard output.
    |     ${output}=         `Execute Command`  net_mgr -d FD04:7C3E:BE2F:1004:213:5007:0000:0a26 evstatus [240]:on
    |     `Should Contain`    ${output}        Ok
    |
    |
    | ***** Keywords *****
    | Connect To Waseca Server
    |    `Connect To Server`    ${SERVER}    ${USERNAME}    ${PASSWORD}

    Save the content as file ``first.robot`` and run:
    ``robot first.robot``
    
    """

    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    ROBOT_LIBRARY_VERSION = VERSION

    def __init__(self, node=None, pcap_file=None, pat=None):
        """Gen5RivaLibrary allows import time node configuration.
        
        | Library | Gen5RivaLibrary | FD04:7C3E:BE2F:1004:213:5007:0000:0a26  |  \\Users\\TEST\\Desktop\\Automation_Gen5Riva\\abcd.pcap
        
        Argument ``node`` can be provided as variable also. 
        Argument ``pcap_file`` can be provided as variable also.
        
        In such case, either ``node`` value or ``pcap_file`` or both value should be provided as  
        [https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#setting-variables-in-command-line|individual variable in command line argument]
        or ``node`` value or ``pcap_file`` value or both can be put inside a variable file and 
        [https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#taking-variable-files-into-use|variablefile should be provided in command line argument]
        
        | Library | Gen5RivaLibrary | ${NIC} | ${pcap_file}

        
        If the library is imported without ``node`` argument, ``node`` argument
        must be provided with the keyword if the keyword needs to be run on any node.
        
        """
        self.logger = None
        TSharkLibrary.__init__(self, pcap_file)
        NodeLibrary.__init__(self, node)
        AzureLibrary.__init__(self, pat)
        super(Gen5RivaLibrary, self).__init__()

    def get_current_node(self):
        """
        This keyword returns the current node.
        """
        return self.current_node

    def _net_mgr(self):
        try:
            net_mgr_cmd = BuiltIn().get_variable_value('${NET_MGR}')
            net_mgr_secure_cmd = BuiltIn().get_variable_value('${NET_MGR_SECURE}')
            net_mgr_fsu_cmd = BuiltIn().get_variable_value('${FSU_NET_MGR}')
            if not net_mgr_cmd or not net_mgr_secure_cmd:
                raise Exception
        except Exception:
            net_mgr_secure_cmd = '/home/waseca/net_mgrS'
            net_mgr_cmd = '/home/waseca/net_mgr'
            net_mgr_fsu_cmd = '/usr/bin/net_mgr'
        return net_mgr_cmd, net_mgr_secure_cmd, net_mgr_fsu_cmd

    def _logging_name(self):
        try:
            kzbot_str = 'KaizenBot'
            project_str = BuiltIn().get_variable_value('${PROJECT_NAME}')
            if not project_str:
                raise Exception
        except Exception:
            kzbot_str = 'KaizenBot'
            project_str = "Gen5RivaLibrary"
        return kzbot_str, project_str

    def _logger(self):
        if self.logger is None:
            log_obj = Loggers()
            self.logger = log_obj.get_logger(self._logging_name()[0] + '-' + self._logging_name()[1])
            return self.logger
        else:
            return self.logger
