# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from kaizenbot.logging_robot import Loggers
import os
from kaizenbot.connection import Connection
import csv, re
from pathlib import Path
from time import gmtime, strftime, localtime
from .nodelibrary import NodeLibrary
from itertools import groupby
from kaizenbot.exceptions import NotATableError, NotADictionaryError

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "Logs")
else:
    DestDir = os.environ.get('KAIZENBOT_G5R_INTERNAL_LOGDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))

nodelib = NodeLibrary()

class NetManagerLibrary:
    
    def __init__(self):
        pass
    
    def get_current_node(self):
        pass
    
    def _net_mgr(self):
        raise NotImplementedError
    
    def _logger(self):
        raise NotImplementedError
    
    def get_phy_transmit_power(self, node=None, secure_run = True):
        """This keyword gets the phy transmit power setting of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``PHY transmit power setting`` on success.
        
        = Examples =
        |          =Keyword=        |     =Node=     |                  =Comment=                        |
        | `Get PHY Transmit Power`  | 0001:0045:0a26 | This will get PHY transmit power for given Node   |
        | `Get PHY Transmit Power`  |                | This will get PHY transmit power for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf phy phy_tx_pwr'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting PHY transmit Power")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=PHY transmit power setting is set to )\d+', output)
            if(match):
                PhyTxPower = match.group(0)
                self._logger().debug("Phy transmit power: {}".format(PhyTxPower))
            else:
                self._logger().info(output)
                self._logger().debug("Exception occurred while getting PHY transmit power: {}".format(output))
                raise Exception("Exception occurred while getting PHY transmit power: {}".format(output))
        return PhyTxPower
    
    def set_phy_transmit_power(self, phytxpower, node = None, secure_run = True):
        """This keyword sets the phy transmit power setting of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |          =Keyword=        | =Phy Tx Power= |  =NodeIP=      |                           =Comment=                        |
        | `Set PHY Transmit Power`  |       20       | 0013:0000:0034 | This will set provided phy transmit power for given Node   |
        | `Set PHY Transmit Power`  |       30       |                | This will set provided phy transmit power for default Node |
        
        Range for Phy Tx Power is 10-30.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            PhyTxPower = int(phytxpower)
        except ValueError:
            self._logger().exception("phy transmit power must be either integer or string-convertible-to-integer")
            raise Exception("phy transmit power must be either integer or string-convertible-to-integer")
         
        if (not (PhyTxPower >= 10 and PhyTxPower <= 30) ):
            self._logger().debug("Invalid Phy Tx Power. Phy Tx Power must be 10 <= PhyTxPower <= 30")
            raise Exception("Invalid Phy Tx Power. Phy Tx Power must be 10 <= PhyTxPower <= 30") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Phy Transmit Power")
            command = net_mgr_and_node + ' conf phy phy_tx_pwr ' + str(PhyTxPower)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception:
            self._logger().exception("Setting Phy Transmit Power failed: {}".format(output))
            raise Exception("Setting Phy Transmit Power failed: {}".format(output))
        return output
    
    def get_mac_fragmentation_size(self, node=None, secure_run = True):
        """This keyword gets the mac fragmentation size of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``mac fragmentation size in bytes`` on success.
        
        = Examples =
        |             =Keyword=         |    =NodeIP=    |                        =Comment=                      |
        | `Get Mac Fragmentation Size`  | 0001:0045:0a26 | This will get Mac fragmentation size for given Node   |
        | `Get Mac Fragmentation Size`  |                | This will get Mac fragmentation size for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mac mac_fragsize'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Mac fragmentation size")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MAC fragment size is set to )\d+', output)
            if(match):
                MacFragSize = match.group(0)
                self._logger().debug('Mac Frag Size: {}'.format(MacFragSize))
            else:
                self._logger().info(output)
                self._logger().debug("Exception occurred while getting Mac fragmentation size: {}".format(output))
                raise Exception("Exception occurred while getting Mac fragmentation size: {}".format(output))
        return MacFragSize
    
    def set_mac_fragmentation_size(self, macfragsize, node = None, secure_run = True):
        """This keyword sets the mac fragmentation size of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |             =Keyword=         | =Mac Frag Size= |  =NodeIP=      |                             =Comment=                          |
        | `Set Mac Fragmentation Size`  |       258       | 0013:0000:0034 | This will set provided mac fragmentation size for given Node   |
        | `Set Mac Fragmentation Size`  |       300       |                | This will set provided mac fragmentation size for default Node |
        
        Range for Mac Frag Size is 128-2048.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            MacFragSize = int(macfragsize)
        except ValueError:
            self._logger().exception("mac fragmentation size must be either integer or string-convertible-to-integer")
            raise Exception("mac fragmentation size must be either integer or string-convertible-to-integer")
         
        if (not (MacFragSize >= 128 and MacFragSize <= 2048) ): 
            self._logger().debug("Invalid Mac Fragmentation Size. Mac Fragmentation Size must be 128 <= MacFragSize <= 2048")
            raise Exception("Invalid Mac Fragmentation Size. Mac Fragmentation Size must be 128 <= MacFragSize <= 2048") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Mac Fragmentation Size")
            command = net_mgr_and_node + ' conf mac mac_fragsize ' + str(MacFragSize)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception:
            self._logger().exception("Setting Mac Fragmentation Size failed: {}".format(output))
            raise Exception("Setting Mac Fragmentation Size failed: {}".format(output))
        return output
    
    def get_route_holddown_time(self, node=None, secure_run = True):
        """This keyword gets the route holddown time of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``route holddown time in secs`` on success.
        
        = Examples =
        |           =Keyword=        |    =NodeIP=    |                      =Comment=                     |
        | `Get Route Holddown Time`  | 0001:0045:0a26 | This will get route holddown time for given Node   |
        | `Get Route Holddown Time`  |                | This will get route holddown time for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf srt holddown_time'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting route holddown time")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Route Hold Down Time is set to )\d+', output)
            if(match):
                RouteAdvRate = match.group(0)
                self._logger().debug('Route Holddown Time: {}'.format(RouteAdvRate))
            else:
                self._logger().info(output)
                self._logger().debug("Exception occurred while getting route holddown time: {}".format(output))
                raise Exception("Exception occurred while getting route holddown time: {}".format(output))
        return RouteAdvRate
    
    def set_route_holddown_time(self, holddown_time, node = None, secure_run = True):
        """This keyword sets the route hold down time of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |             =Keyword=      | =Holddown Time=  |  =NodeIP=      |                          =Comment=                          |
        | `Set Route Holddown Time`  |       258        | 0013:0000:0034 | This will set provided route holddown time for given Node   |
        | `Set Route Holddown Time`  |       300        |                | This will set provided route holddown time for default Node |
        
        Range for Holddown Time is 0-1800.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            HoldDownTime = int(holddown_time)
        except ValueError:
            self._logger().exception("route holddown time must be either integer or string-convertible-to-integer")
            raise Exception("route holddown time must be either integer or string-convertible-to-integer")
         
        if (not (HoldDownTime >= 0 and HoldDownTime <= 1800) ):
            self._logger().debug("Invalid Route Holddown Time. Holddown Time must be 0 <= RouteAdvRate <= 1800")
            raise Exception("Invalid Route Holddown Time. Holddown Time must be 0 <= RouteAdvRate <= 1800") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Route Holddown Time")
            command = net_mgr_and_node + ' conf srt holddown_time ' + str(HoldDownTime)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception:
            self._logger().exception("Setting Route Holddown Time failed: {}".format(output))
            raise Exception("Setting Route Holddown Time failed: {}".format(output))
        return output
    
    def get_dli_time_to_live(self, node=None, secure_run = True):
        """This keyword gets the dli time to live of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``dli time to live in hops`` on success.
        
        = Examples =
        |          =Keyword=      |    =NodeIP=    |                    =Comment=                    |
        | `Get Dli Time To Live`  | 0001:0045:0a26 | This will get dli time to live for given Node   |
        | `Get Dli Time To Live`  |                | This will get dli time to live for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf dli ttl'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting dli time to live")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Default DLI TTL is set to )\d+', output)
            if(match):
                DliTTL = match.group(0)
                self._logger().debug('Dli time to live: {}'.format(DliTTL))
            else:
                self._logger().debug("Exception occurred while getting dli time to live: {}".format(output))
                raise Exception("Exception occurred while getting dli time to live: {}".format(output))
        return DliTTL
    
    def set_dli_time_to_live(self, dli_ttl, node = None, secure_run = True):
        """This keyword sets the dli time to live of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |          =Keyword=      | =DLI TTL= |  =NodeIP=      |                        =Comment=                         |
        | `Set dli time to live`  |   20      | 0013:0000:0034 | This will set provided dli time to live for given Node   |
        | `Set dli time to live`  |   16      |                | This will set provided dli time to live for default Node |
        
        Range for DLI TTL is 1-63.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            DliTtl = int(dli_ttl)
        except ValueError:
            self._logger().exception("dli time to live must be either integer or string-convertible-to-integer")
            raise Exception("dli time to live must be either integer or string-convertible-to-integer")
         
        if (not (DliTtl >= 1 and DliTtl <= 63) ):
            self._logger().debug("Invalid Dli Time To Live. Dli Time To Live must be 1 <= DliTtl <= 63")
            raise Exception("Invalid Dli Time To Live. Dli Time To Live must be 1 <= DliTtl <= 63") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Dli Time To Live")
            command = net_mgr_and_node + ' conf dli ttl ' + str(DliTtl)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception:
            self._logger().exception("Setting Dli Time To Live failed: {}".format(output))
            raise Exception("Setting Dli Time To Live failed: {}".format(output))
        return output
    
    def get_mlme_keep_pkt_period(self, node=None, secure_run = True):
        """This keyword gets the mlme keep packet period of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``mlme keep packet period in seconds`` on success.
        
        = Examples =
        |              =Keyword=         |    =NodeIP=    |                        =Comment=                       |
        | `Get Mlme Keep Packet Period`  | 0001:0045:0a26 | This will get Mlme Keep Packet Period for given Node   |
        | `Get Mlme Keep Packet Period`  |                | This will get Mlme Keep Packet Period for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme mlme_keep_pkt_period'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Mlme Keep Packet Period")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Period that keep pkts are sent out is set to )\d+', output)
            if(match):
                Mlme_keep_pkt_period = match.group(0)
                self._logger().debug('Mlme Keep Packet Period: {}'.format(Mlme_keep_pkt_period))
            else:
                self._logger().debug("Exception occurred while getting Mlme Keep Packet Period: {}".format(output))
                raise Exception("Exception occurred while getting Mlme Keep Packet Period: {}".format(output))
        return Mlme_keep_pkt_period
    
    def set_mlme_keep_pkt_period(self, mlme_keep_period, node = None, secure_run = True):
        """This keyword sets the Mlme Keep Packet Period of provided node
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |             =Keyword=          | =Mlme Keep Period= |  =NodeIP=      |                            =Comment=                            |
        | `Set Mlme Keep Packet Period`  |   20               | 0013:0000:0034 | This will set provided Mlme Keep Packet Period for given Node   |
        | `Set Mlme Keep Packet Period`  |   16               |                | This will set provided Mlme Keep Packet Period for default Node |
        
        Range for Mlme Keep Period is 10-43200.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            MlmeKeepPeriod = int(mlme_keep_period)
        except ValueError:
            self._logger().exception("Mlme Keep Packet Period must be either integer or string-convertible-to-integer")
            raise Exception("Mlme Keep Packet Period must be either integer or string-convertible-to-integer")
         
        if (not (MlmeKeepPeriod >= 10 and MlmeKeepPeriod <= 43200) ):
            self._logger().debug("Invalid Mlme Keep Packet Period. Mlme Keep Packet Period must be 10 <= DliTtl <= 43200")
            raise Exception("Invalid Mlme Keep Packet Period. Mlme Keep Packet Period must be 10 <= DliTtl <= 43200") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Mlme Keep Packet Period")
            command = net_mgr_and_node + ' conf mlme mlme_keep_pkt_period ' + str(MlmeKeepPeriod)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception:
            self._logger().exception("Setting Mlme Keep Packet Period failed: {}".format(output))
            raise Exception("Setting Mlme Keep Packet Period failed: {}".format(output))
        return output
    
    def get_missed_beacon_count(self, node=None, secure_run = True):
        """This keyword gets the missed beacon count of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Missed Beacon Count`` on success.
        
        = Examples =
        |           =Keyword=        |    =NodeIP=    |                   =Comment=                        |
        | `Get Missed Beacon Count`  | 0001:0045:0a26 | This will get Missed Beacon Count for given Node   |
        | `Get Missed Beacon Count`  |                | This will get Missed Beacon Count for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            command = net_mgr_and_node + ' conf mlme mlme_max_missed_beacons'
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Missed Beacon Count")
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME maximum # of consecutively missed beacons is set to )\d+', output)
            if(match):
                BeaconCount = match.group(0)
                self._logger().debug("Missed beacon count: {}".format(BeaconCount))
            else:
                self._logger().debug("Exception occurred while getting Missed Beacon Count: {}".format(output))
                raise Exception("Exception occurred while getting Missed Beacon Count: {}".format(output))
        return BeaconCount
    
    def set_missed_beacon_count(self, beaconcount, node = None, secure_run = True):
        """This keyword sets the missed beacon count of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |           =Keyword=        | =beaconcount= |  =NodeIP=      |                            =Comment=                        |
        | `Set Missed Beacon Count`  |       20      | 0013:0000:0034 | This will set provided Missed Beacon Count for given Node   |
        | `Set Missed Beacon Count`  |       30      |                | This will set provided Missed Beacon Count for default Node |
        
        Range for beaconcount is 6-15.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            BeaconCount = int(beaconcount)
        except ValueError:
            self._logger().exception("Missed Beacon Count must be either integer or string-convertible-to-integer")
            raise Exception("Missed Beacon Count must be either integer or string-convertible-to-integer")
         
        if (not (BeaconCount >= 6 and BeaconCount <= 15) ):
            self._logger().debug("Invalid Missed Beacon Count. Missed Beacon Count must be 6 <= BeaconCount <= 15")
            raise Exception("Invalid Missed Beacon Count. Missed Beacon Count must be 6 <= BeaconCount <= 15") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
            self._logger().info("Setting Missed Beacon Count")
            command = net_mgr_and_node + ' conf mlme mlme_max_missed_beacons ' + str(BeaconCount)
            output = Connection.execute_command(self, command)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info(output)
        except Exception:
            self._logger().exception("Setting Missed Beacon Count failed: {}".format(output))
            raise Exception("Setting Missed Beacon Count failed: {}".format(output))
        return output
    
    def verify_beacon_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the beacon statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=        | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Beacon Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Beacon Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Beacon Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Beacon Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            
        try:
            self._logger().info("Getting Beacon Statistics data from net manager")
            command = net_mgr_and_node + ' stat beacon' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='Beacon Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
    
    def verify_mlme_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the mlme statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=      | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Mlme Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Mlme Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Mlme Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Mlme Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting MLME statistics data from net manager")
            command = net_mgr_and_node + ' stat mlme' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='MLME statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
        
    def verify_mac_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the Mac statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=     | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Mac Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Mac Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Mac Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Mac Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting MAC Statistics data from net manager")
            command = net_mgr_and_node + ' stat mac' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='MAC Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
        
    def verify_route_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the Route statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |            =Keyword=      | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Route Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Route Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Route Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Route Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting SSN Layer 2 Routing Statistics data from net manager")
            command = net_mgr_and_node + ' stat srt' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='SSN Layer 2 Routing Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
        
    def verify_dli_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the DLI statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=     | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify DLI Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify DLI Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify DLI Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify DLI Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting DLI Statistics data from net manager")
            command = net_mgr_and_node + ' stat dli' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='DLI Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
        
    def verify_time_sync_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the Time Sync statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |              =Keyword=        | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Time Sync Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Time Sync Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Time Sync Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Time Sync Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting Time Sync Statistics data from net manager")
            command = net_mgr_and_node + ' stat timesync' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='Time Sync Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
    
    def verify_dns_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the DNS statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=     | =Only Header= |                  =Filter=                |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify DNS Statistics` |    False      | filter=No Buffers AND Unknown RX Packets | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify DNS Statistics` |    True       | filter=No Buffers                        | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify DNS Statistics` |    True       |                                          | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify DNS Statistics` |    False      |                                          |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting DNS Statistics data from net manager")
            command = net_mgr_and_node + ' stat dns' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='DNS Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
    
    def verify_mlme_sec_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the mlme_sec statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=          | =Only Header= |                  =Filter=                  |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Mlme Sec Statistics` |    False      | filter=Frames received AND Bytes received  | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Mlme Sec Statistics` |    True       | filter=Frames received                     | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Mlme Sec Statistics` |    True       |                                            | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Mlme Sec Statistics` |    False      |                                            |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Author: Varun Kaundinya
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting MLME Sec statistics data from net manager")
            command = net_mgr_and_node + ' stat mlme_sec' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='MLME Security Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
                

    def verify_mlme_lg_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the mlme_lg statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |           =Keyword=         | =Only Header= |                  =Filter=                  |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Mlme Lg Statistics` |    False      | filter=Frames received AND Bytes received  | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Mlme Lg Statistics` |    True       | filter=Frames received                     | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Mlme Lg Statistics` |    True       |                                            | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Mlme Lg Statistics` |    False      |                                            |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Author: Varun Kaundinya
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting MLME Lg statistics data from net manager")
            command = net_mgr_and_node + ' stat mlme_lg' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='MLME Lg Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
                

    def verify_ndxp_statistics(self, only_header=True, filter=None, node = None, ignore_case=False, secure_run = True):
        """This keyword verifies the ndxp statistics data of provided node
        
        This takes 3 optional arguments ``only_header``, ``node`` and ``filter``.
        
        ``only_header`` is set to ``True`` by default which will give output as stat data without numbers for each value
        
        ``filter`` is optional argument which takes data which need to be filtered while running
        dns statistics
        
        ``ignore_case`` is set to ``False`` by default and this can be set to ``True`` if we have to filter
        any data with ignoring the case.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``list of output data`` on success.

        = Examples =
        |          =Keyword=       | =Only Header= |                  =Filter=                  |  =NodeIP=      |  =ignore_case= |                                =Comment=                                  |
        | `Verify Ndxp Statistics` |    False      | filter=Frames received AND Bytes received  | 0013:0000:0034 |      True      | This will verify provided list of list for filtered data for given Node   |
        | `Verify Ndxp Statistics` |    True       | filter=Frames received                     | 0013:0000:0034 |     False      | This will verify provided list of filtered data for given Node            |
        | `Verify Ndxp Statistics` |    True       |                                            | 0013:0000:0034 |                | This will verify provided list of headers without number for given Node   |                                                                                                                                         
        | `Verify Ndxp Statistics` |    False      |                                            |                |                | This will verify provided list of list data with numbers for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        Author: Varun Kaundinya
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
       
        filter_cmd=''
        if(filter is not None):
            filter_strs = filter.split(' AND ')
            for filter_str in filter_strs:
                if (ignore_case == True):
                    filter_cmd += '| grep -iE ' + '"'+filter_str+'"'
                else:
                    filter_cmd += '| grep ' + '"'+filter_str+'"'
        
        if(secure_run):
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
        else:
            net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
        try:
            self._logger().info("Getting Ndxp statistics data from net manager")
            command = net_mgr_and_node + ' stat ndxp' + filter_cmd
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
        if output == '':
            self._logger().debug("No data received")
            self._logger().info(output)
            raise Exception("No data received")
        else:
            try:
                header='Node Data Exchange Protocol Statistics:'
                if(filter_cmd == ''): 
                    if(only_header==True):
                        number=False                                          
                        final_list= self._convert_stat_output_in_list(output, header, number)
                        self._logger().debug(final_list)
                        return final_list
                    else:
                        final_list= self._convert_stat_output_in_list(output, header)
                        self._logger().debug(final_list)
                        return final_list
                else:
                    final_list= self._convert_stat_output_in_list(output)
                    if(len(final_list)==1):
                        return final_list[0]
                    self._logger().debug(final_list)
                    return final_list
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
                

    def _convert_stat_output_in_list(self, output, header=None, number=True):
        """ This keyword converts the provided output in list by removing spaces and integers from each value.
        """
        
        # split into lines/rows
        output_ = output.split('\n')
        if header in output_:
            val= output_.index(header)
            self._logger().debug(val)
            output_=output_[val:] ##added to resolve bug-1951277
            #output_ = output_[1:] ## removed as part of bug-1951277
    
        # remove empty lines if any
        while('' in output_):
            output_.remove('')
        
        # remove spaces in a value
        tmp = []
        for line in output_:
            tmp.append(line.strip())
        
        if(number == False):
            #remove digit value from each value
            tmp1=[]
            for data in tmp:
                res= re.sub(r'^[\d.]+\s*', '', data)
                tmp1.append(res)
        
            #remove space added before each value in list
            final_list=[x.strip(' ') for x in tmp1]
            self._logger().debug(final_list)
        else:
            #remove space added before each value in list
            tmp1=[x.strip(' ') for x in tmp]
            new_list=[[i] for i in tmp1]
            final_list=[]
            for data in new_list:
                if(any(char.isdigit() for char in data[0])):
                    res = [''.join(j).strip() for sub in data for k, j in groupby(sub, str.isdigit)] 
                    if res== ['SSN Layer', '2', 'Routing Statistics:']:
                        res=[' '.join(res)]
                    final_list.append(res)
                else:
                    final_list.append(data)
        self._logger().debug(final_list)
        return final_list
    
    def show_configured_modes(self, node=None, secure_run = True):
        """This keyword shows the current and configured modes of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``configured modes data as dict`` on success.
        
        = Examples =
        |           =Keyword=      |    =NodeIP=    |                              =Comment=                           |
        | `Show Configured Modes`  | 0001:0045:0a26 | This will provide configured modes data in dict for given Node   |
        | `Show Configured Modes`  |                | This will provide configured modes data in dict for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Getting configured modes data from net manager")
            tablename='modeusage show'
            mode_data = NodeLibrary._get_table(self,node, tablename, secure_run)
            self._logger().info(mode_data)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        return mode_data
    
    def delete_configured_mode(self, modeid, node=None, secure_run = True):
        """This keyword deletes the `modeid` mode of provided node.
        
        This takes 1 mandatory argument ``modeid``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |           =Keyword=      | =ModeID= |    =NodeIP=    |                                    =Comment=                            |
        | `Delete Configured Mode` | 4        | 0001:0045:0a26 | This will delete provided mode id from configured node for given Node   |
        | `Delete Configured Mode` | 2        |                | This will delete provided mode id from configured node for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Deleting modeid {} from configured modes".format(modeid))
            command = net_mgr_and_node + ' modeusage delete mode:' + modeid
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Deleting ModeID {} from configured modes failed".format(modeid))
            raise Exception("Deleting ModeID {} from configured modes failed".format(modeid))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("ModeID '{}' is not deleted".format(modeid))
                self._logger().info(output)
                raise Exception("ModeID '{}' is not deleted".format(modeid))
            else:
                return 'Ok'
            
            
    def add_configured_mode(self, modeid, node=None, secure_run = True):
        """This keyword adds the `modeid` mode of provided node.
        
        This takes 1 mandatory argument ``modeid``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |        =Keyword=      | =ModeID= |    =NodeIP=    |                      =Comment=                  |
        | `Add Configured Mode` | 4        | 0001:0045:0a26 | This will add provided mode id for given Node   |
        | `Add Configured Mode` | 2        |                | This will add provided mode id for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Adding modeid {} from configured modes".format(modeid))
            command = net_mgr_and_node + ' modeusage add mode:' + modeid
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Adding ModeID {} from configured modes failed".format(modeid))
            raise Exception("Adding ModeID {} from configured modes failed".format(modeid))
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("ModeID '{}' is not Added".format(modeid))
                self._logger().info(output)
                raise Exception("ModeID '{}' is not Added".format(modeid))
            else:
                return 'Ok'
            
    def add_invalid_mode(self, modeid, node=None, secure_run = True):
        """This keyword verifies that error message displayed while 
        adding invalid `modeid` mode of provided node.
        
        This takes 1 mandatory argument ``modeid``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Erroneous request`` on success.
        
        = Examples =
        |        =Keyword=      | =ModeID= |    =NodeIP=    |                      =Comment=                  |
        | `Add Configured Mode` | 4        | 0001:0045:0a26 | This will add provided mode id for given Node   |
        | `Add Configured Mode` | 2        |                | This will add provided mode id for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        valid_mode_id=['1', '2', '3', '4','5','7','8', '9', '10', '11','18', '19', '21', '22', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36',
                       '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '58', '59', '60', '61']
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        if (modeid in valid_mode_id):
            self._logger().debug("Invalid mode ID is not provided by User. Please provide invalid mode id")
            raise Exception("Invalid mode ID is not provided by User. Please provide invalid mode id")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Adding modeid {} from configured modes".format(modeid))
            command = net_mgr_and_node + ' modeusage add mode:' + modeid
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Adding ModeID {} from configured modes failed".format(modeid))
            raise Exception("Adding ModeID {} from configured modes failed".format(modeid))
        else:
            if(output.find('Erroneous request') == -1):
                self._logger().debug("Issue while providing Invalid ModeID '{}'".format(modeid))
                self._logger().info(output)
                raise Exception("Issue while providing Invalid ModeID '{}'".format(modeid))
            else:
                self._logger().debug("Invalid ModeID '{}' provided".format(modeid))
                return 'Erroneous request'
        
    def get_phymode_information(self, node=None, secure_run = True):
        """This keyword the PHY Mode information of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``phymode information as dict`` on success.
        
        = Examples =
        |          =Keyword=        |    =NodeIP=    |                         =Comment=                    |
        | `Get PHYMode Information` | 0001:0045:0a26 | This will give PHY Mode information for given Node   |
        | `Get PHYMode Information` |                | This will give PHY Mode information for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Getting PHY Mode Information")
            tablename='phymode show'
            mode_data = self._get_phymode_info(node, tablename, secure_run)
            self._logger().info(mode_data)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        return mode_data
    
    def _get_phymode_info(self, node, tablename, secure_run):
        """
        This makes and returns the dictionary of the given table ``tablename``.
        ``tablename`` must be ``phymode show``.
        Note: It removes extra value 'OK' from output and gives dict of remaining data
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            
            if (output.find('OK') ==-1):
                self._logger().debug("OK not displayed in the phymode information")
                raise Exception("OK not displayed in the phymode information")
            
            if(output.strip() == ''):
                return {} 
                        
            # split into lines/rows
            output_ = output.split('\n')
            output_ = output_[1:]
            
            # remove empty lines
            while('' in output_):
                output_.remove('')
            
            # remove spaces in a value
            tmp = []
            for line in output_:
                line = re.sub(': +', ':', line)
                tmp.append(line)
            output_ = tmp
            
            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp
             
            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp
            
            # remove empty values
            for alist in output_[:-1]:
                while('' in alist):
                    alist.remove('')
            
            #removing 'OK' value from list
            table_header_len = len(output_[0])
            for alist in output_[:-1]:
                if(table_header_len != len(alist)):
                    raise NotATableError
                
            #removing 'OK' value from list before creating dictionary
            table = {column[0]:list(column[1:]) for column in zip(*output_[:-1])}
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
    def delete_all_configured_modes(self, node=None, secure_run = True):
        """This keyword deletes all the configured modes of provided node 
        and reverts to regulatory defaults.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |             =Keyword=         |    =NodeIP=    |                         =Comment=                      |
        | `Delete All Configured Modes` | 0001:0045:0a26 | This will delete all configured modes for given Node   |
        | `Delete All Configured Modes` |                | This will delete all configured modes for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Deleting all configured modes")
            command = net_mgr_and_node + ' modeusage clear'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Deleting all configured modes")
            raise Exception("Deleting all configured modes")
        else:
            if(output.find('Ok') == -1):
                self._logger().debug("Failed to delete all configured modes: {}".format(output))
                self._logger().info(output)
                raise Exception("Failed to delete all configured modes: {}".format(output))
            else:
                return 'Ok'
    
    def get_aggressive_discovery_duration(self, node=None, secure_run = True):
        """This keyword gets the Aggressive discovery duration of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Aggressive discovery duration in seconds`` on success.
        
        = Examples =
        |                =Keyword=            |    =NodeIP=    |                            =Comment=                         |
        | `Get Aggressive Discovery Duration` | 0001:0045:0a26 | This will get Aggressive discovery duration for given Node   |
        | `Get Aggressive Discovery Duration` |                | This will get Aggressive discovery duration for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme disc_aggr_dur'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Aggressive discovery duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Aggressive discovery duration is set to )\d+', output)
            if(match):
                Aggr_Disc_Dur = match.group(0)
                self._logger().debug("Aggressive Discovery Duration: {}".format(Aggr_Disc_Dur))
            else:
                self._logger().debug("Exception occurred while getting Aggressive discovery duration: {}".format(output))
                raise Exception("Exception occurred while getting Aggressive discovery duration: {}".format(output))
        return Aggr_Disc_Dur
    
    def set_aggressive_discovery_duration(self, disc_aggr_dur, node = None, secure_run = True):
        """This keyword sets the Aggressive discovery duration of provided node
        
        This takes 1 mandatory argument ``disc_aggr_dur``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |                =Keyword=            | =Disc Aggr Dur= |  =NodeIP=      |                                 =Comment=                             |
        | `Set Aggressive Discovery Duration` |       120       | 0013:0000:0034 | This will set provided Aggressive discovery duration for given Node   |
        | `Set Aggressive Discovery Duration` |       300       |                | This will set provided Aggressive discovery duration for default Node |
        
        Range for Disc Aggr Dur is 10-600 seconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Disc_Aggr_Dur = int(disc_aggr_dur)
        except ValueError:
            self._logger().exception("Aggressive discovery duration must be either integer or string-convertible-to-integer")
            raise Exception("Aggressive discovery duration must be either integer or string-convertible-to-integer")
         
        if (not (Disc_Aggr_Dur >= 10 and Disc_Aggr_Dur <= 600) ): 
            self._logger().debug("Invalid Aggressive discovery duration. Aggressive discovery duration must be 10 <= Disc_Aggr_Dur <= 600")
            raise Exception("Invalid Aggressive discovery duration. Aggressive discovery duration must be 10 <= Disc_Aggr_Dur <= 600") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Aggressive discovery duration")
            command = net_mgr_and_node + ' conf mlme disc_aggr_dur ' + str(Disc_Aggr_Dur)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Aggressive discovery duration failed: {}".format(output))
            raise Exception("Setting Aggressive discovery duration failed: {}".format(output))
        return output
    
    def get_aggressive_discovery_timeout(self, node=None, secure_run = True):
        """This keyword gets the Aggressive discovery timeout of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Aggressive discovery timeout in milliseconds`` on success.
        
        = Examples =
        |                =Keyword=           |    =NodeIP=    |                            =Comment=                        |
        | `Get Aggressive Discovery Timeout` | 0001:0045:0a26 | This will get Aggressive discovery timeout for given Node   |
        | `Get Aggressive Discovery Timeout` |                | This will get Aggressive discovery timeout for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme disc_aggr_timeout'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Aggressive discovery duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Aggressive discovery re-transmit timeout is set to )\d+', output)
            if(match):
                Aggr_Disc_Timeout = match.group(0)
                self._logger().debug("Aggressive Discovery Timeout: {}".format(Aggr_Disc_Timeout))
            else:
                self._logger().debug("Exception occurred while getting Aggressive discovery Timeout: {}".format(output))
                raise Exception("Exception occurred while getting Aggressive discovery Timeout: {}".format(output))
        return Aggr_Disc_Timeout
    
    def set_aggressive_discovery_timeout(self, disc_aggr_timeout, node = None, secure_run = True):
        """This keyword sets the Aggressive discovery Timeout of provided node
        
        This takes 1 mandatory argument ``disc_aggr_timeout``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |                =Keyword=           | =Disc Aggr Timeout= |  =NodeIP=      |                                 =Comment=                            |
        | `Set Aggressive Discovery Timeout` |         120         | 0013:0000:0034 | This will set provided Aggressive discovery Timeout for given Node   |
        | `Set Aggressive Discovery Timeout` |         300         |                | This will set provided Aggressive discovery Timeout for default Node |
        
        Range for Disc Aggr Timeout is 10-10000 milliseconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Disc_Aggr_Timeout = int(disc_aggr_timeout)
        except ValueError:
            self._logger().exception("Aggressive discovery duration must be either integer or string-convertible-to-integer")
            raise Exception("Aggressive discovery duration must be either integer or string-convertible-to-integer")
         
        if (not (Disc_Aggr_Timeout >= 10 and Disc_Aggr_Timeout <= 10000) ): 
            self._logger().debug("Invalid Aggressive discovery Timeout. Aggressive discovery Timeout must be 10 <= Disc_Aggr_Timeout <= 10000")
            raise Exception("Invalid Aggressive discovery Timeout. Aggressive discovery Timeout must be 10 <= Disc_Aggr_Timeout <= 10000") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Aggressive discovery Timeout")
            command = net_mgr_and_node + ' conf mlme disc_aggr_timeout ' + str(Disc_Aggr_Timeout)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Aggressive discovery Timeout failed: {}".format(output))
            raise Exception("Setting Aggressive discovery Timeout failed: {}".format(output))
        return output
    
    def get_slow_discovery_duration(self, node=None, secure_run = True):
        """This keyword gets the Slow discovery duration of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Slow discovery duration in seconds`` on success.
        
        = Examples =
        |             =Keyword=         |    =NodeIP=    |                         =Comment=                      |
        | `Get Slow Discovery Duration` | 0001:0045:0a26 | This will get Slow discovery duration for given Node   |
        | `Get Slow Discovery Duration` |                | This will get Slow discovery duration for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme disc_slow_dur'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Slow discovery duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Slow discovery duration is set to )\d+', output)
            if(match):
                Slow_Disc_Dur = match.group(0)
                self._logger().debug("Slow Discovery Duration: {}".format(Slow_Disc_Dur))
            else:
                self._logger().debug("Exception occurred while getting Slow discovery duration: {}".format(output))
                raise Exception("Exception occurred while getting Slow discovery duration: {}".format(output))
        return Slow_Disc_Dur
    
    def set_slow_discovery_duration(self, disc_slow_dur, node = None, secure_run = True):
        """This keyword sets the Slow discovery duration of provided node
        
        This takes 1 mandatory argument ``disc_slow_dur``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |             =Keyword=         | =Disc Aggr Dur= |  =NodeIP=      |                              =Comment=                          |
        | `Set Slow Discovery Duration` |       120       | 0013:0000:0034 | This will set provided slow discovery duration for given Node   |
        | `Set Slow Discovery Duration` |       300       |                | This will set provided slow discovery duration for default Node |
        
        Range for Disc Slow Dur is 0-600 seconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Disc_Slow_Dur = int(disc_slow_dur)
        except ValueError:
            self._logger().exception("Slow discovery duration must be either integer or string-convertible-to-integer")
            raise Exception("Slow discovery duration must be either integer or string-convertible-to-integer")
         
        if (not (Disc_Slow_Dur >= 0 and Disc_Slow_Dur <= 600) ): 
            self._logger().debug("Invalid Slow discovery duration. Slow discovery duration must be 0 <= Disc_Slow_Dur <= 600")
            raise Exception("Invalid Slow discovery duration. Slow discovery duration must be 0 <= Disc_Slow_Dur <= 600") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Slow discovery duration")
            command = net_mgr_and_node + ' conf mlme disc_slow_dur ' + str(Disc_Slow_Dur)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Slow discovery duration failed: {}".format(output))
            raise Exception("Setting Slow discovery duration failed: {}".format(output))
        return output
    
    def get_selective_discovery_duration(self, node=None, secure_run = True):
        """This keyword gets the Aggressive selective discovery duration of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Aggressive selective discovery duration in seconds`` on success.
        
        = Examples =
        |               =Keyword=            |    =NodeIP=    |                                  =Comment=                             |
        | `Get Selective Discovery Duration` | 0001:0045:0a26 | This will get Aggressive selective discovery duration for given Node   |
        | `Get Selective Discovery Duration` |                | This will get Aggressive selective discovery duration for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme disc_sel_dur'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Aggressive selective discovery duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Aggressive discovery selective duration is set to )\d+', output)
            if(match):
                Slow_Disc_Dur = match.group(0)
                self._logger().debug("Aggressive selective Discovery Duration: {}".format(Slow_Disc_Dur))
            else:
                self._logger().debug("Exception occurred while getting Aggressive selective discovery duration: {}".format(output))
                raise Exception("Exception occurred while getting Aggressive selective discovery duration: {}".format(output))
        return Slow_Disc_Dur
    
    def set_selective_discovery_duration(self, disc_sel_dur, node = None, secure_run = True):
        """This keyword sets the Aggressive selective discovery duration of provided node
        
        This takes 1 mandatory argument ``disc_sel_dur``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |                =Keyword=           | =Disc Sel Dur= |  =NodeIP=      |                                      =Comment=                                  |
        | `Set Selective Discovery Duration` |       120      | 0013:0000:0034 | This will set provided Aggressive selective discovery duration for given Node   |
        | `Set Selective Discovery Duration` |       300      |                | This will set provided Aggressive selective discovery duration for default Node |
        
        Range for Disc Sel Dur is 0-600 seconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Disc_Sel_Dur = int(disc_sel_dur)
        except ValueError:
            self._logger().exception("Aggressive selective discovery duration must be either integer or string-convertible-to-integer")
            raise Exception("Aggressive selective discovery duration must be either integer or string-convertible-to-integer")
         
        if (not (Disc_Sel_Dur >= 0 and Disc_Sel_Dur <= 600) ): 
            self._logger().debug("Invalid Aggressive selective discovery duration. Aggressive selective discovery duration must be 0 <= Disc_Sel_Dur <= 600")
            raise Exception("Invalid Aggressive selective discovery duration. Aggressive selective discovery duration must be 0 <= Disc_Sel_Dur <= 600") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Aggressive selective discovery duration")
            command = net_mgr_and_node + ' conf mlme disc_sel_dur ' + str(Disc_Sel_Dur)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Aggressive selective discovery duration failed: {}".format(output))
            raise Exception("Setting Aggressive selective discovery duration failed: {}".format(output))
        return output
    
    def get_passive_discovery_timeout(self, node=None, secure_run = True):
        """This keyword gets the Passive discovery timeout of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Passive discovery timeout in minutes`` on success.
        
        = Examples =
        |              =Keyword=          |    =NodeIP=    |                          =Comment=                       |
        | `Get Passive Discovery Timeout` | 0001:0045:0a26 | This will get Passive discovery timeout for given Node   |
        | `Get Passive Discovery Timeout` |                | This will get Passive discovery timeout for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme disc_passive_timeout'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Passive discovery duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Passive discovery timeout is set to )\d+', output)
            if(match):
                Aggr_Disc_Timeout = match.group(0)
                self._logger().debug("Passive Discovery Timeout: {}".format(Aggr_Disc_Timeout))
            else:
                self._logger().debug("Exception occurred while getting Passive discovery Timeout: {}".format(output))
                raise Exception("Exception occurred while getting Passive discovery Timeout: {}".format(output))
        return Aggr_Disc_Timeout
    
    def set_passive_discovery_timeout(self, disc_passive_timeout, node = None, secure_run = True):
        """This keyword sets the Passive discovery Timeout of provided node
        
        This takes 1 mandatory argument ``disc_passive_timeout``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |              =Keyword=          | =Disc Aggr Timeout= |  =NodeIP=      |                               =Comment=                           |
        | `Set Passive Discovery Timeout` |         120         | 0013:0000:0034 | This will set provided Passive discovery Timeout for given Node   |
        | `Set Passive Discovery Timeout` |         300         |                | This will set provided Passive discovery Timeout for default Node |
        
        Range for Disc Passive Timeout is 30-2880 minutes.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Disc_Passive_Timeout = int(disc_passive_timeout)
        except ValueError:
            self._logger().exception("Passive discovery duration must be either integer or string-convertible-to-integer")
            raise Exception("Passive discovery duration must be either integer or string-convertible-to-integer")
         
        if (not (Disc_Passive_Timeout >= 30 and Disc_Passive_Timeout <= 2880) ): 
            self._logger().debug("Invalid Passive discovery Timeout. Passive discovery Timeout must be 30 <= Disc_Passive_Timeout <= 2880")
            raise Exception("Invalid Passive discovery Timeout. Passive discovery Timeout must be 30 <= Disc_Passive_Timeout <= 2880") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Passive discovery Timeout")
            command = net_mgr_and_node + ' conf mlme disc_passive_timeout ' + str(Disc_Passive_Timeout)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Passive discovery Timeout failed: {}".format(output))
            raise Exception("Setting Passive discovery Timeout failed: {}".format(output))
        return output
    
    def get_mlme_nodeq_persist_period(self, node=None, secure_run = True):
        """This keyword gets the MLME Nodeq persist period of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``MLME Nodeq persist period in minutes`` on success.
        
        = Examples =
        |              =Keyword=          |    =NodeIP=    |                          =Comment=                       |
        | `Get MLME Nodeq Persist Period` | 0001:0045:0a26 | This will get mlme nodeq persist period for given Node   |
        | `Get MLME Nodeq Persist Period` |                | This will get mlme nodeq persist period for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf mlme mlme_nodeq_persist_period'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting MLME Nodeq Persist Period")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=MLME nodeq persist period is set to )\d+', output)
            if(match):
                Nodeq_Persist_Period = match.group(0)
                self._logger().debug("MLME Nodeq Persist Period: {}".format(Nodeq_Persist_Period))
            else:
                self._logger().debug("Exception occurred while getting MLME Nodeq Persist Period: {}".format(output))
                raise Exception("Exception occurred while getting MLME Nodeq Persist Period: {}".format(output))
        return Nodeq_Persist_Period
    
    def set_mlme_nodeq_persist_period(self, persist_period, node = None, secure_run = True):
        """This keyword sets the MLME Nodeq persist period of provided node
        
        This takes 1 mandatory argument ``persist_period``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.

        = Examples =
        |              =Keyword=          | =Persist Period= |  =NodeIP=      |                               =Comment=                           |
        | `Set MLME Nodeq persist period` |        120       | 0013:0000:0034 | This will set provided MLME Nodeq persist period for given Node   |
        | `Set MLME Nodeq persist period` |        300       |                | This will set provided MLME Nodeq persist period for default Node |
        
        Range for Persist Period is 1-50000 minutes.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Persist_Period = int(persist_period)
        except ValueError:
            self._logger().exception("MLME Nodeq persist period must be either integer or string-convertible-to-integer")
            raise Exception("MLME Nodeq persist period must be either integer or string-convertible-to-integer")
         
        if (not (Persist_Period >= 1 and Persist_Period <= 50000) ): 
            self._logger().debug("Invalid MLME Nodeq persist period. MLME Nodeq persist period must be 1 <= Disc_Passive_Timeout <= 50000")
            raise Exception("Invalid MLME Nodeq persist period. MLME Nodeq persist period must be 1 <= Disc_Passive_Timeout <= 50000") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Passive discovery Timeout")
            command = net_mgr_and_node + ' conf mlme mlme_nodeq_persist_period ' + str(Persist_Period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting MLME Nodeq persist period failed: {}".format(output))
            raise Exception("Setting MLME Nodeq persist period failed: {}".format(output))
        return output
    
    def get_forward_NREG(self, node=None, secure_run=True):
        """This keyword gets the forward NREG value of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``1`` or ``0`` on success.
        
        = Examples =
        |      =Keyword=      |     =Node=     |                   =Comment=                        |
        | `Get Forward NREG`  | 0001:0045:0a26 | This will get forward NREG status for given Node   |
        | `Get Forward NREG`  |                | This will get forward NREG status for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt nreg_fw_enabled'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Forward NREG status")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Forward NREGs is set to )\d+', output)
            if(match):
                FwNREGStatus = match.group(0)
                self._logger().debug('Forward NREG Status: {}'.format(FwNREGStatus))
            else:
                self._logger().debug("Exception occurred while getting Forward NREG status: {}".format(output))
                raise Exception("Exception occurred while getting Forward NREG status: {}".format(output))
        return FwNREGStatus
    
    def set_forward_NREG(self, fw_nreg_status, node=None, secure_run = True):
        """This keyword sets the Forward NREGs status of provided node.
        
        This takes 1 mandatory argument ``fw_nreg_status``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |        =Keyword=    | =FW NREG Status= |     =Node=     |                         =Comment=                       |
        | `Set Forward NREG`  |         1        | 0001:0045:0a26 | This will set Forward NREG as enabled for given Node    |
        | `Set Forward NREG`  |         0        |                | This will set Forward NREG as disabled for default Node |
        
        Forward NREG status should be either 0(disable) or 1 (enable).
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            FW_NREG_Status = int(fw_nreg_status)
        except ValueError:
            self._logger().exception("Forward NREG status must be either integer or string-convertible-to-integer")
            raise Exception("Forward NREG status must be either integer or string-convertible-to-integer")
         
        if (not (FW_NREG_Status == 0 or FW_NREG_Status == 1) ):
            self._logger().debug("Invalid Forward NREG Status. Forward NREG Status must be either 0 or 1")
            raise Exception("Invalid Forward NREG Status. Forward NREG Status must be either 0 or 1") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Forward NREG Status")
            command = net_mgr_and_node + ' conf srt nreg_fw_enabled ' + str(FW_NREG_Status)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Forward NREG Status failed: {}".format(output))
            raise Exception("Setting Forward NREG Status failed: {}".format(output))
        return output
    
    def get_RTA_enabled_status(self, node=None, secure_run=True):
        """This keyword gets the RTA Enabled status of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``1`` or ``0`` on success.
        
        = Examples =
        |         =Keyword=        |     =Node=     |                   =Comment=                       |
        | `Get RTA Enabled Status` | 0001:0045:0a26 | This will get RTA Enabled Status for given Node   |
        | `Get RTA Enabled Status` |                | This will get RTA Enabled Status for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt rta_enabled'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting RTA Enabled Status")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Send any RTAs \(on/off\) is set to )\d+', output)
            self._logger().debug(match)
            if(match):
                RTAStatus = match.group(0)
                self._logger().debug('RTA Enabled Status: {}'.format(RTAStatus))
            else:
                self._logger().debug("Exception occurred while getting RTA Enabled Status: {}".format(output))
                raise Exception("Exception occurred while getting RTA Enabled Status: {}".format(output))
        return RTAStatus
    
    def set_RTA_enabled_status(self, rta_status, node=None, secure_run = True):
        """This keyword sets the RTA Enabled Status of provided node.
        
        This takes 1 mandatory argument ``rta_status``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |          =Keyword=       | =RTA Status= |     =Node=     |                             =Comment=                         |
        | `Set RTA Enabled Status` |       1      | 0001:0045:0a26 | This will set RTA Enabled Status as enabled for given Node    |
        | `Set RTA Enabled Status` |       0      |                | This will set RTA Enabled Status as disabled for default Node |
        
        RTA status should be either 0(disable) or 1 (enable).
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            RTA_Status = int(rta_status)
        except ValueError:
            self._logger().exception("RTA Enabled Status must be either integer or string-convertible-to-integer")
            raise Exception("RTA Enabled Status must be either integer or string-convertible-to-integer")
         
        if (not (RTA_Status == 0 or RTA_Status == 1) ):
            self._logger().debug("Invalid RTA Enabled Status. RTA Enabled Status must be either 0 or 1")
            raise Exception("Invalid RTA Enabled Status. RTA Enabled Status must be either 0 or 1") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting RTA Enabled Status")
            command = net_mgr_and_node + ' conf srt rta_enabled ' + str(RTA_Status)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting RTA Enabled Status failed: {}".format(output))
            raise Exception("Setting RTA Enabled Status failed: {}".format(output))
        return output
    
    def get_NREG_ack_enabled_status(self, node=None, secure_run=True):
        """This keyword gets the NREG Ack Enabled Status of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``1`` or ``0`` on success.
        
        = Examples =
        |            =Keyword=          |     =Node=     |                        =Comment=                       |
        | `Get NREG Ack Enabled Status` | 0001:0045:0a26 | This will get NREG Ack Enabled Status for given Node   |
        | `Get NREG Ack Enabled Status` |                | This will get NREG Ack Enabled Status for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt nreg_ack_enabled'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting RTA Enabled Status")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Send NREG acks is set to )\d+', output)
            if(match):
                RTAStatus = match.group(0)
                self._logger().debug('NREG Ack Enabled Status: {}'.format(RTAStatus))
            else:
                self._logger().debug("Exception occurred while getting NREG Ack Enabled Status: {}".format(output))
                raise Exception("Exception occurred while getting NREG Ack Enabled Status: {}".format(output))
        return RTAStatus
    
    def set_NREG_ack_enabled_status(self, nreg_ack_status, node=None, secure_run = True):
        """This keyword sets the NREG Ack Enabled Status of provided node.
        
        This takes 1 mandatory argument ``nreg_ack_status``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |             =Keyword=         | =NREG Ack Status= |     =Node=     |                                =Comment=                           |
        | `Set NREG Ack Enabled Status` |         1         | 0001:0045:0a26 | This will set NREG Ack Enabled Status as enabled for given Node    |
        | `Set NREG Ack Enabled Status` |         0         |                | This will set NREG Ack Enabled Status as disabled for default Node |
        
        NREG Ack Enabled status should be either 0(disable) or 1 (enable).
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            NREG_Ack_Status = int(nreg_ack_status)
        except ValueError:
            self._logger().exception("NREG Ack Enabled Status must be either integer or string-convertible-to-integer")
            raise Exception("NREG Ack Enabled Status must be either integer or string-convertible-to-integer")
         
        if (not (NREG_Ack_Status == 0 or NREG_Ack_Status == 1) ):
            self._logger().debug("Invalid NREG Ack Enabled Status. NREG Ack Enabled Status must be either 0 or 1")
            raise Exception("Invalid NREG Ack Enabled Status. NREG Ack Enabled Status must be either 0 or 1") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting NREG Ack Enabled Status")
            command = net_mgr_and_node + ' conf srt nreg_ack_enabled ' + str(NREG_Ack_Status)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting NREG Ack Enabled Status failed: {}".format(output))
            raise Exception("Setting NREG Ack Enabled Status failed: {}".format(output))
        return output
    
    def force_NREG(self, node=None, secure_run = True):
        """This keyword forces the node to reregister with all gateways of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |  =Keyword=   |      =Node=     |                                  =Comment=                                |
        | `Force NREG` |  0001:0045:0a26 | This will force the node to reregister with all gateways for given Node   |
        | `Force NREG` |                 | This will force the node to reregister with all gateways for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Forcing node to reregister with all gateways")
            command = net_mgr_and_node + ' srt nreg_force'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Forcing node to reregister with all gateways failed: {}".format(output))
            raise Exception("Forcing node to reregister with all gateways failed: {}".format(output))
        return output
    
    def get_NREG_ack_timeout(self, node=None, secure_run=True):
        """This keyword gets the NREG Ack timeout duration of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Network Registration Acknowledgement Timeout in seconds`` on success.
        
        = Examples =
        |        =Keyword=       |     =Node=     |                          =Comment=                       |
        | `Get NREG Ack Timeout` | 0001:0045:0a26 | This will get NREG Ack timeout duration for given Node   |
        | `Get NREG Ack Timeout` |                | This will get NREG Ack timeout duration for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt nreg_ack_timeout'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting NREG Ack Timeout Duration")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Network Registration Acknowledgement Timeout is set to )\d+', output)
            if(match):
                NREG_Ack_Timeout = match.group(0)
                self._logger().debug('NREG Ack Timeout Duration: {} secs'.format(NREG_Ack_Timeout))
            else:
                self._logger().debug("Exception occurred while getting NREG Ack Timeout Duration: {}".format(output))
                raise Exception("Exception occurred while getting NREG Ack Timeout Duration: {}".format(output))
        return NREG_Ack_Timeout
    
    def set_NREG_ack_timeout(self, nreg_ack_timeout, node=None, secure_run = True):
        """This keyword sets the NREG Ack Timeout Duration of provided node.
        
        This takes 1 mandatory argument ``nreg_ack_timeout``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |         =Keyword=      | =NREG Ack Timeout= |     =Node=     |                         =Comment=                        |
        | `Set NREG Ack Timeout` |          10        | 0001:0045:0a26 | This will set NREG Ack Timeout Duration for given Node   |
        | `Set NREG Ack Timeout` |          20        |                | This will set NREG Ack Timeout Duration for default Node |
        
        NREG Ack Timeout Duration Range: 1-180 secs.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            NREG_Ack_Timeout = int(nreg_ack_timeout)
        except ValueError:
            self._logger().exception("NREG Ack Timeout Duration must be either integer or string-convertible-to-integer")
            raise Exception("NREG Ack Timeout Duration must be either integer or string-convertible-to-integer")
         
        if (not (NREG_Ack_Timeout >= 1 and NREG_Ack_Timeout <= 180) ):
            self._logger().debug("Invalid NREG Ack Timeout Duration. NREG Ack Timeout Duration must be 1>= NREG_Ack_Timeout <= 180")
            raise Exception("Invalid NREG Ack Timeout Duration. NREG Ack Timeout Duration must be 1>= NREG_Ack_Timeout <= 180") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting NREG Ack Timeout Duration")
            command = net_mgr_and_node + ' conf srt nreg_ack_timeout ' + str(NREG_Ack_Timeout)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting NREG Ack Timeout Duration failed: {}".format(output))
            raise Exception("Setting NREG Ack Timeout Duration failed: {}".format(output))
        return output
    
    def get_NREG_ack_max_tries(self, node=None, secure_run=True):
        """This keyword gets the Maximum number of tries NREG'ing w/out NREG_ACK before
        failing (verified routes) of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Max Try Counter Value`` on success.
        
        = Examples =
        |          =Keyword=       |     =Node=     |                                =Comment=                                   |
        | `Get NREG Ack Max Tries` | 0001:0045:0a26 | This will get NREG Ack Max Try Counter for verified route for given Node   |
        | `Get NREG Ack Max Tries` |                | This will get NREG Ack Max Try Counter for verified route for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt nreg_ack_max_tries'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting NREG Ack Max Try Counter for Verified route")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Network Registration Acknowledgement Maximum Try Counter \(verified\) is set to )\d+', output)
            if(match):
                NREG_Ack_Max_Try_Counter = match.group(0)
                self._logger().debug('NREG Ack Max Try Counter for Verified route: {}'.format(NREG_Ack_Max_Try_Counter))
            else:
                self._logger().debug("Exception occurred while getting NREG Ack Max Try Counter for Verified route: {}".format(output))
                raise Exception("Exception occurred while getting NREG Ack Max Try Counter for Verified route: {}".format(output))
        return NREG_Ack_Max_Try_Counter
    
    def set_NREG_ack_max_tries(self, nreg_ack_max_try, node=None, secure_run = True):
        """This keyword sets the Maximum number of tries NREG'ing w/out NREG_ACK before
        failing (verified routes) of provided node.
        
        This takes 1 mandatory argument ``nreg_ack_max_try``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |          =Keyword=       | =NREG Ack Max Try= |     =Node=     |                                  =Comment=                                 |
        | `Set NREG Ack Max Tries` |          3         | 0001:0045:0a26 | This will set NREG Ack Max Try Counter for verified route for given Node   |
        | `Set NREG Ack Max tries` |          2         |                | This will set NREG Ack Max Try Counter for verified route for default Node |
        
        NREG Ack Max Try Counter Range: 1-32.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            NREG_Ack_Max_Try = int(nreg_ack_max_try)
        except ValueError:
            self._logger().exception("NREG Ack Max Try Counter for Verified route must be either integer or string-convertible-to-integer")
            raise Exception("NREG Ack Max Try Counter for Verified route must be either integer or string-convertible-to-integer")
         
        if (not (NREG_Ack_Max_Try >= 1 and NREG_Ack_Max_Try <= 32) ):
            self._logger().debug("Invalid NREG Ack Max Try Counter for Verified route. NREG Ack Max Try Counter for Verified route must be 1>= NREG_Ack_Max_Try <= 32")
            raise Exception("Invalid NREG Ack Max Try Counter for Verified route. NREG Ack Max Try Counter for Verified route must be 1>= NREG_Ack_Max_Try <= 32") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting NREG Ack Max Try Counter for Verified route")
            command = net_mgr_and_node + ' conf srt nreg_ack_max_tries ' + str(NREG_Ack_Max_Try)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting NREG Ack Max Try Counter for Verified route failed: {}".format(output))
            raise Exception("Setting NREG Ack Max Try Counter for Verified route failed: {}".format(output))
        return output
    
    def get_NREG_ack_max_tries_tnt(self, node=None, secure_run=True):
        """This keyword gets the Maximum number of tries NREG'ing w/out NREG_ACK before
        failing (tentative routes) of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Max Try TnT Counter Value`` on success.
        
        = Examples =
        |            =Keyword=         |     =Node=     |                                =Comment=                                   |
        | `Get NREG Ack Max Tries Tnt` | 0001:0045:0a26 | This will get NREG Ack Max Try Counter for tentative route for given Node   |
        | `Get NREG Ack Max Tries Tnt` |                | This will get NREG Ack Max Try Counter for tentative route for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt nreg_ack_max_tries_tnt'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting NREG Ack Max Try Counter for Tentative route")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Network Registration Acknowledgement Maximum Try Counter \(tentative\) is set to )\d+', output)
            if(match):
                NREG_Ack_Max_Try_TnT_Counter = match.group(0)
                self._logger().debug('NREG Ack Max Try Counter for Tentative route: {}'.format(NREG_Ack_Max_Try_TnT_Counter))
            else:
                self._logger().debug("Exception occurred while getting NREG Ack Max Try Counter for Tentative route: {}".format(output))
                raise Exception("Exception occurred while getting NREG Ack Max Try Counter for Tentative route: {}".format(output))
        return NREG_Ack_Max_Try_TnT_Counter
    
    def set_NREG_ack_max_tries_tnt(self, nreg_ack_max_try_tnt, node=None, secure_run = True):
        """This keyword sets the Maximum number of tries NREG'ing w/out NREG_ACK before
        failing (tentative routes) of provided node.
        
        This takes 1 mandatory argument ``nreg_ack_max_try_tnt``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |            =Keyword=         | =NREG Ack Max Try Tnt= |     =Node=     |                                  =Comment=                                  |
        | `Set NREG Ack Max Tries Tnt` |            3           | 0001:0045:0a26 | This will set NREG Ack Max Try Counter for tentative route for given Node   |
        | `Set NREG Ack Max tries Tnt` |            2           |                | This will set NREG Ack Max Try Counter for tentative route for default Node |
        
        NREG Ack Max Try Tnt Counter Range: 1-32.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            NREG_Ack_Max_Try_Tnt = int(nreg_ack_max_try_tnt)
        except ValueError:
            self._logger().exception("NREG Ack Max Try Counter for Tentative route must be either integer or string-convertible-to-integer")
            raise Exception("NREG Ack Max Try Counter for Tentative route must be either integer or string-convertible-to-integer")
         
        if (not (NREG_Ack_Max_Try_Tnt >= 1 and NREG_Ack_Max_Try_Tnt <= 32) ):
            self._logger().debug("Invalid NREG Ack Max Try Counter for Tentative route. NREG Ack Max Try Counter for Tentative route must be 1>= NREG_Ack_Max_Try_Tnt <= 32")
            raise Exception("Invalid NREG Ack Max Try Counter for Tentative route. NREG Ack Max Try Counter for Tentative route must be 1>= NREG_Ack_Max_Try_Tnt <= 32") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting NREG Ack Max Try Counter for Tentative route")
            command = net_mgr_and_node + ' conf srt nreg_ack_max_tries_tnt ' + str(NREG_Ack_Max_Try_Tnt)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting NREG Ack Max Try Counter for Tentative route failed: {}".format(output))
            raise Exception("Setting NREG Ack Max Try Counter for Tentative route failed: {}".format(output))
        return output
    
    def get_NREG_period(self, node=None, secure_run=True):
        """This keyword gets the Network Registration Period of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Network Registration Period in secs`` on success.
        
        = Examples =
        |      =Keyword=    |     =Node=     |                        =Comment=                           |
        | `Get NREG Period` | 0001:0045:0a26 | This will get Network Registration Period for given Node   |
        | `Get NREG Period` |                | This will get Network Registration Period for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt nreg_period'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Network Registration Period")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r'(?<=Network Registration Period is set to )\d+', output)
            if(match):
                NREG_Period = match.group(0)
                self._logger().debug('Network Registration Period: {} secs'.format(NREG_Period))
            else:
                self._logger().debug("Exception occurred while getting Network Registration Period: {}".format(output))
                raise Exception("Exception occurred while getting Network Registration Period: {}".format(output))
        return NREG_Period
    
    def set_NREG_period(self, nreg_period, node=None, secure_run = True):
        """This keyword sets Network Registration Period of provided node.
        
        This takes 1 mandatory argument ``nreg_period``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |       =Keyword=   | =NREG Period= |     =Node=     |                        =Comment=                           |
        | `Set NREG Period` |      650      | 0001:0045:0a26 | This will set Network Registration Period for given Node   |
        | `Set NREG Period` |      600      |                | This will set Network Registration Period for default Node |
        
        Network Registration Period Range: 600-86400 seconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            NREG_Period = int(nreg_period)
        except ValueError:
            self._logger().exception("Network Registration Period must be either integer or string-convertible-to-integer")
            raise Exception("Network Registration Period must be either integer or string-convertible-to-integer")
         
        if (not (NREG_Period >= 600 and NREG_Period <= 86400) ):
            self._logger().debug("Invalid Network Registration Period. Network Registration Period must be 600>= NREG_Period <= 86400")
            raise Exception("Invalid Network Registration Period. Network Registration Period must be 600>= NREG_Period <= 86400") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Network Registration Period")
            command = net_mgr_and_node + ' conf srt nreg_period ' + str(NREG_Period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Network Registration Period failed: {}".format(output))
            raise Exception("Setting Network Registration Period failed: {}".format(output))
        return output
    
    def force_RTA(self, node=None, secure_run = True):
        """This keyword Forces the node to readvertise routes to all neighbors
        of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |   =Keyword= |      =Node=     |                                    =Comment=                                     |
        | `Force RTA` |  0001:0045:0a26 | This will Force the node to readvertise routes to all neighbors for given Node   |
        | `Force RTA` |                 | This will Force the node to readvertise routes to all neighbors for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Forcing the node to readvertise routes to all neighbors")
            command = net_mgr_and_node + ' srt rta_force'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Forcing the node to readvertise routes to all neighbors failed")
            raise Exception("Forcing the node to readvertise routes to all neighbors failed: {}".format(output))
        return output
    
    def force_request_RTA(self, node=None, secure_run = True):
        """This keyword Forces the node to request route advertisements from neighbors
         of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |       =Keyword=     |      =Node=     |                                         =Comment=                                        |
        | `Force Request RTA` |  0001:0045:0a26 | This will Force the node to request route advertisements from neighbors for given Node   |
        | `Force Request RTA` |                 | This will Force the node to request route advertisements from neighbors for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Forcing the node to request route advertisements from neighbors")
            command = net_mgr_and_node + ' srt rta_req_force'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Forcing the node to request route advertisements from neighbors failed: {}".format(output))
            raise Exception("Forcing the node to request route advertisements from neighbors failed: {}".format(output))
        return output
    
    def NREG_restore_force(self, node=None, secure_run = True):
        """This keyword Force the node to reregister with all gateways with reboot 
        state unclean to force a restore trap on AP of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |        =Keyword=     |      =Node=     |                               =Comment=                               |
        | `NREG Restore Force` |  0001:0045:0a26 | This will Force the node to reregister with all gateways with reboot\
                                                   state unclean to force a restore trap on AP for given Node            |
        | `NREG Restore Force` |                 | This will Force the node to rreregister with all gateways with reboot\
                                                   state unclean to force a restore for default Node                     |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Forcing the node to reregister with all gateways with reboot state unclean to force a restore trap on AP")
            command = net_mgr_and_node + ' srt nreg_restore_force'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Forcing the node to reregister with all gateways with reboot state unclean to force a restore trap on AP failed: {}".format(output))
            raise Exception("Forcing the node to reregister with all gateways with reboot state unclean to force a restore trap on AP failed: {}".format(output))
        return output
    
    def schedule_NREG(self, sched_time, node=None, secure_run = True):
        """This keyword Forces the node to reregister with all gateways after a delay
        of provided node.
        
        This takes 1 mandatory argument ``sched_time`` in seconds.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |     =Keyword=   | =Sched Time= |     =Node=     |                                         =Comment=                                       |
        | `Schedule NREG` |      10      | 0001:0045:0a26 | This will Force the node to reregister with all gateways after a delay for given Node   |
        | `Schedule NREG` |     15       |                | This will Force the node to reregister with all gateways after a delay for default Node |
        
        NREG Sched Time Range: 0 - 65535 seconds
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            NREG_Sched = int(sched_time)
        except ValueError:
            self._logger().exception("NREG Schedule Period must be either integer or string-convertible-to-integer")
            raise Exception("Network Schedule Period must be either integer or string-convertible-to-integer")
         
        if (not (NREG_Sched >= 0 and NREG_Sched <= 65535) ):
            self._logger().debug("Invalid Network Registration Period. Network Registration Period must be 0>= NREG_Sched <= 65535")
            raise Exception("Invalid Network Registration Period. Network Registration Period must be 0>= NREG_Sched <= 65535") 
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Forcing the node to reregister with all gateways after a delay")
            command = net_mgr_and_node + ' srt nreg_sched ' + str(NREG_Sched)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Forcing the node to reregister with all gateways after a delay failed: {}".format(output))
            raise Exception("Forcing the node to reregister with all gateways after a delay failed: {}".format(output))
        return output
    
    def get_min_RTA_period(self, node=None, secure_run=True):
        """This keyword gets the Minimum time (seconds) between route advertisements of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Network Registration Period in secs`` on success.
        
        = Examples =
        |       =Keyword=      |     =Node=     |                          =Comment=                        |
        | `Get Min RTA Period` | 0001:0045:0a26 | This will get Minimum time between RTA's for given Node   |
        | `Get Min RTA Period` |                | This will get Minimum time between RTA's for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt min_rta_period'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Minimum time between RTA's")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r"(?<=SRT min period between rta's is set to )\d+", output)
            if(match):
                Min_RTA_Period = match.group(0)
                self._logger().debug("Minimum time between RTA's: {} secs".format(Min_RTA_Period))
            else:
                self._logger().debug("Exception occurred while getting Minimum time between RTA's: {}".format(output))
                raise Exception("Exception occurred while getting Minimum time between RTA's: {}".format(output))
        return Min_RTA_Period
    
    def set_min_RTA_period(self, min_rta_period, node=None, secure_run = True):
        """This keyword sets Minimum time (seconds) between route advertisements of provided node.
        
        This takes 1 mandatory argument ``min_rta_period``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |        =Keyword=     | =Min RTA Period= |     =Node=     |                        =Comment=                          |
        | `Set Min RTA Period` |       300        | 0001:0045:0a26 | This will set Minimum time between RTA's for given Node   |
        | `Set Min RTA Period` |       350        |                | This will set Minimum time between RTA's for default Node |
        
        Minimum time between RTA's Range: 0-7200 seconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Min_RTA_Period = int(min_rta_period)
        except ValueError:
            self._logger().exception("Minimum time between RTA's must be either integer or string-convertible-to-integer")
            raise Exception("Minimum time between RTA's must be either integer or string-convertible-to-integer")
         
        if (not (Min_RTA_Period >= 0 and Min_RTA_Period <= 7200) ):
            self._logger().debug("Invalid Minimum time between RTA's. Minimum time between RTA's must be 0>= Min_RTA_Period <= 7200")
            raise Exception("Invalid Minimum time between RTA's. Minimum time between RTA's must be 0>= Min_RTA_Period <= 7200") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Minimum time between RTA's")
            command = net_mgr_and_node + ' conf srt min_rta_period ' + str(Min_RTA_Period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Minimum time between RTA's failed: {}".format(output))
            raise Exception("Setting Minimum time between RTA's failed: {}".format(output))
        return output
    
    def get_min_NREG_period(self, node=None, secure_run=True):
        """This keyword gets the minimum period a device must wait between nregs of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Network Registration Period in secs`` on success.
        
        = Examples =
        |        =Keyword=      |     =Node=     |                          =Comment=                        |
        | `Get Min NREG Period` | 0001:0045:0a26 | This will get Minimum period between NREG's for given Node   |
        | `Get Min NREG Period` |                | This will get Minimum period between NREG's for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            command = net_mgr_and_node + ' conf srt min_nreg_period'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
            self._logger().info("Getting Minimum period between NREG's")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            match = re.search(r"(?<=Minimum period a device must wait between nregs is set to )\d+", output)
            if(match):
                Min_NREG_Period = match.group(0)
                self._logger().debug("Minimum period between NREG's: {} secs".format(Min_NREG_Period))
            else:
                self._logger().debug("Exception occurred while getting Minimum period between NREG's: {}".format(output))
                raise Exception("Exception occurred while getting Minimum period between NREG's: {}".format(output))
        return Min_NREG_Period
    
    def set_min_NREG_period(self, min_nreg_period, node=None, secure_run = True):
        """This keyword sets minimum period a device must wait between nregs of provided node.
        
        This takes 1 mandatory argument ``min_rta_period``.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |        =Keyword=      | =Min NREG Period= |     =Node=     |                          =Comment=                          |
        | `Set Min NREG Period` |       300        | 0001:0045:0a26 | This will set Minimum period between NREG's for given Node   |
        | `Set Min NREG Period` |       350        |                | This will set Minimum period between NREG's for default Node |
        
        Minimum period between NREG's Range: 0-3600 seconds.
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
        
        try:
            Min_NREG_Period = int(min_nreg_period)
        except ValueError:
            self._logger().exception("Minimum period between NREG's must be either integer or string-convertible-to-integer")
            raise Exception("Minimum period between NREG's must be either integer or string-convertible-to-integer")
         
        if (not (Min_NREG_Period >= 0 and Min_NREG_Period <= 3600) ):
            self._logger().debug("Invalid Minimum period between NREG's. Minimum period between NREG's must be 0>= Min_NREG_Period <= 3600")
            raise Exception("Invalid Minimum period between NREG's. Minimum period between NREG's must be 0>= Min_NREG_Period <= 3600") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Setting Minimum period between NREG's")
            command = net_mgr_and_node + ' conf srt min_nreg_period ' + str(Min_NREG_Period)
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Setting Minimum period between NREG's failed: {}".format(output))
            raise Exception("Setting Minimum period between NREG's failed: {}".format(output))
        return output
    
    def get_srt_ral_list(self, data, node=None, secure_run=True):
        """This keyword gives the ``data`` from list of  entries in route accept list of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        Below are the ``data`` values supported:
        
        - ``1`` OR ``Address`` for list of addresses in srt ral list
        - ``2`` OR ``Flags`` for list of flags in srt ral list
        - ``3`` OR ``Tag`` for list of tag in srt ral list
        - ``4`` OR ``RediscTime`` for list of redisctime in srt ral list
        - ``5`` OR ``Resets`` for list of resets in srt ral list
        - ``6`` OR ``LQM`` for list of LQM in srt ral list
        - ``0`` OR ``all`` for all above (1-6) values) as a python like-tuple
        
        ``data`` values are case-sensitive.

        = Examples =
        |       =Keyword=    |     =Data=     |     =Node=     |                                =Comment=                              |
        | `Get SRT RAL List` |       all      | 0001:0045:0a26 | This will get list of all values in route accept list for given Node  |
        | `Get SRT RAL List` |     Address    |                | This will get list of addresses in route accept list for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            tablename = 'srt_ral list'
            ral_list_data = self._get_ral_data(node, tablename, secure_run)
            self._logger().info(ral_list_data)
        except Exception as e:
            self._logger().exception("Could not get data from srt RAL list: {}".format(e))
            raise Exception("Could not get data from srt RAL list: {}".format(e))
        else:
            if(ral_list_data == {}):
                self._logger().debug("Srt RAL List is empty")
                raise Exception("Srt RAL list is empty")
            try:
                if(data=='all' or data == '0'):
                    return ral_list_data
                else:
                    data_list= ral_list_data[data]
                    self._logger().info(data_list)
                    return data_list
            except KeyError as e:
                self._logger().exception("Invalid data '{}'".format(data)) 
                raise Exception("Invalid data '{}'".format(data))
             
    def show_srt_ral_data(self, data, node=None, secure_run=True):
        """This keyword gives the ``data`` from list of entries in route accept list of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        Below are the ``data`` values supported:
        
        - ``1`` OR ``Address`` for list of addresses in srt ral list
        - ``2`` OR ``Flags`` for list of flags in srt ral list
        - ``3`` OR ``Tag`` for list of tag in srt ral list
        - ``4`` OR ``Rediscover Time`` for list of redisctime in srt ral list
        - ``5`` OR ``Resets`` for list of resets in srt ral list
        - ``0`` OR ``all`` for all above (1-5) values) as a python like-tuple
        
        ``data`` values are case-sensitive.

        = Examples =
        |        =Keyword=    |     =Data=     |     =Node=     |                                =Comment=                              |
        | `Show SRT RAL Data` |       all      | 0001:0045:0a26 | This will get list of all values in route accept list for given Node  |
        | `Show SRT RAL Data` |     Address    |                | This will get list of addresses in route accept list for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
        
        try:
            tablename = 'srt_ral show'
            ral_list_data = self._get_ral_data(node, tablename, secure_run)
            self._logger().info(ral_list_data)
        except Exception as e:
            self._logger().exception("Could not get data from srt RAL data: {}".format(e))
            raise Exception("Could not get data from srt RAL data: {}".format(e))
        else:
            if(ral_list_data == {}):
                self._logger().debug("Srt RAL Data is empty")
                raise Exception("Srt RAL Data is empty")
            try:
                if(data=='all' or data == '0'):
                    return ral_list_data
                else:
                    data_list= ral_list_data[data]
                    self._logger().info(data_list)
                    return data_list
            except KeyError as e:
                self._logger().exception("Invalid data '{}'".format(data)) 
                raise Exception("Invalid data '{}'".format(data))
             
    def _get_ral_data(self, node, tablename, secure_run):
        """
        This makes and returns the python-like dictionary of the given table ``tablename``.
        The ``tablename`` is supposed to be a name of a net mgr command which outputs 
        a table-like string considering the first line of the output is excluded.
        Otherwise it will raise ``NotATableError``. 
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        ``Note:`` It assumes that the header names and their corresponding values are separated 
        by at least 1 space. No value in the table-like string should be empty.
        """
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
            command = net_mgr_and_node + ' ' + tablename
            output = Connection.execute_command(self,command)
            self._logger().info(output)
            if(output.strip() == ''):
                return {} 
                        
            # split into lines/rows
            output_ = output.split('\n')
            
            # remove empty lines
            while('' in output_):
                output_.remove('')
            
            # remove spaces in a value
            tmp = []
            for line in output_:
                line = re.sub(': +', ':', line)
                tmp.append(line)
            output_ = tmp
            
            # remove multiple spaces between values
            tmp = []
            for line in output_:
                line = re.sub(' +', ' ', line)
                tmp.append(line)
            output_ = tmp
            
            # handle headers names with spaces
            headers = output_[0]
            if('Rediscover' in headers):
                headers = re.sub('Rediscover Time','Rediscover_Time', headers)
                output_[0] = headers
            
            # split into columns 
            tmp = []
            for line in output_:
                line = line.split(' ')
                tmp.append(line)
            output_ = tmp
            
            # remove empty values
            for alist in output_: 
                while('' in alist):
                    alist.remove('')
                    
            # make modified headers to original headers again
            tmp = []
            for index, a_header in enumerate(output_[0]):
                if a_header == 'Rediscover_Time':
                    output_[0][index] = 'Rediscover Time'
            
            table_header_len = len(output_[0])
            for alist in output_:
                if(table_header_len != len(alist)):
                    raise NotATableError
                
            table = {column[0]:list(column[1:]) for column in zip(*output_)}
            self._logger().debug(table)
            return table
        except NotATableError:
            self._logger().exception("NotATableError Occured")
            raise NotATableError 
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        
    def clear_srt_RAL(self, node=None, secure_run = True):
        """This keyword clears the SRT RAL data of provided node.
        
        This takes 1 optional argument ``node``.
         
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails
        
        This returns ``Ok`` on success.
        
        = Examples =
        |     =Keyword=   |     =Node=     |                      =Comment=                     |
        | `Clear SRT RAL` | 0001:0045:0a26 | This will clears the SRT RAL data for given Node   |
        | `Clear SRT RAL` |                | This will clears the SRT RAL data for default Node |
        
        A special value ``NAG`` (case-sensitive) to ``node`` enables ``-i`` option of net mgr and command is sent to NIC Attached to Gwncc daemon.
        
        By default, secure net mgr command ``net_mgrS`` is used, it can be changed by providing a false value to ``secure_run``.
        
        """
        node = node or self.get_current_node()
        if (not node):
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command") 
                          
        try:
            if(secure_run):
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[1] + ' -d ' + node
            else:
                net_mgr_and_node = self._net_mgr()[2] + ' -i' if node == 'NAG' else self._net_mgr()[0] + ' -d ' + node
                
            self._logger().info("Clearing SRT RAL data")
            command = net_mgr_and_node + ' srt_ral clear'
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            self._logger().info('Executed command for NIC with IP: {}'.format(node))
        except Exception:
            self._logger().exception("Clearing SRT RAL data failed: {}".format(output))
            raise Exception("Clearing SRT RAL data failed: {}".format(output))
        return output
    
    
