#!/usr/bin/env python

import re
import sys
import os
from os.path import abspath, dirname, join
from setuptools import setup

PKGVERSION='2.2'
REQUIREMENTS=[]
REQUIREMENTS = ['wheel']
REQUIREMENTS.append('robotframework == 4.1')
REQUIREMENTS.append('cryptography == 36.0.2')
REQUIREMENTS.append('paramiko >= 1.15.3')
REQUIREMENTS.append('pytz >= 2019.3')
REQUIREMENTS.append('psycopg2-binary == 2.8.6')
REQUIREMENTS.append('psycopg2 == 2.8.6')
REQUIREMENTS.append('azure-devops == 6.0.0b2')
REQUIREMENTS.append('requests >= 2.23.0')
REQUIREMENTS.append('scp >= 0.13.2')
REQUIREMENTS.append('pysmb == 1.1.28')
REQUIREMENTS.append('typing >= 3.7')
REQUIREMENTS.append('robotframework-pabot == 2.0.1')
REQUIREMENTS.append('sqlite-web >= 0.3.6')
REQUIREMENTS.append('pymsteams == 0.1.13')
REQUIREMENTS.append('json2html >= 1.3.0')
REQUIREMENTS.append('bs4 >= 0.0.1')
REQUIREMENTS.append('lxml >= 4.5.2')
REQUIREMENTS.append('robotframework-csvlib >= 1.0.2')
REQUIREMENTS.append('robotframework-sshlibrary >= 3.6.0')
REQUIREMENTS.append('robotremoteserver == 1.1')
REQUIREMENTS.append('shareplum == 0.5.1')

CLASSIFIERS = '''
Development Status :: 5 - Production/Stable
License :: Itron
Intended Audience :: Automation Engineers
Operating System :: OS Independent
Programming Language :: Python
Topic :: Software Development :: Testing
Framework :: Robot Framework
Framework :: Robot Framework :: Library
'''.strip().splitlines()

setup(
	name='KaizenBot-Linux',
	version=PKGVERSION,
	description='KaizenBot core framework for Linux',
	author='KaizenBot Team',
	author_email='Sirajdeen.Hameedkamsa@itron.com,Rajasekhar.Inguva@itron.com',
	url='https://www.itron.com/',
	keywords='KaizenBot',
	platforms='any',
	classifiers=CLASSIFIERS,
	install_requires=REQUIREMENTS,
    include_package_data=True,
	python_requires='>=3.6',
	packages=['kaizenbot']
)

