**AppServLibrary - KaizenBot Framework**

    Introduction
    Installation
    Example
    Usage
    Guideline
    Support and contact

**Introduction**

AppServLibrary is a KaizenBot test library for AppServ functionality on Gen5Riva meter and it can be extended easily with libraries implemented using Python.

KaizenBot Framework is operating system and application independent. The core framework is implemented using Python 3(i.e 3.6). The framework has a rich ecosystem around it consisting of various generic libraries related to various functionalities of Gen5 Riva meters.

"AppServLibrary - KaizenBot Framework" development is sponsored by Itron.

**Installation**

Each individual libraries of KaizenBot were hosted on the pypi server provided by Itron. [http://kaizenbot-azure:18080/]

If you already have Python with pip installed and tar file available, you can simply run:

	pip install --extra-index-url=http://kaizenbot-azure:18080 --trusted-host=kaizenbot-azure KaizenBot-AppServLibrary

else if you already have AppServLibrary and you want to do an upgrade to the latest library

	pip install --upgrade --extra-index-url=http://kaizenbot-azure:18080 --trusted-host=kaizenbot-azure KaizenBot-AppServLibrary
	
else if you want to upgrade to the specific version of a Library (say: version 1.4)

	pip install --upgrade --extra-index-url=http://kaizenbot-azure:18080 --trusted-host=kaizenbot-azure KaizenBot-AppServLibrary==1.4


Below is a simple example test case for testing login to some system. You can find more examples with links to related demo projects from http://robotframework.org.

**Settings**
Documentation     A test suite with a single test for enabling given events.
Library   AppServLibrary
Suite Setup        Connect To Server    A:B:C:D    myusername   mypassword
Suite Teardown     Close Server


**Test Cases**
Enable the given event
    [Tags]    1830451    RF MAC
    [Setup]   Verify Node Is Registered     
    Disable Event    all
    Enable Event     239,240

**Usage**

Tests (or tasks) are executed from the command line using the robot command or by executing the robot module directly like python -m robot.

The basic usage is giving a path to a test (or task) file or directory as an argument with possible command line options before the path:

robot tests.robot
robot --variable BROWSER:Firefox --outputdir results path/to/tests/

Additionally there is the rebot tool for combining results and otherwise post-processing outputs:

rebot --name Example output1.xml output2.xml

**Guidelines**

Use strings consciously. Everything in robot framework test data except keywords and variables is string and it is passed to keywords as it is provided. 
    All the integers are passed as strings.
    | some keyword |           100
    100 in above example will be treated as a string by keyword some keyword.
    An integer can be passed as
    | some keyword |           ${100}
    'hello' and hello are not same strings.
    Hence | Should Be Equal | 'hello' | hello | will give FAIL as result.
Log the test step details as a good practice. Use keyword Log To Console to print anything on the console of the system and keyword Log to print anything in the log file. 
If a number of variables are used in many test data. Put the variables in variable file and import the variable file using Variable setting in test data.
If a number of steps in test data is being used repeatedly, define a keyword having those steps. If a number of such keywords are required for many test data, create a resource file defining such keywords and import the resource file using Resource setting in all such test data.

**Support and contact**

    Sirajdeen.Hameedkamsa@itron.com
	Shweta.Kaushik@itron.com
    Ayush.Goswami@itron.com
