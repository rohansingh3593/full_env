"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""

from time import sleep
from pywinauto.application import Application

# I received an error when first installing pywinauto both on my Itron laptop
# and personal laptop, something about a dll missing
#
# After reloading it a few times it worked properly
# (on my itron laptop I tried upgrading pip though I don't think that's what fixed it)

FDM_EXE_PATH = r"C:\Program Files (x86)\Itron\Field Deployment Manager\Mobile Client\Fdm.exe"
FDM_WINDOW_TITLE = "Field Deployment Manager"
FDM_PASSWORD = "Dev12345"


class FDM():
    def __init__(self, launch=True):
        self._gui = None
        self._app = None
        self._ip_addr = None
        self._launched = False
        if launch:
            self.launch()

    def __del__(self):
        if self._launched and self._app.is_process_running():
            self._app.kill()

    # SEAN DO NOT MERGE THIS CLASS/METHOD IN!! FOR TESTING ONLY SEAN
    class _logger():
        def warn(self, text):
            print(text)

    def launch(self):
        self._app = Application().start(FDM_EXE_PATH)
        self._gui = self._app[FDM_WINDOW_TITLE]
        self._launched = True

    def login(self):
        self._gui['OK'].click()
        self._gui['Edit2'].set_keyboard_focus()      # Edit2 = Password field
        self._gui['Edit2'].type_keys(FDM_PASSWORD)   # Edit2 = Password field
        self._gui['OK'].click()

    def connect_to_meter(self, ip_addr=None):
        self._gui["Gen5 Riva Electricity Meter"].click()
        self._gui["Device Control Panel"].click()
        self._gui.wait('active', 10)
        print("Adding ip")
        if ip_addr:
            self._ip_addr = ip_addr
            self._gui['TCPEdit'].set_keyboard_focus()
            self._gui['TCPEdit'].type_keys(ip_addr)
        else:
            self._ip_addr = self._gui['TCPEdit'].window_text()
        self._gui['Next'].click()

        sleep(1)
        while self._gui.child_window(auto_id='DynamicProgressModalPage').exists():
            sleep(0.2)

        result = self._gui['Static'].window_text()
        if "error" in result:
            raise Exception("Failed to connect to meter: {}".format(result))

    def get_cosem_object(self, cosem_object, item):
        """ Give a COSEM Object, and the item, and will return the value"""
        if not self.connected_to_meter():
            raise Exception("Must be connected to meter first")
        self._gui['Device Control Panel'].set_focus()
        self._gui['Device Control Panel'].click_input()

        # This must be done via mouse clicks as the 'Device Control Panel' screen does not have any automatable buttons
        list_item = 7  # Navigate to '7. Advanced Diagnostics'
        self._gui.click_input(
            coords=(200, 105+(36*list_item)), absolute=False, double=True)

        list_item = 1  # Navigate to '1. COSEM Reader'
        self._gui.click_input(
            coords=(200, 105+(36*list_item)), absolute=False, double=True)

        items = [s for s in self._gui['ListBox'].item_texts()
                 if cosem_object in s]
        if len(items) > 1:
            self._logger().warn(f"COSEM Object Argument is ambiguous. Found string in {len(items)} objects: {items}")

        self._gui['ListBox'].select(items[0])

    def connected_to_meter(self):
        if self._gui['Device Control PanelStatic'].exists():
            return True
        else:
            return False

    def quit(self):
        self._gui['Quit'].click()

    def get(self, identity):
        return self._gui[identity].window_text()


if __name__ == "__main__":
    fdm = FDM()
    fdm.login()
    fdm.connect_to_meter()
    fdm.get_cosem_object("Application Service Version", "Value")
