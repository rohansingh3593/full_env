# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""
from kaizenbot.connection import Connection
from .version import VERSION
from kaizenbot.azurelibrary import AzureLibrary
import sys, os
from robot.libraries.BuiltIn import BuiltIn
from kaizenbot.logging_robot import Loggers

from .util import Util
from .fwupgrade import FWupgrade

class AppServLibrary(Connection, AzureLibrary, Util, FWupgrade):
    """AppServLibrary is a Robot Framework test library for AppServ functionality.
    
    This document explains how to use keywords provided by AppServLibrary.
    For information about installation, support, and more please visit the
    [https://itron.sharepoint.com/:t:/s/GFW-IVV/EfEir5666s5PvJTMPrPLJigBCRlSmMGIJncnmsxuob8zBA?e=x0mGlZ|README]
    
    For more information about Robot Framework, see http://robotframework.org.
    
    """

    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    ROBOT_LIBRARY_VERSION = VERSION

    def __init__(self, pat=None):
        """AppServibrary.
        
        | Library | AppServLibrary 

        """
        self.logger = None
        AzureLibrary.__init__(self, pat)
        super().__init__()

    def _logging_name(self):
        try:
            kzbot_str = 'KaizenBot'
            project_str = BuiltIn().get_variable_value('${PROJECT_NAME}')
            if not project_str:
                raise Exception
        except Exception:
            kzbot_str = 'KaizenBot'
            project_str = "AppServLibrary"
        return kzbot_str, project_str

    def _logger(self):
        if self.logger is None:
            log_obj = Loggers()
            self.logger = log_obj.get_logger(self._logging_name()[0] + '-' + self._logging_name()[1])
            return self.logger
        else:
            return self.logger
