# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""
import re
import os
import time
import xml.etree.ElementTree as ET
from zipfile import ZipFile
import collections
# from .fdm import FDM
import urllib.request
import shutil

import subprocess
from bs4 import BeautifulSoup
from lxml import etree

from kaizenbot.connection import Connection
from kaizenbot.logging_robot import Loggers


class Util:
    """Util is a Robot Framework test library for AppServ functionality.

    This document explains how to use keywords provided by Util.
    For information about installation, support, and more please visit the
    [https://itron.sharepoint.com/:t:/s/GFW-IVV/EfEir5666s5PvJTMPrPLJigBCRlSmMGIJncnmsxuob8zBA?e=x0mGlZ|README]

    For more information about Robot Framework, see http://robotframework.org.

    """

    def __init__(self):
        pass

    def _logger(self):
        raise NotImplementedError

    def _local_get_release(self, type):
        """ This locally downloads the release file
        ``type`` is the image type
        types: Appserve, pubsubagent

        This returns the release package name

        = Examples =
        |       =Keyword=         |     =type=      |
        |   `Local Get Release`   |     appserve    |
        """
        try:
            if (type.lower() == "appserve"):
                path = 'http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/latest_test/bionic-x86_64/TargetDebug/FinalPackage/'
                prefix = 'DI-AppServices-Package'
            elif (type.lower() == "pubsubagent"):
                path = '//itron.com/raleigh/Distintel/Agent/PubSubAgent/'
                prefix = 'ItronPubSubAgent'
            else:
                self._logger().info("Invalid type")
                raise Exception("Invalid type")

            self._logger().info(path)

            if (path.startswith("http")):
                #URL method
                html_page = urllib.request.urlopen(path)
                soup = BeautifulSoup(html_page, "html.parser")
                for link in soup.findAll('a'):
                    if (link.get('href').startswith(prefix)):
                        package = link.get('href')
                        break

                self._logger().info(package)
                urllib.request.urlretrieve(path+package, "{}\{}".format(os.getcwd(), package))

            else:
                #copyfile method
                full_list = [os.path.join(path,i) for i in os.listdir(path)]
                time_sorted_list = sorted(full_list, key=os.path.getmtime)
                package_path = time_sorted_list[-1] + '/' + prefix + '/Release/'
                self._logger().info(package_path)
                for file in [os.path.join(package_path,i) for i in os.listdir(package_path)]:
                    if (file[len(package_path):].startswith(prefix)):
                        package = file[len(package_path):]
                        break;
                self._logger().info(package)
                try:
                    shutil.copyfile(package_path+package, os.getcwd() + '/' + package)
                except shutil.SameFileError:
                    self._logger().info("Error: Source and destination represents the same file.")
                # If destination is a directory.
                except IsADirectoryError:
                    self._logger().info("Error: Destination is a directory.")
                # If there is any permission issue
                except PermissionError:
                    self._logger().info("Error: Permission denied.")
                # For other errors
                except:
                    self._logger().info("Error occurred while copying file.")

        except Exception as e:
            self._logger().exception("could get release: {}".format(e))
            raise Exception

        self._logger().info(os.getcwd())
        return package

    def local_unzip(self, zipfile, files=None, path=None):
        """ This locally unzips a file
        ``zipfile`` is zipfile to unzip
        ``files`` is optional and contains files to be unzipped
        ``path`` is optional and is the directory to unzip

        This returns a list of unzip files

        = Examples =
        |  =Keyword=    |     =zipfile=      |     =files=            |    =path   |         =Comment=                   |
        | `Local Unzip` |  appserve.zip      |   ReleaseManifest.xml  |            |  Unzips ReleaseManifest.xml only    |
        | `Local Unzip` |  appserve.zip      |        .tar.gz         |            |  Unzips matching string             |
        | `Local Unzip` |  appserve.zip      |                        |     temp   |  Unzips all files temp folder       |
        """
        unzip = []
        try:
            with ZipFile(zipfile, 'r') as zipObj:
                # Get a list of all archived file names from the zip
                listOfFileNames = zipObj.namelist()
                self._logger().info(listOfFileNames)
                if (files):
                    # Iterate over the file names
                    for fileName in listOfFileNames:
                        if re.search(files, fileName):
                            # Extract a single file from zip
                            zipObj.extract(fileName, path=path)
                            unzip.append(fileName)
                else:
                    zipObj.extractall(path=path)
                    unzip = listOfFileNames

        except Exception as e:
            self._logger().exception("could not read zipfile: {}".format(e))
            raise Exception

        self._logger().info("Unzipped files: {}".format(unzip))
        return unzip

    def run_helper_cmd(self, access_type, lid_name, value=None):
        """ This keyword runs the helper command
        ``access_type`` is mandatory and is either read or write
        ``lid_name`` is mandaory and is lid to process
        ``value`` is optional and is use when access_type is write

        = Examples =
        |    =Keyword=     |  =access_type=   |            =lid_name=                 |  =value=  |                =Comment=                               |
        | `Run Helper Cmd` |      read        |   ILID_DATASERVER_APPSERV_FW_VERSION  |           | This will return appsere fw version                    |
        | `Run Helper Cmd` |      write       |   ILID_APP_SERVICE_PKG_INSTALLED      |    false  | This will set ILID_APP_SERVICE_PKG_INSTALLED to false  |

        """
        try:
            if (access_type.lower() == "read"):
                type = 'r' 
            elif (access_type.lower() == "write"):
                type = 'w'
                if (value==None):
                    self._logger().info("Write access missing value")
                    raise Exception("Write access missing value")
            else:
                self._logger().info("Invalid type")
                raise Exception("Invalid type")

            command = "Helper-CmdList.sh -{} {} {}".format(type, lid_name, value) 
            output = Connection.execute_command(self, command)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception("could not run command: {}".format(e))
            raise Exception
        else:
            return output.rstrip()

    def run_ps_cmd(self, process, column=None):
        """ This keyword runs PS command
        ``process`` is mandatory and is the process to query
        ``column`` is optional and if entered it will return the requested column
            column values: PID, USER, VSZ, STAT, COMMAND

        = Examples =
        |    =Keyword=   |  =process=     | =column= |                =Comment=                 |
        | `Run Ps Cmd`   |   DataServer   |          | This will return the full string         |
        | `Run Ps Cmd`   |   DataServer   |   PID    | This will return the PID for DataServer  |

        """
        fields = [ 'pid', 'user', 'vsz', 'stat', 'command']
        do_awk = 0
        if (column):
            for i, val in enumerate(fields, 1):
                if (column.lower() == val):
                    do_awk = i

        try:
            output = Connection.execute_command(self, 'ps | grep {} | grep -v grep | awk \'{{print ${}}}\''.format(process, do_awk))
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            return output.rstrip()

    def run_transaction_process(self, event, command, param, value=None):
        """ This keyword runs a transaction process
        ``event`` is mandatory and is the event type
            Supports: 'MUSE_V1' only
        ``command`` is mandatory and is the command type
            MUSE_V1 commands: ReadLid, WriteLid
        ``param`` is mandatory and is the parameter for the command
            MUSE_V1 params: ILIDs
        ``value`` is optional and used when access_type is write

        = Examples =
        |    =Keyword=                |  =event=  | =command=  |            =param=                     |  =value=  |                =Comment=                               |
        | `Run Transaction Process`   |   MUSE_V1 |  ReadLid   |   ILID_DATASERVER_APPSERV_FW_VERSION   |           | This will return appsere fw version                    |
        | `Run Transaction Process `  |   MUSE_V1 |  WriteLid  |   ILID_APP_SERVICE_PKG_INSTALLED       |    false  | This will set ILID_APP_SERVICE_PKG_INSTALLED to false  |
        """
        self._logger().debug("Transaction Process command")
        if ( event=="MUSE_V1"):
            try:
                if (command=="ReadLid"):
                    output = self.execute_command('TransactionProcess --event="MUSE_V1;{};{}"'.format(command, param))
                    self._logger().info(output)
                elif (command=="WriteLid"):
                    if (value):
                        output = self.execute_command('TransactionProcess --event="MUSE_V1;{};{};{}"'.format(command, param, value))
                        self._logger().info(output)
                    else:
                        self._logger().info("WriteLid missing value")
                        raise Exception("WriteLid missing value")
                else:
                    self._logger().info("Invalid MUSE_V1 command")
                    raise Exception("Invalid MUSE_V1 command")

                final_val = None
                if '=' in output:
                    match = output.rpartition('=')
                    self._logger().debug(match)
                    val=match[2]
                    final_val=val.strip()
                    self._logger().debug(final_val)
                elif ':' in output:
                    match = output.rpartition(':')
                    self._logger().debug(match)
                    val=match[2]
                    final_val=val.strip()
                    self._logger().debug(final_val)

                if final_val:
                    return final_val
                else:
                    self._logger().debug("Could not fetch Run transaction process data for ILID {}".format(param))
                    return
            except Exception as e:
                self._logger().exception(e)
                raise Exception(e)
        else:
            self._logger().info("Invalid/Unsupported TransactionProcess command")
            raise Exception("Invalid/Unsupported TransactionProcess command")

    def run_dbus_send_cmd(self, path, message, *contents, dest="$path", print_reply=False, reply_timeout=None, type=None):
        """ Run the `dbus-send` command
        ``path`` (Required)
            Destination object path
        ``message`` (Required)
            Relative or absolute message name
            If parameter starts with a '.', then it will be appended to the path
            Any other leading character will be passed to `dbus-send` as is
        ``*contents`` (Optional)
            Array of contents arguments to pass to dbus-send
        ``dest`` (Optional, default='$path')
            `--dest` parameter. The default value for this parameter is `$path` which will 
            set the `--dest` parameter equal to the path with periods substituted for slashes
            Eg if `path=/com/itron/museplatform/ContainerManager` default will use `--dest=.com.itron.museplatform.ContainerManager`
            If `dest=''` then the dest argument will be omitted
        ``print_reply`` (Optional, default=False)
            `--print_reply`` parameter
            Supports: True, False, 'literal'
        ``reply_timeout`` (Optional)
            reply timeout in msec
        ``type`` (Optional)
            type

        = Examples =
        |      =Keyword=      |                  =path=                  |                    =message=                    |  =contents_0=  | =contents_1...etc= | =dest= |  =print_reply=   |  =reply_timeout=   |      =type=      |
        | `Run Dbus Send Cmd` | /com/itron/museplatform/ContainerManager |                .StopAllContainer                |                |                    |        |                  |                    |                  |
        | `Run Dbus Send Cmd` |       /com/itron/owi/MasterControl       |                     .Restart                    | string:cosemd  |                    |        | print_reply=True |                    |                  |
        | `Run Dbus Send Cmd` | /com/itron/museplatform/ContainerManager | com.itron.museplatform.ContainerManager.Refresh |                |                    |        |                  |                    |                  |
        | `Run Dbus Send Cmd` |       /com/itron/owi/eismd/System        |              .VerifyCertAgainstCert             |   uint32:50    |     uint32:45      |        | print_reply=True | reply_timeout=4000 | type=method_call |
        
        """
        command = "dbus-send --system"
        dot_path = path[1:].replace("/",".")

        if dest == "$path":
            command += " --dest={}".format(dot_path)
        elif dest is not None:
            command += " --dest={}".format(dest)

        if print_reply:
            if print_reply == True:
                command += " --print-reply"
            elif print_reply in {'literal'}:
                command += " --print-reply={}".format(print_reply)
            else:
                raise ValueError("print_reply must be True, False, or 'literal'")

        if reply_timeout is not None:
            command += " --reply-timeout={}".format(reply_timeout)

        if type is not None:
            command += " --type={}".format(type)

        command += " '{}'".format(path)

        # Use relative message addressing
        if str(message)[0] == '.':
            message = "{}{}".format(dot_path, message)
        
        command += " '{}'".format(message)

        if contents:
            command += " {}".format(" ".join(contents))

        try:
            output = Connection.execute_command(self, command)
            self._logger().info(output)
            return output.strip()
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

    def run_im_prov_cmd(self, command, arg1=None, arg2=None):
        """ This keyword runs the ImProvHelper command
        ``command`` is mandatory and is the ImProvHelper command type:
            ppp, rest, RESET, mountIdle, mount, print
        ``arg1`` is optional and needed for:
            image, version, image-type, print, ReadLid, ReadTable, Dbus, decode, log
        ``arg2`` is optional abd needed for:
            WriteLid

        = Examples =
        |    =Keyword=        |    =command=   |       =arg1=            |     =arg2=    |         =Comment=                                  |
        | `Run Im Prov Cmd`   |      image     |    <path to image >     |               |   Download the image provided in 'image path'      |
        | `Run Im Prov Cmd`   |      RESET     |                         |               |   This will perform GMR                            |
        """

        self._logger().debug("ImProvHelper command")

        # "print" has an optional command so it is in both arg0 and arg1
        arg0_commands = {"ppp","reset","RESET","mountIdle","mount","print"}
        arg1_commands = {"image","version","image-type","print","ReadLid","ReadTable","Dbus","decode","log"}
        arg2_commands = {"WriteLid"}
        try:
            if (command in arg2_commands) and arg1 and arg2:
                output = self.execute_command('ImProvHelper.sh --{} {} {}'.format(command, arg1, arg2))
            elif (command in arg1_commands) and arg1:
                output = self.execute_command('ImProvHelper.sh --{} {}'.format(command, arg1))
            elif (command in arg0_commands):
                output = self.execute_command('ImProvHelper.sh --{}'.format(command))
            else:
                self._logger().info("Invalid or Unsupported command")
                raise Exception("Invalid or Unsupported command")

            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

        else:
            return output.rstrip()

    def _to_str_list(self, string, sep = '/' ):
        return string.split(sep)

    def run_cat_cmd(self, file, grep_str, cat_options=None, grep_options=None):
        """ This keyword runs CAT command
        ``file`` is mandatory and is the file to cat
        ``grep_str`` is mandatory and is the string to grep
        ``cat_options`` is optional and is the cat argument
        ``grep_options`` is optional and is the grep argument

        = Examples =
        |    =Keyword=   |    =file=     | =grep_str=  |   =cat_options=  |   =grep_options=   |            =Comment=                 |
        | `Run Cat Cmd`  |  agent_log    |    result   |                  |       -ve          |  This will return the full string    |

        """
        try:
            if ( cat_options and  grep_options):
                output = Connection.execute_command(self, 'cat {} {} | grep {} {}'.format(cat_options, file, grep_options, grep_str))
            elif ( cat_options ):
                output = Connection.execute_command(self, 'cat {} {} | grep {}'.format(cat_options, file, grep_str))
            elif ( grep_options ):
                output = Connection.execute_command(self, 'cat  {} | grep {} {}'.format(file, grep_options, grep_str))
            else:
                 output = Connection.execute_command(self, 'cat  {} | grep {}'.format(file, grep_str))

            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            return output.split('\n')

    def find_event_record(self, record, path):
        """ This keyword finds an event record via 'cdsEventLogDecoderV2'
        ``record`` (Required) The name of the record we are searching for
        ``path`` (Required) Directory where logs reside

        Returns the output of any found event records

        = Examples =
        |      =Keyword=      |       =record=       |         =path=         |
        | `Find Event Record` | InstallDIAppServices | /tmp/logs/TM-TP/DEBUG/ |

        """
        try:
            command = "cdsEventLogDecoderV2 -f1 -i {} | grep \"{}\"".format(path, record)
            return Connection.execute_command(self, command)
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def process_is_running(self, process_name):
        """ This keyword returns 'True' if the given process is running, otherwise 'False'
        ``process_name`` (Required) The name of the process to check

        = Examples =
        |       =Keyword=      |  =process_name=  |
        | `Process Is Running` | ContainerManager |
        | `Process Is Running` | ThirdPartyAgent  |

        """
        try:
            command = "pgrep -alf {}".format(process_name)
            output = Connection.execute_command(self, command)
            return process_name in output
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def select_from_database(self, table, columns='*', order_by=None, limit=1, prune=True, where=None, wordcount=None, retries=5):
        """This keyword will return records from muse database
        Beware that all arguments must be case sensitive

        ``table`` (Required) The table to select from
        ``columns`` (Optional) The columns to select (default='*' for all)
        ``order_by`` (Optional) A column name to order by (such as 'LocalTimeStampInMs')
        ``limit`` (Optional) Limit the number of record rows to be returned (Default is 1)
        ``prune`` (Optional) prevent returning lists and dicts when possible. Explained below... (Default is True)
        ``where`` (Optional) query database by
        ``wordcount`` (Optional) returns the wordcount
        ``retries`` (Optional) database retry count
        Will return database as a dictionary with the column names as the keys

        When prune=True, the following will occur:
            If there is only one row (default limit=1) then they dict values will be strings
            If there are multiple rows the dict values will return as tuples (lists)

            If there is only one column selected, return will either be a string or tuple (as stated above) without the dict key

            Therefore when selecting a single column with limit=1, will return a single string

        = Examples =
        |        =Keyword=       |      =table=     | =columns= |     =order_by=     | =limit= | =prune= |
        | `Select From Database` | ContainerOverlay |           |                    |         |         |
        | `Select From Database` | log_eventrecords |  IsAlarm  | LocalTimeStampInMs |    2    |  True   |

        """
        if order_by:
            order_by_cmd = "ORDER BY " + order_by
        else:
            order_by_cmd = ""

        if limit:
            limit_cmd = "LIMIT " + str(limit)
        else:
            limit_cmd = ""

        if where:
            where_cmd = "where " + where
        else:
            where_cmd = ""

        # wordcount disables header
        if wordcount:
            header = ""
        else:
            header = "-header"

        for i in range(retries):
            try:
                query = "SELECT {} FROM {} {} {} {};".format(columns, table, order_by_cmd, where_cmd, limit_cmd)
                # Replace single quotes with double, since we encase the query in single quotes below
                query = query.replace("'", "\"") 
                command = "sqlite3 /usr/share/itron/database/muse01.db {} -list '{}'".format(header, query)
                str_response = Connection.execute_command(self, command).strip()

                # Do some processing so we can return as a dict
                try:
                    data = [row.split('|') for row in str_response.split('\n')]

                    index = 0
                    # Make sure we have info with header and check for XML format
                    if (len(data) > 1):
                        for entry in data[1]:
                            if ("<" in entry and ">" in entry):
                                xml_file = entry + '\n'
                                j = 0
                                for line in data[index:]:
                                    xml_file += ''.join(line) + '\n'
                                    j += 1
                                    if (''.join(line) == ''.join(data[index])[:1] + '/' + ''.join(data[index])[1:] ):
                                        break

                                data[1][index] = xml_file
                                del(data[index:index+j])
                            index += 1

                    final_response = {}

                    if (wordcount):
                        final_response = len(str_response.replace('\n', '').strip())
                    else:
                        for column in list(zip(*data)):
                            if len(column[1:]) == 1:
                                # If there is only one row, then values for each row should be a string
                                final_response[column[0]] = column[1]
                            else:
                                # If there are multiple rows, they will be returned as a tuple
                                final_response[column[0]] = column[1:]

                        if len(final_response) == 1:
                            # If there is one column with one value, return without column key
                            final_response = list(final_response.values())[0]

                    return final_response
                except Exception as e:
                    self._logger().exception("Could not return response as a dict. Will return as a string instead\n{}".format(e))
                    return str_response
            except Exception as e:
                if i < retries - 1 and "database is locked" in str(e):
                    self._logger().info("Could not run command, retry:{}/{} :{}".format(i+1, retries, e))
                    continue
                else:
                    self._logger().exception("Could not run command, retried out: {}".format(e))
                    raise RuntimeError(e)
            break

    def cosemtest_obis(self, get_set, obis_code, obis_attribute, obis_class, obis_sap=None, obis_data=None):
        """Get an obis value through the cosemtest interface
        !! Returns raw value for now, future implementation will include the decoded value through the use of the dlms tool !!
        ``get_set`` (Required) Either `get or `set` depending on if it is desired to get or set the obis data
        ``obis_code`` (Required) Obis code to get/set
        ``obis_attribute`` (Required)
        ``obis_class`` (Required)
        ``obis_sap`` (Optional)
        ``obis_data`` (Required if `get_set`==`set`)

        = Examples =
        |     =Keyword=    | =get_set= |  =obis_code=  | =obis_attribute= | =obis_class= | =obis_sap= | =obis_data= |
        | `Cosemtest Obis` |    get    | 1-9:0.2.0.255 |         2        |       1      |    120     |             |
        | `Cosemtest Obis` |    set    | 1-9:0.2.0.255 |         2        |       1      |    120     |             |

        """
        get_set = get_set.lower()
        if get_set not in ['get','set']:
            raise ValueError("Value of get_set must either be 'get' or 'set'")
        try:
            if obis_sap:
                obis_sap_cmd = 'sap={}'.format(obis_sap)
            else:
                obis_sap_cmd = ''

            command = "cosemtest {}obis obis={} attribute={} class={} {}".format(
                get_set, obis_code, obis_attribute, obis_class, obis_sap_cmd)
            if get_set == 'set':
                if obis_data is None:
                    raise ValueError("obis_data arg cannot be 'None' when get_set='set'")
                command += " data={}".format(obis_data)
            response = Connection.execute_command(self, command)
            return response.split('Result:')[-1].strip()
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def SDI_get_obis(self, meter_ip_addr, obis_code, obis_title):
        """Retrieve an obis value from the meter through the use of the SDI.exe tool
        ``meter_ip_addr`` (Required) IP address of meter to retrieve obis data from
        ``obis_code`` (Required) obis code to retrieve
        ``obis_title`` (Required) title of obis to retrieve

        = Examples =
        |    =Keyword=   | =meter_ip_addr= |  =obis_code=  |  =obis_title=   |
        | `SDI Get Obis` |  10.176.101.65  | 1.9.0.2.0.255 | Meter OBIS code |

        """
        try:
            command = r"""C:\ToolsSuite\SDI.exe --nosa --ip {} --obis "{}, {}" """.format(meter_ip_addr, obis_code, obis_title)
            resp = Connection.execute_command(self, command)
            try:
                if "Data not available" in resp:
                    return "Data not available"
                else:
                    return re.search('Value="(.*)"', resp).group(1)
            except Exception as e:
                err_msg = "SDI could not complete succesfully. Response was: {}".format(resp)
                self._logger().exception(err_msg)
                raise RuntimeError("{}\n{}".format(err_msg, e))
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def update_featureid(self, featureid, folder, param, value):
        """
        Updates the Feature ID configuration file.
        Beware that all arguments must be case sensitive

        = Examples =
        |    =Keyword=       | =Featureid= |      =folder=       |    =param=     | =value= |
        | `Update Featureid` |   50593776  |  DIBasicTestEvent1  |  EventActive   |    1    |

        """
        try:
            featureconfig = Util.select_from_database(self, table='featureconfiguration', columns='featureid, configurationid, level', limit=100)
            exist = None

            for key, id in featureconfig.items():
                if key == "FeatureId" and featureid in id:
                    exist = featureid
                    break

            if ( exist == None ):
                err_msg = 'FeatureId: "{}".format(featureid) not found'
                self._logger().exception(err_msg)
                raise RuntimeError(err_msg)

            config_xml = '{}.xml'.format(featureid)
            config_xmlgz = config_xml + ".gz"

            #clean up node files if exist
            if (Connection.file_exists(self, '{}'.format(config_xmlgz))):
                Connection.execute_command(self, 'rm {}'.format(config_xmlgz))
            if (Connection.file_exists(self, '{}'.format(config_xml))):
                Connection.execute_command(self, 'rm {}'.format(config_xml))

            # Generates .xml.gz file
            configfile = Util.select_from_database(self, table='featureconfiguration', columns='writefile("{}", Data)'.format(config_xmlgz), where='FeatureId={} and Level = 5'.format(featureid) )

            # Convert to .xml and send to node
            if (Connection.file_exists(self, '{}'.format(config_xmlgz))):
                Connection.execute_command(self, 'gunzip {}'.format(config_xmlgz))
                Connection.get_file(self, config_xml)
            else:
                err_msg = '"{}.xml.gz".format(featureid) not found'
                self._logger().exception(err_msg)
                raise RuntimeError(err_msg)

            # Parse and set the config file and send back to node
            tree = ET.parse(config_xml)
            root = tree.getroot()
            for elem in root.iter('folder'):
                if elem.get('name') == folder:
                    self._logger().info("Found folder: " + elem.get('name'))
                    for subelem in elem:
                        if subelem.get('name') == param:
                            self._logger().info("Found param: " + subelem.get('name'))
                            subelem.set('value', value)
                            tree.write(config_xml)
                            Connection.put_file(self, config_xml, '/root/')
                            if os.path.exists(config_xml):
                                os.remove(config_xml)
                            Connection.execute_command(self, 'gzip {}'.format(config_xml))
                            # Update config db
                            Util._update_database(self, 'featureconfiguration', 'data', 'FeatureID={} and Level=5'.format(featureid), config_xmlgz)
                            #clean up host file
                            Connection.execute_command(self, 'rm {}'.format(config_xmlgz))
                            return

            #clean up node files on error
            if (Connection.file_exists(self, '{}'.format(config_xmlgz))):
                Connection.execute_command(self, 'rm {}'.format(config_xmlgz))
            if (Connection.file_exists(self, '{}'.format(config_xml))):
                Connection.execute_command(self, 'rm {}'.format(config_xml))

            #clean up host files on error
            if os.path.exists(config_xml):
                os.remove(config_xml)
            if os.path.exists(config_xmlgz):
                os.remove(config_xmlgz)

            err_msg = 'Not able to find folder:{} or parameter:{} in config file!'.format(folder, param)
            self._logger().exception(err_msg)
            raise RuntimeError(err_msg)
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)
    
    def run_tail_command(self, duration, path, num_lines=10):
        """ This keyword is for basic sanity test to execute tail command for Agent cout log to verify agent is functional through publish messages and it can used to general use for other logs too'
        ``path`` (Required) The path of the agent log to check
        ``num_lines`` (Optional, default=10) Number of lines to tail prior to follow

        = Examples =
        |     =Keyword=      | =duration= |                          =path=                                 |
        | `run_tail_command` |     30     |  /tmp/container/50593792/rootfs/tmp/agent/0302ff77/0302ff77_log |
        """
        try:
            command = "tail -n {} -F {}".format(num_lines, path)
            Connection.execute_command(self, command=command, timeout=duration, BackgroundRun=True, OutputFile='/mnt/common/output')
            time.sleep(int(duration))
            res= Connection.execute_command(self, 'cat /mnt/common/output.log')
            #clean up file
            Connection.execute_command(self, 'rm {}' .format('/mnt/common/output.log'))
            return res

        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def _update_database(self, table, column, where, xml_file, retries=5):
        for i in range(retries):
            try:
                cmd = 'sqlite3 /usr/share/itron/database/muse01.db ' \
                        '\'update {} set {}=readfile("{}") where {};' \
                        '\''.format(table, column, xml_file, where)
                Connection.execute_command(self, '{}'.format(cmd))
            except Exception as e:
                if i < retries - 1 and "database is locked" in str(e):
                    self._logger().info("Could not update db, retry:{}/{} :{}".format(i+1, retries, e))
                    continue
                else:
                    self._logger().exception("Could not update db, retried out: {}".format(e))
                    raise RuntimeError(e)

            break

    def update_policyfile(self, agentid, command, xpath, element="", value="", new_value=None):
        """
        Update policy file by Agent ID.  Supported commands are 'disable', 'enable', 'remove', 'add', 'insert', 'append' and 'update'.
        ``new_value`` is optional and used when command is 'update'
        Beware that all arguments must be case sensitive

        This returns the element or comment line which got updated.

        = Commands =
        ``disable`` - comment element
        ``enable`` - uncomment element
        ``remove`` - remove element
        ``add`` - add attribute to existing element
        ``append`` - add new element
        ``insert`` - add new tree path
        ``update`` - update attribute of existing element from value to new_value


        = Examples = 
        |    =Keyword=        |   =Agentid= | =command= |           =xpath=                                                      |   =element=                     |           =value=             |    =new_value=    |
        | `Update Policyfile` |   50528119  |  disable  | Agent/Permissions/Permission                                           |     name                        |    Data:Subscription:Agent    |                   |
        | `Update Policyfile` |   50528119  |  add      | Agent/Functions/Features/Feature/[@ID="50593776"]/NetworkData/Upstream | dailyAlarmWarningLimit          |              10               |                   |
        | `Update Policyfile` |   50528119  |  append   | Agent/Functions/Features/Feature/[@ID="50593776"]/NetworkData          | Upstream/dailyAlarmWarningLimit |              10               |                   |
        | `Update Policyfile` |   50528119  |  remove   | Agent/Functions/Features/Feature/[@ID="50593776"]/NetworkData          |                                 |                               |                   |
        | `Update Policyfile` |   50528119  |   insert  | Agent/Functions                                                        | MeterEvents                     |                               |                   |

        """
        valid_commands = { "enable", "disable", "update", "add", "append", "remove", "insert" }
        ret = None
        command = command.lower()
        if command not in valid_commands:
            raise ValueError("Invalid command type!  Valid commands are {}".format(valid_commands))

        if command == "update" and new_value == None:
            raise ValueError("Update command missing new_value!")

        try:
            policyfile = Util.select_from_database(self, table='DIPolicyFile', columns='PolicyFile', where='AgentId={}'.format(agentid), limit=100)

            policyfile_xml = 'policyfile_{}.xml'.format(agentid)

            #clean up node file if exist
            if (Connection.file_exists(self, '{}'.format(policyfile_xml))):
                Connection.execute_command(self, 'rm {}'.format(policyfile_xml))

            # Generates .xml file
            configfile = Util.select_from_database(self, table='DIPolicyFile', columns='writefile("{}", PolicyFile)'.format(policyfile_xml), where='AgentId={}'.format(agentid) )

            # Convert to .xml and send to node
            if (Connection.file_exists(self, '{}'.format(policyfile_xml))):
                Connection.get_file(self, policyfile_xml)
            else:
                err_msg = '"{}".format(policyfile_xml) not found'
                self._logger().exception(err_msg)
                raise RuntimeError(err_msg)

            # Parse and set the policy file and send back to node
            tree = etree.parse(policyfile_xml)
            root = tree.getroot()
            updated_xml = None

            if command == "enable":
                comments = tree.xpath('//comment()')
                for c in comments:
                    if element in str(c) and value in str(c):
                        ret = c
                        self._logger().info("Found comment {}={}".format(element, value))
                        elem = str(c).lstrip('<!--').rstrip('-->')
                        self._logger().info("passed")
                        c.getparent().replace(c, etree.fromstring('<{}>'.format(elem)))
                        
                        updated_xml = True
                        break
            elif command == "disable" or command == "update":
                for elem in root.findall("./{}".format(xpath)):
                    if elem.get(element) == value:
                        self._logger().info("Found {}={}".format(element, value))
                        ret = etree.tostring(elem).decode()
                        if command == "disable":
                            elem.getparent().replace(elem, etree.Comment(etree.tostring(elem).strip().decode()))
                        else:
                            elem.set(element, new_value)

                        updated_xml = True
                        break
            elif command == "append":
                elem = root.find("./{}".format(xpath))
                ret = etree.tostring(elem).decode()
                subelem, attr = element.split('/')
                etree.SubElement(elem, subelem, {attr: value})
                updated_xml = True
            elif command == "remove":
                elem = root.find("./{}".format(xpath))
                ret = etree.tostring(elem).decode()
                elem.getparent().remove(elem)
                updated_xml = True
            elif command == "insert":
                elem = root.find("./{}".format(xpath))
                ret = etree.tostring(elem).decode()
                meter_events = etree.Element(element)
                elem.append(meter_events)
                updated_xml = True
                
            else:
                elem = root.find("./{}".format(xpath))
                ret = etree.tostring(elem).decode()
                elem.set(element, value)
                updated_xml = True

                    
            if ( updated_xml != None ):
                tree.write(policyfile_xml, encoding="UTF-8", xml_declaration=True)
                Connection.put_file(self, policyfile_xml, '/root/')

                if os.path.exists(policyfile_xml):
                    os.remove(policyfile_xml)

                # Update config db
                Util._update_database(self, 'DIPolicyFile', 'PolicyFile', 'AgentID={}'.format(agentid), policyfile_xml)
                #clean up host file
                Connection.execute_command(self, 'rm {}'.format(policyfile_xml))
                return ret

            #clean up node file on error
            if (Connection.file_exists(self, '{}'.format(policyfile_xml))):
                Connection.execute_command(self, 'rm {}'.format(policyfile_xml))

            #clean up host files on error
            if os.path.exists(policyfile_xml):
                os.remove(policyfile_xml)

            err_msg = 'Not able to find {}={} at xpath:{} in policyfile!'.format(element, value, xpath)
            self._logger().exception(err_msg)
            raise RuntimeError(err_msg)
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def kill_process(self, name=None, pid=None):
        """ Terminate a process by either name or pid.
            One of either `name` or `pid` must be specified
        ``name`` process name
        ``pid`` process ID

        = Examples =
        |    =Keyword=   |   =name=    | =pid= |
        | `Kill Process` | DITestAgent |       |
        | `Kill Process` |             |  134  |

        """
        try:
            if name:
                Connection.execute_command(self, "pkill -9 {}".format(name))
            elif pid:
                Connection.execute_command(self, "kill -9 {}".format(pid))
            else:
                raise ValueError("One of `name` or `pid` must be specified")
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def cbor_decode(self, hex_string):
        self._logger().info("Hex string to cbor decode: {}".format(hex_string))
        try:
            char = hex_string[5:19]
            tot_list = hex_string.split(char)

            items = []
            items.append(tot_list[1][tot_list[1].find('A'):])
            items.append(tot_list[2][tot_list[2].find('A'):])
            temp = items[1][items[1].find('668B'):]
            items.append(temp[temp.find('A'):])

            decoded_items = []

            for num, item in enumerate(items):
                child_proccess = subprocess.Popen("echo {} | xxd -r -ps | python -m cbor2.tool".format(item),
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                decoded = child_proccess.communicate()[0].decode()
                self._logger().debug("Decoded data for item {}: {}".format(num, decoded))

                decoded_items.append(decoded)

            return decoded_items

        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)

    def move_remote_file(self, src, dst):
        try:
            Connection.execute_command(self, 'mv {} {}'.format(src, dst))
        except Exception as e:
            self._logger().exception("Could not run command: {}".format(e))
            raise RuntimeError(e)
