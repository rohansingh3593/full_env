# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential
  information, ideas and expressions. No part of which may be reproduced or
  transmitted in any form or by any means electronic, mechanical, or otherwise.
  Including photocopying and recording or in connection with any information
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""

from kaizenbot.connection import Connection
from .util import Util
from kaizenbot.Gen5RivaLibrary.g5rfwflash import G5RFWFlash
from kaizenbot.Gen5RivaLibrary.fwupgradelibrary import FWUpgradeLibrary
from time import sleep

import os, re

class FWupgrade:
    def __init__(self):
        pass
        
    def _logger(self):
        raise NotImplementedError

    def switch_di_init(self, mode='d'):
        """This command will switch DI_init between stand-alone and default mode.

        This takes 1 optional argument ``mode``

        Default ``mode`` is ``d`` unlicensed version of agents will not start on default mode but licensed agent only.

        return value: This will return complete output after executing switch_di_init
        return type: string

        Example:

        | = Keyword =      | = mode =  | = comment =                   |
        | `Switch Di Init` | s         | #converts to standalone mode  |
        | `Switch Di Init` | d         | #converts to default mode     |

        Note: This SwitchDI-Init script is only available on Debug version of AppServices to test unlicensed agents
        """
        try:
            cmd = 'SwitchDIInits.sh -{}'.format(mode)
            out = Connection.execute_command(self,cmd)
            self._logger().info('Output: {}'.format(out))
            if out.find('Updated the database successfully') != -1:
                self._logger().info('DB updated Successfully')
            elif out.find('Failed to update the database') != -1:
                self._logger().info('Failed to update the database')
                self._logger().info('Clearing DB conflicts')
                clear_db = 'sqlite3 /usr/share/itron/database/muse01.db "delete from CONTAINEROVERLAY where ' \
                           'OverlayUID=50659329" '
                tmp = Connection.execute_command(self, clear_db)
                while tmp.find('database is locked') != -1:
                    self._logger().info('database is locked!! retrying...')
                    sleep(2)
                    tmp = Connection.execute_command(self, clear_db)
                out = Connection.execute_command(self,cmd)
                if out.find('Updated the database successfully') != -1:
                    self._logger().info('DB updated Successfully')
                else:
                    self._logger().info('SwitchDIInits operation Failed')
                    raise Exception('SwitchDIInits operation Failed')
            else:
                self._logger().info('Invalid mode: -{}'.format(mode))
                raise Exception('Invalid mode: -{}'.format(mode))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            return out

    def do_gmr(self, retry, interval, method='script', node=None, waittime=60):
        """This will do a Global Meter Reset and will wait until the meter is back online.

        This takes 2 mandatory arguments ``retry`` and ``interval``
        This takes 3 optional arguments ``method``, ``node`` and ``waittime``

        Default ``method`` is script
        Default ``node`` is None
        Default ``waittime`` is 60

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        return value: ``Success`` message upon successful reset and meter will be up and running
        return type: string

        Example:

        | = Keyword = | = retry =  | = interval = | = method = | = node =      | = waittime =   |
        | `Do Gmr`    | 200        | 20           | script     | 10.21.100.235 | 120            |
        | `Do Gmr`    | 200        | 20           |            |               |                |

        """
        node = node or self.get_current_node()
        self._logger().info('node to GMR is {}'.format(node))
        if not node:
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
            
        try:
            if method == 'script':
                self._logger().info('GMR inprogress, Please wait few mins')
                Connection.execute_command(self, '/usr/share/itron/scripts/GlobalMeterReset.sh', BackgroundRun=True)
                G5RFWFlash.wait_until_node_becomes_unreachable(self, waittime)
                FWUpgradeLibrary.wait_until_node_is_up(self, retry=retry, interval=interval, node=node)
                return 'Success'
            else:
                self._logger().info("Method: {} not implemented yet".format(method))
                raise NotImplementedError
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

    def install_appserv(self, appserv_image, skip_gmr=True, node=None, retry=300, interval=20):
        """This will install the appserv package on the connected node.

        This takes 1 mandatory arguments ``appserv_image``
        This takes 4 optional arguments ``skip_gmr`` , ``node``, ``retry`` and ``interval``

        Default ``skip_gmr`` is True
        Default ``node`` is None
        Default ``retry`` is 300 seconds
        Default ``interval`` is 20 seconds
        
        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        return value: This will return complete output after executing ImProvHelper --image {image_name} command but actual upgrade will take few minutes
        return type: string

        Example:

        | = Keyword =        | = appserv_image =     | = skip_gmr = | = node =       | = retry = | = interval = | = comment =                      |
        | `Install Appserv` | <package_name>.tar.gz | False        | 10.21.100.235  | 200        | 20          | #GMR before upgrade              |
        | `Install Appserv` | <package_name>.tar.gz |              |                |           |              | #no GMR and proceed with upgrade |

        """
        node = node or self.get_current_node()
        self._logger().info('{} package installation initiated on node: {}'.format(appserv_image, node))
        if not node:
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
            
        self._logger().info("Skip GMR status: {}".format(skip_gmr))
        try:
            if not skip_gmr:
                self.do_gmr(retry, interval, node=node)
            if appserv_image.endswith('.tar.gz'):
                cmd = 'ImProvHelper.sh --image {}'.format(appserv_image)
                output = Connection.execute_command(self, cmd)
                self._logger().info(output)
            else:
                self._logger().info('Invalid Image: {}. Please check the image'.format(appserv_image))
                raise Exception('Invalid Image: {}'.format(appserv_image))
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            return output

    def install_agent(self, agent_image, node=None):
        """This will install the agent package on the connected node.

        This takes 1 mandatory arguments ``agent_image``
        This takes 1 optional argument ``node``

        This keyword will be run on ``node`` if it is provided.
        If ``node`` is not provided, keyword is run on the node set by keyword `Set Node`.
        If `Set Node` Keyword has not been used,keyword is run on the node provided at the time of library import.
        If no node is provided at the time of library import also, it raises an exception and keyword fails

        return value: This will return complete output after executing ImProvHelper --image {image_name} command but actual upgrade will take few minutes
        return type: string

        Example:

        | = Keyword =     | = agent_image =       | = node =       | = comment =          |
        | `Install Agent` | <package_name>.tar.gz | 10.21.100.235  | #Install given agent on provided node|
        | `Install Agent` | <package_name>.tar.gz |                | #Install given agent on current node|

        Note: DI AppServices install is prerequisite before agent installation else agent installation will fail

        """
        node = node or self.get_current_node()
        self._logger().debug('{} agent installation initiated on node: {}'.format(agent_image, node))
        if not node:
            self._logger().debug("No NIC IP provided by User to execute command")
            raise Exception("No NIC IP provided by User to execute command")
            
        try:
            appserv_inst_status = Util.run_helper_cmd(self,'read','ILID_APP_SERVICE_PKG_INSTALLED')
            if appserv_inst_status.strip() == 'false':
                self._logger().info("No AppServ installed! Agent installation requires AppService installation first!!")
                raise Exception('Agent installation requires AppService installation first!')
            else:
                output = self.install_appserv(agent_image, skip_gmr=True, node=node)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        return output

    def install_package_from_preinstall(self, path, pattern):
        """This will install the package from the given path on the connected node.

        This takes 2 mandatory arguments ``path`` and ``pattern``

        return value: This will return complete output after executing ImProvHelper --image {<pattern>.tar.gz} command but actual upgrade will take few minutes
        return type: string

        Example:

        |            = Keyword =            |          = path =            |   = pattern =    |
        | `Install Package From Preinstall` | /usr/share/itron/PreInstall/ |    AppService    |
        | `Install Package From Preinstall` | /usr/share/itron/PreInstall/ |      HAN         |

        """
        self._logger().info('{} package installation initiated..'.format(pattern))

        if not path.endswith('/'):
            path += '/'
        try:
            cmd = 'ImProvHelper.sh --image {}'.format(Connection.list_files_in_directory(self, path, pattern)[0])
            self._logger().info(cmd)
            output = Connection.execute_command(self, cmd)
            self._logger().info(output)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            return output

