#!/usr/bin/env python

import re
import sys
import os
from os.path import abspath, dirname, join
from setuptools import setup

# Version info -- read without importing
_locals = {}
with open("kaizenbot/AppServLibrary/version.py") as fp:
    exec(fp.read(), None, _locals)
version = _locals["VERSION"]

PKGVERSION=version
REQUIREMENTS=[]
REQUIREMENTS.append('KaizenBot-CommonLibrary>=1.4')
REQUIREMENTS.append('KaizenBot-Gen5RivaLibrary>=1.4')
REQUIREMENTS.append('cbor2>=5.4')
if (os.name == 'nt'):
    REQUIREMENTS.append('pywinauto>=0.6.8')

CLASSIFIERS = '''
Development Status :: 3 - Alpha
License :: Itron
Intended Audience :: Automation Engineers
Operating System :: OS Independent
Programming Language :: Python
Topic :: Software Development :: Testing
Framework :: Robot Framework
Framework :: Robot Framework :: Library
'''.strip().splitlines()

setup(
	name='KaizenBot-AppServLibrary',
	version=PKGVERSION,
	description='Appserv keyword library',
	author='Sean Booth',
	author_email='Shweta.Kaushik@itron.com,rajasekhar.inguva@itron.com,sirajdeen.hameedkamsa@itron.com,Vincent.Siu@itron.com,sean.booth@itron.com',
	url='https://www.itron.com/',
	keywords='Appserv',
	platforms='any',
	classifiers=CLASSIFIERS,
	install_requires=REQUIREMENTS,
    include_package_data=True,
	python_requires='>=3.6',
	packages=['kaizenbot']
)

