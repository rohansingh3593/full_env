#!/usr/bin/env python3
from azure.devops.connection import Connection
from msrest.authentication import BasicAuthentication
from azure.devops.v5_1.member_entitlement_management.member_entitlement_management_client import MemberEntitlementManagementClient
import sys,os

def get_user_details_from_name(uname):
    credentials = BasicAuthentication('', "xki3dbfuzmarnrf3ndrxibwzdlllwqrp76jjkbzelz7o3b5vdawa")
    adscon = Connection(base_url='https://dev.azure.com/itron', creds=credentials)
    ads = adscon.clients.get_core_client()
    usermgmt = MemberEntitlementManagementClient(base_url='https://vsaex.dev.azure.com/itron', creds=credentials)
    print("Retriveing user details of user: %s" %(uname))
    resp = usermgmt.get_user_entitlements(top=10000,filter="name eq "+uname)
    if not resp:
        print("Failed to retrieve user details for: %s" %(uname))
        sys.exit(1)
    print("User alias is: %s" %(resp.members[0].user.directory_alias))
    return resp.members[0].user.directory_alias
    """
    responses = []
    responses.append(resp)
    recvd = len(resp.members)
    total = int(resp.additional_properties['totalCount'])
    while recvd < total:
        resp = usermgmt.get_user_entitlements(top=10000,skip=recvd,filter="name eq "+uname)
        recvd = recvd + len(resp.members)
        responses.append(resp)
    
    print("Total: ",total)
    for row in responses:
        for member in row.members:
            if uname in member.user.display_name:
                print("%s:%s\n" % (member.user.display_name,member.id))
                print(member.user.directory_alias)
                print(member.user)
    
    #print(resp.members[0].id)
    #print(resp.members[0].user.display_name)
    #print(resp.members[0].user.directory_alias)

    get_user_details_from_name("Shweta Kaushik","xki3dbfuzmarnrf3ndrxibwzdlllwqrp76jjkbzelz7o3b5vdawa")
    """
