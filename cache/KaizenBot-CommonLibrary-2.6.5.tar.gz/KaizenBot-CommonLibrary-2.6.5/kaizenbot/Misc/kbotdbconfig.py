DB_Dict = {
    'kaizenbot.itron.com:5432': {
        'db_type': 'psql',
        'appservschema':{
            'db_name': 'a2FpemVuYm90X2FwcHNlcnY=',
            'db_user': 'YXBwc2Vydl91c2Vy',
            'db_pwd' : 'aXRyb25AMTIz',
            'db_file': None},
        'gen5rivaschema':{
            'db_name': 'a2FpemVuYm90X2dlbjVyaXZh',
            'db_user': 'Z2VuNXJpdmFfdXNlcg==',
            'db_pwd' : 'aXRyb24xMjM=',
            'db_file': None},
        'platformschema':{
            'db_name': 'a2FpemVuYm90X3BsYXRmb3Jt',
            'db_user': 'cGxhdGZvcm1fdXNlcg==',
            'db_pwd' : 'aXRyb25AMTIz',
            'db_file': None},
        'gen5cctschema':{
            'db_name': 'a2FpemVuYm90X2dlbjVjY3Q=',
            'db_user': 'Z2VuNWNjdF91c2Vy',
            'db_pwd' : 'aXRyb24xMjM=',
            'db_file': None},
        'dip2pschema':{
            'db_name': 'a2FpemVuYm90X2RpcDJw',
            'db_user': 'ZGlwMnBfdXNlcg==',
            'db_pwd' : 'aXRyb24xMjM=',
            'db_file': None},
        'hanschema':{
            'db_name': 'a2FpemVuYm90X2hhbg==',
            'db_user': 'aGFuX3VzZXI=',
            'db_pwd' : 'aXRyb24xMjM=',
            'db_file': None},
        'kaizenbotschema':{
            'db_name': 'a2FpemVuYm90',
            'db_user': 'cG9zdGdyZXM=',
            'db_pwd' : 'S2FpemVuYm90QDEyMw==',
            'db_file': None},
        },
    'ocn-rd-actval3.itron.com:8270': {
        'db_type': 'sqlite',
        'db_name': [],
        'db_user': [],
        'db_schema': [],
        'db_file': None}
}
