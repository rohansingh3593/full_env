#export KAIZENBOT_DRYRUN=`cmd.exe /c echo %KAIZENBOT_DRYRUN% | grep -v % | sed 's/\r//g' | sed 's/\%RELEASE_AGENTS\%//g'`

dir_path=$1
chmod 777 $dir_path/env.csv
exclude_array=('Path' 'Selected_System')
SPACE=' '
QUOTES='\"'

while IFS=\, read -r a b
do
    if [[ "$a" == '' || "${exclude_array[@]}" == *"${a}"* ]]; then
        continue
    else
        KEY=$(echo $a | sed 's/\"//g' | sed 's/\./\_/g')
        KEY=$(echo $KEY | sed 's/\s/_/g')
        VAL=$(echo $b | sed 's/\"//g' | sed 's/\r//g')
        VAL=$(echo $VAL | sed 's/\\/\//g')
        #echo "$KEY=$VAL"
        if [[ "$VAL" == *"$SPACE"* && "$VAL" != *"$QUOTES"* ]]; then
            #echo $VAL
            VAL=\'$VAL\'
        fi
        export "$KEY=$VAL"
    fi
done <$dir_path/env.csv

echo "env mapping done successfully"
