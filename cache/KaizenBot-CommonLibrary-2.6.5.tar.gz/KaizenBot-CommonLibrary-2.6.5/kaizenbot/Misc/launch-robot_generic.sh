#!/bin/bash

PreEcho()
{
    SITEPKG_VAR="`find $KAIZENBOT_LABSERVER_HOME/kaizenbot/lib -name 'kaizenbot'`"
    KZ_VERSION=`cat $SITEPKG_VAR/Misc/version.py | grep VERSION | awk $'{print $3}'`
    echo "TEST_RUNID: $TEST_RUNID"
    echo "KAIZENBOT_VERSION: $KZ_VERSION"
    echo "KAIZENBOT_SUITEID: $KAIZENBOT_SUITEID"
    echo "KAIZENBOT_SUITENAME: $KAIZENBOT_SUITENAME"
    echo "KAIZENBOT_TPLANID: $KAIZENBOT_TPLANID"
    echo "KAIZENBOT_USERNAME: $KAIZENBOT_USERNAME"
    echo "KAIZENBOT_DRYRUN: $KAIZENBOT_DRYRUN"
    echo "KAIZENBOT_LOGLEVEL: $KAIZENBOT_LOGLEVEL"
    echo "KAIZENBOT_TESTNAME: $KAIZENBOT_TESTNAME"
    echo "KAIZENBOT_INCLUDETAGS: $KAIZENBOT_INCLUDETAGS"
    echo "KAIZENBOT_EXCLUDETAGS: $KAIZENBOT_EXCLUDETAGS"
    echo "KAIZENBOT_PLATFORM: $KAIZENBOT_PLATFORM"
    echo "KAIZENBOT_PROJECT: $KAIZENBOT_PROJECT"
    echo "KAIZENBOT_WAIT_ON_BUSY_PLATFORM: $KAIZENBOT_WAIT_ON_BUSY_PLATFORM"
    echo "KAIZENBOT_NODES: $KAIZENBOT_NODES"
    echo "RELEASE_APPSERVVERSION: $RELEASE_APPSERVVERSION"
    echo "RELEASE_HANVERSION: $RELEASE_HANVERSION"
    echo "RELEASE_FWVERSION: $RELEASE_FWVERSION"
    echo "RELEASE_AGENTS: $RELEASE_AGENTS"
    echo "RELEASE_DSP_VERSION: $RELEASE_DSP_VERSION"
    echo "KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION: $KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION"
    echo "KAIZENBOT_USERPAT: $KAIZENBOT_USERPAT"
    echo "KAIZENBOT_REPLICATE_IN_PARALLEL: $KAIZENBOT_REPLICATE_IN_PARALLEL"
    echo "KAIZENBOT_BUG_AREAPATH: $KAIZENBOT_BUG_AREAPATH"
    echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
    echo "ADS_AGENT_USER: $ADS_AGENT_USER"
    echo "ADS_AGENT_PASSWORD: $ADS_AGENT_PASSWORD"
    echo "KAIZENBOT_DBSERVER: $KAIZENBOT_DBSERVER"
    echo "KAIZENBOT_DBSERVER_PORT: $KAIZENBOT_DBSERVER_PORT"
    echo "KAIZENBOT_DBSERVER_SCHEMA: $KAIZENBOT_DBSERVER_SCHEMA"
    echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
    echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
    echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
    echo "KAIZENBOT_LABSERVER_HOME: $KAIZENBOT_LABSERVER_HOME"
    echo "KAIZENBOT_SUITE_SERIAL_EXECUTION: $KAIZENBOT_SUITE_SERIAL_EXECUTION"
    echo "KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE: $KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE"
    echo "KAIZENBOT_RERUN_LEVEL: $KAIZENBOT_RERUN_LEVEL"
    echo "KAIZENBOT_MANUAL_REVERT_TEST: $KAIZENBOT_MANUAL_REVERT_TEST"
    echo "KAIZENBOT_ENIC_TEST: $KAIZENBOT_ENIC_TEST"
    echo "KAIZENBOT_ENIC_BUILD: $KAIZENBOT_ENIC_BUILD"
}

Validate_ReturnCode_andExit()
{
    ret_code=$1
    echo "Validating return code: $ret_code"
    if [ $ret_code -ne 0 ]; then exit $ret_code; fi
}

Define_Variables()
{
    ADS_SERVER_ADDRESS=$ADS_SERVER
    #ADS_SERVER_ADDRESS=kaizenbot.itron.com

    SANITY_STR='Sanity'
    UPGRADE_STR='Upgrade'
    COMMA=','
    SPACE=' '
    COMMA_SPACE=', '
    NONE='None'
    ALL_STR='All'

    ##Adding default value to ADS_SERVER_ADDRES if it is empty
    if [[ "$ADS_SERVER_ADDRESS" == "" || ${ADS_SERVER_ADDRESS,,} == "${NONE,,}" ]]
    then
        echo "Defaulting the ADS_SERVER_ADDRESS"
        ADS_SERVER_ADDRESS=kaizenbot.itron.com
    fi

    if [[ "$KAIZENBOT_EXITONFAILURE" != "" ]]
    then
        echo "KAIZENBOT_EXITONFAILURE: $KAIZENBOT_EXITONFAILURE"
        echo "Setting Exit-On-Failure flag"
        KAIZENBOT_EXITONFAILURE='-X'
    fi

    ##Checking username should not be empty
    if [[ "$KAIZENBOT_USERNAME" == "" || ${KAIZENBOT_USERNAME,,} == "${NONE,,}" ]]
    then
        echo "Please provide username to continue testing"
        deactivate
        exit 252
    fi

    if [ "$KAIZENBOT_DBSERVER" == "" ]
    then
        KAIZENBOT_DBSERVER="$KAIZENBOT_LABSERVER"
    fi
    if [ "$KAIZENBOT_DBSERVER_PORT" == "" ]
    then
        KAIZENBOT_DBSERVER_PORT="8270"
    fi
    INTERNAL_RESOURCE_SERVER_URI="$KAIZENBOT_DBSERVER:$KAIZENBOT_DBSERVER_PORT"

    ##Test required variables
    INTERNAL_KAIZENBOT_OPTIONS=''
    INTERNAL_TESTS_TO_RUN=''
    WAIT_ON_BUSY_STATUS='False'
    DISABLE_TEST_PARALLELISM='True'

    ## replacing comma to OR to form Tags variable for robot
    KAIZENBOT_INCLUDETAGS=$(echo $KAIZENBOT_INCLUDETAGS | sed 's/,/OR/g')
    KAIZENBOT_EXCLUDETAGS=$(echo $KAIZENBOT_EXCLUDETAGS | sed 's/,/OR/g')
}

Create_TSSTR_TCSTR()
{
    ## creating robot test and suite options from comma separated variables
    OLDIFS=$IFS
    IFS=','
    TCSTR=()
    TSSTR=()
    for suitename in $KAIZENBOT_SUITENAME
    do
        TSSTR+=( --suite $suitename )
    done
    for tcname in $KAIZENBOT_TESTNAME
    do
        TCSTR+=( --test $tcname )
    done
    IFS=$OLDIFS

    ## If suitename provided is 'All' then making test suite array to empty
    if [[ ${KAIZENBOT_SUITENAME,,} == "${ALL_STR,,}" || ${KAIZENBOT_SUITENAME,,} == "${NONE,,}" ]]
    then
        declare -a TSSTR=()
        echo "suitename from ADS: $KAIZENBOT_SUITENAME"
        echo "suitename: ${TSSTR[@]}"
    fi

    ##Setting testname, include and exclude tags to empty if the value is None based on Approach 3
    if [[ ${KAIZENBOT_TESTNAME,,} == *"${NONE,,}"* ]]
    then
        declare -a TCSTR=()
        echo "testname from ADS: $KAIZENBOT_TESTNAME"
        echo "testname: ${TCSTR[@]}"
    fi
    if [[ ${KAIZENBOT_INCLUDETAGS,,} == *"${NONE,,}"* ]]
    then
        declare KAIZENBOT_INCLUDETAGS=""
        echo "include tags: $KAIZENBOT_INCLUDETAGS"
    fi
    if [[ ${KAIZENBOT_EXCLUDETAGS,,} == *"${NONE,,}"* ]]
    then
        declare KAIZENBOT_EXCLUDETAGS=""
        echo "include tags: $KAIZENBOT_EXCLUDETAGS"
    fi
}

Populate_Robot_Options()
{
    ##Creating array to save robot options
    INTERNAL_TESTS_TO_RUN=()

    ## Filling robot option array to pass to test
    if [ "$KAIZENBOT_TESTNAME" ]; then INTERNAL_TESTS_TO_RUN+=( "${TCSTR[@]}" ); fi
    if [ "$KAIZENBOT_SUITENAME" ]; then INTERNAL_TESTS_TO_RUN+=( "${TSSTR[@]}" ); fi
    if [ "$KAIZENBOT_INCLUDETAGS" ]; then INTERNAL_TESTS_TO_RUN+=( --include "$KAIZENBOT_INCLUDETAGS" ); fi
    if [ "$KAIZENBOT_EXCLUDETAGS" ]; then INTERNAL_TESTS_TO_RUN+=( --exclude "$KAIZENBOT_EXCLUDETAGS" ); fi
    if [ "$KAIZENBOT_LOGTITLE" ]; then INTERNAL_TESTS_TO_RUN+=( --logtitle "$KAIZENBOT_LOGTITLE Log" ); fi
    if [ "$KAIZENBOT_REPORTTITLE" ]; then INTERNAL_TESTS_TO_RUN+=( --reporttitle "$KAIZENBOT_REPORTTITLE Report" ); fi

    ##Checking if all required robot variables are empty ans exit test
    #if [ "${INTERNAL_TESTS_TO_RUN[0]}" != "" ]; then echo "Running Tests"; else echo "Please provide valid test. Got empty tests."; deactivate; exit 0; fi

    ###Checking if provided test is sanity or upgrade and setting build download accordingly
    if [[ "${KAIZENBOT_TESTNAME,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_SUITENAME,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_INCLUDETAGS,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_EXCLUDETAGS,,}" == *"${SANITY_STR,,}"* ]]; then INTERNAL_TESTS_TO_RUN+=( --name "$SANITY_STR" ); elif [[ "${KAIZENBOT_TESTNAME,,}" == *"${UPGRADE_STR,,}"* || "${KAIZENBOT_SUITENAME,,}" == *"${UPGRADE_STR,,}"* || "${KAIZENBOT_INCLUDETAGS,,}" == *"${UPGRADE_STR,,}"* || "${KAIZENBOT_EXCLUDETAGS,,}" == *"${UPGRADE_STR,,}"* ]]; then INTERNAL_TESTS_TO_RUN+=( --name "Firmware Upgrade" ); else INTERNAL_TESTS_TO_RUN+=( --name "$KAIZENBOT_PROJECT" ); fi
}

Populate_Pabot_Options()
{
    ## Filling pabot option array to pass to test
    INTERNAL_KAIZENBOT_OPTIONS=()

    if [ "$KAIZENBOT_USERNAME" ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --tester "$KAIZENBOT_USERNAME" ); fi

    if [ "$KAIZENBOT_PLATFORM" ]
    then
        INTERNAL_KAIZENBOT_OPTIONS+=( --useplatform "$KAIZENBOT_PLATFORM" )
        INTERNAL_KAIZENBOT_OPTIONS+=( --resourceserveruri "$INTERNAL_RESOURCE_SERVER_URI" )
        if [ "$KAIZENBOT_PROJECT" ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --project "$KAIZENBOT_PROJECT" ); fi
        if [ "$KAIZENBOT_DBSERVER_SCHEMA" ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --schema "$KAIZENBOT_DBSERVER_SCHEMA" ); fi
        if [[ "${KAIZENBOT_WAIT_ON_BUSY_PLATFORM,,}" == *"${WAIT_ON_BUSY_STATUS,,}"* || "$KAIZENBOT_WAIT_ON_BUSY_PLATFORM" == "" ]]; then INTERNAL_KAIZENBOT_OPTIONS+=( --nowait ); fi
    else
        INTERNAL_KAIZENBOT_OPTIONS+=( --noplatform )
    fi

    if [ $KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION = 'False' ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --testlevelsplit ); fi

    if [ $KAIZENBOT_SUITE_SERIAL_EXECUTION = 'True' ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --processes 1 ); fi

    ##if suite serial execution is enabled and suite name is not ALL, then serialize as per pipeline suite order
    if [[ $KAIZENBOT_SUITE_SERIAL_EXECUTION == 'True' && $KAIZENBOT_SUITENAME != 'All' && $KAIZENBOT_SUITENAME == *"$COMMA"* ]]
    then
        SUITE_EXEC_ORDER_FILE=$KAIZENBOT_INTERNAL_OUTDIR/suite-order.txt
        echo "Enforcing strict suite execution order. File: $SUITE_EXEC_ORDER_FILE"
        for s in `echo ${KAIZENBOT_SUITENAME} | tr ',' ' '`
        do
            echo "--suite $s" >> $SUITE_EXEC_ORDER_FILE
        done
        INTERNAL_KAIZENBOT_OPTIONS+=( --ordering  "$SUITE_EXEC_ORDER_FILE" )
    else
        echo "We did not hit this path at all"
    fi
}

Create_Output_Dir()
{
    KAIZENBOT_RUN_PATH=$KAIZENBOT_LABSERVER_HOME/$KAIZENBOT_PROJECT/Output_Directory ## to ask Raj on how to generalise proj name
    if [ ! -d $KAIZENBOT_RUN_PATH ]; then mkdir -p $KAIZENBOT_RUN_PATH; fi

    ##Creating Output and Logs folder
    echo "Creating Output and Logs folder"
    if [[ "$KAIZENBOT_USERNAME" == *"$SPACE"* ]]
    then
        USERNAME=$(echo $KAIZENBOT_USERNAME | tr " " "_")
        G5R_USERNAME=$USERNAME
        if [[ "$USERNAME" == *"$COMMA"* ]]
        then
            G5R_USERNAME=$(echo $USERNAME | tr "," "_")
        fi
    elif [[ "$KAIZENBOT_USERNAME" == *"$COMMA"* ]]
    then
        G5R_USERNAME=$(echo $KAIZENBOT_USERNAME | tr "," "_")
    else
        G5R_USERNAME=$KAIZENBOT_USERNAME
    fi
    for i in `seq 999999`
    do
        if [ -d $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i ]
        then
            continue
        else
            #mkdir $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i
            mkdir -p $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Results
            mkdir -p $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Logs
            export KAIZENBOT_INTERNAL_OUTDIR=$KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Results
            export KAIZENBOT_INTERNAL_LOGDIR=$KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Logs
            break
        fi
    done

    echo "Result folder: $KAIZENBOT_INTERNAL_OUTDIR"
    echo "Logs folder: $KAIZENBOT_INTERNAL_LOGDIR"
}

Collect_TestCases_TestSuites()
{
    ##Getting test cases id and plan and suite id based on test run id
    if [[ $TEST_RUNID != "" && ${TEST_RUNID,,} !=  *"${NONE,,}"* ]]
    then
        echo "Test run id is: $TEST_RUNID"
        echo "Creating Tags for the tests present in Test Run id";
        test_cases_from_runid_path=$KAIZENBOT_INTERNAL_OUTDIR
        echo "Tag for test cases path: $KAIZENBOT_INTERNAL_OUTDIR"
        test_runid=$TEST_RUNID
        echo "Test Run ID: $test_runid"
        echo "Internal test to run: ${INTERNAL_TESTS_TO_RUN[@]}"
        $(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat
azurelib = AzureLibrary(pat)
test_cases=azurelib._get_test_cases_by_runid(runid='$test_runid')
print("test_case_tag=%s"%test_cases)' 1>$test_cases_from_runid_path/test_case_tag.log)
        Test_case_tag="`eval grep 'test_case_tag=' $test_cases_from_runid_path/test_case_tag.log | sed 's/^.*=//'`"
        echo $Test_case_tag
        INTERNAL_TESTS_TO_RUN+=( $Test_case_tag )
        echo "New Test val: ${INTERNAL_TESTS_TO_RUN[@]}"
    else
        #echo "Please provide valid test. Got empty tests.";
        #deactivate;
        #exit 0;
        echo -n ""
    fi

    if [[ $KAIZENBOT_PROJECT == 'INS' ]]
    then
        echo 'Creating CSV file for INS Regression'
        csv_file_creation_path=$KAIZENBOT_INTERNAL_OUTDIR
        echo $csv_file_creation_path
        $(python -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat, TestPlanID, TestSuiteID, IncludeTag, ExcludeTag
from kaizenbot.Gen5RivaLibrary.ins import INS
azurelib = AzureLibrary(pat)
tc_list=azurelib._get_test_cases_by_suiteid(planid=TestPlanID,suiteid=TestSuiteID)
if ExcludeTag:
    INS.create_file_from_tclist("'$csv_file_creation_path'/500WRegressionSuite",tc_list,excludetag=ExcludeTag)
elif IncludeTag:
    INS.create_file_from_tclist("'$csv_file_creation_path'/500WRegressionSuite",tc_list,includetag=IncludeTag)
else:
    INS.create_file_from_tclist("'$csv_file_creation_path'/500WRegressionSuite",tc_list)' 2>$csv_file_creation_path/csv_creation_error.log)
    fi

    ###Create include tag if user has provided suitename as 'All' and provided plan and suite id to select all test cases
    echo "suite: $KAIZENBOT_SUITENAME"
    if [[ ${KAIZENBOT_SUITENAME,,} == "${ALL_STR,,}" ]]
    then
        ###check if plan id and suite id is not empty
        if [[ "$KAIZENBOT_TPLANID" == "" || ${KAIZENBOT_TPLANID,,} == *"${NONE,,}"* ]]
        then
            echo "Please provide Plan id to proceed with the execution"
            exit 252
        fi
        if [[ "$KAIZENBOT_SUITEID" == "" || ${KAIZENBOT_SUITEID,,} == *"${NONE,,}"* ]]
        then
            echo "Please provide Suite id to proceed with the execution"
            exit 252
        fi
        tag_path=$KAIZENBOT_INTERNAL_OUTDIR
        echo "path to save tag data: $tag_path"
        echo "Internal test to run: ${INTERNAL_TESTS_TO_RUN[@]}"
        $(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat, TestPlanID, TestSuiteID
include_tag=AzureLibrary(pat).create_tags_from_plan_and_suiteid(planid=TestPlanID,suiteid=TestSuiteID)
print("include_tag=%s"%include_tag)' 1>$tag_path/tag.log)
        Include_Tag="`eval grep 'include_tag=' $tag_path/tag.log | sed 's/^.*=//'`"
        echo $Include_Tag
        INTERNAL_TESTS_TO_RUN+=( $Include_Tag )
        echo "New Test val: ${INTERNAL_TESTS_TO_RUN[@]}"
    fi
}

Create_Clone_Git_Repo()
{
    ##Creating ramdom string of length 10
    RANDOM_STR=$(echo $RANDOM | md5sum | head -c 10)

    ##Creating git repo folder if not present
    GIT_REPO_FOLDER=$KAIZENBOT_LABSERVER_HOME/kaizenbot/${KAIZENBOT_LABSERVER_USERNAME}_git_repo_${RANDOM_STR}
    if [ ! -d $GIT_REPO_FOLDER ]; then mkdir -p $GIT_REPO_FOLDER; fi

    ##getting test suites from GIT
    echo "Getting Test Suites from Git"
    if [[ "$BUILD_BUILDNUMBER" == "" || ${BUILD_BUILDNUMBER,,} == *"${NONE,,}"* ]]
    then
        echo "This is a release pipeline. Expecting Repo/Branch details from variables"
        if [[ "$KAIZENBOT_TESTS_REPOSITORY" == "" || ${KAIZENBOT_TESTS_REPOSITORY,,} == *"${NONE,,}"* ]]
        then
            echo "Repo details are not provided. Please set kaizenbot.tests.repository"
            deactivate
            exit 252
        fi
        if [[ "$KAIZENBOT_TESTS_REPOSITORY_BRANCH" == "" || ${KAIZENBOT_TESTS_REPOSITORY_BRANCH,,} == *"${NONE,,}"* ]]
        then
            echo "Branch details are not provided. Please set kaizenbot.tests.repository.branch"
            deactivate
            exit 252
        fi
        $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.gitlibrary $GIT_REPO_FOLDER $KAIZENBOT_TESTS_REPOSITORY $KAIZENBOT_TESTS_REPOSITORY_BRANCH 2>$GIT_REPO_FOLDER/git_error.log
        GIT_REPO=$GIT_REPO_FOLDER/$KAIZENBOT_TESTS_REPOSITORY
    else
        $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.gitlibrary $GIT_REPO_FOLDER 2>$GIT_REPO_FOLDER/git_error.log
        GIT_REPO=$GIT_REPO_FOLDER/$BUILD_REPOSITORY_NAME
    fi
    export GIT_REPO
    echo "git repo folder: $GIT_REPO"
}

Update_Skip_Tag()
{
    echo "Skip Tag feature Option-3 testing; Update Skip if BUG Tag found"
    tag_path=$KAIZENBOT_INTERNAL_OUTDIR
    grep -r "\[Tags\]" $GIT_REPO_FOLDER | grep -i bug | cut -d: -f2 > /tmp/tag_grep_output.log
    if [ -s /tmp/tag_grep_output.log ]
    then
        $(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
import os
from kaizenbot.azuredata import pat
az=AzureLibrary(pat)
bug_tc_list=az._parse_tag_file("/tmp/tag_grep_output.log")
skip_tag=az.create_tags_for_openbug_testcases(bug_tc_list=bug_tc_list)
print("skip_tag=%s"%skip_tag)' 1>$tag_path/skip_tag.log)
        Skip_Tag="`eval grep 'skip_tag=' $tag_path/skip_tag.log | sed 's/^.*=//'`"
        echo $Skip_Tag
        INTERNAL_TESTS_TO_RUN+=( $Skip_Tag )
        echo "New skip_tag val: ${INTERNAL_TESTS_TO_RUN[@]}"
    else
        echo "No BUG tag Found"
    fi
}

Download_Build_Files()
{
    ##Check and download the enic build. new pipeline variable KAIZENBOT_ENIC_TEST == True
    if [[ $KAIZENBOT_ENIC_TEST == True || $KAIZENBOT_ENIC_TEST == true || $KAIZENBOT_ENIC_TEST == TRUE ]]
    then
        echo "do copy from waseca"
        ENIC_BUILD_PATH='/shared/release/firmware/daily-builds/5.6.x/5.6.1/LATEST/rni_nic/'
        ENIC_BUILD_FILE=$KAIZENBOT_ENIC_BUILD
        ENIC_BUILD_VERSION=$(echo $KAIZENBOT_ENIC_BUILD | egrep -o "[[:digit:]]{2}.[[:digit:]]{2}.[[:alnum:]]{4}.[[:digit:]]{2}")

        sshpass -p "23Silver$" scp -o StrictHostKeyChecking=no waseca@10.57.202.2:$ENIC_BUILD_PATH$ENIC_BUILD_FILE $KAIZENBOT_INTERNAL_OUTDIR
        export ENIC_BUILD_FILE ENIC_BUILD_VERSION
        INTERNAL_TESTS_TO_RUN+=( -v enic_build_file:"$ENIC_BUILD_FILE" -v enic_build_version:"$ENIC_BUILD_VERSION" )
        return
    fi

    ##Downloading build if test/suite is sanity or firmware upgrade
    ##Downloading build for every run as user will run test based on approach 3 and user will not provide suite/test name
    DOWNLOAD_BUILD='True'
    if [ $DOWNLOAD_BUILD = 'True' ]
    then
        echo "Downloading Build"
        echo $RELEASE_FWVERSION
        if [[ "$RELEASE_FWVERSION" == "" || ${RELEASE_FWVERSION,,} == *"${NONE,,}"* ]]
        then
            echo "Please provide build number/firmware version to download build"
            #deactivate
            #exit 1
        fi
        CONVERTER_VERSION='10.0.113.2'
        BUILD_DIR=$KAIZENBOT_INTERNAL_OUTDIR/
        echo "Build directory is:$BUILD_DIR"
        export BUILD_DIR
        SITEPKG_VAR="`find $KAIZENBOT_LABSERVER_HOME/kaizenbot/lib -name 'kaizenbot'`"
        chmod +x $SITEPKG_VAR/Misc/get_build_folder.sh

        ##Downloading G5R Build File
        echo "Downloading G5R Build File"
        . $SITEPKG_VAR/Misc/get_build_folder.sh $RELEASE_FWVERSION gen5riva
        echo "Folder is: $BFOLDER"
        echo "RFS_Log File is: $RFSFILE"
        if [ "$BFOLDER" != "None" ]
        then
            TMP_SCRIPTNAME=`mktemp -u`
            echo "#!/bin/bash" > $TMP_SCRIPTNAME
            $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $RELEASE_FWVERSION $BFOLDER gen5riva $TMP_SCRIPTNAME
            export KB_RETURNCODE=$?
            Validate_ReturnCode_andExit $KB_RETURNCODE

            chmod +x $TMP_SCRIPTNAME
            . $TMP_SCRIPTNAME
            rm -f $TMP_SCRIPTNAME
            #eval `$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $RELEASE_FWVERSION $BFOLDER $KAIZENBOT_PROJECT`
        else
            echo "No Build file found."
            #deactivate
            #exit 0
        fi
        echo "Build file is:$BUILD_FILE"
        echo "Build fw version is:$BUILD_FWVERSION"
        BUILD_FILE=$BUILD_FILE
        BUILD_FWU_FILE=$BUILD_FWU_FILE
        BUILD_VERSION=$BUILD_FWVERSION
        export BUILD_FILE BUILD_FWU_FILE BUILD_VERSION
        INTERNAL_TESTS_TO_RUN+=( -v build_file:"$BUILD_FILE" -v build_fwu_file:"$BUILD_FWU_FILE" -v build_version:"$BUILD_FWVERSION" )

        ##Verify the project and auto-get the AppServ&HAN version if not provided
        if echo $KAIZENBOT_PROJECT | grep -qiE 'han|appserv|dip2pgenx'
        then
            ##Download G5R RFSinjection log to get the HAN and AppServ version
            wget $RFSFILE -O $BUILD_DIR/rfsInjection.log
            if [[ "$RELEASE_APPSERVVERSION" == "" || ${RELEASE_APPSERVVERSION,,} == *"${NONE,,}"* ]]
            then
                . $SITEPKG_VAR/Misc/get_build_folder.sh get_appserv_version:$BUILD_DIR/rfsInjection.log
                RELEASE_APPSERVVERSION=$PREINS_APPSERV_VERSION
            fi
            if [[ "$RELEASE_HANVERSION" == "" || ${RELEASE_HANVERSION,,} == *"${NONE,,}"* ]]
            then
                . $SITEPKG_VAR/Misc/get_build_folder.sh get_han_version:$BUILD_DIR/rfsInjection.log
                RELEASE_HANVERSION=$PREINS_HAN_VERSION
            fi
            rm -f $BUILD_DIR/rfsInjection.log

            echo "RELEASE_APPSERVVERSION: $RELEASE_APPSERVVERSION"
            echo "RELEASE_HANVERSION: $RELEASE_HANVERSION"
            INTERNAL_TESTS_TO_RUN+=( -v appserv_version:"$RELEASE_APPSERVVERSION" )
        fi

        ##Downloading AppServ build
        if [[ "$RELEASE_APPSERVVERSION" != "" ]]
        then
            . $SITEPKG_VAR/Misc/get_build_folder.sh $RELEASE_APPSERVVERSION appserv
            echo "AppServ Folder is: $BFOLDER"
            if [ "$BFOLDER" != "None" ]
            then
                wget -P $BUILD_DIR $BFOLDER
            else
                echo "AppServ file not found."
            fi
        fi

        ##Adding HAN agent to the release_agents list if project is HAN
        if [[ "$RELEASE_HANVERSION" != "" ]] &&  echo $KAIZENBOT_PROJECT | grep -qiE 'han'
        then
            echo "Adding HAN agent to the release_agents list"
            if [ ${#RELEASE_AGENTS} -eq 0 ]
            then
                RELEASE_AGENTS+=HANAgent:$RELEASE_HANVERSION
            else
                RELEASE_AGENTS+=,HANAgent:$RELEASE_HANVERSION
            fi
            INTERNAL_TESTS_TO_RUN+=( -v han_version:"$RELEASE_HANVERSION" )
        fi

        ##Verify the project before downloading the converter file
        if echo $KAIZENBOT_PROJECT | grep -qiE 'gen5riva'
        then
            ##Downloading G5R Converter File
            echo "Downloading G5R Converter File"
            . $SITEPKG_VAR/Misc/get_build_folder.sh $CONVERTER_VERSION gen5riva
            if [ "$BFOLDER" != "None" ]
            then
                TMP_SCRIPTNAME=`mktemp -u`
                echo "#!/bin/bash" > $TMP_SCRIPTNAME
                $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $CONVERTER_VERSION $BFOLDER gen5riva $TMP_SCRIPTNAME
                #eval `$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $CONVERTER_VERSION $BFOLDER $KAIZENBOT_PROJECT`
                chmod +x $TMP_SCRIPTNAME
                . $TMP_SCRIPTNAME
                rm -f $TMP_SCRIPTNAME
            else
                echo "No Converter Build file found"
                #deactivate
                #exit 0
            fi
            CONVERTER_FILE=$BUILD_FILE
            CONVERTER_FWVERSION=$BUILD_FWVERSION
            echo "Converter file is:$CONVERTER_FILE"
            echo "Converter file fw version is:$CONVERTER_FWVERSION"
            INTERNAL_TESTS_TO_RUN+=( -v converter_file:"$CONVERTER_FILE" )
        fi

        ##Downloading Agent Files
        if [ "$RELEASE_AGENTS" != "" ]
        then
            echo "Downloading Agent Files"
            AGENTS_LIST=($(echo $RELEASE_AGENTS | tr "," "\n"))
            for agent in "${AGENTS_LIST[@]}"
            do
                . $SITEPKG_VAR/Misc/get_build_folder.sh $agent agent
                echo "Agent Folder is: $BFOLDER"
                if [ "$BFOLDER" != "None" ]
                then
                    wget -P $BUILD_DIR $BFOLDER
                else
                    echo "Agent file not found."
                    #deactivate
                    #exit 0
                fi
            done
        fi

        ##Downloading DSP Firmware
        if [ "$RELEASE_DSP_VERSION" != "" ]
        then
            echo "Downloading DSP Files"
            DSP_LIST=($(echo $RELEASE_DSP_VERSION | tr "," "\n"))
            for dsp_var in "${DSP_LIST[@]}"
            do
                . $SITEPKG_VAR/Misc/get_build_folder.sh $dsp_var dsp
                echo "DSP Folder is: $BFOLDER"

                DSP_TYPE_VERSION=($(echo $dsp_var | tr ":" "\n"))
                DSP_VERSION="${DSP_TYPE_VERSION[1]}"

                if [ "$BFOLDER" != "None" ]
                    then
                    TMP_SCRIPTNAME=`mktemp -u`
                    echo "#!/bin/bash" > $TMP_SCRIPTNAME
                    $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $DSP_VERSION $BFOLDER dip2pgenx $TMP_SCRIPTNAME
                    export KB_RETURNCODE=$?
                    Validate_ReturnCode_andExit $KB_RETURNCODE

                    chmod +x $TMP_SCRIPTNAME
                    . $TMP_SCRIPTNAME
                    rm -f $TMP_SCRIPTNAME
                else
                    echo "No DSP Build file found."
                fi
            done
        fi
    fi
}

Define_NodeFile_Print()
{
    ##Nodes file path
    NODESFILE=$KAIZENBOT_INTERNAL_OUTDIR/nodes.txt
    echo $NODESFILE

    ##Checking for running replicated tests/suites in parallel
    echo "${INTERNAL_KAIZENBOT_OPTIONS[@]}"
    echo "${INTERNAL_TESTS_TO_RUN[@]}"
    echo $ADS_RESULT_DEST
    echo $KAIZENBOT_INTERNAL_OUTDIR
}

Create_Runliner()
{
    if [ $KAIZENBOT_REPLICATE_IN_PARALLEL = 'True' ]
    then
        echo "CASE:1 Running Same Tests/Suites in Parallel for all nodes of given platform"
        $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.argfile_generator2 --nodesfile $NODESFILE "${INTERNAL_KAIZENBOT_OPTIONS[@]}" --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command --RunEmptySuite "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d "$KAIZENBOT_INTERNAL_OUTDIR" "$GIT_REPO" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log
        export KB_RETURNCODE=$?
        #Validate_ReturnCode_andExit $KB_RETURNCODE
    elif [[ $KAIZENBOT_PROJECT == 'INS' ]]
    then
        #Exceptional case: INS project
        echo "CASE:2 Running Exceptional case for INS project"
        $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/pabot --verbose "${INTERNAL_KAIZENBOT_OPTIONS[@]}" --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command -d $KAIZENBOT_INTERNAL_OUTDIR --name "$KAIZENBOT_PROJECT" "$GIT_REPO" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log
        export ROBOT_RETURNCODE=$?
        #Validate_ReturnCode_andExit $ROBOT_RETURNCODE
    elif [[ "${KAIZENBOT_TESTNAME,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_TESTNAME,,}" != *"${UPGRADE_STR,,}"* && "${KAIZENBOT_SUITENAME,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_SUITENAME,,}" != *"${UPGRADE_STR,,}"* && "${KAIZENBOT_INCLUDETAGS,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_INCLUDETAGS,,}" != *"${UPGRADE_STR,,}"* && "${KAIZENBOT_EXCLUDETAGS,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_EXCLUDETAGS,,}" != *"${SANITY_STR,,}"* ]]
    then
        ##Running test/suites in parallel based without replicate
        echo "CASE:3 Running Suites/tests in parallel"
        #env
        $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/pabot --verbose "${INTERNAL_KAIZENBOT_OPTIONS[@]}" --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command --RunEmptySuite "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d $KAIZENBOT_INTERNAL_OUTDIR --name "$KAIZENBOT_PROJECT" "$GIT_REPO" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log
        export ROBOT_RETURNCODE=$?
        #Validate_ReturnCode_andExit $ROBOT_RETURNCODE
    else
        ##Running firmware/Upgrade sanity in parallel - special scenario
        echo "CASE:4 Running Firmware Upgrade/Sanity Test"

        ##creating nodes.txt after reading variables from pipeline
        if [ "$KAIZENBOT_NODES" ]
        then
            if [[ "$KAIZENBOT_NODES" == *"$COMMA"* ]]
            then
                NODES=$(echo $KAIZENBOT_NODES | tr "," "\n")
            else
                NODES=$KAIZENBOT_NODES
            fi
            echo "Creating nodes.txt"
            echo $NODES

            NODESFILE=$KAIZENBOT_INTERNAL_OUTDIR/nodes.txt
            echo $NODESFILE
            echo "$NODES">$NODESFILE
        else
            echo "ERROR: Please provide nodes"
            deactivate
            exit 252  #252=>	Invalid test data or command line options.
        fi

        echo "${INTERNAL_TESTS_TO_RUN[@]}"
        if [[ $KAIZENBOT_SUITE_SERIAL_EXECUTION == 'True' && $KAIZENBOT_SUITENAME != 'All' && $KAIZENBOT_SUITENAME == *"$COMMA"* ]]
        then
            $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.argfile_generator "$NODESFILE" "$GIT_REPO" --ordering "$SUITE_EXEC_ORDER_FILE" --tester "$KAIZENBOT_USERNAME" --noplatform --verbose --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command --RunEmptySuite "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d "$KAIZENBOT_INTERNAL_OUTDIR" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log
            export KB_RETURNCODE=$?
            #Validate_ReturnCode_andExit $KB_RETURNCODE
        else
            $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.argfile_generator "$NODESFILE" "$GIT_REPO" --tester "$KAIZENBOT_USERNAME" --noplatform --verbose --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command --RunEmptySuite "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d "$KAIZENBOT_INTERNAL_OUTDIR" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log
            export KB_RETURNCODE=$?
            #Validate_ReturnCode_andExit $KB_RETURNCODE
        fi
    fi
}

Copy_ReportFiles_AgentServer()
{
### Copy all required files to ADS
if [ -f $KAIZENBOT_INTERNAL_OUTDIR/output.xml ]; then echo "File exists"; fi
echo $KAIZENBOT_LABSERVER_HOME
echo $KAIZENBOT_INTERNAL_OUTDIR
echo $ADS_SERVER_ADDRESS
echo $ADS_AGENT_USER
echo $ADS_AGENT_PASSWORD
echo $ADS_RESULT_DEST
echo KB_RETURNCODE:$KB_RETURNCODE
echo ROBOT_RETURNCODE:$ROBOT_RETURNCODE

$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/output.xml $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/output.xml
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/xunit.xml $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/xunit.xml
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/report.html $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/report.html
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/log.html $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/log.html
if [ $KAIZENBOT_PROJECT == 'INS' ]; then
    $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/TestReport.csv $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/TestReport.csv
fi
if [[ $KAIZENBOT_REPLICATE_IN_PARALLEL = 'True' || "${KAIZENBOT_SUITENAME,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_SUITENAME,,}" == *"${UPGRADE_STR,,}"* ]]; then
    $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $NODESFILE $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/nodes.txt
fi
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfolder $KAIZENBOT_INTERNAL_LOGDIR $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST
}

Remove_BuildFiles()
{
    if [ -e $BUILD_FILE ]; then rm -f $BUILD_FILE; fi
    if [ -e $CONVERTER_FILE ]; then rm -f $CONVERTER_FILE; fi
}

if [ $# == 1 ]
then
    . $1
    #rm -f $1
    echo $HOME
    source $HOME/kaizenbot/bin/activate
    PreEcho
    Define_Variables
    Create_TSSTR_TCSTR
    Populate_Robot_Options
    Create_Output_Dir
    Populate_Pabot_Options
    Collect_TestCases_TestSuites
    Create_Clone_Git_Repo
    Update_Skip_Tag
    Download_Build_Files
    Define_NodeFile_Print
    Create_Runliner
    Copy_ReportFiles_AgentServer
    if [ "$KAIZENBOT_RERUN_LEVEL" ]
    then
        echo "Rerun Initiated"
        LAST_OUTPUT_FILE="$KAIZENBOT_INTERNAL_OUTDIR/output.xml"
        Populate_Robot_Options
        Create_Output_Dir
        Populate_Pabot_Options
        if echo $KAIZENBOT_RERUN_LEVEL | grep -qi 'test_level'; then INTERNAL_TESTS_TO_RUN+=( --rerunfailed $LAST_OUTPUT_FILE ); fi
        if echo $KAIZENBOT_RERUN_LEVEL | grep -qi 'suite_level'; then INTERNAL_TESTS_TO_RUN+=( --rerunfailedsuites $LAST_OUTPUT_FILE ); fi
        Update_Skip_Tag
        Collect_TestCases_TestSuites
        Download_Build_Files
        Define_NodeFile_Print
        Create_Runliner
        Copy_ReportFiles_AgentServer
    fi
    ##remove files after test completion
    #rm -f $1
    #rm $NODESFILE
    deactivate
else
    echo "FATAL: TMPENV missing"
    exit 255  #255 =>	Unexpected internal error.
fi
