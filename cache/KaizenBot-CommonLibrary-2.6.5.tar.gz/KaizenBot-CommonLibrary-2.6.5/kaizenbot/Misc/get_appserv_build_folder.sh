#!/bin/bash

RELEASE_FWVERSION=$1
rm -f index.htm*
rm -f Latest*

TGT_BUILD=$RELEASE_FWVERSION
PACKAGE_NAME='DI-AppServices-Package-'$TGT_BUILD'_TS.zip'
echo "Fetching base folder listing"
wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/ 2>&1
FOLDER_LOCATION=""
BFOLDER="None"
if [ "$?" != "0" ]
then
	echo "Wget: Failed"
	#exit 1
fi
echo "Fetching App Serv folders"
DIRLIST="`grep NB_DIAppServices_2021 index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
echo $DIRLIST
got_a_hit="0"
for d in $DIRLIST
do
	echo "Searching http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage"
	wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage 2>&1
	if [ "$?" != "0" ]
	then
		echo "No folder named FinalPackage. Ignoring this folder"
		rm -f FinalPackage
		continue
	else
		echo "http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage is a valid location"
		FOLDER_LOCATION="`grep $TGT_BUILD FinalPackage | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
		if [ "$FOLDER_LOCATION" != "" ]
		then
			got_a_hit="1"
			rm -f FinalPackage
			break
		fi
		rm -f FinalPackage
	fi
done
if [ "$got_a_hit" == "1" ]
then
	echo "Firmware available at: http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage/$PACKAGE_NAME"
	#echo "Firmware available at: http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage/$FOLDER_LOCATION"
	rm -f index.htm*
	export BFOLDER="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage/$PACKAGE_NAME"
	#export BFOLDER="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage/$FOLDER_LOCATION"
	#exit 0
else
	echo "Could not locate firmware $RELEASE_FWVERSION"
	rm -f FinalPackage*
	#exit 1
fi
