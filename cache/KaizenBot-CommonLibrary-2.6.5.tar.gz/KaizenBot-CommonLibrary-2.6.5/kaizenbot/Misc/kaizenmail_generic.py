#!/usr/bin/env python3
import smtplib
from email.message import EmailMessage
import os,re
import sys
import pymsteams
from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.kbotdbclient_psql import _KBotDBClient_psql
azurelib = AzureLibrary()
from kaizenbot.azuredata import  update, pat, TestPlanID, TestSuiteID, tester, parallel

def _create_email_body(proj, suite):
    """
    :return: email_body and email_subject
    """
    ##Setting suite name for Sanity and Firmware Upgrade and updating mail body accordingly
    suite_name = 'Sanity' if suite == 'Sanity' else suite
    suite_name = 'Firmware Upgrade' if suite_name == 'Firmware Upgrade' else suite

    if proj.lower() == "gen5riva":
        email_subject = "%s - %s --- G5R Rel %s" % (suite_name, status, build)
    else:
        email_subject = "%s - %s --- %s Rel %s" % (proj, suite_name, status, build)

    email_subject = "%s - Test Report --- %s" % (proj, status) if suite_name != 'Sanity' and suite_name != 'Firmware Upgrade' else email_subject

    email_body = "Hi,\n"
    email_body += "\n%s build '%s' %s test results.\n" % (proj, build, suite) if suite_name == 'Sanity' or suite_name == 'Firmware Upgrade' else "\n%s test results.\n" % proj
    email_body += decstr
    email_body += "\nRan on %s node(s)." % total_nodes if suite_name == 'Sanity' or suite_name == 'Firmware Upgrade' else "\nRan %s tests." % total_num
    email_body += "\nTotal Tests: %s." % total_num if suite_name == 'Sanity' or suite_name == 'Firmware Upgrade' else ''
    email_body += "\nPassed: %s." % pass_num
    email_body += "\nFailed: %s." % fail_num
    email_body += "\nSkipped: %s." % skip_num
    email_body += "\n\nPass Consistency: %s%s" % (pass_percentage, '%') if suite_name == 'Sanity' or suite_name == 'Firmware Upgrade' else "\n\nPass Percentage: %s%s" % (pass_percentage, '%')
    email_body += "\nFail Consistency: %s%s" % (fail_percentage, '%') if suite_name == 'Sanity' or suite_name == 'Firmware Upgrade' else "\nFail Percentage: %s%s" % (fail_percentage, '%')
    email_body += "\nMin. Pass Percentage: %s%s" % (min_pass_perc, '%') if min_pass_perc else ''
    email_body += "\n\nRun By: %s\n" % username
    email_body += decstr
    email_body += "\nLab details and Reports are attached.\n"
    email_body += "\nPipeline Details: %s" % pipeline_url
    email_body += "\nTestRun Url: %s" % Test_Run_Url
    email_body += "\nBug Link: %s" % BugLink if create_bug_flag and BugLink else ''
    email_body += "\n\nRegards,"
    email_body += "\nTeam KaizenBot"
    return email_body, email_subject

def _send_mail(From, To, Subject, Body):
    try:
        email = EmailMessage()
        email['From'] = From
        email['To'] = ','.join(To)
        email['Subject'] = Subject
        email.set_content(Body)

        r_fd = open(os.path.join(output_path, 'report.html'), 'rb')
        r_content = r_fd.read(); r_fd.close()
        l_fd = open(os.path.join(output_path, 'log.html'), 'rb')
        l_content = l_fd.read(); l_fd.close()

        if suite_name == 'Sanity' or suite_name == 'Firmware Upgrade':
            n_fd = open(os.path.join(output_path, 'nodes.txt'), 'rb')
            n_content = n_fd.read(); n_fd.close()
            email.add_attachment(n_content, maintype='text', subtype='text', filename='Node-Details.txt')

        if suite_name == 'Sanity':
            email.add_attachment(r_content, maintype='text', subtype='html', filename='SanityReport.html')
            email.add_attachment(l_content, maintype='text', subtype='html', filename='SanityLog.html')
        elif suite_name == 'Firmware Upgrade':
            email.add_attachment(r_content, maintype='text', subtype='html', filename='FirmwareUpgradeReport.html')
            email.add_attachment(l_content, maintype='text', subtype='html', filename='FirmwareUpgradeLog.html')
        elif project_name.lower() == 'ins':
            email.add_attachment(r_content, maintype='text', subtype='html', filename='kb_report.html')
            email.add_attachment(l_content, maintype='text', subtype='text', filename='kb_log.html')
            if os.path.isfile(output_path + "/TestReport.csv"):
                email.add_attachment(clet_report_content.encode('utf-8'), maintype='text', subtype='csv',
                                     filename='CLET_TestReport.csv')
                email.add_attachment(clet_suiteurl_content.encode('utf-8'), maintype='text', subtype='text',
                                     filename='CLET_TestSuites.txt')
        else:
            email.add_attachment(r_content, maintype='text', subtype='html', filename='Report.html')
            email.add_attachment(l_content, maintype='text', subtype='html', filename='Log.html')

        if os.path.exists(os.path.join(output_path, 'Non-Fatal-Errors.txt')):
            fd = open(os.path.join(output_path, 'Non-Fatal-Errors.txt'), 'rb')
            content = fd.read()
            email.add_attachment(content, maintype='text', subtype='text', filename='Errors.txt')
            fd.close()
        smtpObj = smtplib.SMTP('localhost') if os.name != 'nt' else smtplib.SMTP('ban-w170401.itron.com')
        smtpObj.send_message(email)
        print("Successfully sent email")
    except smtplib.SMTPException as e:
        print(e)
        print("Error: unable to send email")

#Getting test run id from build variables
test_runid=os.environ.get('TEST_RUNID')
print("Test Run ID: {}".format(test_runid))

min_pass_perc = os.getenv('KAIZENBOT_MINPASS_PERC')

if (test_runid == "" or test_runid == None):
    kbvarfile=sys.argv[1]
    if (os.path.isfile(kbvarfile)):
        with open(kbvarfile, 'r') as kbf:
            kbf_data=kbf.read()
            print(kbf_data)
            pat=re.search(r"(?<=pat=)'(.*)'",kbf_data).group(1)
            TestPlanID=re.search(r"(?<=TestPlanID=)'(.*)'",kbf_data).group(1)
            TestSuiteID=re.search(r"(?<=TestSuiteID=)'(.*)'",kbf_data).group(1)
            tester=re.search(r"(?<=tester=)'(.*)'",kbf_data).group(1)
            parallel=re.search(r"(?<=parallel=)'(.*)'",kbf_data).group(1)
            output_path=re.search(r"(?<=ADS_RESULT_DEST=)'(.*)'",kbf_data).group(1)
    else:
        raise FileNotFoundError("File {} does not exists".format(kbvarfile))

#if (test_runid != "" and test_runid != None):
#    ##Getting test config variables from ADS associated with test run id
#    test_configs=azurelib.get_config_from_runid(runid=test_runid)

##Build firmware version, Mail Details, username, areapth for bug creation, project name from test configs and variables
if (test_runid == "" or test_runid == None):
    build=os.environ.get('RELEASE_FWVERSION')
    diffprior=os.environ.get('RELEASE_PRIORFWVERSION')
    slntbase=os.environ.get('RELEASE_SLNTBASEFWVERSION')
    mailto = os.environ.get('KAIZENBOT_EMAILTO').split(',')
    username=os.environ.get('KAIZENBOT_USERNAME')
    project_name=os.environ.get('KAIZENBOT_PROJECT')
    platform_name = os.environ.get('KAIZENBOT_PLATFORM', default='')
    areapath=os.environ.get('KAIZENBOT_BUG_AREAPATH')
    ##Getting LabServer Hostname
    hostname=os.environ.get('KAIZENBOT_LABSERVER')
    print("Hostname: {}".format(hostname))
else:
    ##Getting test config variables from ADS associated with test run id
    test_configs=azurelib._get_config_from_runid(runid=test_runid)
    for key, value in test_configs.items():
        if key.upper().find("G5R"):
            test_configs={key.upper().replace('_G5R_', '_'): value for key, value in test_configs.items()}
    build=test_configs.get('RELEASE_FWVERSION')
    diffprior=test_configs.get('RELEASE_PRIORFWVERSION')
    slntbase=test_configs.get('RELEASE_SLNTBASEFWVERSION')
    mailto=test_configs.get('KAIZENBOT_EMAILTO').split(',')
    username=test_configs.get('KAIZENBOT_USERNAME')
    project_name=test_configs.get('KAIZENBOT_PROJECT')
    platform_name = test_configs.get('KAIZENBOT_PLATFORM', default='')
    areapath=test_configs.get('KAIZENBOT_BUG_AREAPATH')
    hostname=test_configs.get('KAIZENBOT_LABSERVER')
    print("username: {}".format(username))
    print("project: {}".format(project_name))

if (build == 'None'):
    build = ''
print("Build FW Version: {}".format(build))

##ouptut file path to get reports and logs
if not output_path:
    output_path=os.environ.get('ADS_RESULT_DEST')
if output_path.find('/mnt/c/') != -1:
    output_path=output_path.replace('/mnt/c/','C:/',1)

print("Received Test Results and Log files: {}".format(output_path))

##Mail details
mailfrom = 'kaizenbot@kaizenbot.itron.com'

##Getting build number to create build Url
relurl = os.environ.get('RELEASE_RELEASEWEBURL')
if relurl:
    pipeline_url=relurl
else:
    build_number = os.environ.get('BUILD_BUILDNUMBER')
    buildurl="https://itron.visualstudio.com/RnD/_build/results?buildId="+build_number+"&view=results"
    pipeline_url=buildurl

##Getting Pass/Fail data from xunit.xml file
Result = azurelib._parse_xunit_file(output_path)
total_num = Result[0].split(':')[1]
pass_num =Result[2].split(':')[1]
fail_num= Result[1].split(':')[1]
skip_num= Result[3].split(':')[1]

##Getting Pass/Fail data for INS project from TestReport.csv file and CLET TestSuite file Creation
if os.path.isfile(output_path+"/TestReport.csv"):
    _,clet_total_num,clet_pass_num,clet_fail_num,clet_skip_num,_=azurelib._parse_clet_log(output_path)
    print('INS exception verification:',clet_total_num,clet_pass_num,clet_fail_num)

    ##create_testsuite_url file by_testcase_id
    with open(output_path+"/TestReport.csv", 'r') as fh1:
        lines = fh1.readlines()
        fh1.seek(0)
        clet_report_content = fh1.read()

    ##Creating unique urls
    myurlset = set()
    for line in lines[1:]:
        TCID = line.split(',')[0]
        myurlset.add(azurelib.create_testsuite_url_by_testcase_id(TCID, TestSuiteID))

    with open(output_path+"/clet_testsuite.txt", 'w+') as fh2:
        for val in myurlset:
            fh2.write(val+'\n')
        fh2.seek(0)
        clet_suiteurl_content = fh2.read()

##Getting suite name from xunit.xml file
suite = azurelib._parse_suite_name(output_path)
suite_name = suite.split('&')[0]

#Getting number of nodes
if os.path.isfile(output_path+"/nodes.txt"):
    fd = open(output_path+"/nodes.txt","r")
    tmparr = fd.readlines()
    fd.close()
    nodes = [x for x in tmparr if x != '\n']
    total_nodes = str(len(nodes))
else:
    total_nodes = '0'

##Creating configuration name to update in ADS based on pipeline variable
if os.getenv('KAIZENBOT_ADS_UPDATE_CONFIG'):
    config = os.getenv('KAIZENBOT_ADS_UPDATE_CONFIG')
    config_pattern = {'%b': build, '%diffprior': diffprior, '%slntbase': slntbase}
    config_name = 'FW.'+'-'.join([config_pattern[val] if val in config_pattern.keys() else val for val in config.split('-')])
elif build != "":
    config_name='FW.'+str(build)
else:
    if project_name.lower()=='gen5riva':
        config_name='Gen5Riva_Network'
    elif project_name.lower()=='ins':
        config_name='500-INS Alpha1'
    else:
        config_name=project_name
print("Configuration Name: {}".format(config_name))

##Updating result in ADS
if (test_runid != "" and test_runid != None):
    Flag,Test_Run_Url,elapsed_time = azurelib.update_result_in_vsts_based_on_runid(update=update, runid=test_runid, tester=tester,log_path=output_path+'/Logs', result_path=output_path)
else:
    Flag,Test_Run_Url,elapsed_time = azurelib.update_result_in_vsts(update=update, planid=TestPlanID, suiteid=TestSuiteID, tester=tester,log_path=output_path+'/Logs', result_path=output_path, configuration=config_name)
print("ADS Testcases Updation: %s"%Flag)
print("Test Run URL: {}".format(Test_Run_Url))

##Variables for creating bug
build_req_email=os.environ.get('BUILD_REQUESTEDFOREMAIL')
if build_req_email:
    user_email=build_req_email
else:
    release_req_email=os.environ.get('RELEASE_REQUESTEDFOREMAIL')
    user_email=release_req_email

print("User email for creating bug: {}".format(user_email))
if user_email=='' or user_email==None:
    user_email='' ##no user name to assign bug

##Creating Bug for failed test cases in ADS
create_bug_var=os.environ.get('KAIZENBOT_CREATE_BUG')
create_bug_flag = True if create_bug_var == True or create_bug_var.lower() == 'true'\
                              or create_bug_var.lower() == 'yes' else False
print("create bug flag:{} ".format(create_bug_flag))

BugLink= None
if create_bug_flag:
    BugID=azurelib.create_bug_in_ADS(output_path, user_email, areapath,log_path=output_path+'/Logs')
    if BugID != -1:
        print("Bug ID: "+str(BugID))
        res = zip(['https://dev.azure.com/itron/RnD/_workitems/edit/'] * len(BugID), BugID)
        BugLink = [x[0] + x[1] for x in res]
else:
    print("User has requested not to create bug for failure")

##Calculating pass and fail percentage based on parsed xnunit.xml data
pass_percentage=round((int(pass_num)/int(total_num))*100,2)
fail_percentage=round((int(fail_num)/int(total_num))*100,2)

##Setting status in mail to Pass/Fail based on the overall result
if project_name.lower() == 'gen5riva':
    status='FAIL' if int(pass_num) == 0 else 'PASS'
elif min_pass_perc:
    status='PASS' if pass_percentage >= float(min_pass_perc) else 'FAIL'
else:
    status='PASS' if int(fail_num) == 0 else 'FAIL'

##Creating non-fatal error text for failures in output.xml file
non_fatal_error= azurelib._get_non_fatal_error(output_path)
print("List of Errors observed in Output: {}".format(non_fatal_error))
if (non_fatal_error != []):
    for errors in non_fatal_error:
        f=open(os.path.join(output_path,'Non-Fatal-Errors.txt'),'a+',newline='\n')
        f.write(errors)
        f.write('\n')
        f.close()

##Mail decorating string
decstr = '#'*27
perc = "%"

if project_name.lower()=="ins":
    subject = "%s - Test Report --- %s" % (project_name, status)
    res = "CLET execution Passed." if total_num == pass_num else "CLET execution Failed."
    body = "Hi,\n\n%s test results.\n%s\n%s\nRun By: %s\n\nFor more information please look at the attached kb_log.html file.\n%s\nLab details and Reports are attached \n\nPipeline Details: %s\nTestRun Url: %s\nTestSuite Url: Please check CLET_TestSuites.txt\n\nRegards,\nTeam KaizenBot" % (project_name,decstr,res,username,decstr,pipeline_url,Test_Run_Url)
else:
    body, subject = _create_email_body(project_name, suite_name)

##Dictionary to customize subject line
email_subject_format=os.environ.get('KAIZENBOT_EMAIL_SUBJECTLINE')
pattern_dict = {'%p': project_name, '%s': suite_name, '%r': status, '%b': build, '%plat': platform_name, '%diffprior': diffprior, '%slntbase': slntbase, '\s': ' ', '\t': '    '}

##Customizing subject line if email.subject available on pipeline variable
if email_subject_format:
    subject=''
    for patt in email_subject_format.split('-'):
        subject+=pattern_dict[patt] if patt in pattern_dict.keys() else patt

#Sending email to the intended audience
_send_mail(mailfrom, mailto, subject, body)

#Sending notification to Microsoft Teams
if(suite_name == 'Sanity') or (suite_name == 'Firmware Upgrade'):
    body_text = "Hi, \n\n%s build '%s' %s test results. \n%s\n\nRan on%s nodes.\n\nPassed on %s nodes. \n\nFailed on %s nodes. \n\nSkipped %s tests. \n\nPass Consistency: %s%s \n\nFail Consistency: %s%s \n\nRun By: %s\n%s \n\n\n\nRegards,\n\nTeam KaizenBot" %(project_name, build,suite_name,decstr,total_nodes,pass_num,fail_num,skip_num,pass_percentage,perc,fail_percentage,perc,username,decstr)
else:
    body_text = "Hi,\n\n%s test results.\n%s\n\nRan %s tests.\n\nPassed: %s tests. \n\nFailed: %s tests.\n\nSkipped: %s tests. \n\nRun By: %s \n%s \n\n\n\nRegards,\n\nTeam KaizenBot" %(project_name,decstr,total_num,pass_num,fail_num,skip_num,username,decstr)
try:
    teamsMsg = pymsteams.connectorcard("https://itron.webhook.office.com/webhookb2/3b00b839-b80c-4c07-bdb0-e5de2cc66dd1@5818bd20-bf25-47b1-b996-d419d7e6e8ba/IncomingWebhook/ef85c248b8fa4e24ac94b1db8681ec1f/bf82ee61-0da4-42d6-ab39-e1ec7b6f4738")
    teamsMsg.title(subject)
    teamsMsg.text(body_text)
    teamsMsg.addLinkButton("Pipeline Details", pipeline_url)
    teamsMsg.addLinkButton("Test Run URL", Test_Run_Url)
    teamsMsg.send()
    print("Successfully sent message to Teams")
except:
    print("Error: unable to send message to Teams")

try:
    kzobj = _KBotDBClient_psql('kaizenbot.itron.com:5432','','','kaizenbotschema')
    kzobj.capture_runinfo(pipeline_url, Test_Run_Url, elapsed_time)
except Exception:
    pass

#Return exit_code according to pass/fail numbers
if(suite_name == 'Sanity' or suite_name == 'Firmware Upgrade') and (project_name.lower()=='gen5riva'):
    if int(pass_num) > 0:
        sys.exit(0)
    else:
        sys.exit(1)
elif min_pass_perc:
    sys.exit(0) if pass_percentage >= float(min_pass_perc) else sys.exit(1)
else:
    if int(fail_num) > 0:
        sys.exit(1)
    else:
        sys.exit(0)
