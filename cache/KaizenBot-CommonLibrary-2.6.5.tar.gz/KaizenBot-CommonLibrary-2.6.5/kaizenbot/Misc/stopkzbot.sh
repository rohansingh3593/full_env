#!/bin/bash
BUILD_NUM=$1
IFS='
'
for pid in `ps aex | grep -i build_buildnumber=$BUILD_NUM | grep -v grep | cut -d' ' -f1`
do
	kill -TERM $pid
done

