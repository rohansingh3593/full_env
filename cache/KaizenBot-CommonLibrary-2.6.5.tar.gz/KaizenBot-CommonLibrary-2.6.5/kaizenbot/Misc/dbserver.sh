#!/bin/bash
source /home/kaizenbot/kaizenbot/bin/activate
KBOTIP=10.21.64.47
KBOTPORT=8270
UIPORT=8271
status() {
	echo -n "Checking of DB server is running.."
	python3 -m robotremoteserver test $KBOTIP:$KBOTPORT 2>&1 >/dev/null
	if [ $? -ne 0 ]
	then
		echo "Not Running"
	else
		echo "Running"
	fi
	echo -n "Checking if DB UI server is running.."
	UIPID=`ps ax | grep sqlite | grep $UIPORT | sed -e 's/^[ \t]*//' | cut -d ' ' -f1`
	if [ "$UIPID" == "" ]
	then
		echo "Not Running"
	else
		echo "Running (PID: $UIPID)"
	fi
	return $UIPID
}

stop() {
	echo -n "Stopping DB server and UI server..."
	python3 -m robotremoteserver stop $KBOTIP:$KBOTPORT
	if [ $? -ne 0 ]
	then
		echo "DB server stop Failed"
	else
		echo "DB Server stopped. OK"
	fi
	UIPID=`ps ax | grep sqlite | grep $UIPORT | sed -e 's/^[ \t]*//' | cut -d ' ' -f1`
	if [ "$UIPID" != "" ]
	then
		echo "Stopping DB UI server PID: $UIPID"
		kill -9 $UIPID
	fi
	echo "UI Server stopped. OK"
}
start() {
	echo -n "Starting DB server and UI server..."
	nohup python3 -m Gen5RivaLibrary.kbotdbserver $HOME/kaizenbot/Resource-Pool/kaizenbotDB.db $KBOTIP $KBOTPORT 2>&1 >/dev/null &
	nohup sqlite_web --host $KBOTIP --port $UIPORT --no-browser --read-only $HOME/kaizenbot/Resource-Pool/kaizenbotDB.db 2>&1 >$HOME/dbui.log &

}

if [ "$1" == "" ]
then
	status
elif [ "$1" == "status" ]
then
	status
elif [ "$1" == "start" ]
then
	start
elif [ "$1" == "stop" ]
then
	stop
else
	echo "Invalid option. Specify one of [start|stop|status]"
	exit 1
fi
deactivate
exit 0

