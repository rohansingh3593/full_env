from robot.libraries.Remote import Remote
SERVER_PORT = '8270'

def runscript(file):
	global REMOTE_URI
	rmlib = Remote(REMOTE_URI)
	with open(file,'r') as sf:
		script = sf.read()
		
	queries = script.split(';')
	for query in queries:
		if query:
			rmlib.run_keyword('runquery', [query], {})
			print("Successfully Ran:")
			print(query)
			
if __name__ == '__main__':
	msg = '''Help Message:
			 \rIt needs 2 arguments.
			 \rFirst argument is server ip and second argument is sql script file.
             \re.g. python populatedata.py 10.21.64.47 mysqlscript.txt
		  '''
	global REMOTE_URI
	import sys
	if len(sys.argv) < 3:
		raise RuntimeError(msg)
	REMOTE_URI = sys.argv[1] + ':'+ SERVER_PORT
	try:
		runscript(sys.argv[2])
	except RuntimeError as e:
		raise RuntimeError(str(e)+"\nNote: Make sure you are connected to VPN")
	except Exception as e:
		raise RuntimeError(str(e)+'\n'+msg)
		