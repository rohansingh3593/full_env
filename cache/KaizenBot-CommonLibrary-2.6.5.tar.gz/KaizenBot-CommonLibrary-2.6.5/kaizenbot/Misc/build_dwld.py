import requests
from bs4 import BeautifulSoup
import os
import re
from kaizenbot.Misc.runprog import Color

CURDIR = os.path.dirname(os.path.abspath(__file__))

def get_last_link(url, type = 'ignore'):
    page = requests.get(url)
    soup = BeautifulSoup(page.content, features='lxml')
    all_links = [link.get("href") for link in soup("a")]
    return all_links[-1]
    
def get_first_link(url, type = 'ignore'):
    page = requests.get(url)
    soup = BeautifulSoup(page.content, features='lxml')
    all_links = [link.get("href") for link in soup("a")]
    return all_links[0]
    
def get_indexed_link(url, index, type = 'ignore'):
    try:
        index = int(index)
    except ValueError:
        raise ValueError("index must be integer or string-convertible-to-integer")
    page = requests.get(url)
    soup = BeautifulSoup(page.content, features='lxml')
    all_links = [link.get("href") for link in soup("a")]
    return all_links[index]

def get_link_from_type(url, ext_type):
    page = requests.get(url)
    soup = BeautifulSoup(page.content, features='lxml')
    all_links = [link.get("href") for link in soup("a")]
    resultant = [x for x in all_links if re.search(ext_type,x)]
    return resultant[0]
    
def get_build_link(url, build):
    if build is None:
        return get_last_link(url)
    page = requests.get(url)
    soup = BeautifulSoup(page.content, features='lxml')
    for link in soup("a"):
        blink = link.get("href")
        if build in str(blink):
            return blink

class Build:
    
    def __init__(self):
        pass
        
    """
    def build_file_name(self):
        pass
        
    def build_url(self):
        pass"""

    @staticmethod
    def _log_message_and_exit(ret_msg, ret_code, exp_handle):
        print("%s%s%s\n" % (Color.RED, ret_msg, Color.ENDC), "%s%s%s" % (Color.BLUE, repr(exp_handle) + ' at file: ' + os.path.basename(__file__), Color.ENDC))
        sys.exit(ret_code)

    def download_build_file(self, dir=None, ext=None):
        dir = dir or CURDIR
        if not os.path.isdir(dir):
            os.mkdir(dir)
        if not ext:
            build_file = os.path.join(dir, self.build_file_name())
            bld_url = self.build_url()
        else:
            build_file = os.path.join(dir, self.build_file_name(ext_type=ext))
            bld_url = self.build_url(ext=ext)
        print(build_file)
        page = requests.get(bld_url)
        with open(build_file, 'wb') as f:
            f.write(page.content)
        return build_file

class Gen5rivaBuild(Build):
    _HW = '4.2'
    #_PRE_URL = 'http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/GEN5_RIVA_SR_10-0_ALPHA3/Latest/'
    _PRE_URL = 'http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/GEN5_RIVA_SR_10-0_BETA1/Latest/'

    _POST_URL_HW42_d = 'Distribution-Files/Gen5RivaMeter-Dev/DowngradePackage/'
    _POST_URL_HW41_d = 'Distribution-Files/Gen5RivaMeter-HW41-Dev/DowngradePackage/'

    _POST_URL_HW42 = 'Distribution-Files/Gen5RivaMeter-Dev/ColdStartPackage/'
    _POST_URL_HW41 = 'Distribution-Files/Gen5RivaMeter-HW41-Dev/ColdStartPackage/'


    def __init__(self, build = None, pre_url = None, post_url = None, hw = None):
        super(Gen5rivaBuild, self).__init__()
        self._build = build
        self.hw = hw or Gen5rivaBuild._HW
        self.pre_url = pre_url or Gen5rivaBuild._PRE_URL
        #self.post_url = post_url or Gen5rivaBuild._POST_URL_HW41 if self.hw == '4.1' else Gen5rivaBuild._POST_URL_HW42
        downgrade_pkg = os.getenv('KAIZENBOT_DOWNGRADE_PKG')

        if post_url:
            self.post_url = post_url
        elif self.hw == '4.1':
            self.post_url = Gen5rivaBuild._POST_URL_HW41_d if downgrade_pkg == 'True' else Gen5rivaBuild._POST_URL_HW41
        else:
            self.post_url = Gen5rivaBuild._POST_URL_HW42_d if downgrade_pkg == 'True' else Gen5rivaBuild._POST_URL_HW42

    @property
    def _pre_url(self):
        return self.pre_url if self.pre_url.endswith('/') else self.pre_url+'/'
        
    @property
    def _post_url(self):
        return self.post_url.strip()
    
    @property
    def build(self):
        return re.sub('\.', '_',build)
    
    @property
    def _build_folder(self):
        if self.build in self._pre_url:
            return ""
        else:
            return get_build_link(self._pre_url, self.build)
        
    def build_file_folder(self):
        url = self._pre_url + self._build_folder + self._post_url
        return url
        
    def build_file_name(self, ext_type=None):
        url = self.build_file_folder()
        return get_last_link(url) if not ext_type else get_link_from_type(url,ext_type=ext_type)
        
    def build_url(self, ext=None):
        if not ext:
            url = self.build_file_folder() + self.build_file_name()
        else:
            url = self.build_file_folder() + self.build_file_name(ext_type=ext)
        return url

class AsicRivaBuild(Gen5rivaBuild):
    _POST_URL = 'Distribution-Files/AsicMeter-Dev/ColdStartPackage/'

    def __init__(self, build, pre_url, post_url = None):
        super().__init__()
        self._build = build
        self.pre_url = pre_url
        self.post_url = post_url or AsicRivaBuild._POST_URL

class PMRNIC_Build(Gen5rivaBuild):
    _POST_URL = 'Distribution-Files/Gen5Riva-PMR-NIC-Dev/ColdStartPackage/'

    def __init__(self, build, pre_url, post_url = None):
        super().__init__()
        self._build = build
        self.pre_url = pre_url
        self.post_url = post_url or PMRNIC_Build._POST_URL

class DSP_Build(Gen5rivaBuild):
    _POST_URL = 'DMCC_DSPv01/Debug/plc_dsp_app'
    _dsp_type = 'PLC'

    def __init__(self, build, pre_url, post_url = None):
        super().__init__()
        self._build = build
        self.pre_url = pre_url
        if pre_url.find('ASICRF_') != -1:
            DSP_Build._POST_URL = 'DMCC_DSPv01/Debug-PON'
            DSP_Build._dsp_type = 'RF'
        self.post_url = post_url or DSP_Build._POST_URL

    def build_file_folder(self):
        return self._pre_url + self._post_url

class AppservBuild(Build):

    def __init__(self, build, pre_url, post_url = None):
        super(AppservBuild, self).__init__()
        self._build = build
        self.pre_url = pre_url
        self.post_url = post_url
    
    @property
    def _pre_url(self):
        return self.pre_url
        
    @property
    def _post_url(self):
        return self.post_url
    
    @property
    def build(self):
        return self._build
        
    def build_file_name(self):
        print(self._pre_url)
        return os.path.basename(self._pre_url)
        
    def build_url(self):
        return self._pre_url

if __name__ == '__main__':
    import sys
    download_dsp = download_fwu = False
    try:
        if len(sys.argv) == 6:
            script_name=sys.argv[5]
            build = sys.argv[2]
            build_dir = sys.argv[1]
            pre_url = sys.argv[3]
            project_name = sys.argv[4]
            #project_name = project_name[0].upper() + project_name[1:]
            if pre_url.find('DM_PMR_REL') != -1:
                bld = PMRNIC_Build(build, pre_url)
            elif pre_url.find('GEN5_RIVA_') != -1:
                bld = Gen5rivaBuild(build, pre_url)
                if os.getenv('KAIZENBOT_DOWNLOAD_FWU') == 'True':
                    download_fwu = True
            elif pre_url.find('DI_APPSERVICES') != -1:
                bld = AppservBuild(build, pre_url)
            elif pre_url.find('/DSP/') != -1:
                bld = DSP_Build(build, pre_url)
                download_dsp = True
            elif pre_url.find('ASIC_RIVA_') != -1:
                bld = AsicRivaBuild(build, pre_url)
            else:
                raise RuntimeError("No BuildDownload_Class matching to this pre_url: '%s'"%pre_url)
        else:
            raise RuntimeError("5 arguments are required to {}".format(sys.argv[0]))
    except Exception as e:
        message = "Internal Exception:"
        Build._log_message_and_exit(message, 255, e)

    if build_dir.find('/mnt/c/') != -1:
        build_dir=build_dir.replace('/mnt/c/','C:/',1)
    if script_name.find('/mnt/c/') != -1:
        script_name=script_name.replace('/mnt/c/','C:/',1)

    try:
        build_file=bld.download_build_file(dir=build_dir) if not download_dsp else bld.download_build_file(dir=build_dir, ext='testsec.fw.bin')
        if download_fwu:
            build_file2=bld.download_build_file(dir=build_dir,ext='.fwu')
    except Exception as e:
        message = "Download_Build_File Exception:"
        Build._log_message_and_exit(message, 255, e)

    fd = open(script_name,'a')
    fd.write('export BUILD_FILE="'+build_file+'"\n') if not download_dsp else fd.write('export %s_DSP_FILE="%s"\n' % (bld._dsp_type, build_file))
    fd.write('export BUILD_FWU_FILE="'+build_file2+'"\n') if download_fwu else print('User Not requested to download FWU build')
    fd.write('export BUILD_FWVERSION="'+build+'"\n') if not download_dsp else fd.write('export %s_DSP_VERSION="%s"\n' % (bld._dsp_type, build))
    fd.close()
