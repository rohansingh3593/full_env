#!/bin/bash
. $1 
rm -f $1
echo $HOME
source $HOME/kaizenbot/bin/activate

echo "TEST_RUNID: $TEST_RUNID"
echo "KAIZENBOT_SUITEID: $KAIZENBOT_SUITEID"
echo "KAIZENBOT_SUITENAME: $KAIZENBOT_SUITENAME"
echo "KAIZENBOT_TPLANID: $KAIZENBOT_TPLANID"
echo "KAIZENBOT_USERNAME: $KAIZENBOT_USERNAME"
echo "KAIZENBOT_DRYRUN: $KAIZENBOT_DRYRUN"
echo "KAIZENBOT_LOGLEVEL: $KAIZENBOT_LOGLEVEL"
echo "KAIZENBOT_TESTNAME: $KAIZENBOT_TESTNAME"
echo "KAIZENBOT_INCLUDETAGS: $KAIZENBOT_INCLUDETAGS"
echo "KAIZENBOT_EXCLUDETAGS: $KAIZENBOT_EXCLUDETAGS"
echo "KAIZENBOT_PLATFORM: $KAIZENBOT_PLATFORM"
echo "KAIZENBOT_PROJECT: $KAIZENBOT_PROJECT"
echo "KAIZENBOT_WAIT_ON_BUSY_PLATFORM: $KAIZENBOT_WAIT_ON_BUSY_PLATFORM"
echo "KAIZENBOT_NODES: $KAIZENBOT_NODES"
echo "RELEASE_FWVERSION: $RELEASE_FWVERSION"
echo "KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION: $KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION"
echo "KAIZENBOT_USERPAT: $KAIZENBOT_USERPAT"
echo "KAIZENBOT_REPLICATE_IN_PARALLEL: $KAIZENBOT_REPLICATE_IN_PARALLEL"
echo "KAIZENBOT_BUG_AREAPATH: $KAIZENBOT_BUG_AREAPATH"
echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
echo "ADS_AGENT_USER: $ADS_AGENT_USER"
echo "ADS_AGENT_PASSWORD: $ADS_AGENT_PASSWORD"
echo "KAIZENBOT_DBSERVER: $KAIZENBOT_DBSERVER"
echo "KAIZENBOT_DBSERVER_PORT: $KAIZENBOT_DBSERVER_PORT"
echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
echo "KAIZENBOT_LABSERVER_HOME: $KAIZENBOT_LABSERVER_HOME"
echo "KAIZENBOT_SUITE_SERIAL_EXECUTION: $KAIZENBOT_SUITE_SERIAL_EXECUTION"
echo "KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE: $KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE"

if [[ "$KAIZENBOT_EXITONFAILURE" != "" || ${KAIZENBOT_EXITONFAILURE,,} != *"${NONE,,}"* ]]
then
    echo "KAIZENBOT_EXITONFAILURE: $KAIZENBOT_EXITONFAILURE"
    echo "Setting Exit-On-Failure flag"
    KAIZENBOT_EXITONFAILURE='-X'
fi
ADS_SERVER_ADDRESS=kaizenbot.itron.com

SANITY_STR='Sanity'
UPGRADE_STR='Upgrade'
COMMA=','
SPACE=' '
COMMA_SPACE=', '
NONE='None'

##Checking username should not be empty
if [[ "$KAIZENBOT_USERNAME" == "" || ${KAIZENBOT_USERNAME,,} == *"${NONE,,}"* ]]
then
        echo "Please provide username to continue testing"
        deactivate
	exit 1
fi

if [ "$KAIZENBOT_DBSERVER" == "" ]
then
    KAIZENBOT_DBSERVER="$KAIZENBOT_LABSERVER"
fi
if [ "$KAIZENBOT_DBSERVER_PORT" == "" ]
then
    KAIZENBOT_DBSERVER_PORT="8270"
fi
INTERNAL_RESOURCE_SERVER_URI="$KAIZENBOT_DBSERVER:$KAIZENBOT_DBSERVER_PORT"

##Test required variables
INTERNAL_KAIZENBOT_OPTIONS=''
INTERNAL_TESTS_TO_RUN=''
WAIT_ON_BUSY_STATUS='False'
DISABLE_TEST_PARALLELISM='True'

##Creating array to save robot options
INTERNAL_TESTS_TO_RUN=()

## replacing comma to OR to form Tags variable for robot 
KAIZENBOT_INCLUDETAGS=$(echo $KAIZENBOT_INCLUDETAGS | sed 's/,/OR/g')
KAIZENBOT_EXCLUDETAGS=$(echo $KAIZENBOT_EXCLUDETAGS | sed 's/,/OR/g')

## creating robot test and suite options from comma separated variables
OLDIFS=$IFS
IFS=','
TCSTR=()
TSSTR=()
for suitename in $KAIZENBOT_SUITENAME
do
	TSSTR+=( --suite $suitename )
done
for tcname in $KAIZENBOT_TESTNAME
do
	TCSTR+=( --test $tcname )
done
IFS=$OLDIFS
ALL_STR='All'
## If suitename provided is 'All' then making test suite array to empty
if [[ ${KAIZENBOT_SUITENAME,,} == *"${ALL_STR,,}"* || ${KAIZENBOT_SUITENAME,,} == *"${NONE,,}"* ]]
then 
	declare -a TSSTR=()	
	echo "suitename from ADS: $KAIZENBOT_SUITENAME"
	echo "suitename: ${TSSTR[@]}"
fi

##Setting testname, include and exclude tags to empty if the value is None based on Approach 3
if [[ ${KAIZENBOT_TESTNAME,,} == *"${NONE,,}"* ]]
then
        declare -a TCSTR=()
        echo "testname from ADS: $KAIZENBOT_TESTNAME"
        echo "testname: ${TCSTR[@]}"
fi
if [[ ${KAIZENBOT_INCLUDETAGS,,} == *"${NONE,,}"* ]]
then
	declare KAIZENBOT_INCLUDETAGS=""
	echo "include tags: $KAIZENBOT_INCLUDETAGS"
fi
if [[ ${KAIZENBOT_EXCLUDETAGS,,} == *"${NONE,,}"* ]]
then
        declare KAIZENBOT_EXCLUDETAGS=""
        echo "include tags: $KAIZENBOT_EXCLUDETAGS"
fi

## Filling robot option array to pass to test
if [ "$KAIZENBOT_TESTNAME" ]; then INTERNAL_TESTS_TO_RUN+=( "${TCSTR[@]}" ); fi
if [ "$KAIZENBOT_SUITENAME" ]; then INTERNAL_TESTS_TO_RUN+=( "${TSSTR[@]}" ); fi
if [ "$KAIZENBOT_INCLUDETAGS" ]; then INTERNAL_TESTS_TO_RUN+=( --include "$KAIZENBOT_INCLUDETAGS" ); fi
if [ "$KAIZENBOT_EXCLUDETAGS" ]; then INTERNAL_TESTS_TO_RUN+=( --exclude "$KAIZENBOT_EXCLUDETAGS" ); fi

##Checking if all required robot variables are empty ans exit test
#if [ "${INTERNAL_TESTS_TO_RUN[0]}" != "" ]; then echo "Running Tests"; else echo "Please provide valid test. Got empty tests."; deactivate; exit 0; fi

###Checking if provided test is sanity or upgrade and setting build download accordingly
DOWNLOAD_BUILD='True'
if [[ "${KAIZENBOT_TESTNAME,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_SUITENAME,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_INCLUDETAGS,,}" == *"${SANITY_STR,,}"* || "${KAIZENBOT_EXCLUDETAGS,,}" == *"${SANITY_STR,,}"* ]]; then INTERNAL_TESTS_TO_RUN+=( --name "$SANITY_STR" ); elif [[ "${KAIZENBOT_TESTNAME,,}" == *"${UPGRADE_STR,,}"* || "${KAIZENBOT_SUITENAME,,}" == *"${UPGRADE_STR,,}"* || "${KAIZENBOT_INCLUDETAGS,,}" == *"${UPGRADE_STR,,}"* || "${KAIZENBOT_EXCLUDETAGS,,}" == *"${UPGRADE_STR,,}"* ]]; then INTERNAL_TESTS_TO_RUN+=( --name "Firmware Upgrade" ); else INTERNAL_TESTS_TO_RUN+=( --name "$KAIZENBOT_PROJECT" ); DOWNLOAD_BUILD='False'; fi

## Filling pabot option array to pass to test
INTERNAL_KAIZENBOT_OPTIONS=()

if [ "$KAIZENBOT_USERNAME" ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --tester "$KAIZENBOT_USERNAME" ); fi

if [ "$KAIZENBOT_PLATFORM" ]
then
	INTERNAL_KAIZENBOT_OPTIONS+=( --useplatform "$KAIZENBOT_PLATFORM" )
	INTERNAL_KAIZENBOT_OPTIONS+=( --resourceserveruri "$INTERNAL_RESOURCE_SERVER_URI" )
	if [ "$KAIZENBOT_PROJECT" ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --project "$KAIZENBOT_PROJECT" ); fi
	if [[ "${KAIZENBOT_WAIT_ON_BUSY_PLATFORM,,}" == *"${WAIT_ON_BUSY_STATUS,,}"* || "$KAIZENBOT_WAIT_ON_BUSY_PLATFORM" == "" ]]; then INTERNAL_KAIZENBOT_OPTIONS+=( --nowait ); fi
else
	INTERNAL_KAIZENBOT_OPTIONS+=( --noplatform )
fi

if [ $KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION = 'False' ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --testlevelsplit ); fi

if [ $KAIZENBOT_SUITE_SERIAL_EXECUTION = 'True' ]; then INTERNAL_KAIZENBOT_OPTIONS+=( --processes 1 ); fi

KAIZENBOT_RUN_PATH=$KAIZENBOT_LABSERVER_HOME/$KAIZENBOT_PROJECT/Output_Directory ## to ask Raj on how to generalise proj name
if [ ! -d $KAIZENBOT_RUN_PATH ]; then mkdir -p $KAIZENBOT_RUN_PATH; fi

##Creating Output and Logs folder
echo "Creating Output and Logs folder"
if [[ "$KAIZENBOT_USERNAME" == *"$SPACE"* ]]
then
        USERNAME=$(echo $KAIZENBOT_USERNAME | tr " " "_")
        G5R_USERNAME=$USERNAME
        if [[ "$USERNAME" == *"$COMMA"* ]]
        then
                G5R_USERNAME=$(echo $USERNAME | tr "," "_")
        fi
elif [[ "$KAIZENBOT_USERNAME" == *"$COMMA"* ]]
then
        G5R_USERNAME=$(echo $KAIZENBOT_USERNAME | tr "," "_")
else
        G5R_USERNAME=$KAIZENBOT_USERNAME
fi
for i in `seq 999999`
do
        if [ -d $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i ]
        then
                continue
        else
                #mkdir $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i
                mkdir -p $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Results
                mkdir -p $KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Logs
                export KAIZENBOT_INTERNAL_OUTDIR=$KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Results
                export KAIZENBOT_INTERNAL_LOGDIR=$KAIZENBOT_RUN_PATH/$G5R_USERNAME-$i/Logs
                break
        fi
done

echo "Result folder: $KAIZENBOT_INTERNAL_OUTDIR"
echo "Logs folder: $KAIZENBOT_INTERNAL_LOGDIR"

##Getting test cases id and plan and suite id based on test run id
if [[ $TEST_RUNID != "" && ${TEST_RUNID,,} !=  *"${NONE,,}"* ]]
then
        echo "Test run id is: $TEST_RUNID"
        echo "Creating Tags for the tests present in Test Run id";
        test_cases_from_runid_path=$KAIZENBOT_INTERNAL_OUTDIR
        echo "Tag for test cases path: $KAIZENBOT_INTERNAL_OUTDIR"
        test_runid=$TEST_RUNID
        echo "Test Run ID: $test_runid"
        echo "Internal test to run: ${INTERNAL_TESTS_TO_RUN[@]}"
        $(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat
azurelib = AzureLibrary(pat)
test_cases=azurelib._get_test_cases_by_runid(runid='$test_runid')
print("test_case_tag=%s"%test_cases)' 1>$test_cases_from_runid_path/test_case_tag.log)
	Test_case_tag="`eval grep 'test_case_tag=' $test_cases_from_runid_path/test_case_tag.log | sed 's/^.*=//'`"
        echo $Test_case_tag
        INTERNAL_TESTS_TO_RUN+=( $Test_case_tag )
        echo "New Test val: ${INTERNAL_TESTS_TO_RUN[@]}"
else
        #echo "Please provide valid test. Got empty tests.";
        #deactivate;
        #exit 0;
        echo -n ""
fi

###Create include tag if user has provided suitename as 'All' and provided plan and suite id to select all test cases
echo "suite: $KAIZENBOT_SUITENAME"
if [[ ${KAIZENBOT_SUITENAME,,} == *"${ALL_STR,,}"* ]]
then
        ###check if plan id and suite id is not empty
        if [[ "$KAIZENBOT_TPLANID" == "" || ${KAIZENBOT_TPLANID,,} == *"${NONE,,}"* ]]
        then
                echo "Please provide Plan id to proceed with the execution"
                exit 1
        fi
        if [[ "$KAIZENBOT_SUITEID" == "" || ${KAIZENBOT_SUITEID,,} == *"${NONE,,}"* ]]
        then
                echo "Please provide Suite id to proceed with the execution"
                exit 1
        fi
	tag_path=$KAIZENBOT_INTERNAL_OUTDIR
	echo "path to save tag data: $tag_path"
	echo "Internal test to run: ${INTERNAL_TESTS_TO_RUN[@]}"
	$(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat, TestPlanID, TestSuiteID
include_tag=AzureLibrary(pat).create_tags_from_plan_and_suiteid(planid=TestPlanID,suiteid=TestSuiteID)
print("include_tag=%s"%include_tag)' 1>$tag_path/tag.log)
        Include_Tag="`eval grep 'include_tag=' $tag_path/tag.log | sed 's/^.*=//'`"
        echo $Include_Tag
        INTERNAL_TESTS_TO_RUN+=( $Include_Tag )
        echo "New Test val: ${INTERNAL_TESTS_TO_RUN[@]}"
fi

##Creating git repo folder if not present
GIT_REPO_FOLDER=$KAIZENBOT_LABSERVER_HOME/kaizenbot/git_repo
if [ ! -d $GIT_REPO_FOLDER ]; then mkdir -p $GIT_REPO_FOLDER; fi

##getting test suites from GIT
echo "Getting Test Suites from Git"
if [[ "$BUILD_BUILDNUMBER" == "" || ${BUILD_BUILDNUMBER,,} == *"${NONE,,}"* ]]
then
	echo "This is a release pipeline. Expecting Repo/Branch details from variables"
	if [[ "$KAIZENBOT_TESTS_REPOSITORY" == "" || ${KAIZENBOT_TESTS_REPOSITORY,,} == *"${NONE,,}"* ]]
	then
		echo "Repo details are not provided. Please set kaizenbot.tests.repository"
		deactivate
		exit 1
	fi
	if [[ "$KAIZENBOT_TESTS_REPOSITORY_BRANCH" == "" || ${KAIZENBOT_TESTS_REPOSITORY_BRANCH,,} == *"${NONE,,}"* ]]
	then
		echo "Branch details are not provided. Please set kaizenbot.tests.repository.branch"
		deactivate
		exit 1
	fi
	$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.gitlibrary $GIT_REPO_FOLDER $KAIZENBOT_TESTS_REPOSITORY $KAIZENBOT_TESTS_REPOSITORY_BRANCH 2>$GIT_REPO_FOLDER/gitcommands.log
	GIT_REPO=$GIT_REPO_FOLDER/$KAIZENBOT_TESTS_REPOSITORY
else
	$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.gitlibrary $GIT_REPO_FOLDER 2>$GIT_REPO_FOLDER/gitcommands.log
	GIT_REPO=$GIT_REPO_FOLDER/$BUILD_REPOSITORY_NAME
fi
export GIT_REPO
echo "git repo folder: $GIT_REPO"

##Downloading build if test/suite is sanity or firmware upgrade
##Downloading build for every run as user will run test based on approach 3 and user will not provide suite/test name
DOWNLOAD_BUILD='True'
if [ $DOWNLOAD_BUILD = 'True' ]
then
	echo "Downloading Build"
        echo $RELEASE_FWVERSION
        if [[ "$RELEASE_FWVERSION" == "" || ${RELEASE_FWVERSION,,} == *"${NONE,,}"* ]]
        then
		echo "Please provide build number/firmware version to download build"
		#deactivate
                #exit 1
        fi
	CONVERTER_VERSION='10.0.113.2'
        BUILD_DIR=$KAIZENBOT_INTERNAL_OUTDIR/
        echo "Build directory is:$BUILD_DIR"
	export BUILD_DIR
	SITEPKG_VAR="`find $KAIZENBOT_LABSERVER_HOME/kaizenbot/lib -name 'kaizenbot'`"
        chmod +x $SITEPKG_VAR/Misc/get_build_folder.sh
   
	##Downloading Build File
        echo "Downloading Build File"
	. $SITEPKG_VAR/Misc/get_build_folder.sh $RELEASE_FWVERSION $KAIZENBOT_PROJECT
        echo "Folder is: $BFOLDER"
        if [ "$BFOLDER" != "None" ]
        then
		TMP_SCRIPTNAME=`mktemp -u`
		echo "#!/bin/bash" > $TMP_SCRIPTNAME
		$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $RELEASE_FWVERSION $BFOLDER $KAIZENBOT_PROJECT $TMP_SCRIPTNAME
		chmod +x $TMP_SCRIPTNAME
		. $TMP_SCRIPTNAME
        rm -f $TMP_SCRIPTNAME
		#eval `$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $RELEASE_FWVERSION $BFOLDER $KAIZENBOT_PROJECT`
        else
		echo "No Build file found."
                #deactivate
		#exit 0
        fi
        echo "Build file is:$BUILD_FILE"
        echo "Build fw version is:$BUILD_FWVERSION"
	BUILD_FILE=$BUILD_FILE
	BUILD_VERSION=$BUILD_FWVERSION
	export BUILD_FILE BUILD_VERSION
        	
	INTERNAL_TESTS_TO_RUN+=( -v build_file:"$BUILD_FILE" -v A7_Version:"$BUILD_FWVERSION" -v build_version:"$BUILD_FWVERSION" )
       	
	##Downloading Converter File
        echo "Downloading Converter File"
        . $SITEPKG_VAR/Misc/get_build_folder.sh $CONVERTER_VERSION
        if [ "$BFOLDER" != "None" ]
        then
		        TMP_SCRIPTNAME=`mktemp -u`
		        echo "#!/bin/bash" > $TMP_SCRIPTNAME
                $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $CONVERTER_VERSION $BFOLDER $KAIZENBOT_PROJECT $TMP_SCRIPTNAME
                #eval `$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 $SITEPKG_VAR/Misc/build_dwld.py $BUILD_DIR $CONVERTER_VERSION $BFOLDER $KAIZENBOT_PROJECT`
		        chmod +x $TMP_SCRIPTNAME
		        . $TMP_SCRIPTNAME
                rm -f $TMP_SCRIPTNAME
        else
                echo "No Converter Build file found"
                #deactivate
		#exit 0
        fi
        CONVERTER_FILE=$BUILD_FILE
        CONVERTER_FWVERSION=$BUILD_FWVERSION
        echo "Converter file is:$CONVERTER_FILE"
        echo "Converter file fw version is:$CONVERTER_FWVERSION"

	INTERNAL_TESTS_TO_RUN+=( -v converter_file:"$CONVERTER_FILE" )
fi

##Nodes file path
NODESFILE=$KAIZENBOT_INTERNAL_OUTDIR/nodes.txt
echo $NODESFILE

##Checking for running replicated tests/suites in parallel
echo "${INTERNAL_KAIZENBOT_OPTIONS[@]}"
echo ${INTERNAL_TESTS_TO_RUN[@]}
echo $ADS_RESULT_DEST
echo $KAIZENBOT_INTERNAL_OUTDIR

if [ $KAIZENBOT_REPLICATE_IN_PARALLEL = 'True' ]
then
	echo "DRY Running Same Tests/Suites in Parallel for all nodes of given platform"
	echo '$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.argfile_generator2 --nodesfile $NODESFILE "${INTERNAL_KAIZENBOT_OPTIONS[@]}" --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d "$KAIZENBOT_INTERNAL_OUTDIR" "$GIT_REPO" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log'

elif [[ "${KAIZENBOT_TESTNAME,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_TESTNAME,,}" != *"${UPGRADE_STR,,}"* && "${KAIZENBOT_SUITENAME,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_SUITENAME,,}" != *"${UPGRADE_STR,,}"* && "${KAIZENBOT_INCLUDETAGS,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_INCLUDETAGS,,}" != *"${UPGRADE_STR,,}"* && "${KAIZENBOT_EXCLUDETAGS,,}" != *"${SANITY_STR,,}"* && "${KAIZENBOT_EXCLUDETAGS,,}" != *"${SANITY_STR,,}"* ]]
then
	##Running test/suites in parallel based without replicate
	echo "DRY Running Suites/tests in parallel"
        #env	
	echo '$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/pabot --verbose "${INTERNAL_KAIZENBOT_OPTIONS[@]}" --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d $KAIZENBOT_INTERNAL_OUTDIR --name "$KAIZENBOT_PROJECT" "$GIT_REPO" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log'

else
	##Running firmware/Upgrade sanity in parallel - special scenario

	##creating nodes.txt after reading variables from pipeline
	if [ "$KAIZENBOT_NODES" ]
	then
        	if [[ "$KAIZENBOT_NODES" == *"$COMMA"* ]]
        	then
                	NODES=$(echo $KAIZENBOT_NODES | tr "," "\n")
        	else
                	NODES=$KAIZENBOT_NODES
        	fi
        	echo "Creating nodes.txt"
        	echo $NODES
		
		NODESFILE=$KAIZENBOT_INTERNAL_OUTDIR/nodes.txt
                echo $NODESFILE
        	echo "$NODES">$NODESFILE
	else
        	echo "ERROR: Please provide nodes"
		deactivate
		exit 0
	fi
	
	echo "DRY Running Firmware Upgrade/Sanity Test with nodes specified"
	echo ${INTERNAL_TESTS_TO_RUN[@]}
	echo '$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.argfile_generator "$NODESFILE" "$GIT_REPO" --tester "$KAIZENBOT_USERNAME" --noplatform --verbose --command $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/robot --end-command "${INTERNAL_TESTS_TO_RUN[@]}" $KAIZENBOT_EXITONFAILURE -d "$KAIZENBOT_INTERNAL_OUTDIR" 2>$KAIZENBOT_INTERNAL_OUTDIR/kzbot_error.log'
fi
deactivate
exit 0
### Copy all required files to ADS
if [ -f $KAIZENBOT_INTERNAL_OUTDIR/output.xml ]; then echo "File exists"; fi
echo $KAIZENBOT_LABSERVER_HOME
echo $KAIZENBOT_INTERNAL_OUTDIR
echo $ADS_SERVER_ADDRESS
echo $ADS_AGENT_USER
echo $ADS_AGENT_PASSWORD
echo $ADS_RESULT_DEST
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/output.xml $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/output.xml
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/xunit.xml $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/xunit.xml
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/report.html $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/report.html
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $KAIZENBOT_INTERNAL_OUTDIR/log.html $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/log.html
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $NODESFILE $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST/nodes.txt
$KAIZENBOT_LABSERVER_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfolder $KAIZENBOT_INTERNAL_LOGDIR $ADS_SERVER_ADDRESS $ADS_AGENT_USER $ADS_AGENT_PASSWORD $ADS_RESULT_DEST
##remove files after test completion
#rm -f $1
#rm $NODESFILE
