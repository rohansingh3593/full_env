#!/usr/bin/env python3
import socket
import paramiko
from paramiko.ssh_exception import SSHException
import time
import sys
import os

class Server:
    def __init__(self, server_ip = None, server_username = None, server_password = None, server_alias = None, timeout = None, port = 22):
        self.server_alias = server_alias 
        self.server_ip = server_ip 
        self.server_username = server_username 
        self.server_password = server_password 
        self.timeout = timeout
        self.server_port = port

        self.client = Server._connect_and_login(self.server_ip, self.server_port, self.server_username, self.server_password, self.timeout)
	
    @staticmethod
    def _connect_and_login(server_ip, server_port, server_username, server_password, timeout):
        """This connects to ``server_ip`` and returns an SSHClient.
        """
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=server_ip, port = server_port, username=server_username, password=server_password, timeout=timeout)
            client.invoke_shell()
            transport = client.get_transport()
            transport.set_keepalive(86400)
        except paramiko.AuthenticationException:
            raise Exception("Authentication failed, please verify your credentials")
        except paramiko.SSHException as sshException:
            raise Exception("Could not establish SSH connection: %s" % sshException)
        except socket.timeout as e:
            raise Exception("Connection timed out: %s" %e)
        except Exception as e:
            raise Exception(e)
        else:
            return client
    
        
    def execute_command(self, command, timeout = 300):
        """This executes command ``command`` on server.
        The command execution timeouts in 5 minutes.
        """
        try:
            timeout = int(timeout)
        except ValueError:
            raise Exception("'timeout' must be an integer or string-convertible-to-integer")
        
        commandout = ''   
          
        try:
            stdin, stdout, stderr = self.client.exec_command(command)
        except paramiko.SSHException as message:
            raise Exception("Executing command '{}' failed: {}".format(command, str(message)))
        else:
            try:
                commandout = stdout.read().decode()
            except socket.timeout:
                raise Exception("Command '{}' taking too long to execute".format(command))
            else:
                if(commandout is ''):
                    commandout = stderr.read().decode()
                    if (commandout is not ''):
                        raise Exception("Executing command '{}' failed: {}".format(command, commandout))
                stdin.flush()
                return commandout
				
if __name__ == '__main__':
        print(len(sys.argv))
        s = Server(server_ip = sys.argv[1], server_username = sys.argv[2], server_password = sys.argv[3])
        command = sys.argv[4]
        print(s.execute_command(command))
