INSERT INTO Project
(PROJECT_NAME)
VALUES 
('GEN5'),
('DIP2P');

INSERT INTO AP
(AP_IP,AP_MAC,AP_SW, AP_NID,PLATFORM_ID,AP_STATUS)
VALUES
('8510','85:10','0x193d','0xfab0','a123','active'),
('8513','85:13','0x193d','0xfab1','b123','active');

INSERT INTO Platform
(PLATFORM_ID, PLATFORM_NAME, PROJECT_NAME)
VALUES
('a123', 'platform1','GEN5'),
('b123', 'platform2','GEN5'),
('c123', 'platform1','DIP2P'),
('d123', 'platform2','DIP2P');

INSERT INTO Node
(NODE_IP, NODE_NAME, NODE_MAC, PLATFORM_ID)
VALUES
('1:2','a:b', 'a123'),
('1:3','a:c', 'a123'),
('1:4','b:b', 'b123'),
('1:5','b:c', 'b123'),
('1:6','c:b', 'c123'),
('1:7','c:c', 'c123'),
('1:8','d:b', 'd123'),
('1:9','d:c', 'd123');