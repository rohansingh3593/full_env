# Copies tables and data from a SQLite database and recreates them
# in a PostgreSQL database

import psycopg2, sqlite3, sys
from getpass import getpass

# Change these values as needed
sqdb = '/home/siraj/kaizenbotDB.db'  # sqlite3 database file
sqlike = ''  # which table to recreate from sqlite3. default = '' which will recreate all the tables
pgdb = 'kaizenbot_gen5cct'  # postgresql database name
pguser = input('Enter the postgress User:')  # postgresql username
pgpswd = getpass(prompt="%s's Password:" % pguser)  # postgresql user_password
pghost = 'kaizenbot.itron.com'  # postgresql database hostname or IP address
pgport = '5432'  # postgresql database port default port is '5432'
pgschema = 'gen5cctschema'  # postgresql schema wherein the tables will be recreated


consq = sqlite3.connect(sqdb)
cursq = consq.cursor()

tabnames = []

if sqlike:
    cursq.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%s'" % sqlike)
else:
    cursq.execute("SELECT name FROM sqlite_master WHERE type='table'")
tabgrab = cursq.fetchall()
for item in tabgrab:
    tabnames.append(item[0])

if not sqlike and pgdb.find('gen5') != -1:
    tabnames[1], tabnames[2] = tabnames[2], tabnames[
        1]  # position to create must be altered for gen5riva db due to dependencies.

print(tabnames)

while True:
    option = input('check the create sequences and press [y/Y] to continue... else press q to quit.\n')
    if option.lower() == 'q':
        exit()
    elif option.lower() == 'y':
        break
    else:
        print('That was an invalid option: {}\t please try again'.format(option))

for table in tabnames:
    print("SELECT sql FROM sqlite_master WHERE type='table' AND name = ?;", (table,))
    cursq.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name = ?;", (table,))
    create = cursq.fetchone()[0]
    table = table.lower()
    cursq.execute("SELECT * FROM %s;" % table)
    rows = cursq.fetchall()
    colcount = len(rows[0])
    pholder = '%s,' * colcount
    newholder = pholder[:-1]

    # some alteration required for creating the table in postgresql
    create = create.replace(table, "%s.%s" % (pgschema, table), 1)
    create = create.replace('REFERENCES ', "REFERENCES %s." % (pgschema))
    create = create.replace(' COLLATE NOCASE', '')
    create = create.replace('NOT_NULL', 'NOT NULL')
    # print(create)

    try:
        conpg = psycopg2.connect(database=pgdb, user=pguser, password=pgpswd,
                                 host=pghost, port=pgport)
        curpg = conpg.cursor()
        curpg.execute("CREATE SCHEMA IF NOT EXISTS %s;" % pgschema)
        curpg.execute("SET search_path TO %s;" % pgschema)
        curpg.execute("DROP TABLE IF EXISTS %s CASCADE;" % table)
        curpg.execute(create)
        curpg.executemany("INSERT INTO %s VALUES (%s);" % (table, newholder), rows)
        if table.find('platform') > -1:
            print("ALTER TABLE %s.%s ADD last_status_change TIMESTAMPTZ NOT NULL DEFAULT ('epoch');" % (pgschema, table))
            curpg.execute("ALTER TABLE %s.%s ADD last_status_change TIMESTAMPTZ NOT NULL DEFAULT ('epoch');" % (pgschema, table))
        elif table.find('node') > -1 or table.find('ap') > -1:
            print("ALTER TABLE %s.%s ADD last_busy_change TIMESTAMPTZ NOT NULL DEFAULT ('epoch');" % (pgschema, table))
            curpg.execute("ALTER TABLE %s.%s ADD last_busy_change TIMESTAMPTZ NOT NULL DEFAULT ('epoch');" % (pgschema, table))
        conpg.commit()
        print("Created %s table into %s Database and added %s entries" % (table, pgdb, len(rows)))
        input("pause for testing.... press any key to continue....")
    except psycopg2.DatabaseError as e:
        print('Error %s' % e)
        sys.exit(1)
    finally:
        if conpg:
            conpg.close()
consq.close()

