#!/usr/bin/env python3
import smtplib
from email.message import EmailMessage
import os,re
import sys
import pymsteams
from kaizenbot.azurelibrary import AzureLibrary
azurelib = AzureLibrary()
from kaizenbot.azuredata import  update, pat, TestPlanID, TestSuiteID, tester, parallel

#Getting test run id from build variables
test_runid=os.environ.get('TEST_RUNID')
print("Test Run ID: {}".format(test_runid))

if (test_runid == "" or test_runid == None):
    kbvarfile=sys.argv[1]
    if (os.path.isfile(kbvarfile)):
        with open(kbvarfile, 'r') as kbf:
            kbf_data=kbf.read()
            print(kbf_data)
            pat=re.search(r"(?<=pat=)'(.*)'",kbf_data).group(1)
            TestPlanID=re.search(r"(?<=TestPlanID=)'(.*)'",kbf_data).group(1)
            TestSuiteID=re.search(r"(?<=TestSuiteID=)'(.*)'",kbf_data).group(1)
            tester=re.search(r"(?<=tester=)'(.*)'",kbf_data).group(1)
            parallel=re.search(r"(?<=parallel=)'(.*)'",kbf_data).group(1)
    else:
        raise FileNotFoundError("File {} does not exists".format(kbvarfile))

#if (test_runid != "" and test_runid != None):
#    ##Getting test config variables from ADS associated with test run id
#    test_configs=azurelib.get_config_from_runid(runid=test_runid)

##Build firmware version, Mail Details, username, areapth for bug creation, project name from test configs and variables
if (test_runid == "" or test_runid == None):
    build=os.environ.get('RELEASE_FWVERSION')
    mailto = os.environ.get('KAIZENBOT_EMAILTO').split(',')
    username=os.environ.get('KAIZENBOT_G5R_USERNAME')
    project_name=os.environ.get('KAIZENBOT_G5R_PROJECT')
    areapath=os.environ.get('KAIZENBOT_BUG_AREAPATH')
    ##Getting LabServer Hostname
    hostname=os.environ.get('KAIZENBOT_LABSERVER')
    print("Hostname: {}".format(hostname))
else:
    ##Getting test config variables from ADS associated with test run id
    test_configs=azurelib._get_config_from_runid(runid=test_runid)
    build=test_configs.get('release_fwversion')
    mailto=test_configs.get('kaizenbot_emailto').split(',')
    username=test_configs.get('kaizenbot_g5r_username')
    project_name=test_configs.get('kaizenbot_g5r_project')
    areapath=test_configs.get('kaizenbot_bug_areapath')
    hostname=test_configs.get('kaizenbot_labserver')
    
if (build == 'None'):
    build = ''
print("Build FW Version: {}".format(build))

##ouptut file path to get reports and logs
output_path=os.environ.get('ADS_RESULT_DEST')
print("Received Test Results and Log files: {}".format(output_path))

##Mail details
mailfrom = 'kaizenbot@kaizenbot.itron.com'

##Getting build number to create build Url
relurl = os.environ.get('RELEASE_RELEASEWEBURL')
if relurl:
    pipeline_url=relurl
else:
    build_number = os.environ.get('BUILD_BUILDNUMBER')
    buildurl="https://itron.visualstudio.com/RnD/_build/results?buildId="+build_number+"&view=results"
    pipeline_url=buildurl


##Getting Pass/Fail data from xunit.xml file
Result = azurelib._parse_xunit_file(output_path)
total_num = Result[0].split(':')[1]
pass_num =Result[2].split(':')[1]
fail_num= Result[1].split(':')[1]

##Getting suite name from xunit.xml file
suite = azurelib._parse_suite_name(output_path)
suite_name = suite.split('&')[0]

##Creating configuration name to update in ADS based on pipeline variable
if (build != ""):
    config_name='FW.'+str(build)
else:
    #config_name=project_name.capitalize()+'_Network'
    config_name='Gen5Riva_Network'
print("Configuration Name: {}".format(config_name))

##Updating result in ADS
if (test_runid != "" and test_runid != None):
    Flag,Test_Run_Url = azurelib.update_result_in_vsts_based_on_runid(update=update, runid=test_runid, tester=tester,log_path=output_path+'/Logs', result_path=output_path)
else:
    Flag,Test_Run_Url = azurelib.update_result_in_vsts(update=update, planid=TestPlanID, suiteid=TestSuiteID, tester=tester,log_path=output_path+'/Logs', result_path=output_path, configuration=config_name)
print(Flag)
print("Test Run URL: {}".format(Test_Run_Url))

##Variables for creating bug
build_req_email=os.environ.get('BUILD_REQUESTEDFOREMAIL')
if build_req_email:
    user_email=build_req_email
else:
    release_req_email=os.environ.get('RELEASE_REQUESTEDFOREMAIL')
    user_email=release_req_email

print("User email for creating bug: {}".format(user_email))
if user_email=='' or user_email==None:
    user_email='' ##no user name to assign bug

##Creating Bug for failed test cases in ADS
BugID=azurelib.create_bug_in_ADS(output_path, user_email, areapath,log_path=output_path+'/Logs')
print("Bug ID: "+str(BugID))

##Calculating pass and fail percentage based on parsed xnunit.xml data
pass_percentage=round((int(pass_num)/int(total_num))*100,2)
fail_percentage=round((int(fail_num)/int(total_num))*100,2)

##Setting status in mail to Pass/fail based on result
if(int(pass_num) == 0):
    status='FAIL'
else:
    status='PASS'

##Creating non-fatal error text for failures in output.xml file
non_fatal_error= azurelib._get_non_fatal_error(output_path)
print("List of Errors observed in Output: {}".format(non_fatal_error))
if (non_fatal_error != []):
    for errors in non_fatal_error:
        f=open(os.path.join(output_path,'Non-Fatal-Errors.txt'),'a+',newline='\n')
        f.write(errors)
        f.write('\n')
        f.close()

##Mail decorating string
decstr = "###########################"
perc = "%"

##Setting suite name for Sanity and Firmware Upgrade and updating mail body accordingly
if(suite_name == 'Sanity'):# in suite_name.casefold()):
    suite_name='Sanity'
    if (hostname == "ocn-rd-actval3.itron.com") or (hostname == "172.17.212.43"):
        subject="%s - %s --- G5R 1.2.1 HAN Rel %s" %(suite_name,status,build)
    else:   
        subject = "%s - %s --- G5R Rel %s" %(suite_name,status,build) 
    body = "Hi,\n\nGen5Riva build '%s' %s test results.\n%s\nRan on%s nodes.\nPassed on%s nodes. \nFailed on%s nodes. \nPass Consistency: %s%s\nFail Consistency: %s%s\nRun By: %s\n%s\nLab details and Reports are attached \n\nPipeline Details: %s\nTestRun Url: %s\n\nRegards,\nTeam KaizenBot" %(build,suite_name,decstr,total_num,pass_num,fail_num,pass_percentage,perc,fail_percentage,perc,username,decstr,pipeline_url,Test_Run_Url)

elif (suite_name == 'Firmware Upgrade'):# and not 'Sanity' in suite_name.casefold()):
    suite_name='Firmware Upgrade'#suite_name
    if (hostname == "ocn-rd-actval3.itron.com") or (hostname == "172.17.212.43"):
        subject="%s - %s --- G5R 1.2.1 HAN Rel %s" %(suite_name,status,build)
    else:   
        subject = "%s - %s --- G5R Rel %s" %(suite_name,status,build)
    body = "Hi,\n\nGen5Riva build '%s' %s test results.\n%s\nRan on%s nodes.\nPassed on%s nodes. \nFailed on%s nodes. \nPass Consistency: %s%s\nFail Consistency: %s%s\nRun By: %s\n%s\nLab details and Reports are attached \n\nPipeline Details: %s\nTestRun Url: %s\n\nRegards,\nTeam KaizenBot" %(build,suite_name,decstr,total_num,pass_num,fail_num,pass_percentage,perc,fail_percentage,perc,username,decstr,pipeline_url,Test_Run_Url) 
else:
    subject = "Gen5Riva - Test Report --- %s" %(status)
    body = "Hi,\n\nGen5Riva test results.\n%s\nRan %s tests.\nPassed %s tests. \nFailed %s tests.\nRun By: %s\n%s\nLab details and Reports are attached \n\nPipeline Details: %s\nTestRun Url: %s\n\nRegards,\nTeam KaizenBot" %(decstr,total_num,pass_num,fail_num,username,decstr,pipeline_url,Test_Run_Url)

#message = """From: kaizenbot@kaizenbot.itron.com To: rajasekhar.inguva@itron.com Subject: Test Message\n

try:
    email = EmailMessage()
    email['From'] = mailfrom
    email['To'] = ','.join(mailto)
    email['Subject'] = subject
    email.set_content(body)
    fd = open(os.path.join(output_path,'report.html'),'rb')
    content = fd.read()
    if (suite_name == 'Sanity'):
        email.add_attachment(content,maintype='text',subtype='html',filename='SanityReport.html')
    elif(suite_name == 'Firmware Upgrade'):
        email.add_attachment(content,maintype='text',subtype='html',filename='FirmwareUpgradeReport.html')
    else:
        email.add_attachment(content,maintype='text',subtype='html',filename='Report.html')
    fd.close()
    if (suite_name == 'Sanity' or suite_name == 'Firmware Upgrade'):
        fd = open(os.path.join(output_path,'nodes.txt'),'rb')
        content = fd.read()
        email.add_attachment(content,maintype='text',subtype='text',filename='Node-Details.txt')
        fd.close()
    fd = open(os.path.join(output_path,'log.html'),'rb')
    content = fd.read()
    email.add_attachment(content,maintype='text',subtype='text',filename='log.html')
    fd.close()
    if (os.path.exists(os.path.join(output_path,'Non-Fatal-Errors.txt'))):
        fd = open(os.path.join(output_path,'Non-Fatal-Errors.txt'),'rb')
        content = fd.read()
        email.add_attachment(content,maintype='text',subtype='text',filename='Errors.txt')
        fd.close()
    smtpObj = smtplib.SMTP('localhost')
    smtpObj.send_message(email)
    #print(body)
    #smtpObj.sendmail(sender, receivers, message)
    print("Successfully sent email")
except smtplib.SMTPException as e:
    print(e)
    print("Error: unable to send email")

#Sending notification to Microsoft Teams
if(suite_name == 'Sanity') or (suite_name == 'Firmware Upgrade'):
    body_text="Hi, \n\nGen5Riva build '%s' %s test results. \n############### \n\nRan on%s nodes.\n\nPassed on%s nodes. \n\nFailed on%s nodes. \n\nPass Consistency: %s%s \n\nFail Consistency: %s%s \n\nRun By: %s\n############### \n\n\n\nRegards,\n\nTeam KaizenBot" %(build,suite_name,total_num,pass_num,fail_num,pass_percentage,perc,fail_percentage,perc,username)
else:
     body_text = "Hi,\n\nGen5Riva test results.\n############## \n\nRan %s tests.\n\nPassed %s tests. \n\nFailed %s tests.\n\nRun By: %s \n############# \n\n\n\nRegards,\n\nTeam KaizenBot" %(total_num,pass_num,fail_num,username)
try:
    teamsMsg = pymsteams.connectorcard("https://outlook.office.com/webhook/ecf4f055-21ec-4b0c-8209-b46cec144333@5818bd20-bf25-47b1-b996-d419d7e6e8ba/IncomingWebhook/5e6eaef44298442e8249b52cc66b8244/b05a9ab4-88b8-4539-bf92-9fd0ee5a40ac")
    teamsMsg.title(subject)
    teamsMsg.text(body_text)
    teamsMsg.addLinkButton("Pipeline Details", pipeline_url)
    teamsMsg.addLinkButton("Test Run URL", Test_Run_Url)
    teamsMsg.send()
    print("Successfully sent message to Teams")
except:
    print("Error: unable to send message to Teams")

