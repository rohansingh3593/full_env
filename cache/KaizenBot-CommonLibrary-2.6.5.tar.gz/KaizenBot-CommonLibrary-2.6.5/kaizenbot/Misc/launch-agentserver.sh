#!/bin/bash
echo "KAIZENBOT_DRYRUN: $KAIZENBOT_DRYRUN"
echo "KAIZENBOT_LOGLEVEL: $KAIZENBOT_LOGLEVEL"
echo "Creating Env file to push to KaizenBot server"
ADS_AGENT_USER=$USER
ADS_AGENT_PASSWORD=$ADS_AGENT_PASSWORD
ADS_AGENT_HOME=/home/$ADS_AGENT_USER/

echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
echo "ADS_AGENT_USER: $ADS_AGENT_USER"
echo "ADS_AGENT_PASSWORD: $ADS_AGENT_PASSWORD"
echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
echo "TEST_RUNID: $TEST_RUNID"

echo "Getting configuration for the tests from Test Run id";
test_runid=$TEST_RUNID
echo "Test Run ID: $test_runid"
NONE='None'
if [[ $TEST_RUNID != "" && ${TEST_RUNID,,} !=  *"${NONE,,}"* ]]
then
	TEMP_CONFIG_FILE="`mktemp -u`"
	echo "Temp created config file to read test config vars: $TEMP_CONFIG_FILE"
	$(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat
azurelib = AzureLibrary(pat)
config_data=azurelib._get_config_from_runid(runid='$test_runid')
print("username=%s"%config_data.get("kaizenbot_g5r_username"))
print("pat=%s"%config_data.get("kaizenbot_g5r_userpat"))
print("ads_agent_password=%s"%config_data.get("ads_agent_password"))
print("kaizenbot_bug_areapath=%s"%config_data.get("kaizenbot_bug_areapath"))
print("kaizenbot_labserver=%s"%config_data.get("kaizenbot_labserver"))
print("kaizenbot_labserver_username=%s"%config_data.get("kaizenbot_labserver_username"))
print("kaizenbot_g5r_suiteid=%s"%config_data.get("kaizenbot_g5r_suiteid"))
print("kaizenbot_g5r_suitename=%s"%config_data.get("kaizenbot_g5r_suitename"))
print("kaizenbot_g5r_tplanid=%s"%config_data.get("kaizenbot_g5r_tplanid"))
print("kaizenbot_g5r_testname=%s"%config_data.get("kaizenbot_g5r_testname"))
print("kaizenbot_g5r_includetags=%s"%config_data.get("kaizenbot_g5r_includetags"))
print("kaizenbot_g5r_excludetags=%s"%config_data.get("kaizenbot_g5r_excludetags"))
print("kaizenbot_g5r_platform=%s"%config_data.get("kaizenbot_g5r_platform"))
print("kaizenbot_g5r_project=%s"%config_data.get("kaizenbot_g5r_project"))
print("kaizenbot_g5r_wait_on_busy_platform=%s"%config_data.get("kaizenbot_g5r_wait_on_busy_platform"))
print("kaizenbot_nodes=%s"%config_data.get("kaizenbot_nodes"))
print("release_fwversion=%s"%config_data.get("release_fwversion"))
print("kaizenbot_disable_parallel_test_execution=%s"%config_data.get("kaizenbot_disable_parallel_test_execution"))
print("kaizenbot_replicate_in_parallel=%s"%config_data.get("kaizenbot_replicate_in_parallel"))
print("kaizenbot_suite_serial_execution=%s"%config_data.get("kaizenbot_suite_serial_execution"))
print("kaizenbot_replicate_in_parallel_nodetype=%s"%config_data.get("kaizenbot_replicate_in_parallel_nodetype"))
print("kaizenbot_labserver_password=%s"%config_data.get("kaizenbot_labserver_password"))' 1>$TEMP_CONFIG_FILE)

	##Getting variables from Test Configuration variables
	echo  "Getting variables from Test Configuration vars"
	KAIZENBOT_G5R_USERNAME="`eval grep 'username=' $TEMP_CONFIG_FILE | grep -v "kaizenbot_labserver_username" | sed 's/^.*=//'`"
	KAIZENBOT_G5R_USERPAT="`eval grep 'pat=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	ADS_AGENT_PASSWORD="`eval grep 'ads_agent_password=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_LABSERVER="`eval grep 'kaizenbot_labserver=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_LABSERVER_USERNAME="`eval grep 'kaizenbot_labserver_username=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_LABSERVER_PASSWORD="`eval grep 'kaizenbot_labserver_password=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_BUG_AREAPATH="`eval grep 'kaizenbot_bug_areapath=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_SUITEID="`eval grep 'kaizenbot_g5r_suiteid=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_SUITENAME="`eval grep 'kaizenbot_g5r_suitename=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_TPLANID="`eval grep 'kaizenbot_g5r_tplanid=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_TESTNAME="`eval grep 'kaizenbot_g5r_testname=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_INCLUDETAGS="`eval grep 'kaizenbot_g5r_includetags=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_EXCLUDETAGS="`eval grep 'kaizenbot_g5r_excludetags=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_PLATFORM="`eval grep 'kaizenbot_g5r_platform=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_PROJECT="`eval grep 'kaizenbot_g5r_project=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_G5R_WAIT_ON_BUSY_PLATFORM="`eval grep 'kaizenbot_g5r_wait_on_busy_platform=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_NODES="`eval grep 'kaizenbot_nodes=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	RELEASE_FWVERSION="`eval grep 'release_fwversion=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION="`eval grep 'kaizenbot_disable_parallel_test_execution=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_REPLICATE_IN_PARALLEL="`eval grep 'kaizenbot_replicate_in_parallel=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_SUITE_SERIAL_EXECUTION="`eval grep 'kaizenbot_suite_serial_execution=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
	KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE="`eval grep 'kaizenbot_replicate_in_parallel_nodetype=' $TEMP_CONFIG_FILE | sed 's/^.*=//'`"
fi
KAIZENBOT_LABSERVER_HOME=/home/$KAIZENBOT_LABSERVER_USERNAME/
echo "KAIZENBOT_G5R_USERNAME: $KAIZENBOT_G5R_USERNAME"
echo "KAIZENBOT_G5R_USERPAT: $KAIZENBOT_G5R_USERPAT"
echo "ADS_AGENT_PASSWORD: $ADS_AGENT_PASSWORD"
echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
echo "KAIZENBOT_LABSERVER_HOME: $KAIZENBOT_LABSERVER_HOME"
echo "KAIZENBOT_G5R_SUITEID: $KAIZENBOT_G5R_SUITEID"
echo "KAIZENBOT_G5R_SUITENAME: $KAIZENBOT_G5R_SUITENAME"
echo "KAIZENBOT_G5R_TPLANID: $KAIZENBOT_G5R_TPLANID"
echo "KAIZENBOT_G5R_TESTNAME: $KAIZENBOT_G5R_TESTNAME"
echo "KAIZENBOT_G5R_INCLUDETAGS: $KAIZENBOT_G5R_INCLUDETAGS"
echo "KAIZENBOT_G5R_EXCLUDETAGS: $KAIZENBOT_G5R_EXCLUDETAGS"
echo "KAIZENBOT_G5R_PLATFORM: $KAIZENBOT_G5R_PLATFORM"
echo "KAIZENBOT_G5R_PROJECT: $KAIZENBOT_G5R_PROJECT"
echo "KAIZENBOT_G5R_WAIT_ON_BUSY_PLATFORM: $KAIZENBOT_G5R_WAIT_ON_BUSY_PLATFORM"
echo "KAIZENBOT_NODES: $KAIZENBOT_NODES"
echo "RELEASE_FWVERSION: $RELEASE_FWVERSION"
echo "KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION: $KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION"
echo "KAIZENBOT_G5R_USERPAT: $KAIZENBOT_G5R_USERPAT"
echo "KAIZENBOT_REPLICATE_IN_PARALLEL: $KAIZENBOT_REPLICATE_IN_PARALLEL"
echo "KAIZENBOT_BUG_AREAPATH: $KAIZENBOT_BUG_AREAPATH"
echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
echo "ADS_AGENT_USER: $ADS_AGENT_USER"
echo "KAIZENBOT_SUITE_SERIAL_EXECUTION: $KAIZENBOT_SUITE_SERIAL_EXECUTION"
echo "KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE: $KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE"

KBVARFILE=$ADS_AGENT_HOME/kbvars.py

##Creating kbvars.py file for updating results in ADS using pabot
echo "Creating Kaizenbot variables file: $KBVARFILE"
echo "TestSuiteID='$KAIZENBOT_G5R_SUITEID'">$KBVARFILE ##using > single operator to create the KBVARFILE freshly
echo "KAIZENBOT_G5R_SUITENAME='$KAIZENBOT_G5R_SUITENAME'">>$KBVARFILE
echo "KAIZENBOT_G5R_TAGS='$KAIZENBOT_G5R_TAGS'">>$KBVARFILE
echo "TestPlanID='$KAIZENBOT_G5R_TPLANID'">>$KBVARFILE
echo "tester='$KAIZENBOT_G5R_USERNAME'">>$KBVARFILE
echo "pat='$KAIZENBOT_G5R_USERPAT'">>$KBVARFILE
echo "parallel='True'">>$KBVARFILE

##Creating kaizen-env.txt file 
KAIZENBOT_G5R_USERNAME="\"$KAIZENBOT_G5R_USERNAME\""
if [[ $TEST_RUNID != "" || ${TEST_RUNID,,} !=  *"${NONE,,}"* ]]
then
	KAIZENBOT_G5R_TESTNAME="\"$KAIZENBOT_G5R_TESTNAME\""
	KAIZENBOT_G5R_SUITENAME="\"$KAIZENBOT_G5R_SUITENAME\""
	KAIZENBOT_G5R_INCLUDETAGS="\"$KAIZENBOT_G5R_INCLUDETAGS\""
	KAIZENBOT_G5R_EXCLUDETAGS="\"$KAIZENBOT_G5R_EXCLUDETAGS\""
fi

KAIZEN_ENV_TXT_FILE="$ADS_AGENT_HOME/kaizen-env.txt"
TEMP_FILE="`mktemp -u`"
env |grep -i kaizenbot | grep -v grep | grep -v PATH > $TEMP_FILE
echo "BUILD_BUILDNUMBER=$BUILD_BUILDNUMBER" >> $TEMP_FILE
cat $TEMP_FILE | sed 's/^/export /g' > $KAIZEN_ENV_TXT_FILE
rm -f $TEMP_FILE
echo "export KAIZENBOT_SLAVE=1" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_HOME=$ADS_AGENT_HOME" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_USER=$ADS_AGENT_USER" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_PASSWORD=\"$ADS_AGENT_PASSWORD\"" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER=$KAIZENBOT_LABSERVER" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_USERNAME=$KAIZENBOT_LABSERVER_USERNAME" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_PASSWORD=$KAIZENBOT_LABSERVER_PASSWORD" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_HOME=\"$KAIZENBOT_LABSERVER_HOME\"" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_REPOSITORY_NAME=$BUILD_REPOSITORY_NAME" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_BUG_AREAPATH=\"$KAIZENBOT_BUG_AREAPATH\"" >> $KAIZEN_ENV_TXT_FILE
echo "export TEST_RUNID=$TEST_RUNID" >> $KAIZEN_ENV_TXT_FILE
echo "export RELEASE_FWVERSION=$RELEASE_FWVERSION" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION=$KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_REPOSITORY_NAME=$BUILD_REPOSITORY_NAME" >> $KAIZEN_ENV_TXT_FILE

export KAIZENBOT_G5R_USERPAT KAIZENBOT_G5R_TPLANID KAIZENBOT_G5R_SUITEID KAIZENBOT_G5R_USERNAME KAIZENBOT_G5R_PARALLEL TEST_RUNID

##creating ADS agent Result directory to copy files from kaizenbot lab server and putting it in kaizen-env.txt
ADS_RESULT_DEST="$ADS_AGENT_HOME/LOGS/`mktemp | cut -d '.' -f 2`"
mkdir -p $ADS_RESULT_DEST
echo "ADS_RESULT_DEST=$ADS_RESULT_DEST" >> $ADS_AGENT_HOME/kaizen-env.txt
echo $ADS_RESULT_DEST
chmod 777 $ADS_RESULT_DEST

##creating TMPENV file for each agent to not collide with copy of kaizen-env.txt in kaizenbot server
TMPENV=`mktemp -u`
echo $TMPENV

##Copying kaizen-env.txt file to TMPENV in KaizenBot Server
echo "Copying env file to KaizenBot Server"
$ADS_AGENT_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $ADS_AGENT_HOME/kaizen-env.txt $KAIZENBOT_LABSERVER $KAIZENBOT_LABSERVER_USERNAME $KAIZENBOT_LABSERVER_PASSWORD $TMPENV

##Watchdog to monitor any cancellation of job
echo "USR1" > /opt/kaizenbot/watchdog/kzsigpipe
echo "$$:/opt/kaizenbot/watchdog/stopkzlab.py $KAIZENBOT_LABSERVER $KAIZENBOT_LABSERVER_USERNAME $KAIZENBOT_LABSERVER_PASSWORD \"/home/$KAIZENBOT_LABSERVER_USERNAME/kaizenbot/bin/stopkzbot.sh $BUILD_BUILDNUMBER\"" > /opt/kaizenbot/watchdog/kzpipe
#echo "$$:/opt/kaizenbot/watchdog/stopkzlab" > /opt/kaizenbot/watchdog/kzpipe

##Launching Kaizenbot on KaizenBot Server and passing TMPENV to read kaizen-env variables
echo "Launching Kaizenbot on KaizenBot Server"
$ADS_AGENT_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.runprog $KAIZENBOT_LABSERVER $KAIZENBOT_LABSERVER_USERNAME $KAIZENBOT_LABSERVER_PASSWORD "/home/$KAIZENBOT_LABSERVER_USERNAME/kaizenbot/bin/launch-robot.sh $TMPENV"

export ADS_RESULT_DEST RELEASE_RELEASEWEBURL NON_FATAL_PATH

##Running Kaizenmail py file to updated result in ADS, send mail and send notification in Teams
$ADS_AGENT_HOME/kaizenbot/bin/python3 $ADS_AGENT_HOME/kaizenbot/bin/kaizenmail.py $KBVARFILE

##Removing files at the end of test
#rm -f $TMPENV
rm -f $ADS_AGENT_HOME/kaizen-env.txt
rm -rf $ADS_RESULT_DEST

##telling watchdog that test exited gracefully
echo "USR2" > /opt/kaizenbot/watchdog/kzsigpipe
echo $$ > /opt/kaizenbot/watchdog/kzpipe
exit 0

