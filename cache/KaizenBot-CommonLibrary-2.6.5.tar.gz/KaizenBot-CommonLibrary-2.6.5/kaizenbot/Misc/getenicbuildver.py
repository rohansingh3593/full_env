#!/usr/bin/python3
import smtplib
from email.message import EmailMessage
import paramiko
import sys 
import os

def _send_mail(From, To, Subject, Msg):
    try:
        email = EmailMessage()
        email['From'] = From
        email['To'] = ','.join(To)
        email['Subject'] = Subject
        Body = 'Hi Team,\n\n' + Msg + '\n\nRegards,\nTeam KaizenBot'
        email.set_content(Body)

        smtpObj = smtplib.SMTP('localhost')
        smtpObj.send_message(email)
        print("Successfully sent email")
    except smtplib.SMTPException as e:
        print(e)
        print("Error: unable to send email")

mailfrom = 'kaizenbot@kaizenbot.itron.com'
mailto = os.environ.get('KAIZENBOT_EMAILTO').split(',')
#mailto = ['sirajdeen.hameedkamsa@itron.com']
subject = 'KaizenBot ENIC Nightly Trigger Status'

# Create object of SSHClient and
# connecting to SSH
ssh = paramiko.SSHClient()
 
# Adding new host key to the local
# HostKeys object(in case of missing)
# AutoAddPolicy for missing host key to be set before connection setup.
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
 
ssh.connect('10.57.202.2', port=22, username='waseca',
            password='23Silver$', timeout=30)

#i,o,e=ssh.exec_command("ls /home/waseca/raj")
# Execute command on SSH terminal
# using exec_command
stdin, stdout, stderr = ssh.exec_command("ls /shared/release/firmware/daily-builds/5.6.x/5.6.1/LATEST/rni_nic |  grep -i 'slic_rni.nic.image.DEV.DEV_sig' | grep -iv 'fload' | grep -iv 'sha1'")
#stdin, stdout, stderr = ssh.exec_command("ls /home/waseca/raj/ |  grep -i 'slic_rni.nic.image.DEV.DEV_sig' | grep -iv 'fload' | grep -iv 'sha1'")
filepath="/home/g5r/enic/PREVBUILD.txt"
curbuild=stdout.read().decode("utf-8").split("\n")[0].strip("\n") #incase two builds are found, we take the first one only
if curbuild == "":
    msg="No build located. Skipping nightly tests"
    print(msg)
    _send_mail(mailfrom, mailto, subject, msg)
    sys.exit(1)
if os.path.exists(filepath):
    prev=open(filepath).readlines()[0]
    print("Previous Build: %s\n" %(prev))
    if curbuild == prev:
        msg="Current available build is same as what we tested before. Skipping nightly tests"
        print(msg)
        _send_mail(mailfrom, mailto, subject, msg)
        sys.exit(1)
    else:
        msg="Previous Build: %s\n" %(prev)
        msg+="Current available build is different than what we tested before. Proceeding with nightly tests. @@%s@@" % (curbuild)
        print(msg)
        _send_mail(mailfrom, mailto, subject, msg)
else:
    msg="No previous runs found. Proceeding with nightly tests. @@%s@@" % (curbuild)
    print(msg)
    _send_mail(mailfrom, mailto, subject, msg)

fd = open(filepath,"w")
fd.write(curbuild)
fd.close()
sys.exit(0)
