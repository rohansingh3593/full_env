import sys
import os
import shutil

CURDIR = os.path.dirname(os.path.abspath(__file__))
argdir = None

def create_argfiles(nodes,repo_dirname):
    global argdir
    if not isinstance(nodes, list):
        nodes = [nodes]
    argdir = os.path.join(CURDIR, os.getenv('KAIZENBOT_LABSERVER_USERNAME'), 'argfiles')
    if os.path.isdir(argdir):
        shutil.rmtree(argdir)
    os.makedirs(argdir)
    for i,node in enumerate(nodes):
        with open(os.path.join(argdir, str(i+1)), 'w') as argfile:
            argfile.write('--variable node:' + node)
            if repo_dirname.lower().find('platform') == -1:
                argfile.write('--name ' + node)

def create_command(num_of_argfiles, testfile, args = None):
    if not argdir:
        raise RuntimeError("No argument files available")
    SPACE = ' '
    command = 'pabot --processes' + SPACE + str(num_of_argfiles) + SPACE
    for i in range(num_of_argfiles):
        command += '--argumentfile' + str(i+1) + SPACE + '"' + os.path.join(argdir, str(i+1)) + '"' + SPACE

    if args:
        for arg in args:
            arg = '"%s"'%arg if ' ' in arg else arg
            command += arg + SPACE

    command += testfile
    return command

if __name__ == "__main__":
    arglen = len(sys.argv)
    if arglen < 3:
        raise RuntimeError("%s requires at least 3 arguments" %sys.argv[0])

    file = sys.argv[1]
    if not os.path.isfile(file):
        raise FileNotFoundError("File '%s' does not exist" %file)

    testfile = sys.argv[2]
    if not os.path.isdir(testfile):
        raise FileNotFoundError("Directory '%s' does not exist" %testfile)

    with open(file, 'r') as nodefile:
        nodes = nodefile.readlines()

    create_argfiles(nodes,testfile)

    args = []
    for i in range(3,arglen):
        args.append(sys.argv[i])

    command = create_command(len(nodes), testfile, args)
    print("Running command: %s\n" % (command))
    os.system(command)

