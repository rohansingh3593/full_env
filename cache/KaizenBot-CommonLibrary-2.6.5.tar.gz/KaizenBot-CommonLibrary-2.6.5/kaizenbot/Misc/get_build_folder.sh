#!/bin/bash

gen5riva()
{
    TGT_BUILD="FW_`echo $FWVERSION | tr '.' '_'`"
    echo "Fetching base folder listing"
    wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/ 2>&1
    FOLDER_LOCATION=""
    BFOLDER="None"
    if [ "$?" != "0" ]
    then
        echo "Wget: Failed"
        #exit 1
    fi
    echo "Fetching Gen5 RIVA folders"
    DIRLIST="`grep _RIVA_ index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
    #echo $DIRLIST
    got_a_hit="0"
    for d in $DIRLIST
    do
        echo "Searching http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/$d/Latest"
        wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/$d/Latest 2>&1
        if [ "$?" != "0" ]
        then
            echo "No folder named Latest. Ignoring this folder"
            rm -f Latest
            continue
        else
            echo "http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/$d/Latest is a valid location"
            FOLDER_LOCATION="`grep $TGT_BUILD Latest | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
            if [ "$FOLDER_LOCATION" != "" ]
            then
                got_a_hit="1"
                rm -f Latest
                break
            fi
            rm -f Latest
        fi
    done
    if [ "$got_a_hit" == "1" ]
    then
        echo "Firmware available at: http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/$d/Latest/$FOLDER_LOCATION"
        rm -f index.htm*
        export BFOLDER="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/$d/Latest/$FOLDER_LOCATION"
        export RFSFILE="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/$d/Latest/$FOLDER_LOCATION/Distribution-Files/Gen5RivaMeter-Dev/Gen5RivaMeter-Dev_rfsInjection.log"
        #exit 0
    else
        echo "Could not locate firmware $FWVERSION"
        rm -f Latest*
        #exit 1
    fi
}

appserv()
{
    TGT_BUILD=$FWVERSION
    PACKAGE_NAME='DI-AppServices-Package-'$TGT_BUILD'_TS.zip'
    echo "Fetching base folder listing"
    wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/ 2>&1
    FOLDER_LOCATION=""
    BFOLDER="None"
    if [ "$?" != "0" ]
    then
        echo "Wget: Failed"
        #exit 1
    fi
    echo "Fetching App Serv folders"
    DIRLIST="`grep NB_DIAppServices_202 index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
    rev_dirlist="`printf '%s\n' "${DIRLIST[@]}" | tac | tr '\n' ' '`"
    echo $rev_dirlist
    got_a_hit="0"
    for d in $rev_dirlist
    do
        echo "Searching http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage"
        wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage 2>&1
        if [ "$?" != "0" ]
        then
            echo "No folder named FinalPackage. Ignoring this folder"
            rm -f FinalPackage
            continue
        else
            echo "http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage is a valid location"
            FOLDER_LOCATION="`grep $TGT_BUILD FinalPackage | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
            if [ "$FOLDER_LOCATION" != "" ]
            then
                got_a_hit="1"
                rm -f FinalPackage
                break
            fi
            rm -f FinalPackage
        fi
    done
    if [ "$got_a_hit" == "1" ]
    then
        echo "Firmware available at: http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage/$PACKAGE_NAME"
        rm -f index.htm*
        export BFOLDER="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_APPSERVICES/NightlyBuilds/Latest/$d/bionic-x86_64/TargetDebug/FinalPackage/$PACKAGE_NAME"
        #exit 0
    else
        echo "Could not locate firmware $FWVERSION"
        rm -f FinalPackage*
        #exit 1
    fi
}

agent()
{
    AGENT_NAME_VERSION=($(echo $FWVERSION | tr ":" "\n"))
    AGENT_NAME="${AGENT_NAME_VERSION[0]}"
    AGENT_VERSION="${AGENT_NAME_VERSION[1]}"

    echo "AGENT_NAME=$AGENT_NAME"
    echo "AGENT_VERSION=$AGENT_VERSION"
    is_thirdparty="0"
    AGENT_GREP_NAME="None"

    # Handle special Agent name to folder name weirdness...
    if [[ "$AGENT_NAME" == *"ThirdParty"* ]]
    then
        is_thirdparty="1"
        if [[ "$AGENT_NAME" != *"ReferenceAgent"* ]]
        then
            AGENT_GREP_NAME="`echo $AGENT_NAME | awk '{ print substr( $0, 11 ) }'`"
        fi
    fi

    if [ "$AGENT_GREP_NAME" == "None" ]
    then
        AGENT_GREP_NAME=$AGENT_NAME
    fi

    if [[ "$AGENT_GREP_NAME" == *V2 || "$AGENT_GREP_NAME" == *V1 ]]
    then
        AGENT_GREP_NAME="`echo $AGENT_GREP_NAME | awk '{ print substr( $0, 1, length($0)-2 ) }'`"
    fi

    if [[ "$AGENT_GREP_NAME" == *[0-9] ]]
    then
        AGENT_GREP_NAME="`echo $AGENT_GREP_NAME | awk '{ print substr( $0, 1, length($0)-1 ) }'`"
    fi

    FOLDER="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/DI_Agents/"
    rm -f index.htm*
    wget $FOLDER 2>&1
    if [ "$?" != "0" ]
    then
        echo "wget: Failed=$FOLDER"
        #exit 1
    fi

    if [[ "$AGENT_GREP_NAME" == *"GTO"*"Agent"* ]]
    then
        AGENT_GREP_FOLDER=V7CloneAgents
    else
        AGENT_GREP_FOLDER=$AGENT_GREP_NAME
    fi

    echo "Fetching matching Agents basefolder listing"
    AGENT_FOLDER="`grep $AGENT_GREP_FOLDER index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
    AGENT_FOLDER_LIST=($(echo $AGENT_FOLDER | tr "[]'" " " | tr "," "\n"))
    declare -p AGENT_FOLDER_LIST
    FOLDER_LOCATION="None"
    BFOLDER="None"
    sub="None"

    for basefolder in "${AGENT_FOLDER_LIST[@]}"
    do
        if [[ "$AGENT_GREP_FOLDER" == "$basefolder"* ]]
        then
            echo "Agent basefolder match=$basefolder"
            VERSION_PATH="${FOLDER}${basefolder}/"
            rm -f index.htm*
            wget $VERSION_PATH 2>&1
            if [ "$?" != "0" ]
            then
                echo "wget: Failed basefolder=$VERSION_PATH"
                exit 1
            fi
            VERSION_FOLDER="`grep DIR index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
            FOLDER_LIST=($(echo $VERSION_FOLDER | tr "[]'" " " | tr "," "\n"))
            declare -p FOLDER_LIST
            for folder in "${FOLDER_LIST[@]}"
            do
                # Find best suited folder...
                if [[ "$AGENT_NAME" == *"$folder"* ]]
                then
                    echo "Selected path=$folder"
                    VERSION_PATH="${VERSION_PATH}${folder}/"
                    rm -f index.htm*
                    wget $VERSION_PATH 2>&1
                    if [ "$?" != "0" ]
                    then
                        echo "wget: Failed VERSON suffix folder=$VERSION_PATH"
                        exit 1
                    fi
                    VERSION_FOLDER="`grep DIR index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
                    break
                fi
            done

            if [[ "$VERSION_FOLDER" == *"$AGENT_VERSION"* ]]
            then
                echo "Agent version match=$AGENT_VERSION"
                SUBNAME_PATH="${VERSION_PATH}${AGENT_VERSION}/"
                rm -f index.htm*
                wget $SUBNAME_PATH 2>&1
                if [ "$?" != "0" ]
                then
                    echo "wget: Failed version=$SUBNAME_PATH"
                    #exit 1
                fi
                SUBNAME_FOLDER="`grep DIR index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
                if [[ "$SUBNAME_FOLDER" == *"Release"* ]]
                then
                    FOLDER_LOCATION="${SUBNAME_PATH}Release/"
                    break
                fi
                # No /Release folder; continue search
                SUBNAME_FOLDER_LIST=($(echo $SUBNAME_FOLDER | tr "[]'" " " | tr "," "\n"))
                declare -p SUBNAME_FOLDER_LIST

                # remove P2P substring from AGENT_NAME
                if [[ "$AGENT_NAME" == *"P2P"* ]]
                then
                    AGENT_NAME="`echo $AGENT_NAME | sed -e 's/P2P//1'`"
                fi

                found_pkg_name="0"
                for sub in "${SUBNAME_FOLDER_LIST[@]}"
                do
                    if [ "$is_thirdparty" == "0" ]
                    then
                        if [[ "$sub" == *"$AGENT_NAME" ]]
                        then
                            found_pkg_name="1"
                            echo "found sub=$sub"
                        fi
                    else
                        if [[ "$sub" == *"Third"* && "$sub" == *"$AGENT_NAME" ]]
                        then
                            found_pkg_name="1"
                        fi
                    fi

                    if [ "$found_pkg_name" == "1" ]
                    then
                        FOLDER_LOCATION="${SUBNAME_PATH}${sub}/Release/"
                        break
                    fi
                done
            fi

            #echo $VERSION_FOLDER
            # No version match but Agent name match
            if [[ "$VERSION_FOLDER" == *"Release"* && "$FOLDER_LOCATION" == "None" ]]
            then
                echo "No ver, agent name match=$AGENT_NAME"
                FOLDER_LOCATION="${VERSION_PATH}Release/"
                break
            fi

            #handle non-conforming folder schemes... (ie HANAgent)
            if [[ "$FOLDER_LOCATION" == "None" ]]
            then
                for folder in "${FOLDER_LIST[@]}"
                do
                    echo "Checking folder=$folder"
                    SUBNAME_PATH="${VERSION_PATH}$folder/"
                    rm -f index.htm*
                    wget $SUBNAME_PATH 2>&1
                    if [ "$?" != "0" ]
                    then
                        echo "wget: Failed folder=$SUBNAME_PATH"
                        #exit 1
                    fi
                    SUBNAME_FOLDER="`grep DIR index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
                    if [[ "$SUBNAME_FOLDER" == *"Release"* ]]
                    then
                        SUBNAME_RELEASE_PATH="${SUBNAME_PATH}Release/"
                        rm -f index.htm*
                        wget $SUBNAME_RELEASE_PATH 2>&1
                        if [ "$?" != "0" ]
                        then
                            echo "wget: Failed release folder=$SUBNAME_RELEASE_PATH"
                            #exit 1
                        fi
                        SUBNAME_RELEASE_FOLDER="`grep zip index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1`"
                        if [[ "$SUBNAME_RELEASE_FOLDER" == *$AGENT_VERSION* ]]
                        then
                            echo "non-conforming folder schemes, agent version match=$AGENT_VERSION"
                            FOLDER_LOCATION=$SUBNAME_RELEASE_PATH
                            break
                        fi
                    fi
                done
            fi
        fi
    done

    if [ "$FOLDER_LOCATION" != "None" ]
    then
        rm -f index.htm*
        wget $FOLDER_LOCATION 2>&1
        if [ "$?" != "0" ]
        then
            echo "wget: Failed finding release: $FOLDER_LOCATION"
        fi
        RELEASE_FOLDER="`grep zip index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'"' -f1`"
        RELEASE_FOLDER_LIST=($(echo $RELEASE_FOLDER | tr "[]'" " " | tr "," "\n"))
        declare -p RELEASE_FOLDER_LIST
        for pkg in "${RELEASE_FOLDER_LIST[@]}"
        do
            if [[ "$pkg" != "unsigned-"*"_TS.zip" && "$pkg" != "PreInstall"*"_TS.zip" ]]
            then
                PACKAGE_NAME=$pkg
                echo "Found package: ${FOLDER_LOCATION}$pkg"
                export BFOLDER="${FOLDER_LOCATION}$pkg"
                break
            fi
        done
    fi
    rm -f index.htm*

    if [ "$BFOLDER" == "None" ]
    then
        echo "No package found for $AGENT_NAME with $AGENT_VERSION"
    fi
}

dsp()
{
    DSP_TYPE_VERSION=($(echo $FWVERSION | tr ":" "\n"))
    DSP_TYPE="${DSP_TYPE_VERSION[0]}"
    DSP_VERSION="${DSP_TYPE_VERSION[1]}"

    FOLDER_LOCATION=""
    BFOLDER="None"

    if [[ "$DSP_TYPE" == *"PLC"* ]]
    then
        GREP_FOLDER=ASIC_PLC_DSP
    else
        GREP_FOLDER=ASIC_RF_DSP
    fi

    wget http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/ASIC_RIVA_PP_SR_4-7_CURIE/DSP/$GREP_FOLDER/davinci/ 2>&1
    DIRLIST="`grep ASIC$DSP_TYPE index.html | sed 's/href="/@/g' | cut -d'@' -f2 | cut -d'/' -f1 | grep _$DSP_VERSION`"
    rm -f index.htm*

    if [ ${#DIRLIST} == 0 ]
    then
        echo "Could not locate DSP firmware $FWVERSION"
    else
        FOLDER_LOCATION=${DIRLIST[0]}
        echo "DSP Firmware available at: http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/ASIC_RIVA_PP_SR_4-7_CURIE/DSP/$GREP_FOLDER/davinci/$FOLDER_LOCATION"
        export BFOLDER="http://ral-rdgbuild-03.itronhdc.com/OWI_Builds/ASIC_RIVA_PP_SR_4-7_CURIE/DSP/$GREP_FOLDER/davinci/$FOLDER_LOCATION"
    fi
}

get_appserv_version()
{
    RFSLOG=$1
    APPSERV_ENTRY="`grep '/usr/share/itron/PreInstall/DI-AppServices-Package-.*.tar.gz' $RFSLOG`"
    if [ "$APPSERV_ENTRY" != "" ]
    then
        PREINS_APPSERV_VERSION="`echo $APPSERV_ENTRY | egrep -o 'DI-App.*[0-9]+.[0-9]+.[0-9]+' | egrep -m 1 -o '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+'`"
        echo "DI-AppServices Preinstall version: $PREINS_APPSERV_VERSION"
        export PREINS_APPSERV_VERSION
    else
        echo "DI-AppServices Preinstall version not found in RFS Log"
        unset PREINS_APPSERV_VERSION
    fi
}

get_han_version()
{
    RFSLOG=$1
    HAN_ENTRY="`grep '/usr/share/itron/PreInstall/HANAgent_.*.tar.gz' $RFSLOG`"
    if  [ "$HAN_ENTRY" != "" ]
    then
        PREINS_HAN_VERSION="`echo $HAN_ENTRY | egrep -o 'HANAgent.*[0-9]+.[0-9]+.[0-9]+' | egrep -m 1 -o '[0-9]+\.[0-9]+\.[0-9]+'`"
        echo "HAN Agent Preinstall version: $PREINS_HAN_VERSION"
        export PREINS_HAN_VERSION
    else
        echo "HAN Agent Preinstall version not found in RFS Log"
        unset PREINS_HAN_VERSION
    fi
}

if [ $# == 2 ]
then
    FWVERSION=$1
    cmd="`echo $2|tr 'A-Z' 'a-z'`"
    rm -f index.htm*
    rm -f Latest*
    if echo $2 | grep -qiE 'kaizenbot|platform|han'
    then
        echo "Project name given is $2.Using project Gen5Riva for build download"
        cmd="gen5riva"
    fi
    $cmd
else
    GET_VERSION_ARRAY=($(echo $1 | tr ":" "\n"}))
    cmd="${GET_VERSION_ARRAY[0]} ${GET_VERSION_ARRAY[1]}"
    $cmd
fi
