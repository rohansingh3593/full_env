#!/bin/bash
change_g5r_vars()
{
    OLDIFS=$IFS
    IFS='
'
    for e in `env`
    do
        if echo $e | grep -q KAIZENBOT_G5R_
        then
            var=`echo $e | cut -d'=' -f1`
            val="`echo $e | cut -d'=' -f2`"
	    #echo "val value: $val, e is: $e"
            export "`echo $var | sed 's/KAIZENBOT_G5R_/KAIZENBOT_/g'`"="$val"
        fi
    done
    export IFS=$OLDIFS
}
echo "KAIZENBOT_DRYRUN: $KAIZENBOT_DRYRUN"
echo "KAIZENBOT_LOGLEVEL: $KAIZENBOT_LOGLEVEL"
echo "Creating Env file to push to KaizenBot server"
ADS_AGENT_USER=$USER
ADS_AGENT_PASSWORD=$ADS_AGENT_PASSWORD
ADS_AGENT_HOME=/home/$ADS_AGENT_USER/

echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
echo "ADS_AGENT_USER: $ADS_AGENT_USER"
echo "ADS_AGENT_PASSWORD: $ADS_AGENT_PASSWORD"
echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
echo "TEST_RUNID: $TEST_RUNID"

echo "Getting configuration for the tests from Test Run id";
test_runid=$TEST_RUNID
echo "Test Run ID: $test_runid"
NONE='None'
change_g5r_vars
if [[ $TEST_RUNID != "" && ${TEST_RUNID,,} !=  *"${NONE,,}"* ]]
then
	TEMP_CONFIG_FILE="`mktemp -u`"
	echo "Temp created config file to read test config vars: $TEMP_CONFIG_FILE"
	$(python3 -c 'from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat
azurelib = AzureLibrary(pat)
config_data=azurelib._get_config_from_runid(runid='$test_runid')
for k in config_data:
   tmpkey=k
   if tmpkey.upper().find("G5R"):
       tmpkey=tmpkey.upper().replace("_G5R_","_")
   print("export {}=\"{}\"".format(tmpkey.upper(),config_data[k]))
print("export KAIZENBOT_TPLANID='$NONE'")
print("export KAIZENBOT_SUITEID='$NONE'")' 2>$HOME/config_error.log 1>$TEMP_CONFIG_FILE)

	. $TEMP_CONFIG_FILE
    echo "Exported all test configuration as environment variables"
    echo "Deleting temporary config file"
    rm -f $TEMP_CONFIG_FILE
fi
KAIZENBOT_LABSERVER_HOME=/home/$KAIZENBOT_LABSERVER_USERNAME/
echo "KAIZENBOT_G5R_USERNAME: $KAIZENBOT_G5R_USERNAME"
echo "KAIZENBOT_G5R_USERPAT: $KAIZENBOT_G5R_USERPAT"
echo "ADS_AGENT_PASSWORD: $ADS_AGENT_PASSWORD"
echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
echo "KAIZENBOT_LABSERVER_HOME: $KAIZENBOT_LABSERVER_HOME"
echo "KAIZENBOT_G5R_SUITEID: $KAIZENBOT_G5R_SUITEID"
echo "KAIZENBOT_G5R_SUITENAME: $KAIZENBOT_G5R_SUITENAME"
echo "KAIZENBOT_G5R_TPLANID: $KAIZENBOT_G5R_TPLANID"
echo "KAIZENBOT_G5R_TESTNAME: $KAIZENBOT_G5R_TESTNAME"
echo "KAIZENBOT_G5R_INCLUDETAGS: $KAIZENBOT_G5R_INCLUDETAGS"
echo "KAIZENBOT_G5R_EXCLUDETAGS: $KAIZENBOT_G5R_EXCLUDETAGS"
echo "KAIZENBOT_G5R_PLATFORM: $KAIZENBOT_G5R_PLATFORM"
echo "KAIZENBOT_G5R_PROJECT: $KAIZENBOT_G5R_PROJECT"
echo "KAIZENBOT_G5R_WAIT_ON_BUSY_PLATFORM: $KAIZENBOT_G5R_WAIT_ON_BUSY_PLATFORM"
echo "KAIZENBOT_NODES: $KAIZENBOT_NODES"
echo "RELEASE_FWVERSION: $RELEASE_FWVERSION"
echo "KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION: $KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION"
echo "KAIZENBOT_G5R_USERPAT: $KAIZENBOT_G5R_USERPAT"
echo "KAIZENBOT_REPLICATE_IN_PARALLEL: $KAIZENBOT_REPLICATE_IN_PARALLEL"
echo "KAIZENBOT_BUG_AREAPATH: $KAIZENBOT_BUG_AREAPATH"
echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
echo "ADS_AGENT_USER: $ADS_AGENT_USER"
echo "KAIZENBOT_SUITE_SERIAL_EXECUTION: $KAIZENBOT_SUITE_SERIAL_EXECUTION"
echo "KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE: $KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE"

KBVARFILE=$ADS_AGENT_HOME/kbvars.py

##Creating kbvars.py file for updating results in ADS using pabot
echo "Username: $KAIZENBOT_USERNAME"
echo "Creating Kaizenbot variables file: $KBVARFILE"
echo "TestSuiteID='$KAIZENBOT_SUITEID'">$KBVARFILE ##using > single operator to create the KBVARFILE freshly
echo "KAIZENBOT_SUITENAME='$KAIZENBOT_SUITENAME'">>$KBVARFILE
echo "KAIZENBOT_TAGS='$KAIZENBOT_TAGS'">>$KBVARFILE
echo "TestPlanID='$KAIZENBOT_TPLANID'">>$KBVARFILE
echo "tester='$KAIZENBOT_USERNAME'">>$KBVARFILE
echo "pat='$KAIZENBOT_USERPAT'">>$KBVARFILE
echo "parallel='True'">>$KBVARFILE

##Creating kaizen-env.txt file 
KAIZENBOT_USERNAME="\"$KAIZENBOT_USERNAME\""
if [[ $TEST_RUNID != "" || ${TEST_RUNID,,} !=  *"${NONE,,}"* ]]
then
	KAIZENBOT_TESTNAME="\"$KAIZENBOT_TESTNAME\""
	KAIZENBOT_SUITENAME="\"$KAIZENBOT_SUITENAME\""
	KAIZENBOT_INCLUDETAGS="\"$KAIZENBOT_INCLUDETAGS\""
	KAIZENBOT_EXCLUDETAGS="\"$KAIZENBOT_EXCLUDETAGS\""
fi

KAIZEN_ENV_TXT_FILE="$ADS_AGENT_HOME/kaizen-env.txt"
TEMP_FILE="`mktemp -u`"
env |grep -i kaizenbot | grep -v grep | grep -v PATH > $TEMP_FILE
echo "BUILD_BUILDNUMBER=$BUILD_BUILDNUMBER" >> $TEMP_FILE
cat $TEMP_FILE | sed 's/^/export /g' > $KAIZEN_ENV_TXT_FILE
rm -f $TEMP_FILE
echo "export KAIZENBOT_USERNAME=$KAIZENBOT_USERNAME" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_SLAVE=1" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_HOME=$ADS_AGENT_HOME" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_USER=$ADS_AGENT_USER" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_PASSWORD=\"$ADS_AGENT_PASSWORD\"" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER=$KAIZENBOT_LABSERVER" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_USERNAME=$KAIZENBOT_LABSERVER_USERNAME" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_PASSWORD=$KAIZENBOT_LABSERVER_PASSWORD" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_HOME=\"$KAIZENBOT_LABSERVER_HOME\"" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_REPOSITORY_NAME=$BUILD_REPOSITORY_NAME" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_QUEUEDBY=$BUILD_QUEUEDBY" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_REQUESTEDFOREMAIL=$BUILD_REQUESTEDFOREMAIL" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_SOURCEBRANCHNAME=$BUILD_SOURCEBRANCHNAME" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_BUG_AREAPATH=\"$KAIZENBOT_BUG_AREAPATH\"" >> $KAIZEN_ENV_TXT_FILE
echo "export TEST_RUNID=$TEST_RUNID" >> $KAIZEN_ENV_TXT_FILE
echo "export RELEASE_FWVERSION=$RELEASE_FWVERSION" >> $KAIZEN_ENV_TXT_FILE
echo "export RELEASE_PRIORFWVERSION=$RELEASE_PRIORFWVERSION" >> $KAIZEN_ENV_TXT_FILE
echo "export RELEASE_SLNTBASEFWVERSION=$RELEASE_SLNTBASEFWVERSION" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION=$KAIZENBOT_DISABLE_PARALLEL_TEST_EXECUTION" >> $KAIZEN_ENV_TXT_FILE
echo "export BUILD_REPOSITORY_NAME=$BUILD_REPOSITORY_NAME" >> $KAIZEN_ENV_TXT_FILE

export KAIZENBOT_USERPAT KAIZENBOT_TPLANID KAIZENBOT_SUITEID KAIZENBOT_USERNAME KAIZENBOT_PARALLEL TEST_RUNID

##creating ADS agent Result directory to copy files from kaizenbot lab server and putting it in kaizen-env.txt
ADS_RESULT_DEST="$ADS_AGENT_HOME/LOGS/`mktemp -u | cut -d '.' -f 2`"
mkdir -p $ADS_RESULT_DEST
echo "ADS_RESULT_DEST=$ADS_RESULT_DEST" >> $ADS_AGENT_HOME/kaizen-env.txt
chmod 777 $ADS_RESULT_DEST

##creating TMPENV file for each agent to not collide with copy of kaizen-env.txt in kaizenbot server
TMPENV=`mktemp -u`

##Copying kaizen-env.txt file to TMPENV in KaizenBot Server
echo "Copying env file to KaizenBot Server"
$ADS_AGENT_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.copyfile $ADS_AGENT_HOME/kaizen-env.txt $KAIZENBOT_LABSERVER $KAIZENBOT_LABSERVER_USERNAME $KAIZENBOT_LABSERVER_PASSWORD $TMPENV

##Watchdog to monitor any cancellation of job
echo "USR1" > /opt/kaizenbot/watchdog/kzsigpipe
echo "$$:/opt/kaizenbot/watchdog/stopkzlab.py $KAIZENBOT_LABSERVER $KAIZENBOT_LABSERVER_USERNAME $KAIZENBOT_LABSERVER_PASSWORD \"/home/$KAIZENBOT_LABSERVER_USERNAME/kaizenbot/bin/stopkzbot.sh $BUILD_BUILDNUMBER\"" > /opt/kaizenbot/watchdog/kzpipe
#echo "$$:/opt/kaizenbot/watchdog/stopkzlab" > /opt/kaizenbot/watchdog/kzpipe

##Launching Kaizenbot on KaizenBot Server and passing TMPENV to read kaizen-env variables
echo "Launching Kaizenbot on KaizenBot Server"
$ADS_AGENT_HOME/kaizenbot/bin/python3 -m kaizenbot.Misc.runprog $KAIZENBOT_LABSERVER $KAIZENBOT_LABSERVER_USERNAME $KAIZENBOT_LABSERVER_PASSWORD "/home/$KAIZENBOT_LABSERVER_USERNAME/kaizenbot/bin/launch-robot_dryrun.sh $TMPENV"

export ADS_RESULT_DEST RELEASE_RELEASEWEBURL NON_FATAL_PATH

##Running Kaizenmail py file to updated result in ADS, send mail and send notification in Teams
#$ADS_AGENT_HOME/kaizenbot/bin/python3 $ADS_AGENT_HOME/kaizenbot/bin/kaizenmail_generic.py $KBVARFILE

##Removing files at the end of test
rm -f $TMPENV
#rm -f $ADS_AGENT_HOME/kaizen-env.txt
rm -rf $ADS_RESULT_DEST

##telling watchdog that test exited gracefully
echo "USR2" > /opt/kaizenbot/watchdog/kzsigpipe
echo $$ > /opt/kaizenbot/watchdog/kzpipe
exit 0

