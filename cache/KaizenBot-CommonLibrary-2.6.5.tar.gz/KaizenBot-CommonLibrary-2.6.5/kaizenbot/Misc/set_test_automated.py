#!/usr/bin/env python3
import os
from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat
az=AzureLibrary(pat)
pull_request_id=os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTID")
repo=os.environ.get('BUILD_REPOSITORY_NAME')
update_status=az._update_workitems_to_automated_from_pullrequests(repo,pull_request_id)
print(update_status)
