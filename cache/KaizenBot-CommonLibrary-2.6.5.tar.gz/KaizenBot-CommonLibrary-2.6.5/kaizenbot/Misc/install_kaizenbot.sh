#!/bin/bash

##Reading pipleine variables
ADS_AGENT_USER=$USER
ADS_AGENT_HOME=/home/$ADS_AGENT_USER/
KAIZENBOT_LABSERVER_HOME=/home/$KAIZENBOT_LABSERVER_USERNAME/
echo "ADS_AGENT_HOME: $ADS_AGENT_HOME"
echo "ADS_AGENT_USER: $ADS_AGENT_USER"
echo "KAIZENBOT_LABSERVER: $KAIZENBOT_LABSERVER"
echo "KAIZENBOT_LABSERVER_USERNAME: $KAIZENBOT_LABSERVER_USERNAME"
echo "KAIZENBOT_LABSERVER_PASSWORD: $KAIZENBOT_LABSERVER_PASSWORD"
echo "KAIZENBOT_GIT_USERNAME: $KAIZENBOT_GIT_USERNAME"
echo "KAIZENBOT_G5R_USERPAT: $KAIZENBOT_G5R_USERPAT"
echo "KAIZENBOT_GIT_BRANCHNAME: $KAIZENBOT_GIT_BRANCHNAME"
echo "MACHINE_SERVER: $MACHINE_SERVER"
echo "KAIZENBOT_LABSERVER_HOME: $KAIZENBOT_LABSERVER_HOME"

NONE='None'
##Checking for empty userpat
if [[ "$KAIZENBOT_G5R_USERPAT" == "" || ${KAIZENBOT_G5R_USERPAT,} == *"${NONE,,}"* ]]
then
        echo "Please provide personal access token detail to continue with installation"
        exit 1
fi

##Checking for empty username
if [[ "$KAIZENBOT_GIT_USERNAME" == "" || ${KAIZENBOT_GIT_USERNAME,,} == *"${NONE,,}"* ]]
then
        echo "Please provide username to continue with installation"
        exit 1
fi

##Checking for empty labserver address
if [[ "$KAIZENBOT_LABSERVER" == "" || ${KAIZENBOT_LABSERVER,,} == *"${NONE,,}"* ]]
then
        echo "Please provide labserver address of system to continue with installation"
        exit 1
fi

##Checking for empty labserver username
if [[ "$KAIZENBOT_LABSERVER_USERNAME" == "" || ${KAIZENBOT_LABSERVER_USERNAME,,} == *"${NONE,,}"* ]]
then
        echo "Please provide labserver username of system to continue with installation"
        exit 1
fi

##Checking for empty labserver password
if [[ "$KAIZENBOT_LABSERVER_PASSWORD" == "" || ${KAIZENBOT_LABSERVER_PASSWORD,,} == *"${NONE,,}"* ]]
then
        echo "Please provide labserver password of system to continue with installation"
        exit 1
fi

##Checking for empty branch name
if [[ "$KAIZENBOT_GIT_BRANCHNAME" == "" || ${KAIZENBOT_GIT_BRANCHNAME,,} == *"${NONE,,}"* ]]
then
        echo "Please provide git branch name to continue with installation"
        exit 1
fi

##Checking for empty machine server
if [[ "$MACHINE_SERVER" == "" || ${MACHINE_SERVER,,} == *"${NONE,,}"* ]]
then
        echo "Please provide machine server detail to continue with installation"
	exit 1
fi

##Creating kaizen-env.txt file 
KAIZEN_ENV_TXT_FILE="$ADS_AGENT_HOME/kaizen-env_swinstall.txt"
TEMP_FILE="`mktemp -u`"
env | grep -i kaizenbot | grep -v grep | grep -v PATH > $TEMP_FILE
echo "BUILD_BUILDNUMBER=$BUILD_BUILDNUMBER" >> $TEMP_FILE
cat $TEMP_FILE | sed 's/^/export /g' > $KAIZEN_ENV_TXT_FILE
rm -f $TEMP_FILE
echo $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_SLAVE=1" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_HOME=$ADS_AGENT_HOME" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_USER=$ADS_AGENT_USER" >> $KAIZEN_ENV_TXT_FILE
echo "export ADS_AGENT_PASSWORD=\"$ADS_AGENT_PASSWORD\"" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER=$KAIZENBOT_LABSERVER" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_USERNAME=$KAIZENBOT_LABSERVER_USERNAME" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_PASSWORD=$KAIZENBOT_LABSERVER_PASSWORD" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_LABSERVER_HOME=\"$KAIZENBOT_LABSERVER_HOME\"" >> $KAIZEN_ENV_TXT_FILE
echo "export KAIZENBOT_GIT_BRANCHNAME=\"$KAIZENBOT_GIT_BRANCHNAME\"" >> $KAIZEN_ENV_TXT_FILE
echo "export MACHINE_SERVER=$MACHINE_SERVER" >> $KAIZEN_ENV_TXT_FILE

##creating TMPENV file for each agent to not collide with copy of kaizen-env.txt in kaizenbot server
TMPENV=`mktemp -u`
echo $TMPENV

ADS='ads'
KAIZENBOT='kaizenbot'
GIT_REPO_FOLDER=$KAIZENBOT_LABSERVER_HOME/kaizenbot/InstallSW/git_repo

##Creating git repo folder if not present
if [[ ${MACHINE_SERVER,,} == *"${ADS,,}"* ]]
then
	if [ ! -d $GIT_REPO_FOLDER ]; then mkdir -p $GIT_REPO_FOLDER; fi
	echo "Git repo folder: $GIT_REPO_FOLDER"
	chmod 777 $GIT_REPO_FOLDER
else
	hostname=$KAIZENBOT_LABSERVER
	username=$KAIZENBOT_LABSERVER_USERNAME
	password=$KAIZENBOT_LABSERVER_PASSWORD
	script='source $HOME/kaizenbot/bin/activate;pwd;mkdir -p '$GIT_REPO_FOLDER'; exit'
	echo "logging in to kaizenbot server to create GIT Repo folder"
	sshpass -p $password ssh -l ${username} ${hostname} "${script}"
	echo "Git repo folder: $GIT_REPO_FOLDER"
fi

##Downloading ADS server installation and kaizenbot server installation files based on user input and copying files
if [[ ${MACHINE_SERVER,,} == *"${ADS,,}"* && "$KAIZENBOT_GIT_BRANCHNAME" == "ADS_Server_Install" ]]
then
	echo "Getting ADS server install code from git"
	$(python3 -c 'import sys,os
clone="git clone https://'$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT'@dev.azure.com/itron/RnD/_git/GFW.IVV"
pull_branch = "sshpass -p '$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT' git pull origin '$KAIZENBOT_GIT_BRANCHNAME'"
os.chdir("'$GIT_REPO_FOLDER'")
if(not os.path.exists("'$GIT_REPO_FOLDER'"+"/GFW.IVV")):
	os.system(clone)
os.chdir("'$GIT_REPO_FOLDER'"+"/GFW.IVV")
os.system("sshpass -p '$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT' git fetch --all")
os.system("sshpass -p '$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT' git reset --hard origin/'$KAIZENBOT_GIT_BRANCHNAME'")
os.system(pull_branch)' 2>$GIT_REPO_FOLDER/git_log_error.log)
	
	GIT_REPO=$GIT_REPO_FOLDER/GFW.IVV
	if [ -d "$GIT_REPO" ]
	then
		echo "Completing installation of kaizenbot software in $MACHINE_SERVER server"
		cp -r $GIT_REPO/ADS_Server_Install/python3.6 $KAIZENBOT_LABSERVER_HOME/kaizenbot/lib
		#cp -r $GIT_REPO/ADS_Server_Install/watchdog /opt/kaizenbot
		cp $GIT_REPO/ADS_Server_Install/stop_server.py $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin
		cp $GIT_REPO/ADS_Server_Install/start_server.py $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin
		cp $GIT_REPO/ADS_Server_Install/set_test_automated.py $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin
		cp $GIT_REPO/ADS_Server_Install/launch-agentserver.sh $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin
		cp $GIT_REPO/ADS_Server_Install/kaizenmail.py $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin
		cp $GIT_REPO/ADS_Server_Install/triggerjob.template $KAIZENBOT_LABSERVER_HOME/kaizenbot/bin
		if [[ ${KAIZENBOT_LABSERVER_USERNAME,,} == *"${KAIZENBOT,,}"* ]]
		then
			cp -r $GIT_REPO/ADS_Server_Install/watchdog /opt/kaizenbot
		fi
		echo "Completed install of KaizenBot software in ADS Server"
	else
		echo "Data is not copied from git"
		exit 1
	fi
	
elif [[ ${MACHINE_SERVER,,} == *"${KAIZENBOT,,}"* && "$KAIZENBOT_GIT_BRANCHNAME" == "KaizenBot_Server_Install" ]]
then
	echo "Copying env file to KaizenBot Server"
	hostname=$KAIZENBOT_LABSERVER
        username=$KAIZENBOT_LABSERVER_USERNAME
        password=$KAIZENBOT_LABSERVER_PASSWORD
        script='source $HOME/kaizenbot/bin/activate;pwd; sshpass -p '$KAIZENBOT_LABSERVER_PASSWORD' scp '$ADS_AGENT_USER'@kaizenbot.itron.com:'$ADS_AGENT_HOME'/kaizen-env_swinstall.txt '$KAIZENBOT_LABSERVER_HOME'; exit'
	echo $script
        echo "logging in to kaizenbot server to copy the kaizen-env_swinstall.txt file"
        sshpass -p $password ssh -l ${username} ${hostname} "${script}"

	echo "Getting KaizenBot server install code from git"
	script1='source $HOME/kaizenbot/bin/activate;pwd;cd '$GIT_REPO_FOLDER';if [[ ! -d '$GIT_REPO_FOLDER' && ! -d '$GIT_REPO_FOLDER'/KaizenBot_Server_Install ]]; then git clone "https://'$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT'@dev.azure.com/itron/RnD/_git/GFW.IVV" '$GIT_REPO_FOLDER' ;fi;cd '$GIT_REPO_FOLDER';sshpass -p '$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT' git fetch --all;sshpass -p '$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT' git reset --hard origin/'$KAIZENBOT_GIT_BRANCHNAME';sshpass -p '$KAIZENBOT_GIT_USERNAME':'$KAIZENBOT_G5R_USERPAT' git pull origin '$KAIZENBOT_GIT_BRANCHNAME' 2>'$GIT_REPO_FOLDER'/git_log_error.log; exit'
        sshpass -p $password ssh -l ${username} ${hostname} "${script1}"
	echo $script1	
	GIT_REPO=$GIT_REPO_FOLDER
	echo $GIT_REPO
	script2='source $HOME/kaizenbot/bin/activate;pwd;if [ ! -d "'$GIT_REPO'" ];then echo "Data is not copied from git";exit 1;else echo "Completing installation of kaizenbot software in '$MACHINE_SERVER' server";cp -r '$GIT_REPO'/KaizenBot_Server_Install/python3.6 '$KAIZENBOT_LABSERVER_HOME'/kaizenbot/lib;cp -r '$GIT_REPO'/KaizenBot_Server_Install/Resource-Pool '$KAIZENBOT_LABSERVER_HOME'/kaizenbot;cp '$GIT_REPO'/KaizenBot_Server_Install/launch-robot.sh '$KAIZENBOT_LABSERVER_HOME'/kaizenbot/bin;cp '$GIT_REPO'/KaizenBot_Server_Install/start_server.py '$KAIZENBOT_LABSERVER_HOME'/kaizenbot/bin;cp '$GIT_REPO'/KaizenBot_Server_Install/stopkzbot.sh '$KAIZENBOT_LABSERVER_HOME'/kaizenbot/bin;if [[ "'$KAIZENBOT_LABSERVER_USERNAME'" == "kaizenbot" || "'$KAIZENBOT_LABSERVER_USERNAME'" == "sanity" ]]; then cp '$GIT_REPO'/KaizenBot_Server_Install/dbserver.sh '$KAIZENBOT_LABSERVER_HOME';chmod +x '$KAIZENBOT_LABSERVER_HOME'/dbserver.sh;./'$KAIZENBOT_LABSERVER_HOME'/dbserver.sh '$KAIZENBOT_LABSERVER' start;fi;fi; echo "Completed install of KaizenBot software in KaizenBot Server"; rm -f '$KAIZENBOT_LABSERVER_HOME'/kaizen-env_swinstall.txt; exit'
        sshpass -p $password ssh -l ${username} ${hostname} "${script2}"
else
    	echo "Please provide appropriate machine server and git branch name to continue with installation. ADS machine server for ADS_Server_Install git branchname and kaizenbot machine server for KaizenBot_Server_Install git branch name"
        exit 1
fi

##Removing files at the end of test
rm -f $KAIZEN_ENV_TXT_FILE
	

