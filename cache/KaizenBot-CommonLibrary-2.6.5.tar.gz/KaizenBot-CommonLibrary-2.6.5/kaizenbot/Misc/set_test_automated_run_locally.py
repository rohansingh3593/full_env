#!/usr/bin/venv python3
from kaizenbot.azurelibrary import AzureLibrary
from kaizenbot.azuredata import pat
az=AzureLibrary(pat)
xyz=az._update_workitems_to_automated_from_pullrequests("GFW.IVV",125639)
print(xyz)
