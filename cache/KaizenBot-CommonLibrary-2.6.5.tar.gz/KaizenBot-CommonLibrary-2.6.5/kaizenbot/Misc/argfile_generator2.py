import sys
import os
import shutil
import pabot

CURDIR = os.path.dirname(os.path.abspath(__file__))
argdir = None


def kbot_run_resource_manager(kbot_args, node_type):
    if not kbot_args.get('schema'):
        from kaizenbot.kbotdbclient import _KBotDBClient
        kbot_robj = _KBotDBClient(kbot_args['resourceserveruri'], kbot_args['tester'], kbot_args['project'])
    else:
        from kaizenbot.kbotdbclient_psql import _KBotDBClient_psql
        kbot_robj = _KBotDBClient_psql(kbot_args['resourceserveruri'], kbot_args['tester'], kbot_args['project'], kbot_args['schema'])

    if not kbot_args['tester']:
        raise RuntimeError("missing argument --tester <name>")
    if not kbot_args['noplatform']:
        if not kbot_args['useplatform']:
            raise RuntimeError("User must specify platform. Use --useplatform <platform> or --noplatform")
        if not kbot_args['project']:
            raise RuntimeError("missing argument --project <name>")
        if not kbot_args['resourceserveruri']:
            raise RuntimeError("missing argument --resourceserveruri <value>")
        kbot_platform = kbot_robj.acquire_platform(kbot_args['nowait'], kbot_args['useplatform'])
        nodes = kbot_robj.read_all_nodes(node_type)
        return kbot_robj, kbot_platform, nodes
    return None,None,None

def _parse_args(args):
    kbot_args = {'tester': None,
                  'noplatform': False,
                  'nowait': False,
                  'useplatform': None,
                  'project': None,
                  'schema': None,
                  'resourceserveruri': None}
    while args and (args[0] in ['--' + param for param in ['tester',
                                                           'noplatform',
                                                           'nowait',
                                                           'useplatform',
                                                           'project',
                                                           'schema',
                                                           'resourceserveruri']]):
        if args[0] == '--tester':
            kbot_args['tester'] = args[1]
            args = args[2:]
            continue
        if args[0] == '--project':
            kbot_args['project'] = args[1]
            args = args[2:]
            continue
        if args[0] == '--resourceserveruri':
            kbot_args['resourceserveruri'] = args[1]
            args = args[2:]
            continue
        if args[0] == '--nowait':
            kbot_args['nowait'] = True
            args = args[1:]
            continue
        if args[0] == '--noplatform':
            kbot_args['noplatform'] = True
            args = args[1:]
            continue
        if args[0] == '--useplatform':
            kbot_args['useplatform'] = args[1]
            args = args[2:]
            continue
        if args[0] == '--schema':
            kbot_args['schema'] = args[1]
            args = args[2:]
            continue
    return kbot_args

def create_argfiles(nodes):
    global argdir
    #if not isinstance(nodes, list):
    #    nodes = [nodes]
    ttl_cnt = len(nodes)
    argdir = os.path.join(CURDIR, os.getenv('KAIZENBOT_LABSERVER_USERNAME'), 'argfiles')
    if os.path.isdir(argdir):
        shutil.rmtree(argdir)
    os.makedirs(argdir)
    args = []
    #for i,node in enumerate(nodes): 
    for i in range(ttl_cnt): 
        with open(os.path.join(argdir, str(i+1)), 'w') as argfile:
            argfile.write('-v node:%s'%nodes[i])
            #pass
            #print(node)
            #if not isinstance(node, dict):
            #    raise RuntimeError("Unexpected Values From database")
            #for key,value in node.items():
            #    argfile.write('--variable %s:%s\n'%(key,value))
            #argfile.write('--name %s'%node.NODE_IP)
        args.append('--argumentfile'+str(i+1))
        args.append(os.path.join(argdir, str(i+1)))
    return args
    
if __name__ == "__main__":
    kbotObj = kbotPlatform = nodes = None
    try:
        if sys.argv[1] != '--nodesfile':
            raise RuntimeError("Missing argument --nodesfile.It must be first argument")
        free_here = False
        kbot_args = _parse_args(sys.argv[3:])
        node_type = os.environ.get('KAIZENBOT_REPLICATE_IN_PARALLEL_NODETYPE')
        kbotObj, kbotPlatform, nodes = kbot_run_resource_manager(kbot_args, node_type)
        if not nodes:
            RED='\033[31m'
            ENDC='\033[m'
            print(RED + "ERROR: No node found for replication for given node type", ENDC)
            raise RuntimeError("No node found for replication")
        with open(sys.argv[2], 'a') as nf:
            for node in nodes:
                nf.write("%s\n"%str(node))
        #print(nodes)
        args = create_argfiles(nodes)
        #args.extend([ '--processes %s'%str(ttl_cnt) ])
        args.append('--processes')
        args.append(str(len(nodes)))
        args.extend(sys.argv[3:])
        #print(args)
        pabot.main(args,kbotObj, kbotPlatform)
    except Exception:
        free_here = True
        raise
    finally:
        if free_here and kbotObj:
            try:
                kbotObj.release_platform()
            except:
                print("Connection to Resource server was closed abnormally. Platform '%s' could not be released" %str(kbotPlatform))
