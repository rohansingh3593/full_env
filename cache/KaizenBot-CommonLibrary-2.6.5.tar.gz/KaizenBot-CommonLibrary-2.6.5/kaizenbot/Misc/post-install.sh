#!/bin/bash

echo "Executing post install script.."
PYVER=$(python -c 'import sys;pyver="python"+".".join(sys.version.split(" ")[0].split(".")[0:2]);print(pyver)')
PYPATH="`which python`"
TARGETDIR="`dirname $PYPATH`"
INSTHOME="$TARGETDIR/../../"
#TARGETDIR="$INSTHOME/kaizenbot/bin"
SRCDIR="`dirname $0`"
LINKDIR="$INSTHOME/kaizenbot/lib/$PYVER/site-packages/kaizenbot/Misc"
SITEDIR="$INSTHOME/kaizenbot/lib/$PYVER/site-packages/"
echo "Source Folder: $SRCDIR"
echo "Link Folder: $LINKDIR"
echo "Target Folder: $TARGETDIR"
echo "Site Package Folder: $SITEDIR"
for f in `ls $SRCDIR`
do
    ln -sf $LINKDIR/$f $TARGETDIR/$f
done
echo "Done"

ACTFILE="$TARGETDIR/activate"
if ! grep -qi "chmod -R 777" $ACTFILE
then
    echo "chmod -R 777 $INSTHOME/kaizenbot" >> $ACTFILE
    echo "cp $LINKDIR/../3rdparty-mods/run.py $SITEDIR/robot/" >> $ACTFILE
    echo "cp $LINKDIR/../3rdparty-mods/settings.py $SITEDIR/robot/conf/" >> $ACTFILE
    echo "cp $LINKDIR/../3rdparty-mods/pabot.py $SITEDIR/pabot/" >> $ACTFILE
    echo "cp $LINKDIR/../3rdparty-mods/arguments.py $SITEDIR/pabot/" >> $ACTFILE
    echo "cp $LINKDIR/../3rdparty-mods/pabot__init__.py $SITEDIR/pabot/__init__.py" >> $ACTFILE
fi
exit 0
