# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from robot.utils import ConnectionCache

class ServerCache(ConnectionCache):
    def __init__(self):
        ConnectionCache.__init__(self, no_current_msg='No active connection.')
 
    @property
    def connections(self):
        return self._connections
            
    @property
    def aliases(self):
        return self._aliases
        
    def close_current(self):
        """
        This closes current connected server using ssh.
        """
        self.current.tpclient.close()
        self.current.scpclient.close()
        connection = self.current.client
        connection.close()
        if(self.current.server_alias is not None):
            self.aliases.pop(self.current.server_alias)
        self.current = self._no_current

    def close_all(self):
        """
        This closes all connected servers using ssh.
        """
        for conn in self.connections:
            conn.tpclient.close()
            conn.scpclient.close()
            conn.client.close()
        self.empty_cache()
        return self.current
    