# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
import os
from .logging_robot import Loggers
import socket
import paramiko
import scp
from paramiko.ssh_exception import SSHException
import time
import sys
from time import gmtime, strftime, localtime

class NotADirectoryError(Exception):
    pass

log_obj = Loggers()
logger = log_obj.get_logger('KaizenBot')

class Server:
    def __init__(self, server_ip = None, server_username = None, server_password = None, server_alias = None, timeout = None, port = 22, key_file = None):
        self.server_alias = server_alias
        self.server_ip = server_ip
        self.server_username = server_username
        self.server_password = server_password
        self.key_file = key_file
        self.timeout = timeout
        self.server_port = port
        self.transport=None
        self.client, self.transport = Server._connect_and_login(self.server_ip, self.server_port, self.server_username, self.server_password, self.timeout, self.key_file)
        self.tpclient = self.client.get_transport()
        self.scpclient = scp.SCPClient(self.tpclient, socket_timeout=60.0, progress =self.progress)
    
    def _logger(self):
        #log_obj = Loggers()
        #logger = log_obj.get_logger('KaizenBot')
        if logger:
            return logger
        else:
            raise Exception("logger is empty")
    
    @staticmethod
    def _connect_and_login(server_ip, server_port, server_username, server_password, timeout, key_file=None):
        """This connects to ``server_ip`` and returns an SSHClient.
        """
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=server_ip, port = server_port, username=server_username, password=server_password, timeout=timeout, key_filename=key_file)
            client.invoke_shell()
            transport = client.get_transport()
            transport.set_keepalive(86400)
        except paramiko.AuthenticationException:
            self._logger().exception("Authentication failed, please verify your credentials")
            raise Exception("Authentication failed, please verify your credentials")
        except paramiko.SSHException as sshException:
            self._logger().exception("Could not establish SSH connection: %s" % sshException)
            raise Exception("Could not establish SSH connection: %s" % sshException)
        except socket.timeout as e:
            self._logger().exception("Connection timed out: %s" %e)
            raise Exception("Connection timed out: %s" %e)
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            return client, transport
        
    def _execute_command(self, command, timeout = 300, BackgroundRun=False, OutputFile=None, codec=None):
        """This executes command ``command`` on server.
        The command execution timeouts in 5 minutes.
        """
        try:
            timeout = int(timeout)
        except ValueError:
            self._logger().exception("'timeout' must be an integer or string-convertible-to-integer")
            raise Exception("'timeout' must be an integer or string-convertible-to-integer")
        
        commandout = ''   
          
        try:
            if BackgroundRun==True:
                if OutputFile==None:
                    command = command.strip() + ' 2>&1 > /dev/null'
                else:
                    command = command.strip() + ' 2>&1 > '+OutputFile+'.log'
                channel=self.transport.open_session()
                return channel.exec_command(command)
            else:
                stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)
        except paramiko.SSHException as message:
            self._logger().exception(message)
            raise Exception("Executing command '{}' failed: {}".format(command, str(message)))
        else:
            try:
                commandout = stdout.read().decode() if not codec else stdout.read().decode(codec)
                #self._logger().info(commandout)
            except socket.timeout:
                self._logger().exception("Command '{}' taking too long to execute".format(command))
                raise Exception("Command '{}' taking too long to execute".format(command))
            else:
                if(commandout is ''):
                    commandout_err = stderr.read().decode()
                    if (commandout_err is not ''):
                        self._logger().debug("Executing command '{}' failed: {}".format(command, commandout_err))
                        raise Exception("Executing command '{}' failed: {}".format(command, commandout_err))
                #self._logger().debug(commandout)
                stdin.flush()
                return commandout
            
    def _invoke_shell(self):
        try:
            return self.client.invoke_shell()
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
            
    def _put_file(self, file, remote_dest):
        """This copies the file ``file`` from the local machine to ``remote_dest`` on the server.
        """
        if(not os.path.isfile(file)):
            self._logger().debug("file '{}' not found".format(file))
            raise FileNotFoundError("file '{}' not found".format(file))
        
        self.scpclient.put(file, remote_dest)
        
    def _get_file(self, file, local_dest):
        """This copies the file ``file`` from the remote machine/server to ``local_dest`` on the local machine.
        """
        if local_dest: 
            self.scpclient.get(file, local_dest)
        else:
            self.scpclient.get(file)
        
    def _file_exists(self, file):
        """This checks if file ``file`` exists on the server.
        In such case, it returns ``True`` otherwise ``False``.
        """
        output = self._execute_command('test -f {} && echo 1 || echo 0'.format(file))
        if(output.find('1') != -1):     # if(output == '1\n'):
            return True
        return False
        
    def _dir_exists(self, dir):
        """This checks if directory ``dir`` exists on the server.
        In such case, it returns ``True`` otherwise ``False``.
        """
        output = self._execute_command('test -d {} && echo 1 || echo 0'.format(dir))
        if(output.find('1') != -1):     # if(output == '1\n'):
            return True
        return False

    def _get_os_name(self):
        """This returns the os name of the server.
        """
        command = r'systeminfo | findstr /B /C:"OS Name"'
        try:
            output = self._execute_command(command)
        except Exception as e:
            self._logger().exception(e)
            output = str(e)
        
        if 'Windows' in output:
            return 'nt'
        else:
            return 'posix'
        
    def list_dir(self, dir, type = None, pattern = None):
        """This returns the python list of all the directories and files in directory ``dir``.
        
        if ``type`` is ``d``, it returns list of directories.
        if ``type`` is ``f`` it returns list of regular files.
        
        if ``pattern`` is given, only list matching the pattern is returned.
        """
        if pattern is not None:
            pattern = '| grep %s' % pattern
        else:
            pattern = ''
            
        if type in ['f', 'd']:
            type = ' -type %s' % type
        else:
            type = ''   
        
        if not self._dir_exists(dir):
            raise NotADirectoryError("Directory '{}' does not exist".format(dir))
            
        command = 'find %s -maxdepth 1' % dir + type + pattern
        output = self._execute_command(command)
        
        output = output.split('\n')
        while('' in output):
            output.remove('')
        return output
    
    def progress(self, filename, size, sent):
        self._logger().info("%s\'s progress: %.2f%%   \r" % (filename, float(sent)/float(size)*100) )

from smb.SMBConnection import SMBConnection
from smb.smb_structs import OperationFailure
from nmb.nmb_structs import NotConnectedError  # smb.base.NotConnectedError
from smb.base import NotReadyError
import tempfile

class CIFSServer:
    
    def __init__(self, userID, password, client_machine_name, server_name, server_ip, domain):
        
        self.userID = userID
        self.password = password
        self.client_machine_name = client_machine_name
        
        self.server_name= server_name
        self.server_ip=  server_ip
        self.domain = domain
        
        self.conn = SMBConnection(self.userID, self.password, self.client_machine_name, self.server_name, self.domain)
        
        if not self.conn.connect(server_ip, 139):
            self.conn.close()
            raise NotReadyError("Could not connect to windows shared machine '{}'".format(server_ip))
        
    def get_file(self, service_name, source_file, dest_dir = None):
        """This copies file from CIFS server.
        ``service_name`` is windows shared folder.
        if ``dest_dir`` does not exist it will create the ``dest_dir``.
        If ``dest_dir`` is not provided, a temporary directory will be created. 
        """
        if not dest_dir:
            dest_dir = tempfile.mkdtemp()
            
        if not os.path.isdir(dest_dir):
            os.mkdir(dest_dir)
        
        filename = get_basename_for_windows_file(source_file)
            
        dest_file = os.path.join(dest_dir, filename)   
        with open(dest_file, 'wb') as dest_file_obj:
            try:
                file_attributes, filesize = self.conn.retrieveFile(service_name, source_file, dest_file_obj)
            except OperationFailure:
                self._logger().exception("Either file '{}' does not exist or you do not have read permissions".format(source_file))
                raise RuntimeError("Either file '{}' does not exist or you do not have read permissions".format(source_file))
            except NotConnectedError:
                self._logger().exception("Not Connected to CIFS server")
                raise NotConnectedError("Not Connected to CIFS server")
            else:
                return dest_file
            
    def close(self):
        """This closes cifs server
        """
        if self.conn:
            self.conn.close()

    
def get_basename_for_windows_file(path):
    import ntpath
    return ntpath.basename(path) 
      
