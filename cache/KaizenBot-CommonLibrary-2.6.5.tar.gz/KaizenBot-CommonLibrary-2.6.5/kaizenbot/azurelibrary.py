# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential
  information, ideas and expressions. No part of which may be reproduced or
  transmitted in any form or by any means electronic, mechanical, or otherwise.
  Including photocopying and recording or in Connection with any information
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from kaizenbot.logging_robot import Loggers
import glob, os, re, base64, time, shutil, sys, json, json2html, io
import xml.dom.minidom
from azure.devops.v6_0.test_plan import models
from azure.devops.connection import Connection
from msrest.authentication import BasicAuthentication
from azure.devops import *
from msrest.exceptions import AuthenticationError
from azure.devops.v6_0 import client_factory
from platform import system
from pathlib import Path
from time import localtime, strftime
import xml.etree.ElementTree as ET
from azure.devops.v5_1.work_item_tracking.models import Wiql
from azure.devops.exceptions import AzureDevOpsServiceError
from datetime import datetime
import zipfile
from functools import reduce

''' Constants '''
pat = 'vamal7crzrrmsuc3y75k5y6mgrudbec5qtbcmytonj4ge5t75jzq'
TEST_CLIENT = "azure.devops.v6_0.test.test_client.TestClient"
TESTPLAN_CLIENT = "azure.devops.v6_0.test_plan.test_plan_client.TestPlanClient"
WORK_CLIENT = "azure.devops.released.work.work_client.WorkClient"
WORK_ITEM_TRACKING_CLIENT = "azure.devops.v6_0.work_item_tracking.work_item_tracking_client.WorkItemTrackingClient"
BUILD_CLIENT = "azure.devops.v6_0.build.build_client.BuildClient"
GIT_CLIENT_BASE = "azure.devops.v6_0.git.git_client_base.GitClientBase"

Test_Run_Batch_Size=100000

'''Inherited Class'''
if(os.name=='nt'):
    Result_Dir = os.path.join(os.getcwd(), "Results")
    Log_Dir = os.path.join(os.getcwd(), "Logs")
else:
    Result_Dir = os.environ.get('KAIZENBOT_INTERNAL_OUTDIR')
    Log_Dir = os.environ.get('KAIZENBOT_INTERNAL_LOGDIR')
    if Log_Dir is None:
        Log_Dir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if Log_Dir is a directory'''
        if os.path.isdir(Log_Dir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(Log_Dir))
        else:
            raise Exception("Directory {} does not exists".format(Log_Dir))

    if Result_Dir is None:
        Result_Dir = os.path.join(os.getcwd(), "Results")
    else:
        '''check if Result_Dir is a directory'''
        if os.path.isdir(Result_Dir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(Result_Dir))
        else:
            raise Exception("Directory {} does not exists".format(Result_Dir))

logger = Loggers().get_logger('KaizenBot-AzureLibrary')

class AzureLibrary:
    def __init__(self, pat=None):
        self.pat=pat
        if pat:
            self.connection = self._authentication()

    def _logger(self):
        if logger:
            return logger
        else:
            raise Exception("logger is empty")

    def set_personal_access_token(self, pat):
        """This keyword sets the personal access token from azure devops to ``VSTS_PERSONAL_ACCESS_TOKEN``.

        This need to be set to establish connection with azure devops.

        Example :

        |         = keyword =         |                       = pat =                        |                     =output=                 |
        | `Set Personal Access Token` | qwfg7cxhicxsczazie7pgy6wki2ouz7i26vt22u3lpskayqtp5qq | This will authenticate ADS with provided pat |

        """
        self.pat = pat
        self.connection = self._authentication()

    def _authentication(self):
        """ This keyword establishes connection with VSTS based on the personal access token provided by the user
        """
        organization_url = 'https://dev.azure.com/itron'
        try:
            ##Create a connection to the org
            if not self.pat:
                from kaizenbot.azuredata import pat
                self.pat = pat
            if(self.pat is None or self.pat==''):
                raise Exception("Please provide personal access token detail for running updating results in ADS")
            credentials = BasicAuthentication('', self.pat)
            connection = Connection(base_url=organization_url, creds=credentials)
        except AuthenticationError:
            self._logger().exception("Authentication failed, please verify your personal access token")
            raise Exception("Authentication failed, please verify your personal access token")
        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)
        else:
            self._logger().info("Connected to ADS")
            return connection

    def _get_project_by_id(self):
        """ This keyword return the project id i.e. id corresponding to RnD
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        get_projects_response = core_client.get_projects()
        if get_projects_response is not None:
            for project in get_projects_response.value:
                index += 1
        if get_projects_response.continuation_token is not None and get_projects_response.continuation_token != "":
            # Get the next page of projects
            get_projects_response = core_client.get_projects(continuation_token=get_projects_response.continuation_token)
        else:
            # All projects have been retrieved
            get_projects_response = None
        return(project.id)

    def _get_projects_by_name(self):
        """ This keyword return the all projects name
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        project_list=[]
        get_projects_response = core_client.get_projects()
        if get_projects_response is not None:
            for project in get_projects_response.value:
                index += 1
                project_list.append(project.name)
        if get_projects_response.continuation_token is not None and get_projects_response.continuation_token != "":
            # Get the next page of projects
            get_projects_response = core_client.get_projects(continuation_token=get_projects_response.continuation_token)
        else:
            # All projects have been retrieved
            get_projects_response = None
        return(project_list)

    def _get_project_by_name(self):
        """ This keyword return the project name i.e. RnD
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        project_name = self._get_projects_by_name()
        if 'RnD' in project_name:
            project_index=project_name.index('RnD')
            project_name = core_client.get_project(project_name[project_index])
            project= project_name.name #this will be RnD
        else:
            print("User is not added in RnD project.")
            project='None' ## setting to none, as user is not in RnD project
        return(project)

    def _get_attachment_count(self, wi_id):
        self.connection = self._authentication()
        wit_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        res = wit_client.get_work_item(wi_id, fields=['System.AttachedFileCount'])
        return res.fields['System.AttachedFileCount']

    def update_result_in_vsts(self, update=False, planid=None, suiteid=None, tester=None, log_path=None, result_path=None, configuration=None, mode_of_attachment=None):
        """This keyword updates the test result in ADS if update is set to ``True``.

        `update` is set to `False` by default, which will not update the result in ADS.

        This keyword has optional arguments `planid`, `suiteid`, `tester`, `log_path` and
        `result_path` set to None.

        If user changes update value to `True`, user need to set `planid`, `suiteid` and
        `tester` for which result will bee updated in ADS.

        `log_path` is path of Logs folder which will be attached in ADS

        `result_path` is path of Results folder which consists of .xml and .html files
        which will be attached in ADS and parsing result status

        This keyword returns `Success` on successfully updating result and attaching logs.

        Example :

        |       = keyword =        | = update = | = plan id = | = suiteid = |   = tester =   |  = log_path =  | = result_path = |                    = output =                        |
        | `Update Result In VSTS`  | False      |             |             |                |                |                 | This will not update result in VSTS                  |
        | `Update Result In VSTS`  | True       | 1870820     | 1934529     | Shweta Kaushik | /home/Logs     | /home/Results   | This will update result in VSTS for provided\
                                                                                                                                 planid, suiteid and tester for each test case and\
                                                                                                                                  logs from provided folders\                          |
        | `Update Result In VSTS`  | True       | 1870820     | 1934529     | Shweta Kaushik |                |                 | This will update result in VSTS for provided\
                                                                                                                                 planid, suiteid and tester for each test case and\
                                                                                                                                  logs from default set folders\                       |
        | `Update Result In VSTS`  | True       |             |             |                |                |                 | This will throw error to enter plan id and same\
                                                                                                                                 if any of the parameters missed with update as `True` |
        """
        self.connection = self._authentication()
        if(update == False):
            self._logger().info("User has not requested to update result in ADS")
            return 'Not Requested', None, '00:00:00'
        else:
            '''Update result in VSTS'''
            '''Setting state to completed for Passed and Failed Test'''
            state = 'Completed'

            '''Test plan id, test suite id and tester details from argument'''
            TestPlanId= planid
            TestSuiteId=suiteid
            if ',' in suiteid:
                Suite_Ids = suiteid.split(',')
                SuiteIds = [x.strip(' ') for x in Suite_Ids]
                TestSuiteId = SuiteIds
            else:
                SuiteIds=[suiteid]
                TestSuiteId = SuiteIds
            Identity=tester
            if(update == True and (TestPlanId is None or TestPlanId == '')):
                self._logger().debug("Please Enter Test Plan Id")
                raise Exception("Please Enter Test Plan Id")
            else:
                '''Converting test plan id to integer'''
                TestPlanId = int(TestPlanId)
            if(len(SuiteIds) == 1):
                if(update == True and  (TestSuiteId[0] is None or TestSuiteId[0] == '')):
                    self._logger().debug("Please Enter Test Suite Id")
                    raise Exception("Please Enter Test Suite Id")
                else:
                    '''Converting test plan id to integer'''
                    TestSuiteId = int(TestSuiteId[0])
            else:
                for i in range(0, len(SuiteIds)):
                    if(update == True and (TestSuiteId[i] is None or TestSuiteId[i] == '')):
                        self._logger().debug("Please Enter Test Suite Id")
                        raise Exception("Please Enter Test Suite Id")
                    else:
                        '''Converting test suite id to integer'''
                        TestSuiteId = [int(i) for i in TestSuiteId]
            if(update == True and (Identity is None or Identity == '')):
                self._logger().debug("Please Enter Tester Name")
                raise Exception("Please Enter Tester Name")

            try:
                '''Getting log data which includes Test Case number and Outcome of each test case from parsed xml file'''
                if(result_path is None):
                    log_data,elapsed_time= self._parse_output_logs()
                else:
                    log_data,elapsed_time= self._parse_output_logs(result_path)

                '''Getting log data from TestReport.csv special case for INS project'''
                if os.path.isfile(result_path+"/TestReport.csv"):
                    log_data,*_,elapsed_time= self._parse_clet_log(result_path)

                TC_list=[]
                TC_Outcome=[]
                for logs in log_data:
                    for key,val in logs.items():
                        TC_list.append(key)
                        TC_Outcome.append(val)
                '''Setting Run name to Tes Result Update by default'''
                runName = 'Test Result Update'
                '''Getting ADS Project name i.e RnD from project list'''
                project = self._get_project_by_name()

                test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
                test_client = self.connection.get_client(TEST_CLIENT)
                work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)

                '''creating configuration'''
                self._logger().info(configuration)
                if (configuration is not None and configuration !=''):
                    TestConfigurationCreateUpdateParameters={
                        'name': configuration,
                        'is_default':True,
                        'description': 'KaizenBot configuration',
                        'values':[
                            {
                                'name':configuration,
                                'value':configuration
                            }
                        ],
                        'state':'Active'
                        }

                    '''Getting All configurations from ADS'''
                    configs=self._get_test_configurations()

                    '''Checking if user provided configuration is present in ADS already and creating new if not present'''
                    for config_data in configs:
                        if configuration.lower() in config_data.lower():
                            config_id= config_data.split('---')[0]
                            break
                        else:
                            continue
                    else:
                        config_val=test_plan_client.create_test_configuration(TestConfigurationCreateUpdateParameters,project)
                        config_id=config_val.id

                    '''Searching for test cases extracted from xml in all test cases for provide plan and suite id if its available'''
                    test_case_list=[]
                    if (len(SuiteIds) > 1):
                        for i in range(len(SuiteIds)):
                            for tests in test_client.get_test_cases(project, TestPlanId, TestSuiteId[i]):
                                self._logger().info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
                                test_case_list.append(tests.test_case.id)
                    else:
                        for tests in test_client.get_test_cases(project, TestPlanId, TestSuiteId):
                            self._logger().info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
                            test_case_list.append(tests.test_case.id)

                    print("updating configuration for all executed test cases in ADS")
                    print("Test Cases in provided plan id and suite id: {}".format(test_case_list))
                    print("Test Cases present in output log: {}".format(TC_list))

                    '''Checking if any test case is not present in provided test plan id and suite id'''
                    for i in range(0, len(TC_list)):
                        if (TC_list[i] in test_case_list):
                            pass
                            self._logger().debug("Test Case found")
                        else:
                            self._logger().info("Test Case present in output is not found in the provided Test plan Id and suite Id")
                            print("Test Case '{}' present in output is not found in the provided Test plan Id and suite Id".format(TC_list[i]))
                            #raise Exception("Test Case present in output is not found in the provided Test plan Id and suite Id")

                    '''Updating configuration for single suite ID and multiple suite IDs'''
                    try:
                        if (len(SuiteIds) > 1):
                            for i in range(len(SuiteIds)):
                                new_test_list=[]
                                '''Checking for specific test cases in suite Ids to update configuration'''
                                for data in test_client.get_test_cases(project, TestPlanId, TestSuiteId[i]):
                                    new_test_list.append(data.test_case.id)

                                '''checking test case obtained from plan id and suite id is present in output log extacted test case list and creating new list'''
                                new_testcase_list=[]
                                for val in TC_list:
                                    if val in new_test_list:
                                        new_testcase_list.append(val)

                                '''Updating configuration for each test cases'''
                                for tcs in new_testcase_list:
                                    id_tc={
                                        'id':tcs
                                        }
                                    SuiteTestCaseCreateUpdateParameters={
                                    'point_assignments':
                                        [{
                                        'configuration_id':config_id
                                        }
                                        ],
                                        'work_item': id_tc
                                    }
                                    test_plan_client.update_suite_test_cases([SuiteTestCaseCreateUpdateParameters], project, TestPlanId, TestSuiteId[i])
                        else:
                            '''Checking for specific test cases in suite Ids to update configuration'''
                            new_test_list=[]
                            for data in test_client.get_test_cases(project, TestPlanId, TestSuiteId):
                                new_test_list.append(data.test_case.id)

                            '''checking test case obtained from plan id and suite id is present in output log extacted test case list and creating new list'''
                            new_testcase_list=[]
                            for val in TC_list:
                                if val in new_test_list:
                                    new_testcase_list.append(val)
                            '''Updating configuration for each test cases'''
                            for tcs in new_testcase_list:
                                id_tc={
                                    'id':tcs
                                    }
                                SuiteTestCaseCreateUpdateParameters={
                                'point_assignments':
                                    [{
                                    'configuration_id':config_id
                                    }
                                    ],
                                    'work_item': id_tc
                                }
                                test_plan_client.update_suite_test_cases([SuiteTestCaseCreateUpdateParameters], project, TestPlanId, TestSuiteId)
                    except Exception as e:
                        if "Error occurred in request" in str(e):
                            print("One of the test cases are not present in provided plan id")
                        else:
                            print("Exception Occurred: {}".format(e))

                '''Getting test points of each test case for the provided plan id and suite id'''
                points_id=[]
                if (len(SuiteIds) == 1):
                    points_ids= test_client.get_points(project, TestPlanId, TestSuiteId)
                else:
                    for i in range(len(SuiteIds)):
                        points= test_client.get_points(project, TestPlanId, TestSuiteId[i])
                        points_id.append(points)
                    points_ids=[]
                    for i in range(len(points_id)):
                        points_ids.extend(points_id[i])

                test_result=[]

                '''Create Test Result'''
                if(points_ids !=[] or points_ids is not None):
                    '''test cases list from get points method'''
                    tcid_pointid_list=[]

                    '''test points list for the corresponding test cases from get points method'''
                    ntcid=[]
                    npointid=[]

                    '''Test case list from xml output which matches test case in ntcid list'''
                    test_case_from_xml=[]

                    '''Test point list for the test cases extracted from xml output'''
                    test_point_for_tc_in_xml=[]

                    '''Creating list of dict with corresponding test case and point details'''
                    for point in points_ids:
                        ntcid.append(point.test_case.id)
                        npointid.append(point.id)
                        tcid_pointid_dict = {point.test_case.id : point.id}
                        tcid_pointid_list.append(tcid_pointid_dict)

                    print("updating result for all executed test cases in ADS")
                    print("Test Cases in provided plan id and suite id: {}".format(ntcid))
                    print("Test Cases present in output log: {}".format(TC_list))

                    '''Searching for test cases extracted from xml in all test cases for provide plan and suite id if its available'''
                    for i in range(0, len(TC_list)):
                        if (TC_list[i] in ntcid):
                            test_case_from_xml.append(TC_list[i])
                            for pointt in tcid_pointid_list:
                                if TC_list[i] in pointt:
                                    test_point_for_tc_in_xml.append(pointt[TC_list[i]])
                        else:
                            self._logger().info("Test Case not found for the provided Test plan Id and suite Plan Id")
                            print("Test Case '{}' present in output is not found in the provided Test plan Id and suite Id".format(TC_list[i]))

                    '''getting test cases index from output log extracted test case list for getting the corresponding outcome required for updating results'''
                    test_case_index_list=[]
                    for tcid_xml in range(0, len(test_case_from_xml)):
                        if tcid_xml and test_case_from_xml[tcid_xml] == test_case_from_xml[tcid_xml-1]:
                            continue
                        for list_index in range(0, len(TC_list)):
                            if test_case_from_xml[tcid_xml] == TC_list[list_index]:
                                test_case_index_list.append(list_index)

                    outcome_sortedlist=[]
                    for i in range(0, len(test_case_index_list)):
                        outcome_sortedlist.append(TC_Outcome[test_case_index_list[i]])

                    '''Getting test plan for the provided test plan id'''
                    testPlan = test_plan_client.get_test_plan_by_id(project, TestPlanId)

                    '''Creating dictionary which will be used in model for creating test run'''
                    Tester ={'display_name': Identity}
                    tplan = {'id': testPlan.id}
                    run_create_model = {
                            'name': runName,
                            'automated': 'true',
                            'plan': tplan,
                            'owner': Tester
                        }

                    '''Create Test Run'''
                    run = test_client.create_test_run(run_create_model, project)
                    self._logger().info("Run ID is: {}".format(run.id))

                    '''Creating dictionary which will be used in model for adding test results to test run'''
                    runid = {'id': run.id}
                    runId = {'test_run': runid}
                    testplanid = {'test_plan': tplan}
                    configid = {'id': config_id}
                    configId = {'configuration': configid}

                    '''Creating few more dictionary which will be used in model for adding test results to test run'''
                    for i in range(0, len(test_case_from_xml)):
                        test_res={}
                        test_case_val=test_case_from_xml[i] # test case value from xml
                        test_point_val=test_point_for_tc_in_xml[i] # test point for the corresponding test case from xml

                        point_model={'id': test_point_val}
                        pointId={'test_point': point_model}
                        owner_name ={'owner': testPlan.owner}
                        RunBy = {'run_by': Tester}

                        '''Getting all test cases for a project'''
                        testcase = work_item_tracking_client.get_work_item(int(test_case_val), project)

                        tc_model={'id': test_case_val}
                        testcaseid={'test_case': tc_model}
                        testcasetitle={'test_case_title': testcase.fields['System.Title']}
                        testcaserevision={'test_case_revision': testcase.rev}

                        test_res.update(owner_name)
                        test_res.update(testplanid)
                        test_res.update(testcaseid)
                        test_res.update(testcasetitle)
                        test_res.update(testcaserevision)
                        test_res.update(RunBy)
                        test_res.update(pointId)
                        test_res.update(runId)
                        test_res.update(configId)
                        test_result.append(test_res) #created list of dictionary models for each test case which will be used to add test result to test run

                    try:
                        '''Adding test result to test run for each test case extracted from xml output along with the outcome'''
                        TestCaseResults = test_client.add_test_results_to_test_run(test_result, project, run.id)
                    except AzureDevOpsServiceError as e:
                        self._logger().info('No testcase available on xml to update in ADS')
                        self._logger().error(e)
                        return 'Failure', None, elapsed_time

                    '''Setting the value of state to completed and outcome of each test case and updating the test result in ADS'''
                    if(TestCaseResults !=[] or TestCaseResults is not None):
                        i=0
                        for result in TestCaseResults:
                            result.state = state # state is set to completed
                            result.outcome= TC_Outcome[test_case_index_list[i]] # taking test outcome for each test case based on extarcted test case index and updating result in ADS
                            resultId = result.id # fetching result ID for each test case for same test run

                            '''Updating test result in ADS for above state and outcome for each test case of xml'''
                            TestResults = test_client.update_test_results(TestCaseResults, project, result.test_run.id)

                            '''Defining mode of attachment: common attachment or individual attachment'''
                            if not mode_of_attachment:
                                if os.path.isfile(result_path + "/TestReport.csv"):
                                    mode_of_attachment = 'individual'
                                else:
                                    mode_of_attachment = 'common'

                            '''Selecting required attachment files for each test case'''
                            attach_files, files_for_encoding = self._select_attachments(log_path, result_path, mode_of_attachment, test_case_from_xml[i])

                            j, flag, newTestRun = 0, 'Failure', None
                            for file in files_for_encoding:
                                with open(files_for_encoding[j], 'rb') as f:
                                    encoded_string = base64.b64encode(f.read()).decode('ascii')

                                Test_Attachment_Request_Model={
                                    'attachment_type': 'GeneralAttachment',
                                    'comment': 'attach report',
                                    'file_name': attach_files[j],
                                    'stream': encoded_string
                                    }

                                '''Adding attachment to each test case'''
                                attachment_id = test_client.create_test_result_attachment(Test_Attachment_Request_Model, project, result.test_run.id, resultId)

                                '''This method checks the attachment and verifies if the log html is attached with each test case or not'''
                                checkid = test_client.get_test_result_attachments(project, result.test_run.id, resultId)
                                attachmentid_list=[]
                                for item in checkid:
                                    attachmentid_list.append(item.id)
                                if(attachment_id.id in attachmentid_list):
                                    #self._logger().debug("Attached result successfully")
                                    flag ='Success'
                                else:
                                    self._logger().error("Attachment failed, File: {}".format(attach_files[j]))
                                    flag ='Failure'
                                j+=1 # loop for attaching log and report html files
                            i+=1 #End of for loop with updating outcome and attaching log files

                    '''This method completes the test run which was created at the start so that no more updates can be done for the test run id'''
                    if (state !='' or state is not None):
                        #for Results in TestResults:
                        #    state = Results.state
                        run_update_model={
                            'state': state
                            }
                        newTestRun = test_client.update_test_run(run_update_model, project, result.test_run.id)
            except Exception as e:
                self._logger().exception(e)
                #raise Exception(e)
                print("None of the Test Cases updated in ADS as executed test cases not found in the provided Test plan Id and suite Plan Id")
            else:
                return flag, newTestRun.web_access_url, elapsed_time

    def _select_attachments(self, log_path, result_path, attaching_mode='common', tc_id=None):
        """Depending upon the attachment mode selecting whether common log files to be attached to the testcase or
        individual log to each testcase """
        attach_files = []
        files_for_encoding = []
        if attaching_mode == 'common':
            '''select common log.html,report.html to each test case after updating file'''
            # Getting latest log file from the specified directory
            if result_path is None:
                self._logger().info("No Result Folder path provided")
            else:
                log_html, report_html = self._get_latest_report_file(result_path)

            log_filename = Path(log_html).name
            report_filename = Path(report_html).name
            attach_files = [log_filename, report_filename]
            files_for_encoding = [log_html, report_html]

            if log_path is None:
                # logs_file=self._get_log_files()
                self._logger().info("No Log Folder path provided")
            else:
                logs_file = self._get_log_files(log_path)
                if len(logs_file) >= 1:
                    for k in range(0, len(logs_file)):
                        files = Path(logs_file[k]).name
                        attach_files.append(files)
                files_for_encoding.extend(logs_file)
        else:
            '''select individual files for each testcase from log_path'''
            if tc_id is None:
                self._logger().info("tc_id must for updating individual attachments")
            if log_path is None:
                self._logger().info("No Log Folder path provided")
            else:
                logs_file = self._get_log_files(log_path, file_pattern=tc_id)
                if logs_file:
                    for file in logs_file:
                        files = Path(file).name
                        attach_files.append(files)
                else:
                    self._logger().info("No Log File found for tcid:{} under logpath:{}".format(tc_id, log_path))
                files_for_encoding.extend(logs_file)
        return attach_files, files_for_encoding

    def _get_test_configurations(self):
        self.connection = self._authentication()
        project = self._get_project_by_name()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        test_config_list=[]
        lookformore = True
        token_val='0'
        MAX_CONFIG=15000
        skip=0
        while(lookformore):
            configs=test_plan_client.get_test_configurations(project, continuation_token=token_val)
            if (configs is not None and configs != []):
                for data in configs:
                    test_config_list.append(str(data.id) +"---" +str(data.name))
                    if(data.id != MAX_CONFIG):
                        token_val= data.id
                    elif (data.id == MAX_CONFIG):
                        lookformore=False
                        break
            else:
                lookformore=False
            token_val=str(int(data.id) + 1)
        return test_config_list

    def _createWorkitem(self, title, description, assign, areaPath,worktype='Issue'):
        self.connection = self._authentication()
        project = self._get_project_by_name()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        self._logger().debug('@#')
        self._logger().debug("%s\n%s\n%s\n%s\n",title, description, assign, areaPath)
        docsam = [
                {"op":"add", "path":"/fields/System.Title", "from": "null", "value": title },
                {"op":"add", "path":"/fields/System.AreaPath", "from": "null", "value": areaPath },
                {"op":"add", "path":"/fields/System.Description", "from": "null", "value": description},
                {"op":"add", "path":"/fields/System.AssignedTo", "from": "null", "value": assign}
             ]
        return work_item_tracking_client.create_work_item(docsam, project,worktype)

    def _updateWorkItemFields(self,wid,fv):
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        self._logger().debug('@#')
        docsam = []
        for field in fv.keys():
            value = fv[field]
            self._logger().debug("Updating field %s with value %s",field,value)
            vstspath = "/fields/" + field
            tmp = {"op":"add", "path":vstspath, "from": "null", "value": value}
            docsam.append(tmp)
        return work_item_tracking_client.update_work_item(docsam,wid)

    def _linkWorkItem(self,wid,lid):
        """wid: existing work item id
           lid: Id to be linked to wid
        """
        self._logger().debug('@#')
        self.connection = self._authentication()
        project = self._get_project_by_name()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        urllink = 'https://dev.azure.com/itron/' + project + "/_workitems/edit/" + str(lid)
        docsam = [ {"op":"add", "path":"/relations/-", "value": {"rel": "System.LinkTypes.Dependency-forward", "url": urllink, "attributes": { "comment": "Making a new link for similar oss component"}}} ]
        return work_item_tracking_client.update_work_item(docsam,wid)

    def create_bug_in_ADS(self, result_path, user_email, areapath,log_path=None):
        """This keyword creates bug in ADS for failed test cases.

        `result_path` is path of Results folder which consists of .xml and .html files
        which will be attached in ADS and parsing result status

        `username` is tester name for creating bug.

        `areapath` is area path to be provided while creating bug

        `log_path` is path of Logs folder which will be attached in ADS. It is set to `None` by default

        Example :

        |       = keyword =    | = result_path = |  = username =   |  = areapath =  | = log_path = |                             = output =                            |
        | `Create Bug In ADS`  |  /home/Results  |  Shweta Kaushik |  RnD\KaizenBot |  /home/Logs  | This will create bug in ADS in provided area path and username    |
        | `Create Bug In ADS`  |                 |                 |                |              | This will throw error to enter result_path, username and areapath |
        """
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        '''Getting log data which includes Test Case number and Outcome of each test case from parsed xml file'''
        if(result_path is None or result_path == ''):
            raise Exception("No Result Path provided. Please provide path for report file folder")
        else:
            log_data,*_= self._parse_output_logs(result_path)

        if (areapath is None or areapath == ''):
            raise Exception("No Area Path provided. Please provide Area Path for creating a bug")
        else:
            areapath=str(areapath)

        TC_list=[]
        for logs in log_data:
            for key,val in logs.items():
                if 'Failed' in val:
                    TC_list.append(key)

        TC_list = list(set(TC_list))
        print(TC_list)
        bug_ID_list=[]
        try:
            if (TC_list != [] or TC_list is not None):
                for test_case in TC_list:
                    bug_tag='TC-'+test_case+'-KZBOT'
                    self._logger().info("Checking for existing tickets with tag: {}".format(bug_tag))
                    Work_Item_Ids = self._getWorkItemsByTag(bug_tag)
                    if(len(Work_Item_Ids) > 0):
                        self._logger().info("Got an existing ticket: {}\n".format(Work_Item_Ids[0]))
                        wi_ref = Work_Item_Ids[0]
                        wi = work_item_tracking_client.get_work_item(wi_ref)
                        state = wi.fields['System.State']
                        if state == 'Active':
                            self._logger().info("State is active\n")
                            ticket_fields = {"System.History":"Testcase TC-"+test_case+" failed again"}
                            self._updateWorkItemFields(wi.id,ticket_fields)
                        else:
                            self._logger().info("State is: . Reopening ticket\n",state)
                            ticket_fields = {"System.State":"Active"}
                            self._updateWorkItemFields(wi.id,ticket_fields)
                    else:
                        self._logger().info("No existing tickets. Creating new one\n")
                        wi=self._createWorkitem("Issue observed in TC-"+test_case+"","This ticket is automatically created by kaizenbot",user_email,areapath)
                        ticket_fields = {"System.Tags":bug_tag} # -KZBOT is mandatory to distinguish tags added by KZBOT
                        self._updateWorkItemFields(wi.id,ticket_fields)
                        self._logger().info("New ticket: {}\n".format(wi.id))
                    bug_ID_list.append(wi.id)

                    '''Link testcase as a Successor link to the bug'''
                    self._linkWorkItem(wi.id, test_case)

                    '''check total attachment on the work item'''
                    tot_attachments = self._get_attachment_count(wi.id)
                    self._logger().info("Total attachments: {}".format(tot_attachments))
                    if tot_attachments > 99: #refer: https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/object-limits?view=azure-devops
                        '''Attachement Limit:100 reached; so Deleting all the old Attachments'''
                        print("Total attachments:", tot_attachments)
                        self._removeAttachments(wi.id, tot_attachments)

                    '''attach log.html to each test case after creating bug'''
                    if(result_path is None):
                        log_html, report_html = self._get_latest_report_file()
                    else:
                        log_html, report_html = self._get_latest_report_file(result_path)
                    log_filename = Path(log_html).name
                    report_filename = Path(report_html).name
                    attach_files=[log_filename, report_filename]
                    files_for_encoding=[log_html, report_html]
                    if(log_path is None):
                        self._logger().info("No log path provided")
                    else:
                        logs_file=self._get_log_files(log_path)
                        if(len(logs_file) >=1):
                            for k in range(0, len(logs_file)):
                                files=Path(logs_file[k]).name
                                attach_files.append(files)
                        files_for_encoding.extend(logs_file)

                    '''Remove duplicate files and get unique files only'''
                    files_for_encoding=list(set(files_for_encoding))

                    '''zip files to be attached as a single zipfile'''
                    zip_name ='%s/log_%s.zip'% (result_path, test_case)
                    files_for_encoding = [Path(n) for n in files_for_encoding]
                    self._logger().info(zip_name)
                    zh = zipfile.ZipFile(zip_name, 'w')
                    for file in files_for_encoding:
                        zh.write(file, compress_type=zipfile.ZIP_DEFLATED)
                    zh.close()
                    self._attachToWorkItem([zip_name], wi.id, "Attaching log files and output files as a zipfile")
                return bug_ID_list
            else:
                self._logger().info("No tests failed")
                return -1
        except Exception as e:
            self._logger().exception(str(e))
            if 'Invalid Area/Iteration id' in str(e):
                print('Exception occurred. Not created Bug')
            else:
                print('Exception occurred: {}'.format(e))


    def _createAttachment(self,content,filename,wid,comments):
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        project = self._get_project_by_name()
        self._logger().info("Creating Attachment object")
        obj = work_item_tracking_client.create_attachment(content,project, filename, 'Simple')
        if not obj:
            raise Exception("Failed to create attachment object")
            return False
        docsam = [ {"op":"add", "path":"/relations/-", "value": {"rel": "AttachedFile", "url": obj.url, "attributes": { "comment": comments}}} ]
        self._logger().debug("Attaching file to ticket")
        if not work_item_tracking_client.update_work_item(docsam,wid):
            raise Exception("Attaching file failed")
            return False
        else:
            self._logger().debug("Attachment succeeded")
            return True

    def _removeAttachments(self, wid, tot_att):
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        self._logger().info("Removing Attachment object")

        ticket_fields = {"System.History": '''Reached Maximum Attachment Limit: %d. Hence deleting all the old attachments.
Please refer: https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/object-limits?view=azure-devops''' % (tot_att) }
        self._updateWorkItemFields(wid, ticket_fields)

        docsam = [{"op": "remove", "path": "/relations/%d" % x} for x in range(tot_att)]
        try:
            work_item_tracking_client.update_work_item(docsam, wid)
            self._logger().debug("Dettachment succeeded")
            return True
        except Exception as e:
            raise Exception("Dettaching file failed. Received exception: %s\n" % e)

    def _attachToWorkItem(self,filearr,wid,comments):
        error = False
        for filename in filearr:
            try:
                if zipfile.is_zipfile(filename):
                    with open(filename, 'rb') as file_data:
                        content = io.BytesIO(file_data.read())
                    os.remove(filename)
                else:
                    with open(filename,'r') as fd:
                        content = io.BytesIO(''.join(fd.readlines()).encode('utf-8'))
            except Exception as e:
                self._logger().exception(str(e))
                raise Exception("Failed to open/read file: %s. Received exception: %s\n" %(filename,str(e)))
                error = True
                continue
            uploadname = os.path.basename(filename)
            if not self._createAttachment(content,uploadname,wid,comments):
                raise Exception("Failed to attach file: %s\n" %(filename))
                error = True

    def _getWorkItemsByTag(self,tag):
        self.connection = self._authentication()
        project = self._get_project_by_name()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        self._logger().info("Retrieving all existing tickets for project %s",project)
        try:
            queryWI = Wiql(query='SELECT * FROM WorkItems WHERE [System.TeamProject] = ' + '"' + project + '"' + ' AND [System.Tags] CONTAINS "' + tag + '"' + ' ORDER BY [System.Id]')
            results = work_item_tracking_client.query_by_wiql(queryWI).work_items
        except Exception as e:
            self._logger().exception("Received exception {}".format(e))
            raise Exception(str(e))
        workitemid = []
        for i in results:
            workitemid.append(i.id)
        workitems = results
        self._logger().info("Total work items: %s",len(workitemid))
        self._logger().info("Work items: %s",workitemid)
        return workitemid

    def _get_latest_report_file(self, file_path=None):
        """This keyword returns the latest log.html file from the specified path
        """
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
        else:
            filepath= path+'/*'
            if(system() == 'Windows'):
                PATH = path+'\\'
            else:
                PATH = path+'/'
        report_list=[]
        log_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if (PATH+'log') in list_of_files[i]:
                log_list.append(list_of_files[i])
            elif (PATH+'report') in list_of_files[i]:
                report_list.append(list_of_files[i])
        if(not report_list):
            raise Exception("No output file found")
        latest_report_file = max(report_list, key=os.path.getctime)
        latest_log_file = max(log_list, key=os.path.getctime)
        return latest_log_file, latest_report_file

    def _parse_output_logs(self, file_path=None):
        """This keyword returns the parsed log data from output xml file with corresponding outcome for each test cases
        for the latest output.xml file
        """
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
        outputxml_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if(PATH+'output') in list_of_files[i]:
                outputxml_list.append(list_of_files[i])
        if not outputxml_list:
            raise Exception("No output file found")
        latest_file = max(outputxml_list, key=os.path.getctime)
        doc = xml.dom.minidom.parse(latest_file)
        val = doc.getElementsByTagName('stat')
        val2 = doc.getElementsByTagName('status')
        data_list=[]
        final_list=[]
        start_time = val2[-1].attributes['starttime'].value
        end_time = val2[-1].attributes['endtime'].value
        #end_time = "20210317 16:55:35.657"
        t1 = datetime.strptime(start_time,'%Y%m%d %H:%M:%S.%f')
        t2 = datetime.strptime(end_time, '%Y%m%d %H:%M:%S.%f')
        elapsed_time =str(t2-t1)[:-7]

        for i in val:
            if i.hasAttribute('skip'):
                xml_data = i.firstChild.data, "pass: " + i.attributes['pass'].value, "fail: " + i.attributes[
                    'fail'].value, "skip: " + i.attributes['skip'].value
            else:
                xml_data = i.firstChild.data, "pass: " + i.attributes['pass'].value, "fail: " + i.attributes[
                    'fail'].value
            data_list.append(xml_data)
        for data in data_list:
            if re.search('TC', str(data)):
                TCID = re.search(r'\d+', data[0]).group(0)
                if 'pass: 0' not in data[1]:
                    outcome = 'Passed'
                    output_dict={TCID: outcome}
                elif 'fail: 0' not in data[2]:
                    outcome = 'Failed'
                    output_dict={TCID: outcome}
                else:
                    outcome = 'Blocked'
                    output_dict={TCID: outcome}
                final_list.append(output_dict)
            elif re.search('All Tests', str(data)):
                '''This is for future use. there is no use-case for now'''
                pass_num = int(re.search(r'pass: (\d+)', data[1]).group(1))
                fail_num = int(re.search(r'fail: (\d+)', data[2]).group(1))
                skip_num = int(re.search(r'skip: (\d+)', data[3]).group(1)) if len(data) > 3 else 0
                tot_num = pass_num + fail_num + skip_num
        return final_list, elapsed_time

    def _move_results(self, path=None):
        """Move report.html and log.html to Results folder
        """
        logFile = 'log %s.html' % (strftime("%Y-%m-%d %Hh-%Mm-%Ss", localtime()))
        reportFile = 'report %s.html' % (strftime("%Y-%m-%d %Hh-%Mm-%Ss", localtime()))
        outputFile = 'output %s.xml' % (strftime("%Y-%m-%d %Hh-%Mm-%Ss", localtime()))
        Dir = os.path.join(os.getcwd(), "Results")
        if not os.path.isdir(Dir):
            os.mkdir(Dir)
        LogDestDir = os.path.join(Dir, logFile)
        ReportDestDir = os.path.join(Dir, reportFile)
        OutputDestDir = os.path.join(Dir, outputFile)
        if(path):
            log=Path(os.path.join(path,'log.html'))
            Report=Path(os.path.join(path,'report.html'))
            outputFile=Path(os.path.join(path,'output.xml'))
        else:
            log=Path('log.html')
            Report=Path('report.html')
            outputFile=Path('output.xml')
        shutil.move(log.absolute(), str(LogDestDir))
        shutil.move(Report.absolute(), str(ReportDestDir))
        shutil.move(outputFile.absolute(), str(OutputDestDir))

    def _get_log_files(self, file_path=None, file_pattern=None, file_extension=None):
        """Get latest files from log folder to attach in ADS
        """
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
        else:
            filepath= Dir+'/*'
            if(system() == 'Windows'):
                PATH = Dir+'\\'
            else:
                PATH = Dir+'/'
        logs_list=[]
        if file_extension:
            list_of_files = glob.glob(filepath +'*.%s' % file_extension) if not file_pattern else glob.glob(filepath + '*%s*.%s' % (file_pattern, file_extension))
        elif file_pattern:
            list_of_files = glob.glob(filepath +'*%s*' % file_pattern)
        else:
            list_of_files = glob.glob(filepath)
        return list_of_files

    def _parse_xunit_file(self, file_path=None):
        """This keyword returns the parsed log data from xunit xml file for total test cases, passed test cases and failed test cases
        for the latest xunit.xml file
        """
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
        else:
            filepath= path+'/*'
            if(system() == 'Windows'):
                PATH = path+'\\'
            else:
                PATH = path+'/'
        xunitxml_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if(PATH+'xunit') in list_of_files[i]:
                xunitxml_list.append(list_of_files[i])
        if(not xunitxml_list):
            raise Exception("No output file found")
        latest_file = max(xunitxml_list, key=os.path.getctime)
        doc = xml.dom.minidom.parse(latest_file)
        val = doc.getElementsByTagName('testsuite')
        final_list=[]
        for i in val:
            xml_data="Total Tests: " +i.attributes['tests'].value, "Failed: " +i.attributes['failures'].value
            skipped_num= "Skipped: " +i.attributes['skipped'].value
            xml_data=list(xml_data)
            pass_num="Passed: "+ str(int(i.attributes['tests'].value)-int(i.attributes['failures'].value)-int(i.attributes['skipped'].value))
            xml_data.append(pass_num)
            xml_data.append(skipped_num)
        return(xml_data)

    def _parse_suite_name(self, file_path=None):
        """This keyword returns the parsed log data from xunit xml file for total test cases, passed test cases and failed test cases
        for the latest xunit.xml file
        """
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
        else:
            filepath= path+'/*'
            if(system() == 'Windows'):
                PATH = path+'\\'
            else:
                PATH = path+'/'
        xunitxml_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if(PATH+'xunit') in list_of_files[i]:
                xunitxml_list.append(list_of_files[i])
        if(not xunitxml_list):
            raise Exception("No output file found")
        latest_file = max(xunitxml_list, key=os.path.getctime)
        doc = xml.dom.minidom.parse(latest_file)
        val = doc.getElementsByTagName('testsuite')
        for i in val:
            suite_name=i.attributes['name'].value
        return suite_name

    def getText(self,nodelist):
        rc = []
        for node in nodelist:
            if node.nodeType == node.TEXT_NODE:
                rc.append(node.data)
        return ''.join(rc)

    def _get_non_fatal_error(self, file_path=None):
        """This keyword returns the parsed non fatal error data from output xml file for failed/passed test cases
        for the latest output.xml file
        """
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
        else:
            filepath= path+'/*'
            if(system() == 'Windows'):
                PATH = path+'\\'
            else:
                PATH = path+'/'
        xunitxml_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if(PATH+'output') in list_of_files[i]:
                xunitxml_list.append(list_of_files[i])
        if(not xunitxml_list):
            raise Exception("No output file found")
        latest_file = max(xunitxml_list, key=os.path.getctime)
        data_list=[]
        tree = ET.parse(latest_file)
        root = tree.getroot()
        for status in root.iter('status'):
            if(status.get('status') == "FAIL"):
                if(status.text !=None):
                    data_list.append(status.text)
        for msg in root.iter('msg'):
            if(msg.get('level') == "FAIL"):
                if(msg.text !=None):
                    data_list.append(msg.text)
        return data_list

    def create_tags_from_plan_and_suiteid(self, planid, suiteid):
        """This keyword creates tags for all the test cases present in provided ``planid`` and ``suiteid``
        which will be used by robot for execution.

        This keyword has two mandatory arguments `planid` and `suiteid`.

        This keyword returns `all test cases prefixed with TC and connected with OR` on success.

        Example :

        |               = keyword =            | = plan id = |    = suiteid =  |                                        = output =                                |
        | `Create Tags From Plan And SuiteID`  |             |                 | This will throw error to provide plan and suite id                               |
        | `Create Tags From Plan And SuiteID`  | 1870820     | 1934529         | This will create tags for all tests cases prefixed with TC and connected with OR |
        | `Create Tags From Plan And SuiteID`  | 1870820     | 1934529,2012103 | This will create tags for all tests cases prefixed with TC and connected with OR |

        """
        self.connection = self._authentication()

        '''Test plan id, test suite id and tester details from argument'''
        TestPlanId= planid
        TestSuiteId=suiteid
        if ',' in suiteid:
            Suite_Ids = suiteid.split(',')
            SuiteIds = [x.strip(' ') for x in Suite_Ids]
            TestSuiteId = SuiteIds
        else:
            SuiteIds=[suiteid]
            TestSuiteId = SuiteIds
        if(TestPlanId is None or TestPlanId == ''):
            self._logger().debug("Please Enter Test Plan Id")
            raise Exception("Please Enter Test Plan Id")
        else:
            '''Converting test plan id to integer'''
            TestPlanId = int(TestPlanId)
        if(len(SuiteIds) == 1):
            if(TestSuiteId[0] is None or TestSuiteId[0] == ''):
                self._logger().debug("Please Enter Test Suite Id")
                raise Exception("Please Enter Test Suite Id")
            else:
                '''Converting test plan id to integer'''
                TestSuiteId = int(TestSuiteId[0])
        else:
            for i in range(0, len(SuiteIds)):
                if(TestSuiteId[i] is None or TestSuiteId[i] == ''):
                    self._logger().debug("Please Enter Test Suite Id")
                    raise Exception("Please Enter Test Suite Id")
                else:
                    '''Converting test suite id to integer'''
                    TestSuiteId = [int(i) for i in TestSuiteId]

        try:
            '''Getting ADS Project name i.e RnD from project list'''
            project = self._get_project_by_name()

            test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
            test_client = self.connection.get_client(TEST_CLIENT)
            work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)

            '''Searching for test cases present in provided plan and suite ids'''
            test_case_list=[]
            if (len(SuiteIds) > 1):
                for i in range(len(SuiteIds)):
                    for tests in test_client.get_test_cases(project, TestPlanId, TestSuiteId[i]):
                        self._logger().info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
                        test_case_list.append(tests.test_case.id)
            else:
                for tests in test_client.get_test_cases(project, TestPlanId, TestSuiteId):
                    self._logger().info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
                    test_case_list.append(tests.test_case.id)
            print("Test Cases present in provided plan id and suite id(s): {}".format(test_case_list))

            '''Adding TC at the start of each test case in the list'''
            string_to_add = 'TC'
            string_to_add += '{0}'
            new_test_case_list=[string_to_add.format(i) for i in test_case_list]
            new_tag='--include ' + "OR".join(new_test_case_list)
            return new_tag
        except Exception as e:
            self._logger().exception("Error occured: {}".format(e))
            raise Exception("Error occurred: {}".format(e))

    def create_tags_for_openbug_testcases(self, bug_tc_list):
        if not isinstance(bug_tc_list,list):
            raise Exception("bug_tc_list should be list of list type")

        tc_list_to_skip = []
        for each_set in bug_tc_list: # bug_tc_list is list[list]
            if not isinstance(each_set,list):
                raise Exception("each_set should be list type")
            tot_bugs = list(filter(lambda x: 'BUG' in x, each_set))
            tot_tc = list(filter(lambda x: 'TC' in x, each_set))

            '''Enabling boolean True for open BUGs as a list'''
            bug_state_list = list(map(lambda x: self._get_work_item_state_by_itemid(x[3:]), tot_bugs))
            resultant= list(map(lambda y: 'New' in y or 'Active' in y, bug_state_list))

            '''If any/all Bug(s) are open; Skip testcases'''
            if reduce(lambda a,b: a or b,resultant):
                tc_list_to_skip.extend(tot_tc)
        tc_list_to_skip = set(tc_list_to_skip)  # to get a unique testcase list
        new_tag = '--skip ' + "OR".join(tc_list_to_skip)
        return new_tag

    def update_result_in_vsts_based_on_runid(self, update=False, runid=None, tester=None, log_path=None, result_path=None, configuration=None):
        """This keyword updates the test result in ADS if update is set to ``True``.

        `update` is set to `False` by default, which will not update the result in ADS.

        This keyword has optional arguments `runid`, `tester`, `log_path` and
        `result_path` set to None.

        If user changes update value to `True`, user need to provide `runid` and
        `tester` for which result will bee updated in ADS.

        `log_path` is path of Logs folder which will be attached in ADS

        `result_path` is path of Results folder which consists of .xml and .html files
        which will be attached in ADS and parsing result status

        This keyword returns `Success` on successfully updating result and attaching logs.

        Example :

        |                = keyword =              | = update = | = run id =  |   = tester =   |  = log_path =  | = result_path = |                    = output =                         |
        | `Update Result In VSTS Based On RunID`  | False      |             |                |                |                 | This will not update result in VSTS                   |
        | `Update Result In VSTS Based On RunID`  | True       | 12317768    | Shweta Kaushik | /home/Logs     | /home/Results   | This will update result in VSTS for provided\
                                                                                                                    runid and tester for each test case and\
                                                                                                                    logs from provided folders\                           |
        | `Update Result In VSTS Based On RunID`  | True       | 12317768    | Shweta Kaushik |                |                 | This will update result in VSTS for provided\
                                                                                                                    runid and tester for each test case and\
                                                                                                                    logs from default set folders\                        |
        | `Update Result In VSTS Based On RunID`  | True       |             |                |                |                 | This will throw error to enter plan id and same\
                                                                                                                    if any of the parameters missed with update as `True` |
        """
        self.connection = self._authentication()
        if(update == False):
            self._logger().info("User has not requested to update result in ADS")
            return 'Not Requested', None, '00:00:00'
        else:
            '''Update result in VSTS'''
            '''Setting state to completed for Passed and Failed Test'''
            state = 'Completed'

            '''Getting ADS Project name i.e RnD from project list'''
            project = self._get_project_by_name()

            test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
            test_client = self.connection.get_client(TEST_CLIENT)
            work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)

            '''Getting Test plan id from provided test run id'''
            TestRunId= runid
            if(update == True and (TestRunId is None or TestRunId == '')):
                self._logger().debug("Please Enter Test Run Id")
                raise Exception("Please Enter Test Run Id")
            else:
                '''Converting test run id to integer'''
                TestRunId = int(TestRunId)

            test_run = test_client.get_test_run_by_id(project, runid)
            planid = test_run.plan.id

            '''Getting Test suite id from obtained plan id using test run id'''
            testsuite_list=[]
            testsuite = test_plan_client.get_test_suites_for_plan(project, planid)
            for suite in testsuite:
                testsuite_list.append(suite.id)
            suiteid=','.join(map(str, testsuite_list))

            TestPlanId=planid
            TestSuiteId=suiteid
            if ',' in suiteid:
                Suite_Ids = suiteid.split(',')
                SuiteIds = [x.strip(' ') for x in Suite_Ids]
                TestSuiteId = SuiteIds
            else:
                SuiteIds=[suiteid]
                TestSuiteId = SuiteIds

            Identity=tester
            if(update == True and (TestPlanId is None or TestPlanId == '')):
                self._logger().debug("Test Plan Id is not obtained from provided Run id")
                raise Exception("Test Plan Id is not obtained from provided Run id")
            else:
                '''Converting test plan id to integer'''
                TestPlanId = int(TestPlanId)

            if(len(SuiteIds) == 1):
                if(update == True and  (TestSuiteId[0] is None or TestSuiteId[0] == '')):
                    self._logger().debug("Test Suite Id is not obtained from provided Run id")
                    raise Exception("Test Suite Id is not obtained from provided Run id")
                else:
                    '''Converting test plan id to integer'''
                    TestSuiteId = int(TestSuiteId[0])
            else:
                for i in range(0, len(SuiteIds)):
                    if(update == True and (TestSuiteId[i] is None or TestSuiteId[i] == '')):
                        self._logger().debug("Test Suite Id is not obtained from provided Run id")
                        raise Exception("Test Suite Id is not obtained from provided Run id")
                    else:
                        '''Converting test suite id to integer'''
                        TestSuiteId = [int(i) for i in TestSuiteId]

            if(update == True and (Identity is None or Identity == '')):
                self._logger().debug("Please Enter Tester Name")
                raise Exception("Please Enter Tester Name")

            try:
                '''Getting log data which includes Test Case number and Outcome of each test case from parsed xml file'''
                if(result_path is None):
                    log_data,elapsed_time= self._parse_output_logs()
                else:
                    log_data,elapsed_time= self._parse_output_logs(result_path)
                TC_list=[]
                TC_Outcome=[]
                for logs in log_data:
                    for key,val in logs.items():
                        TC_list.append(key)
                        TC_Outcome.append(val)
                '''Setting Run name to Tes Result Update by default'''
                runName = 'Test Result Update'

                '''creating configuration'''
                self._logger().info(configuration)
                if (configuration is not None and configuration !=''):
                    TestConfigurationCreateUpdateParameters={
                        'name': configuration,
                        'is_default':True,
                        'description': 'KaizenBot configuration',
                        'values':[
                            {
                                'name':configuration,
                                'value':configuration
                            }
                        ],
                        'state':'Active'
                        }

                    '''Getting All configurations from ADS'''
                    configs=self._get_test_configurations()

                    '''Checking if user provided configuration is present in ADS already and creating new if not present'''
                    for config_data in configs:
                        if configuration.lower() in config_data.lower():
                            config_id= config_data.split('---')[0]
                            break
                        else:
                            continue
                    else:
                        config_val=test_plan_client.create_test_configuration(TestConfigurationCreateUpdateParameters,project)
                        config_id=config_val.id

                    '''Searching for test cases extracted from xml in all test cases for provide plan and suite id if its available'''
                    test_case_list=[]
                    if (len(SuiteIds) > 1):
                        for i in range(len(SuiteIds)):
                            for tests in test_client.get_test_cases(project, TestPlanId, TestSuiteId[i]):
                                self._logger().info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
                                test_case_list.append(tests.test_case.id)
                    else:
                        for tests in test_client.get_test_cases(project, TestPlanId, TestSuiteId):
                            self._logger().info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
                            test_case_list.append(tests.test_case.id)

                    print("updating configuration for all executed test cases in ADS")
                    print("Test Cases in provided plan id and suite id: {}".format(test_case_list))
                    print("Test Cases present in output log: {}".format(TC_list))

                    '''Checking if any test case is not present in provided test plan id and suite id'''
                    for i in range(0, len(TC_list)):
                        if (TC_list[i] in test_case_list):
                                pass
                                self._logger().debug("Test Case found")
                        else:
                            self._logger().info("Test Case present in output is not found in the provided Test plan Id and suite Id")
                            print("Test Case '{}' present in output is not found in the provided Test plan Id and suite Id".format(TC_list[i]))
                            #raise Exception("Test Case present in output is not found in the provided Test plan Id and suite Id")

                    '''Updating configuration for single suite ID and multiple suite IDs'''
                    try:
                        if (len(SuiteIds) > 1):
                            for i in range(len(SuiteIds)):
                                new_test_list=[]
                                '''Checking for specific test cases in suite Ids to update configuration'''
                                for data in test_client.get_test_cases(project, TestPlanId, TestSuiteId[i]):
                                    new_test_list.append(data.test_case.id)

                                '''checking test case obtained from plan id and suite id is present in output log extacted test case list and creating new list'''
                                new_testcase_list=[]
                                for j in range(0, len(TC_list)):
                                    if (TC_list[j] in new_test_list):
                                        new_testcase_list.append(TC_list[j])

                                '''Updating configuration for each test cases'''
                                for tcs in new_testcase_list:
                                    id_tc={
                                        'id':tcs
                                        }
                                    SuiteTestCaseCreateUpdateParameters={
                                    'point_assignments':
                                        [{
                                        'configuration_id':config_id
                                        }
                                        ],
                                        'work_item': id_tc
                                    }
                                    test_plan_client.update_suite_test_cases([SuiteTestCaseCreateUpdateParameters], project, TestPlanId, TestSuiteId[i])
                        else:
                            '''Checking for specific test cases in suite Ids to update configuration'''
                            new_test_list=[]
                            for data in test_client.get_test_cases(project, TestPlanId, TestSuiteId):
                                new_test_list.append(data.test_case.id)

                            '''checking test case obtained from plan id and suite id is present in output log extacted test case list and creating new list'''
                            new_testcase_list=[]
                            for j in range(0, len(TC_list)):
                                if (TC_list[j] in new_test_list):
                                    new_testcase_list.append(TC_list[j])
                            '''Updating configuration for each test cases'''
                            for tcs in new_testcase_list:
                                id_tc={
                                    'id':tcs
                                    }
                                SuiteTestCaseCreateUpdateParameters={
                                'point_assignments':
                                    [{
                                    'configuration_id':config_id
                                    }
                                    ],
                                    'work_item': id_tc
                                }
                                test_plan_client.update_suite_test_cases([SuiteTestCaseCreateUpdateParameters], project, TestPlanId, TestSuiteId)
                    except Exception as e:
                        if "Error occurred in request" in str(e):
                            print("One of the test cases are not present in provided plan id")
                        else:
                            print("Exception Occurred: {}".format(e))

                '''Getting test points of each test case for the provided plan id and suite id'''
                points_id=[]
                if (len(SuiteIds) == 1):
                    points_ids= test_client.get_points(project, TestPlanId, TestSuiteId)
                else:
                    for i in range(len(SuiteIds)):
                        points= test_client.get_points(project, TestPlanId, TestSuiteId[i])
                        points_id.append(points)
                    points_ids=[]
                    for i in range(len(points_id)):
                        points_ids.extend(points_id[i])

                test_result=[]

                '''Create Test Result'''
                if(points_ids !=[] or points_ids is not None):
                    '''test cases list from get points method'''
                    tcid_pointid_list=[]

                    '''test points list for the corresponding test cases from get points method'''
                    ntcid=[]
                    npointid=[]

                    '''Test case list from xml output which matches test case in ntcid list'''
                    test_case_from_xml=[]

                    '''Test point list for the test cases extracted from xml output'''
                    test_point_for_tc_in_xml=[]

                    '''Creating list of dict with corresponding test case and point details'''
                    for point in points_ids:
                        ntcid.append(point.test_case.id)
                        npointid.append(point.id)
                        tcid_pointid_dict = {point.test_case.id : point.id}
                        tcid_pointid_list.append(tcid_pointid_dict)

                    print("updating result for all executed test cases in ADS")
                    print("Test Cases in provided plan id and suite id: {}".format(ntcid))
                    print("Test Cases present in output log: {}".format(TC_list))

                    '''Searching for test cases extracted from xml in all test cases for provide plan and suite id if its available'''
                    for i in range(0, len(TC_list)):
                        if (TC_list[i] in ntcid):
                            test_case_from_xml.append(TC_list[i])
                            for pointt in tcid_pointid_list:
                                if TC_list[i] in pointt:
                                    test_point_for_tc_in_xml.append(pointt[TC_list[i]])
                        else:
                            self._logger().info("Test Case not found for the provided Test plan Id and suite Plan Id")
                            print("Test Case '{}' present in output is not found in the provided Test plan Id and suite Id".format(TC_list[i]))

                    TestCaseResults= test_client.get_test_results(project, runid, top=None)
                    Test_Case_From_Results_list=[]
                    for res in TestCaseResults:
                        Test_Case_From_Results_list.append(res.test_case.id)

                    '''getting test cases index from output log extracted test case list and test case Result list for getting the corresponding outcome required for updating results'''
                    test_case_index_list=[]
                    for tcid_xml in range(0, len(Test_Case_From_Results_list)):
                        if tcid_xml and Test_Case_From_Results_list[tcid_xml] == Test_Case_From_Results_list[tcid_xml-1]:
                            continue
                        for list_index in range(0, len(TC_list)):
                            if Test_Case_From_Results_list[tcid_xml] == TC_list[list_index]:
                                test_case_index_list.append(list_index)

                    outcome_sortedlist=[]
                    for i in range(0, len(test_case_index_list)):
                        outcome_sortedlist.append(TC_Outcome[test_case_index_list[i]])

                    '''Setting the value of state to completed and outcome of each test case and updating the test result in ADS'''
                    if(TestCaseResults !=[] or TestCaseResults is not None):
                        i=0
                        for result in TestCaseResults:
                            print(result)
                            result.state = state # state is set to completed
                            outcome=result.outcome
                            print(TC_Outcome[test_case_index_list[i]])
                            result.outcome= TC_Outcome[test_case_index_list[i]] # taking test outcome for each test case based on extarcted test case index and updating result in ADS
                            resultId = result.id # fetching result ID for each test case for same test run

                            '''Updating test result in ADS for above state and outcome for each test case of xml'''
                            TestResults = test_client.update_test_results(TestCaseResults, project, result.test_run.id)

                            '''attach log.html to each test case after updating file'''
                            #Getting latest log file from the specified directory
                            if(result_path is None):
                                self._logger().info("No Result Folder path provided")
                            else:
                                log_html, report_html = self._get_latest_report_file(result_path)
                            log_filename = Path(log_html).name
                            report_filename = Path(report_html).name
                            attach_files=[log_filename, report_filename]
                            files_for_encoding=[log_html, report_html]
                            if(log_path is None):
                                #logs_file=self._get_log_files()
                                self._logger().info("No Log Folder path provided")
                            else:
                                logs_file=self._get_log_files(log_path)
                                if(len(logs_file) >=1):
                                    for k in range(0, len(logs_file)):
                                        files=Path(logs_file[k]).name
                                        attach_files.append(files)
                                files_for_encoding.extend(logs_file)

                            j=0
                            for file in files_for_encoding:
                                with open(files_for_encoding[j], 'rb') as f:
                                    encoded_string = base64.b64encode(f.read()).decode('ascii')

                                Test_Attachment_Request_Model={
                                    'attachment_type': 'GeneralAttachment',
                                    'comment': 'attach report',
                                    'file_name': attach_files[j],
                                    'stream': encoded_string
                                    }

                                '''Adding attachment to each test case'''
                                attachment_id = test_client.create_test_result_attachment(Test_Attachment_Request_Model, project, result.test_run.id, result.id)

                                '''This method checks the attachment and verifies if the log html is attached with each test case or not'''
                                checkid = test_client.get_test_result_attachments(project, result.test_run.id, result.id)
                                attachmentid_list=[]
                                for item in checkid:
                                    attachmentid_list.append(item.id)
                                if(attachment_id.id in attachmentid_list):
                                    #self._logger().debug("Attached result successfully")
                                    flag ='Success'
                                else:
                                    self._logger().error("Attachment failed, File: {}".format(attach_files[j]))
                                    flag ="Failure"
                                j+=1 # loop for attaching log and report html files
                            i+=1 #End of for loop with updating outcome and attaching log files

                    '''This method completes the test run which was created at the start so that no more updates can be done for the test run id'''
                    if (state !='' or state is not None):
                        for Results in TestResults:
                            state = Results.state
                        run_update_model={
                            'state': state
                            }
                        newTestRun = test_client.update_test_run(run_update_model, project, result.test_run.id)
            except Exception as e:
                self._logger().exception(e)
                #raise Exception(e)
                print("None of the Test Cases updated in ADS as executed test cases not found in the provided Test plan Id and suite Plan Id")
            else:
                return flag, newTestRun.web_access_url, elapsed_time

    def _update_workitem_to_automated(self, repository_id, workitemid):
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        work_items_list=[]
        docsam = []
        wid_list=[]
        if (isinstance(workitemid, list)):
            for items in workitemid:
                work_items_list.append(items)
        else:
            work_items_list=workitemid.split(',')
        #print(work_items_list)
        for test_cases in work_items_list:
            fv={"Microsoft.VSTS.TCM.AutomatedTestName":"TC-"+test_cases+"", "Microsoft.VSTS.TCM.AutomatedTestStorage": ""+repository_id+"", "Microsoft.VSTS.TCM.AutomatedTestType": "Scripts"}
            for field in fv.keys():
                value = fv[field]
                print("Updating field {} with value {}".format(field,value))
                vstspath = "/fields/" + field
                tmp = {"op":"add", "path":vstspath, "from": "null", "value": value}
                docsam.append(tmp)
            wid=work_item_tracking_client.update_work_item(docsam,test_cases, expand='Fields')
            wid_list.append(wid)
            docsam.clear() ## clearing the list so that new test cases model can be created
        if wid_list !=[]:
            return 'True'
        else:
            return 'False'

    def _get_test_cases_by_runid(self, runid):
        """ This keyword gets the test cases list from the tests results for provided `runid` for project RnD

        This takes mandatory argument `runid`

        This keyword return the test case ids list
        """
        self.connection = self._authentication()
        project = self._get_project_by_name()
        test_client = self.connection.clients.get_test_client()
        results= test_client.get_test_results(project, runid, top=None)
        print(results)
        test_results=[]
        for result in results:
            print(result.test_case.id)
            test_results.append(result.test_case.id)

        '''Adding TC at the start of each test case in the list'''
        string_to_add = 'TC'
        string_to_add += '{0}'
        new_test_case_list=[string_to_add.format(i) for i in test_results]
        new_tag='--include ' + "OR".join(new_test_case_list)
        return new_tag

    def _get_build_pipeline_variables(self, build_number):
        """ This keyword gets the build details for provided `build_number` for project RnD

        This takes mandatory argument `build_number`

        This keyword return the
        """
        self.connection = self._authentication()
        project = self._get_project_by_name()
        build_client = self.connection.get_client(BUILD_CLIENT)
        res=build_client.get_build(project, build_number, property_filters='True')
        return res.parameters

    def _update_workitems_to_automated_from_pullrequests(self, repository_id, pullrequest_id):
        self.connection = self._authentication()
        project = self._get_project_by_name()
        git_client_base = self.connection.get_client(GIT_CLIENT_BASE)
        pullrequest_data=git_client_base.get_pull_request(repository_id,pullrequest_id, project,include_work_item_refs=True)
        work_items=pullrequest_data.work_item_refs
        work_items_list=[]
        for workitem in work_items:
            work_items_list.append(workitem.id)
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        docsam = []
        wid_list=[]
        for test_cases in work_items_list:
            fv={"Microsoft.VSTS.TCM.AutomatedTestName":"TC-"+test_cases+"", "Microsoft.VSTS.TCM.AutomatedTestStorage": ""+repository_id+"", "Microsoft.VSTS.TCM.AutomatedTestType": "Scripts"}
            for field in fv.keys():
                value = fv[field]
                print("Updating field {} with value {}".format(field,value))
                vstspath = "/fields/" + field
                tmp = {"op":"add", "path":vstspath, "from": "null", "value": value}
                docsam.append(tmp)
            wid=work_item_tracking_client.update_work_item(docsam,test_cases, expand='Fields')
            wid_list.append(wid)
            docsam.clear() ## clearing the list so that new test cases model can be created
        if wid_list !=[]:
            return 'True'
        else:
            return 'False'

    def _get_config_from_runid(self, runid):
        self.connection = self._authentication()
        project = self._get_project_by_name()
        test_client = self.connection.clients.get_test_client()
        results= test_client.get_test_results(project, runid, top=None)
        test_results=[]
        for result in results:
            test_results.append(result.configuration.id)
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        conf=test_plan_client.get_test_configuration_by_id(project, result.configuration.id)
        conf_dict={}
        for val in conf.values:
            conf_dict.update({val.name:val.value})
        return conf_dict

    def _get_test_cases_by_suiteid(self, planid, suiteid):
        """ This keyword gets the test cases list for provided `planid` and `suiteid` for project RnD
        This takes mandatory argument `planid` and `suiteid`
        This keyword return the test case ids list; eg:['TC1628825', 'TC1628826']
        """
        test_results = []
        self.connection = self._authentication()
        project = self._get_project_by_name()
        test_client = self.connection.get_client(TEST_CLIENT)
        suiteid_list = suiteid.split(',')

        #Handling single and multiple suiteid for the given tplanid
        for suite in suiteid_list:
            results = test_client.get_test_cases(project, planid, suite)
            test_results.extend(['TC'+res.test_case.id for res in results])

        return test_results

    def _get_work_item_title_by_itemid(self, itemid):
        """ This keyword gets the Work_item title from the provided `itemid` for project RnD
        This takes mandatory argument `itemid`
        This keyword return the work_item/test_case title
        """
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        wi = work_item_tracking_client.get_work_item(itemid)
        return wi.fields['System.Title']

    def _get_work_item_state_by_itemid(self, itemid):
        """ This keyword gets the Work_item state from the provided `itemid` for project RnD
        This takes mandatory argument `itemid`
        This keyword return the work_item/test_case title
        """
        self.connection = self._authentication()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        wi = work_item_tracking_client.get_work_item(itemid)
        return wi.fields['System.State']

    def _parse_clet_log(self,log_file_path):
        try:
            with open('{}/TestReport.csv'.format(log_file_path), 'r') as fh:
                lines = fh.readlines()
                fh.seek(0)
                content = fh.read()

        except Exception as e:
            self._logger().exception(e)
            raise Exception(e)

        pass_num = len(re.findall('PASS',content))
        fail_num = len(re.findall('FAIL',content))
        tot_num = pass_num + fail_num

        final_list = []
        for line in lines[1:]:
            TCID, res = line.strip('\n').split(',')
            outcome = 'Passed' if res == 'PASS' else 'Failed'
            output_dict = {TCID: outcome}
            final_list.append(output_dict)
        return final_list, tot_num, pass_num, fail_num, 0, '00:00:00'

    def _parse_tag_file(self, file, delimiter='    '):
        if not os.path.isfile(file):
            raise Exception('%s is not a valid tag file'% file)
        with open(file,'r') as fh:
            content = fh.readlines()
        bug_tc_list = [line.strip().split(delimiter) for line in content]
        return bug_tc_list

    def create_testsuite_url_by_testcase_id(self, tc_id, suiteid):
        self.connection = self._authentication()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        testsuites = test_plan_client.get_suites_by_test_case_id(tc_id)

        if not isinstance(suiteid, list):
            suiteid = suiteid.split(',')

        suiteid = [int(suit) for suit in suiteid]
        for suite in testsuites:
            if suite.id in suiteid:
                return 'https://dev.azure.com/itron/%s/_testPlans/define?planId=%s&suiteId=%s'%(suite.project.name,suite.plan.id,suite.id)

if __name__ == 'kaizenbot.azurelibrary':
    azurelibrary = AzureLibrary
