# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from .server import Server, CIFSServer
from .servercache import ServerCache
from .logging_robot import Loggers
import glob,os
from platform import system
gen5 = ServerCache()

class Connection:
    def __init__(self):
        self.logger = None
    
    def _logger(self):
        if not self.logger:
            self.logger = Loggers().get_logger('KaizenBot-Connection')
        return self.logger
    
    def connect_to_server(self, ip, username, password, alias = None, timeout = None, port = 22, key_file = None): 
        """
        This opens connection and logs in to server ``ip``.
        
        This returns the index on success.
        Which can be used as a server handle in subsequent keywords.
        
        | ${mysystem}=        | `Connect To Server`  | localhost | test | test |
        | `Switch Connection` | ${mysystem}          |
        
        Using ``alias`` option, an alias can be given to the server 
        which can be used in subsequent keywords.

        | `Connect To Server` | localhost | test | test | mysystem |
        | `Switch Connection` | mysystem  |
        
        Using option ``timeout``, a timeout (in seconds) can be provided for the TCP connect.
        
        The most suitable use of this keyword is in suite and test setup. 
        
        """
        try: 
            self._logger().info("Establishing connection with Server")        
            serv = Server(server_ip = ip, server_username = username, server_password = password, server_alias=alias, timeout = timeout, port=port, key_file=key_file)
            self._logger().info("Connected to Server {}".format(ip))
        except Exception as e:
            self._logger().exception(e)
            self._logger().exception("Connection to Server {} Failed".format(ip))
            raise Exception("Connection to Server {} Failed".format(ip))
        else:
            index = gen5.register(serv, alias)
            self._logger().info("Index of connected server: {}".format(index))
            return index
    
    def get_os_name(self):
        """This returns the os name (either 'nt' or 'posix') of the server.
        """
        return gen5.current._get_os_name()
            
    def execute_command(self, command,timeout=300, BackgroundRun=False, OutputFile=None, codec=None):
        """This executes command ``command`` on server.
        
        This takes 1 mandatory argument ``command``.
        
        This takes 4 optional arguments ``timeout``, ``BackgroundRun``, ``OutputFile`` and ``codec``.
        
        ``timeout`` is set to 300 seconds by default for command to execute.
        
        ``BackgroundRun`` is set to ``False`` by default and user and set it to ``True`` 
        if user wants to run any commands in background and output file will be generated 
        in the path provided in argument ``OutputFile`` or else it will not generate in any
        output file.
        ``codec`` is for decoding the byte string. eg:- codec='latin-1'
        """
        self._logger().info("Executing command --> {}".format(command))
        return gen5.current._execute_command(command,timeout,BackgroundRun,OutputFile) if not codec else gen5.current._execute_command(command,timeout,BackgroundRun,OutputFile,codec)
    
    def open_interactive_shell(self):
        """This opens an interactive shell on the server.
        It returns an interactive shell handle which can be passed in keywords 
        `Send Data To Interactive Shell` and `Receive Data From Interactive Shell`
        """
        return interactiveShell()
    
    def send_data_to_interactive_shell(self, sh_handle, data):
        """This keyword sends the ``data`` to stdin of interactive shell.
        """
        sh_handle.send(data)
        
    def receive_data_from_interactive_shell(self, sh_handle, timeout = 60.0): 
        """This returns the stdout of the interactive shell.
        ``timeout`` is a float value in seconds to wait for output to be produced.
        Default ``timeout`` is 60.0.
        """
        return sh_handle.recv(float(timeout))   
    
    def list_directory(self, dir, pattern = None):
        """This returns all the files and directories as python list in the directory ``dir`` on server.
        if ``pattern`` is given, list only of directories and files matching the pattern is returned.
        
        Note: Directory name ``dir`` is prefixed to all the files and directories. 
        ``It is supportable on unix server only.``
        """
        return gen5.current.list_dir(dir, None, pattern)
    
    def list_directories_in_directory(self, dir, pattern = None):
        """This returns all directories as python list in the directory ``dir`` on server.
        if ``pattern`` is given, list only of directories matching the pattern is returned.
        
        Note: Directory name ``dir`` is prefixed to all the directories.
        ``It is supportable on unix server only.``
        """
        return gen5.current.list_dir(dir, 'd', pattern)
    
    def list_files_in_directory(self, dir, pattern = None):
        """This returns all the files as python list in the directory ``dir`` on server.
        if ``pattern`` is given, list only of files matching the pattern is returned.
        
        Note: Directory name ``dir`` is prefixed to all the files.
        ``It is supportable on unix server only.``
        """
        return gen5.current.list_dir(dir, 'f', pattern)
    
    def put_file(self, file, remote_dest):
        """It copies the file ``file`` from local to ``remote_dest`` on remote machine/server.
        """
        gen5.current._put_file(file, remote_dest)
        
    def get_file(self, file, local_dest = None):
        """It copies the file ``file`` from remote machine/server to ``local_dest`` on local machine.
        If ``local_dest`` is not provided,``file`` is copied in current directory with the same name as in the remote machine.
        """
        gen5.current._get_file(file, local_dest)
     
    def connect_to_cifs_server(self,username, password, my_name, server_name, server_ip, domain=''):
        """This opens connection with CIFS (windows shared machine) server and returns an instance of CIFSServer.
        
        ``username`` and ``password`` are the username and password of your machine which has access to CIFS server machine.
        ``my_name`` is an alias to your machine.
        ``server_name`` is the computer name of the CIFS server.
        ``server_ip`` is the ip address of CIFS server machine.
        ``domain`` is the domain of CIFS server machine.
        
        Example:
        
        | Connect To CIFS Server | test | test | mymachine | ocn-vm-rnd1 | 10.137.160.3 |
        
        """
        return CIFSServer(username, password, my_name, server_name, server_ip, domain)
           
    def get_file_from_cifs(self,cifs_obj, service_name, source_file, local_dest_dir = None):
        """It copies the file ``source_file`` from CIFS (windows shared machine) server to ``local_dest_dir`` on local machine.
        ``cifs_obj`` is an instance of CIFSServer. It is usually the return value of `Connect To CIFS Server`.
        ``service_name`` is CIFS server's shared folder.
        if ``local_dest_dir`` does not exist it will create the ``local_dest_dir``.
        If ``local_dest_dir`` is not provided, a temporary directory will be created 
        and file will be copied with the same name as in the CIFS server.
        
        This return the absolute path of the destination file
        Example:
        
        |   = Keyword =        | = cifs_obj =  | = service_name =  | = source_file =            | = local_dest_dir =    |
        | `Get File From CIFS` | ${cifs_obj}   |  cpe              | \\jkatkuri\\GEN5\\test.txt | \\home\\user\\mydir\\ |
        | `Get File From CIFS` | ${cifs_obj}   |  cpe              | \\jkatkuri\\GEN5\\test.txt |                       |
        
        """
        if isinstance(cifs_obj, CIFSServer):
            return cifs_obj.get_file(service_name, source_file, local_dest_dir)
        else:
            self._logger().debug("cifs_obj is not an instance of CIFSServer")
            raise RuntimeError("cifs_obj is not an instance of CIFSServer")
     
    def close_cifs_server(self, cifs_obj):
        """This closes CIFS server.
        """        
        if isinstance(cifs_obj, CIFSServer):
            cifs_obj.close()
        else:
            self._logger().debug("cifs_obj is not an instance of CIFSServer")
            raise RuntimeError("cifs_obj is not an instance of CIFSServer")        
    
    def file_exists(self, file):
        """This keyword returns False if the ``file`` does not exist and True if ``file`` exist on the server connected.
        This keyword is supportable only on unix-based servers.
        """
        return gen5.current._file_exists(file)

    def file_should_exist(self, file):
        """This keyword fails if the ``file`` does not exist on the server connected.
        This keyword is supportable only on unix-based servers.
        """
        try:  
            if( not gen5.current._file_exists(file)):
                raise Exception("file '{}' does not exist".format(file))
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e)

    def directory_exists(self, dir):
        """This keyword returns False if the ``dir`` does not exist and True if ``dir`` exist on the server connected.
        This keyword is supportable only on unix-based servers.
        """
        return gen5.current._dir_exists(dir)
        
    def directory_should_exist(self, dir):
        """This keyword fails if the ``dir`` does not exist on the server connected.
        This keyword is supportable only on unix-based servers.
        """
        try:  
            if( not gen5.current._dir_exists(dir)):
                raise Exception("directory '{}' does not exist".format(dir))
        except Exception as e:
            self._logger().exception(e)
            raise RuntimeError(e) 
            
    def close_connection_to_server(self):
        """This closes current active connection to server.
        This keyword does not switch connection.
        
        To switch connection, `Switch Connection` must be used.
        """
        server_alias = gen5.current.server_alias
        if(not server_alias):
            self._logger().info("Closing current connection")
        else:
            self._logger().info("Closing current connection {}".format(server_alias))
        gen5.close_current()
        self._logger().info("Closed current connection")
        
    def switch_connection(self, alias_or_index):
        """This switches server connection to provided ``alias_or_index``
        It raises an error if no connection with the given index or alias found.
        """
        gen5.switch(alias_or_index)
        self._logger().info("switched connection to : {}".format(alias_or_index))
        
    def close_all_connections(self):
        """This closes all connections
        """
        gen5.close_all()
        self._logger().info("Closed all connections")
        
    def delete_files(self, file_path):
        '''delete the files'''
        self._logger().info(file_path)
        self._logger().info(os.path.basename(file_path))
        if(file_path):
            filepath= file_path+'/*'
            if(system() == 'Windows'):
                PATH = file_path+'\\'
            else:
                PATH = file_path+'/'
            if os.path.exists(file_path):
                self._logger().info('True')
            else:
                self._logger().info('False')
        list_of_files = glob.glob(filepath)
        self._logger().info(list_of_files)
        for file in list_of_files:
            self._logger().info(file)
            os.remove(file)

    def _get_sharepoint_sub_dir(self,to_vers):
        dir = "Shared Documents/Firmware Packages/"
        if "10.2" in to_vers:
            return dir + "Gen5 Riva Meter R1.2.1"
        elif "10.3" in to_vers:
            return dir + "Gen5 Riva Meter R1.3"
        elif "10.4" in to_vers:
            return dir + "Gen5 Riva Meter R1.3_500S"
        elif "10.5" in to_vers:
            return dir + "Gen5 Riva Meter R3.1"
        else:
            return dir + "Gen5 Riva Meter R1.3"

    def get_fwu_diff_build(self, user, pswd, diff_version, dest_location=None):
        """
        This keyword will fetch the desired fwu diff file from the FWU sharepoint into the user defined location [on a windows machine] for automatic Firmware Upgrade with inputs provided.

        It takes four mandatory Arguments ``user``, ``pswd``, ``diff_version``, ``dest_location`` are given next to the keyword.
        So that the required diff upgrade file will be fetched from sharepoint and will be placed in the desired destination folder in the remote machine using these values.
        If the required .fwu file is found, it will display message as "Diff Build FOUND" and will return BuildFile_Name.
        If the required .fwu file is not found, it will display message as "Diff Build NOTFOUND" and will return -1.

        ``user``            - Sharepoint user name to login into FWU sharepoint
        ``pswd``            - Sharepoint password to login into FWU sharepoint
        ``diff_version``    - Specify the versions to upgrade (from and to, seperated using '-').
                              Sample Format: 10.4.558.3-10.4.559.1
        ``dest_location``   - Specify the destination folder on the remote machine where the fwu file has to be downloaded. If no destination location is given, by default the downloaded file will be stored in the path: C:/Users/<userid>/ directory if this path is present on the remote machine.

        = Example: =
        |       = Keyword =        |            = user =             |        = pswd =       |   = diff_version =    |              = dest_location =           |
        |  `Get Fwu Diff Build`    | <sharepoint_username>@itron.com | <sharepoint_password> | 10.4.558.3-10.4.559.1 | C:/KAIZENBOT_DIFF_UPGRADE_FWU/diff/Build |

        """
        import re
        from shareplum import Site, Office365
        from shareplum.site import Version
        from_vers, to_vers = diff_version.split('-')
        sub_dir = self._get_sharepoint_sub_dir(to_vers)
        dest = dest_location if dest_location else os.getenv('USERPROFILE')
        authcookie = Office365("https://itron.sharepoint.com", username=user, password=pswd).GetCookies()
        auth_site = Site("https://itron.sharepoint.com/sites/GFW-IVV/", version=Version.v365, authcookie=authcookie)
        sharepoint_dir = "/".join([sub_dir, "Unapproved"])
        _folder = auth_site.Folder(sharepoint_dir)
        buildpath = None
        for listitems in _folder.files:
            for key, value in listitems.items():
                if (key == 'Name') and (diff_version in str(value) and ('Dev' in str(value))):
                    if (re.search('^FWDL', value) != None) and (re.search('fwu$', value) != None):
                        buildpath = value
                        break
            if buildpath != None:
                break
        if buildpath != None:
            buildname = ''.join(buildpath.split("/")[-1])
            file = _folder.get_file(buildname)
            buildname = os.path.join(dest, buildname)
            print("Diff Build FOUND")
            with open(buildname, 'wb') as f:
                f.write(file)
                f.close()
            return buildname
        else:
            print("Diff Build NOTFOUND")
            return -1

    def get_dm_pmr_diff_build(self, sharepoint_user, sharepoint_pswd, diff_version, dest_location=None):
        from shareplum import Site, Office365
        from shareplum.site import Version
        sharepoint_dir = "Shared Documents/Development/OTA/"
        default_location=os.getenv('USERPROFILE') if system() == 'Windows' else os.getenv('HOME')
        dest = dest_location if dest_location else default_location
        authcookie = Office365("https://itron.sharepoint.com", username=sharepoint_user, password=sharepoint_pswd).GetCookies()
        auth_site = Site("https://itron.sharepoint.com/sites/DualMeshSBR-PMR/", version=Version.v365, authcookie=authcookie)
        _folder = auth_site.Folder(sharepoint_dir)
        final_folder = list(filter(lambda x: diff_version in x, _folder.folders))[0]
        _final_folder = auth_site.Folder(sharepoint_dir+final_folder)
        all_files=[x['Name'] for x in _final_folder.files]
        for fname in all_files:
            fullpath = os.path.join(dest, fname)
            content = _final_folder.get_file(file_name=fname)
            with open(fullpath, 'wb') as f:
                f.write(content)
        return all_files


import time
class interactiveShell:
    def __init__(self):
        self.chan = gen5.current._invoke_shell()
        
    def __del__(self):
        self.chan.close()
        
    def send(self, command):
        if command[-1] != '\n':
            command += '\n'
            
        self.chan.send(command) 
        
    def recv(self, timeout=60.0):
        time_elapsed = 0.0
        while(not self.chan.recv_ready() and time_elapsed < float(timeout)):
            time.sleep(0.1)
            time_elapsed += 0.1
            
        output = ''
        while self.chan.recv_ready():
            data = self.chan.recv(1024)   
            output += data.decode()
        return output


if __name__ == 'kaizenbot.connection':
    connection = Connection
