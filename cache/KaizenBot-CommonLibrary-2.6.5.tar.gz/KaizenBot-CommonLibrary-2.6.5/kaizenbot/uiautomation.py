# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential
  information, ideas and expressions. No part of which may be reproduced or
  transmitted in any form or by any means electronic, mechanical, or otherwise.
  Including photocopying and recording or in connection with any information
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""
import os
import time

from pywinauto import mouse
from pywinauto.timings import wait_until
from pywinauto.application import Application
from pywinauto.findwindows import ElementNotFoundError
from pywinauto.keyboard import send_keys
from robot.api import logger

app = None
FDM_WINDOW_TITLE = "Field Deployment Manager"
FDM_PASSWORD = "0p3nw@y"

#'EXE_PATH': os.path.join(os.environ.get('USERPROFILE'),'AppData\Local\Programs\Itron', 'Field Deployment Manager\Mobile Client\Fdm.exe').replace("\\", "/"),
application_info = {'fdm': {
    'WINDOW_TITLE': "Field Deployment Manager",
    'EXE_PATH': os.path.join('C:\Program Files (x86)\Itron\Field Deployment Manager\Mobile Client\Fdm.exe').replace("\\", "/"),
    'USER_NAME': 'QaFDMDev',
    'PASSWORD': "0p3nw@y",
    'MAIN_MENU_ELEMENT': "Tools"}}


class UIAutomation:
    """Documentation for library ``kaizenbot.uiautomation``.

    UIAutomation Module has to be imported explicitly on the Test Suite setting as a Library Import.
    """
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    ROBOT_LIBRARY_VERSION = 1.0

    def __init__(self):
        self.app = None
        self.app2 = None
        self.appl = None
        self.title = None
        self.exe = None
        self.username = None
        self.password = None

    def _gui_launch(self):
        try:
            self.app = Application().connect(title=self.title)
            self.app.top_window().set_focus()
        except ElementNotFoundError:
            self.app = Application(backend="uia").start(self.exe)
            time.sleep(10)
            self.app = Application().connect(title=self.title)
            if self.app.is_process_running():
                logger.info("{} has launched Successfully".format(self.appl.upper()))
            self.mouse_action('click', 'OK') if self.appl.lower() == 'fdm' else None
        except Exception as e:
            self.app.kill()
            logger.error(e)
            raise Exception(e)
        return self.app

    @staticmethod
    def _get_element_obj(app, **kwargs):
        try:
            window = app['WindowsForms10.Window.8.app.0.189441b_r11_ad1']
        except Exception as e:
            print(e)
        else:
            return window.child_window(**kwargs)

    @staticmethod
    def _wait_until_element_found(app, retry, interval, **kwargs):
        starttime = time.time()
        timepassed = 0
        while not UIAutomation._get_element_obj(app, **kwargs).exists() and timepassed < retry:
            time.sleep(interval - 1)
            timepassed = time.time() - starttime
        try:
            print('total wait time in secs: {}'.format(timepassed))
            if not UIAutomation._get_element_obj(app, **kwargs).exists():
                raise ElementNotFoundError
        except Exception as e:
            print(e)
            raise Exception(e)
        if timepassed > retry:
            raise Exception("{} element wrapper not found in allotted time {}".format(kwargs, retry))

    def mouse_action(self, action, element=None, auto_id=None, coords=None):
        """This will do mouse functionality like left-mouse click, double-click etc., and it is useful in UI automation.

        This takes 1 mandatory arguments ``action``
        This takes 3 optional arguments ``element``, ``auto_id`` and ``coords``

        Default ``element`` is None
        Default ``auto_id`` is None
        Default ``coords`` is None

        If ``coords`` is provided, mouse will perform click() on the given x,y co-ordinates .
        If `element` will be mandatory if ``coords`` not given.

        return value: this command has no return value but action
        return type: NoneType

        Example:

        | = Keyword =     | = action =  |       = element =        | = auto_id =    |  = coords =    | = comments =   |
        | `Mouse Action`  |   click     | 01. Device Control Panel |                |                |                |
        | `Mouse Action`  |   click     |           TCP            | TCPRadioButton |                |                |
        | `Mouse Action`  |   click     |     coords=197:217       |                |                |                |

        """
        self.app.top_window().set_focus()
        logger.debug(action)
        logger.debug(element)
        logger.debug(coords)
        if not coords and not element:
            logger.info('element parameter is must when coord is not pass as an argument')
            raise Exception('element parameter is must when coord is not pass as an argument')
        if action == 'click' and not coords:
            opt = UIAutomation._get_element_obj(self.app, title=element,
                                                auto_id=auto_id) if auto_id else UIAutomation._get_element_obj(self.app, best_match=element)
            opt.click_input()
        elif action == 'click' and coords:
            x, y = coords.split(':')
            mouse.click(coords=(int(x), int(y)))
        else:
            logger.info('Mouse action: {} is not implemented'.format(action))
            raise NotImplementedError

    def keyboard_action(self, action, element, value=None):
        """This will do keyboard functionality like typing, Enter, Tab, UP, DOWN etc.,and it is useful in UI automation.

        This takes 2 mandatory arguments ``action`` and ``element``
        This takes 1 optional argument ``value``

        Default ``value`` is None, value also means no. of times the key to be pressed if action is send_keys

        return value: this command has no return value but action
        return type: NoneType

        Example:

        |   = Keyword =     | = action =  |  = element =        |  = Value =  | = comments =   |
        | `Keyboard Action` |   type      |  _UserNameTextBox   |    root     |                |
        | `Keyboard Action` |  send_keys  |       DOWN          |      4      |                |
        | `Keyboard Action` |  send_keys  |       ENTER         |             |                |

        """
        self.app.top_window().set_focus()
        if action == 'type':
            opt = UIAutomation._get_element_obj(self.app, auto_id=element)
            opt.set_edit_text('')
            opt.type_keys(value)
        elif action == 'send_keys':
            send_keys('{' + '{} {}'.format(element, value) + '}') if value else send_keys(
                '{' + '{}'.format(element) + '}')
            time.sleep(2)
        elif action == 'HwndWrapper':
            opt = self.app.active()
            dlg = opt.child_window(class_name_re=u'HwndWrapper')
            dlg.send_keystrokes(element)
        else:
            logger.info('Keyboard action: {} is not implemented'.format(action))
            raise NotImplementedError

    def fdm_server_config(self, host, port, domain):
        """This will configure FDM server before logging in.

        This takes 3 mandatory arguments ``host`` , ``port`` and ``domain``

        return value: this command has no return value but action
        return type: NoneType

        Example:

        |   = Keyword =       |             = host =         |  = port =  |  = domain =   |
        | `Fdm Server Config` |  ral-riva-fdm.itronhdc.com   |    8731    |  ral-riva-fdm |

        """
        try:
            if not self.app.is_process_running():
                logger.info('app not running')
                raise Exception('app not running')
            self.app.top_window().set_focus()
            self.mouse_action('click', 'Server')
            self.keyboard_action('type', 'HostTextBox', host)
            self.keyboard_action('type', 'DomainTextBox', domain)
            self.mouse_action('click', 'OK')
        except Exception as e:
            logger.error(e)
            raise Exception(e)

    def fdm_login(self, username, password):
        """This will login to FDM using given credential.

        This takes 2 mandatory arguments ``username``  and ``password``

        return value: this command will return "Login successful" message
        return type: String

        Example:

        | = Keyword =   |  = username = |  = password =  |
        | `Fdm Login`   |    QaFDMDev   |    0p3nw@y     |

        """
        try:
            if not self.app.is_process_running():
                logger.info('app not running')
                raise Exception('app not running')
            self.app.top_window().set_focus()
            obj_attr = self.app.__getattribute__(''.join(self.title.strip().split(' ')).upper())
            self.keyboard_action('type', '_UserNameTextBox', username)
            self.keyboard_action('type', '_PasswordTextBox', password)
            self.mouse_action('click', 'OK')
            obj_attr.maximize()
            if application_info[self.appl.lower()].get('MAIN_MENU_ELEMENT'):
                logger.info('Sync in progress')
                logger.info('Waiting for Main Menu Element!')
                UIAutomation._wait_until_element_found(self.app, retry=300, interval=10,
                                                       best_match=application_info[self.appl.lower()]['MAIN_MENU_ELEMENT'])
                return 'Login successful and Sync completed'
        except Exception as e:
            logger.error(e)
            raise Exception(e)

    def fdm_maximize(self):
        """This will Maximize the FDM Window .

        Example:

        | = Keyword =      |
        | `Fdm Maximize`   |

        """
        try:
            if not self.app.is_process_running():
                logger.info('app not running')
                raise Exception('app not running')
            self.app.top_window().set_focus()
            obj_attr = self.app.__getattribute__(''.join(self.title.strip().split(' ')).upper())
            obj_attr.restore()
            obj_attr.maximize()

        except Exception as e:
            logger.error(e)
            raise Exception(e)

    def connect_to_gui(self, appl):
        """This keyword will launch any of the window application provided application_info dictionary has to
        updated with necessary information.

        This takes 1 mandatory argument ``appl`` which denotes your application name
        Note: Dict application_info has only FDM information hence it has only FDM support currently.

        return value: this command will return "Login successful" message
        return type: String

        Example:

        | = Keyword =       |  = appl =     |        = comments =             |
        | `Connect To Gui`  |    FDM        |    this will launch FDM app     |
        | `Connect To Gui`  |    Notepad    |    this will launch Notepad app |

        """
        try:
            self.appl = appl
            self.title = application_info[self.appl.lower()]['WINDOW_TITLE']
            self.exe = application_info[self.appl.lower()]['EXE_PATH']
            self.username = application_info[self.appl.lower()]['USER_NAME']
            self.password = application_info[self.appl.lower()]['PASSWORD']
            self.app = self._gui_launch()
        except Exception as e:
            self.app.kill()
            logger.error('Exception on {} UIAutomation'.format(self.appl))
            raise Exception(e)
        logger.info("{} Launched Successfully".format(self.appl.upper()))
        return self.app

    def fdm_connect_to_meter_via_ip(self, meter_ip):
        """This keyword will login to the meter using given ipv4 address.

        This takes 1 mandatory argument ``meter_ip``

        return value: this command will return "success" message
        return type: String

        Example:

        | = Keyword =                    |  = meter_ip =    |  = comments =  |
        | `Fdm Connect To Meter Via Ip`  |    192.168.2.5   |                |
        | `Fdm Connect To Meter Via Ip`  |    ${node1_ip}   |                |

        """
        try:
            if not self.app.is_process_running():
                logger.info('app not running')
                raise Exception('app not running')
            self.app.top_window().set_focus()
            UIAutomation._wait_until_element_found(self.app, retry=30, interval=5, title='Use Hosted WiFi Connection')
            self.mouse_action('click', 'TCP', 'TCPRadioButton')
            self.keyboard_action('type', 'SocketAddressTextBox', meter_ip)
            self.mouse_action('click', 'Next')
            UIAutomation._wait_until_element_found(self.app, retry=30, interval=5, title_re=r'ESN*')
            if not UIAutomation._get_element_obj(self.app, title_re=r'ESN*').exists():
                logger.error('Login to meter failed')
                raise ElementNotFoundError
            logger.info('success')
        except Exception as e:
            logger.error(e)
            raise Exception(e)

    def fdm_verify_content(self, content, wait_element=None, retry=300, interval=5):
        """This keyword will validate the final result on the FDM window.

        This takes 1 mandatory argument ``content`` is the search content to verify
        This takes 3 optional arguments ``wait_element``, ``retry`` and ``interval``

        Default ``wait_element`` is None, if enabled it will wait till the element found until the ``retry`` duration
        Default ``retry`` is 300 secs
        Default ``interval`` is 5 secs

        return value: this command will return full matching string which matches the ``content`` parameter.
        return type: String

        Example:

        | = Keyword =           |      = content =          |  = wait_element =     |  = retry =  |  = interval =  |  = comments =  |
        | `Fdm Verify Content`  |  successfully downloaded  |       Finish          |             |                |                |
        | `Fdm Verify Content`  |activation process started |       Finish          |             |                |                |

        """
        try:
            if wait_element:
                UIAutomation._wait_until_element_found(self.app, retry=retry, interval=interval, title=wait_element)
            opt = UIAutomation._get_element_obj(self.app, title_re='{}*'.format(content))
            output = opt.window_text()
        except Exception as e:
            logger.error(e)
            raise Exception(e)
        else:
            return output

    def close_application(self):
        """This keyword will disconnect the session created by ``connect_to_gui`` method and close the program.

        return value: this command will return "true" if successfully closed the session else "false"
        return type: String

        Example:

        | = Keyword =          |          = comments =                |
        | `Close Application`  |  disconnects the application session |

        """
        try:
            self.app.kill()
            output = 'true' if not self.app.is_process_running() else 'false'
        except Exception as e:
            logger.error(e)
            raise Exception(e)
        else:
            return output

    def select_different_window(self, window_title):
        """

        ``:param window_title``: title of the window to select a different window (in case the window is a pop-up)
        ``:return``: object of the selected ``window_title``
        """
        try:
            self.app2 = Application().connect(title_re=window_title)
            self.app2.top_window().set_focus()
        except ElementNotFoundError:
            self.app2 = Application(backend="uia").connect(title_re=window_title)
            if self.app2.is_process_running():
                logger.info("{} window has launched Successfully".format(self.app2.upper()))
        except Exception as e:
            self.app2.kill()
            logger.error(e)
            raise Exception(e)
        return self.app2

    def fdm_file_retrieval(self, fdm_file_path, local_dest_zip):
        """

        ``:param fdm_file_path``: file path to retrieve through FDM file Retrieval
        ``:param local_dest_zip``: absolute local file location to save the file retrieval zip file of the ``fdm_file_path`` to
        :return: None
        Note: The FDM should be in the inside the 'Distributed Intelligence->FileRetrieval' window for this keyword to work
        Example:
        | = Keyword =               |   = fdm_file_path =     |  = local_dest_zip =      |
        | `Fdm File Retrieval`  |  /mnt/common/database/  |  C:/Itron/FileRetrieval  |

        """
        import pyperclip
        fdm_paths_dict = {1: r'/.dvmeta/',
                          2: r'/mnt/common/database/',
                          3: r'/mnt/common/logs/',
                          4: r'/mnt/common/resourceCaddy/',
                          5: r'/mnt/pouch/',
                          6: r'/mnt/pouch/coredumps/',
                          7: r'/mnt/pouch/dsp_crashdump',
                          8: r'/mnt/pouch/KernelOOPs/',
                          9: r'/mnt/pouch/LifeBoatLogs/',
                          10: r'/mnt/pouch/threp',
                          11: r'/tmp/',
                          12: r'/tmp/InstaCapture',
                          13: r'/tmp/logs'}

        # Picking the key from value given in fdm_file_path
        num = tuple(fdm_paths_dict.values()).index(fdm_file_path)+1

        self.keyboard_action('send_keys', 'VK_HOME')
        for i in range(1, num+1):
            self.keyboard_action('send_keys', 'DOWN')
            self.select_different_window(r"Save As")
            if i == num:
                pyperclip.copy(local_dest_zip)
                self.app2.top_window().child_window(class_name="Edit")
                time.sleep(1)
                send_keys("^v")
                self.app2.top_window().child_window(title="&Save", class_name="Button").click_input()
                time.sleep(2)
                self.select_different_window(r"Confirm Save As")
                if self.app2.top_window().is_visible():
                    self.app2.top_window().child_window(title="&Yes", class_name="Button").click_input()
                time.sleep(20)  # waiting till zip file gets saved from FDM

            else:
                self.app2.top_window().child_window(title="Cancel", class_name="Button").click_input()
        return


uiautomation = UIAutomation
