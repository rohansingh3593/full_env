import psycopg2
from psycopg2 import sql
from sqlite3 import Error
from threading import RLock
import base64


class KBotDBServer:
    def __init__(self, pgdb=None, pguser=None, pgpswd=None, pghost=None, pgport=None):
        """ create a database connection to a SQLite database """
        self.conn = None
        self.curpg = None
        self.pgdb = base64.b64decode(pgdb).decode()
        self.pguser = base64.b64decode(pguser).decode()
        self.pgpswd = base64.b64decode(pgpswd).decode()
        self.pghost = pghost
        self.pgport = pgport
        self.connect()
        self.lock = RLock()
        self.shared_nodes = {}  # TYPE: DICT{str:int} {shared-node-ip:number of shared instances}
        self.shared_aps = {}  # TYPE: DICT{str:int} {shared-ap-ip:number of shared instances}

    def __del__(self):
        self.close()

    def _acquire_first_free_platform(self, schema, tester, project):
        query = '''SELECT platform_id
                   FROM %s.Platform
                   WHERE platform_busy = 'no' and project_name = '%s'
                ''' % (schema, project)
        self.lock.acquire()
        try:
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                return None, 'ALL'

            query = '''UPDATE %s.platform
                       SET platform_busy = 'yes', platform_owner = '%s', last_status_change = (SELECT now())
                       WHERE platform_id = '%s'
                    ''' % (schema, tester, data[0][0])

            self.runquery(query)

            query = '''SELECT platform_name
                       FROM %s.Platform
                       WHERE platform_id = '%s'
                    ''' % (schema, data[0][0])
            cursor = self.runquery(query)
            data = cursor.fetchall()
            return data[0][0], None
        finally:
            self.lock.release()

    def _all_nodes_with_attribute(self, schema, attr_name, attr_values):
        nodes = []
        for attrv in attr_values:
            query = '''SELECT NODE_IP
                       FROM %s.Node
                       WHERE %s = '%s' and node_status = 'active'
                    ''' % (schema, attr_name, attrv)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                raise RuntimeError("Node table has no value '%s' for attribute '%s'" % (attrv, attr_name))
            for node in data[0]:
                if node not in nodes:
                    nodes.append(node)
        return nodes

    def all_bpds_with_attribute(self, schema, attr_name, attr_values):
        bpds = []
        for attrv in attr_values:
            query = '''SELECT BPD_MAC
                       FROM %s.bpd
                       WHERE %s = '%s' and bpd_status = 'active'
                    ''' % (schema, attr_name, attrv)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                raise RuntimeError("bpd table has no value '%s' for attribute '%s'" % (attrv, attr_name))
            for bpd in data:
                if bpd not in bpds:
                    bpds.append(bpd)
        return bpds

    def _allot_nodes_with_limit(self, schema, platform, project, data, limit):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_node_cnt = self.total_nodes_in_platform(schema, plt_id)

        where_condt = sql.SQL(' OR '.join("%s = '%s'" % ('node_ip', v[0].strip()) for v in data[:limit]))
        query = sql.SQL("UPDATE {tab} SET node_busy = 'yes', "
                        "busy_change_count = busy_change_count + 1, "
                        "last_busy_change = (SELECT now()) "
                        "WHERE {condition}").format(tab=sql.SQL(schema + '.Node'), condition=where_condt)
        self.runquery(query)
        clm_names = self.column_names(schema, 'Node')

        alloted_nodes = self._get_alloted_nodes(schema, data)

        if len(alloted_nodes) == limit:
            nodes_data = [{column[0]: column[1] for column in zip(*[clm_names, list(val)])} for val in alloted_nodes]
            return nodes_data, ttl_node_cnt
        return None, ttl_node_cnt

    def _allot_bpds_with_limit(self, schema, platform, project, data, limit):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_bpd_cnt = self.total_bpds_in_platform(schema, plt_id)

        where_condt = sql.SQL(' OR '.join("%s = '%s'" % ('bpd_mac', v[0].strip()) for v in data[:limit]))
        query = sql.SQL("UPDATE {tab} SET bpd_busy = 'yes', "
                        "busy_change_count = busy_change_count + 1, "
                        "last_busy_change = (SELECT now()) "
                        "WHERE {condition}").format(tab=sql.SQL(schema + '.bpd'), condition=where_condt)
        self.runquery(query)
        clm_names = self.column_names(schema, 'bpd')
        alloted_bpds = self._get_alloted_bpds(schema, data)

        if len(alloted_bpds) == limit:
            bpds_data = [{column[0]: column[1] for column in zip(*[clm_names, list(val)])} for val in alloted_bpds]
            return bpds_data, ttl_bpd_cnt
        return None, ttl_bpd_cnt

    def _all_aps_with_attribute(self, schema, attr_name, attr_values):
        aps = []
        for attrv in attr_values:
            query = '''SELECT AP_IP
                       FROM %s.AP
                       WHERE %s = '%s' and ap_status = 'active'
                    ''' % (schema, attr_name, attrv)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                raise RuntimeError("AP table has no value '%s' for attribute '%s'" % (attrv, attr_name))
            for ap in data[0]:
                if ap not in aps:
                    aps.append(ap)
        return aps

    def _get_alloted_nodes(self, schema, data):
        get_lst_timestp_query = "SELECT last_busy_change FROM %s.Node WHERE node_ip = '%s'" % (schema, data[0][0])
        cursor = self.runquery(get_lst_timestp_query)
        lst_timestp = cursor.fetchall()

        all_data = "SELECT * FROM %s.Node WHERE last_busy_change = '%s'" % (schema, lst_timestp[0][0])
        cursor = self.runquery(all_data)
        return cursor.fetchall()

    def _get_alloted_bpds(self, schema, data):
        get_lst_timestp_query = "SELECT last_busy_change FROM %s.bpd WHERE bpd_mac = '%s'" % (schema, data[0][0])
        cursor = self.runquery(get_lst_timestp_query)
        lst_timestp = cursor.fetchall()

        all_data = "SELECT * FROM %s.bpd WHERE last_busy_change = '%s'" % (schema, lst_timestp[0][0])
        cursor = self.runquery(all_data)
        return cursor.fetchall()

    def _mark_ap_as_busy(self, schema, ip):
        cur_busy_count = self.get_current_count(schema, 'ap', ip)
        query = '''UPDATE %s.AP
                   SET ap_busy = 'yes', last_busy_change = (SELECT now())
                   WHERE ap_ip = '%s' and ap_status = 'active'
                ''' % (schema, ip)
        self.runquery(query)
        cur_busy_count = int(cur_busy_count)
        cur_busy_count += 1
        cur_busy_count = str(cur_busy_count)
        self.increment_busy_change_count(schema, 'ap', cur_busy_count, ip)
        return cur_busy_count

    def _mark_ap_as_shared(self, schema, ip):
        cur_busy_count = self.get_current_count(schema, 'ap', ip)
        query = '''UPDATE %s.AP
                   SET ap_busy = 'shared', last_busy_change = (SELECT now())
                   WHERE ap_ip = '%s' and ap_status = 'active'
                ''' % (schema, ip)
        self.runquery(query)
        self.shared_aps[ip] = self.shared_aps.get('%s' % ip, 0) + 1
        cur_busy_count = int(cur_busy_count)
        cur_busy_count += 1
        cur_busy_count = str(cur_busy_count)
        self.increment_busy_change_count(schema, 'ap', cur_busy_count, ip)
        return cur_busy_count

    def _mark_node_as_busy(self, schema, ip):
        cur_busy_count = self.get_current_count(schema, 'node', ip)
        query = '''UPDATE %s.Node
                   SET node_busy = 'yes', last_busy_change = (SELECT now())
                   WHERE node_ip = '%s' and node_status = 'active'
                ''' % (schema, ip)
        self.runquery(query)
        cur_busy_count = int(cur_busy_count)
        cur_busy_count += 1
        cur_busy_count = str(cur_busy_count)
        self.increment_busy_change_count(schema, 'node', cur_busy_count, ip)
        return cur_busy_count

    def _mark_bpd_as_busy(self, schema, mac):
        cur_busy_count = self.get_current_count(schema, 'bpd', mac)
        query = '''UPDATE %s.bpd
                   SET bpd_busy = 'yes', last_busy_change = (SELECT now())
                   WHERE bpd_mac = '%s' and bpd_status = 'active'
                ''' % (schema, mac)
        self.runquery(query)
        cur_busy_count = int(cur_busy_count)
        cur_busy_count += 1
        cur_busy_count = str(cur_busy_count)
        self.increment_busy_change_count(schema, 'bpd', cur_busy_count, mac)
        return cur_busy_count

    def _mark_node_as_shared(self, schema, ip):
        cur_busy_count = self.get_current_count(schema, 'node', ip)
        query = '''UPDATE %s.Node
                   SET node_busy = 'shared', last_busy_change = (SELECT now())
                   WHERE node_ip = '%s' and node_status = 'active'
                ''' % (schema, ip)
        self.runquery(query)
        self.shared_nodes[ip] = self.shared_nodes.get('%s' % ip, 0) + 1
        cur_busy_count = int(cur_busy_count)
        cur_busy_count += 1
        cur_busy_count = str(cur_busy_count)
        self.increment_busy_change_count(schema, 'node', cur_busy_count, ip)
        return cur_busy_count

    def _verify_singularity(self, data):
        if not (data and
                isinstance(data, list) and
                len(data) == 1 and
                data[0] and
                isinstance(data[0], tuple) and
                len(data[0]) == 1):
            return False
        return True

    def connect(self):
        try:
            self.conn = psycopg2.connect(database=self.pgdb, user=self.pguser, password=self.pgpswd,
                                         host=self.pghost, port=self.pgport)
            self.curpg = self.conn.cursor()
        except Error as e:
            print(e)
            raise

    def commit(self):
        if self.conn:
            self.conn.commit()

    def close(self):
        if self.conn:
            self.conn.close()
            self.curpg = None

    def runquery(self, query):
        try:
            # acquire lock here
            self.lock.acquire()
            self.curpg.execute(query)
            self.conn.commit()
            return self.curpg
        except psycopg2.DatabaseError as e:
            print('kbotdbserver_psql: Error %s' % e)
            raise e
        finally:
            # release lock here
            self.lock.release()

    '''def runscript(self, sql_file):
        if not os.path.isfile(sql_file):
            raise FileNotFoundError("file '%s' does not exist"%sql_file)

        with open(sql_file, 'r') as sf:
            script = sf.read()

        try:
            #acquire lock here
            self.lock.acquire()
            cursor = self.conn.executescript(script)
            self.commit()
            return cursor
        except psycopg2.OperationalError:
            raise
        finally:
            #release lock here
            self.lock.release()'''

    def acquire_platform(self, schema, platform, tester, project):
        if platform.upper() == 'ANY':
            return self._acquire_first_free_platform(schema, tester, project)

        plt_id = self.get_platform_id(schema, platform, project)
        if plt_id == 'NULL':
            raise Exception(
                "No platform '%s' exists under project '%s' on schemaname '%s'" % (platform, project, schema))
        if plt_id == 'AMBIGUOUS':
            raise Exception("Ambiguous platform definitions are found for platform '%s' and project '%s' on "
                            "schemaname '%s'" % (platform, project, schema))

        busy, owner = self.is_platform_busy(schema, plt_id)
        if busy:
            return None, owner
        query = '''UPDATE %s.platform
                   SET platform_busy = 'yes', platform_owner = '%s', last_status_change = (SELECT now())
                   WHERE platform_id = '%s'
                ''' % (schema, tester, plt_id)

        self.runquery(query)
        return platform, owner

    def allot_all_aps(self, schema, platform, project):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_ap_cnt = self.total_aps_in_platform(schema, plt_id)
        return self.allot_aps(schema, platform, project, ttl_ap_cnt)

    def _allot_all_nodes(self, schema, platform, project, data):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_node_cnt = self.total_nodes_in_platform(schema, plt_id)

        where_condt = sql.SQL(' OR '.join("%s = '%s'" % ('node_ip', v[0].strip()) for v in data))
        query = sql.SQL("UPDATE {tab} SET node_busy = 'yes', "
                        "busy_change_count = busy_change_count + 1, "
                        "last_busy_change = (SELECT now()) "
                        "WHERE {condition}").format(tab=sql.SQL(schema+'.Node'), condition=where_condt)
        self.runquery(query)
        clm_names = self.column_names(schema, 'Node')

        alloted_nodes = self._get_alloted_nodes(schema, data)

        if len(alloted_nodes) == len(data):
            nodes_data = [{column[0]: column[1] for column in zip(*[clm_names, list(val)])} for val in alloted_nodes]
            return nodes_data, ttl_node_cnt
        return None, ttl_node_cnt

    def allot_aps(self, schema, platform, project, num_of_aps):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_ap_cnt = self.total_aps_in_platform(schema, plt_id)
        if num_of_aps > ttl_ap_cnt:
            return None, ttl_ap_cnt
        self.lock.acquire()
        try:
            active_free_ap_cnt = self.free_aps_in_platform(schema, plt_id)
            if num_of_aps > active_free_ap_cnt:
                return None, ttl_ap_cnt

            query = '''SELECT AP_IP
                       FROM %s.AP
                       WHERE ap_busy = 'no' and platform_id = '%s'
                    ''' % (schema, plt_id)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            alloted_ap_cnt = 0
            aps_data = []
            clm_names = self.column_names(schema, 'AP')
            for i in range(len(data)):
                self._mark_ap_as_busy(schema, data[i][0])
                query = '''SELECT *
                           FROM %s.AP
                           WHERE ap_ip = '%s'
                        ''' % (schema, data[i][0])
                cursor = self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                aps_data.append(ap)
                alloted_ap_cnt += 1
                if alloted_ap_cnt == num_of_aps:
                    return aps_data, ttl_ap_cnt
        finally:
            self.lock.release()

    def allot_aps_with_attribute(self, schema, platform, project, attr_name, attr_values, lock):
        plt_id = self.get_platform_id(schema, platform, project)

        if not isinstance(attr_values, list):
            raise RuntimeError("attribute values must be a list type")

        self.lock.acquire()
        try:
            if attr_name.upper() != 'AP_IP':
                aps = self._all_aps_with_attribute(schema, attr_name, attr_values)
            else:
                aps = attr_values

            clm_names = self.column_names(schema, 'AP')
            aps_data = []
            for ap in aps:
                status = self.ap_busy(schema, ap)
                if status.lower() == 'yes' or (status.lower() == 'shared' and lock):
                    aps_marked = [ap['AP_IP'] for ap in aps_data]
                    self.free_aps(schema, platform, project, aps_marked)
                    aps_data = []
                    break

                if lock:
                    self._mark_ap_as_busy(schema, ap)
                else:
                    self._mark_ap_as_shared(schema, ap)

                query = '''SELECT *
                           FROM %s.AP
                           WHERE ap_ip = '%s'
                        ''' % (schema, ap)
                cursor = self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                aps_data.append(ap)
            return aps_data
        finally:
            self.lock.release()

    def allot_nodes(self, schema, platform, project, num_of_nodes, node_type=None):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_node_cnt = self.total_nodes_in_platform(schema, plt_id)

        if num_of_nodes > ttl_node_cnt:
            return None, ttl_node_cnt
        self.lock.acquire()
        try:
            active_free_nodes_cnt = self.free_nodes_in_platform(schema, plt_id, node_type)
            if num_of_nodes > active_free_nodes_cnt:
                return None, ttl_node_cnt

            if not node_type:
                query = '''SELECT NODE_IP
                           FROM %s.Node
                           WHERE node_busy = 'no' and platform_id = '%s' and node_status = 'active'
                        ''' % (schema, plt_id)
            else:
                query = '''SELECT NODE_IP
                           FROM %s.Node
                           WHERE node_busy = 'no' and platform_id = '%s' and node_device_type = %s
                           and node_status = 'active'
                        ''' % (schema, plt_id, node_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            alloted_node_cnt = 0
            nodes_data = []
            clm_names = self.column_names(schema, 'Node')

            '''request to allot all the nodes will go for bulk allocation to reduce time complexity'''
            if num_of_nodes == len(data):
                return self._allot_all_nodes(schema, platform, project, data)

            '''request to allot more than one node will go for bulk allocation to reduce time complexity'''
            if num_of_nodes > 1:
                return self._allot_nodes_with_limit(schema, platform, project, data, limit=num_of_nodes)

            for i in range(len(data)):
                self._mark_node_as_busy(schema, data[i][0])
                query = '''SELECT *
                           FROM %s.Node
                           WHERE node_ip = '%s'
                        ''' % (schema, data[i][0])
                cursor = self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                nodes_data.append(node)
                alloted_node_cnt += 1
                if alloted_node_cnt == num_of_nodes:
                    return nodes_data, ttl_node_cnt
        finally:
            self.lock.release()

    def allot_bpds(self, schema, platform, project, num_of_bpds, bpd_type):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_bpd_cnt = self.total_bpds_in_platform(schema, plt_id)

        if num_of_bpds > ttl_bpd_cnt:
            return None, ttl_bpd_cnt
        self.lock.acquire()
        try:
            active_free_bpds_cnt = self.free_bpds_in_platform(schema, plt_id, bpd_type)
            if num_of_bpds > active_free_bpds_cnt:
                msg = "Platform '%s' has %d free %s bpds but requested %d bpds" % (
                platform, active_free_bpds_cnt, bpd_type, num_of_bpds)
                raise RuntimeError(msg)

            if not bpd_type:
                query = '''SELECT BPD_MAC
                           FROM %s.bpd
                           WHERE bpd_busy = 'no' and platform_id = '%s' and bpd_status = 'active'
                        ''' % (schema, plt_id)
            else:
                query = '''SELECT BPD_MAC
                           FROM %s.bpd
                           WHERE bpd_busy = 'no' and platform_id = '%s' and bpd_type = '%s'
                           and bpd_status = 'active'
                        ''' % (schema, plt_id, bpd_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            '''request to allot bpds bulk allocation to reduce time complexity'''
            if num_of_bpds > 0:
                return self._allot_bpds_with_limit(schema, platform, project, data, limit=num_of_bpds)
        finally:
            self.lock.release()

    def allot_nodes_with_attribute(self, schema, platform, project, attr_name, attr_values, lock):
        plt_id = self.get_platform_id(schema, platform, project)

        if not isinstance(attr_values, list):
            raise RuntimeError("attribute values must be a list type")

        self.lock.acquire()
        try:
            if attr_name.upper() != 'NODE_IP':
                nodes = self._all_nodes_with_attribute(schema, attr_name, attr_values)
            else:
                nodes = attr_values

            clm_names = self.column_names(schema, 'Node')
            nodes_data = []
            for node in nodes:
                if not self.is_node_exitsin_platform(schema, node, plt_id):
                    raise RuntimeError("This node '%s' does not belong to platform '%s'" % (node, platform))
                status = self.node_busy(schema, node)
                if status.lower() == 'yes' or (status.lower() == 'shared' and lock):
                    nodes_marked = [node['NODE_IP'] for node in nodes_data]
                    self.free_nodes(platform, project, nodes_marked)
                    nodes_data = []
                    break

                if lock:
                    self._mark_node_as_busy(schema, node)
                else:
                    self._mark_node_as_shared(schema, node)

                query = '''SELECT *
                           FROM %s.Node
                           WHERE node_ip = '%s'
                        ''' % (schema, node)
                cursor = self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                nodes_data.append(node)
            return nodes_data
        finally:
            self.lock.release()

    def allot_bpds_with_attribute(self, schema, platform, project, attr_name, attr_values, lock=True):
        """
        Under Construction
        """
        plt_id = self.get_platform_id(schema, platform, project)

        if not isinstance(attr_values, list):
            raise RuntimeError("attribute values must be a list type")

        self.lock.acquire()
        try:
            if attr_name.upper() != 'BPD_MAC':
                bpds = self.all_bpds_with_attribute(schema, attr_name, attr_values)
            else:
                bpds = attr_values

            clm_names = self.column_names(schema, 'Bpd')
            bpds_data = []
            for bpd_mac in bpds:
                if not self.is_bpd_exitsin_platform(schema, bpd_mac, plt_id):
                    raise RuntimeError("This bpd '%s' does not belong to platform '%s'" % (bpd_mac, platform))
                status = self.get_bpd_busy_status(schema, bpd_mac)

                if status.lower() == 'yes':
                    self.free_bpds(schema, platform, project, [bpd_mac])

                self._mark_bpd_as_busy(schema, bpd_mac)
                query = '''SELECT *
                           FROM %s.bpd
                           WHERE bpd_mac = '%s'
                        ''' % (schema, bpd_mac)
                cursor = self.runquery(query)
                d = cursor.fetchall()
                bpd = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                bpds_data.append(bpd)
            return bpds_data #type List[Dict{str:str}]
        finally:
            self.lock.release()

    def column_names(self, schema, table):
        query = '''SELECT *
                   FROM %s.%s
                ''' % (schema, table)
        cursor = self.runquery(query)
        names = [description[0].upper() for description in cursor.description]
        return names

    def table_names(self, schema):
        query = '''SELECT table_name
                   FROM information_schema.tables
                   WHERE table_schema = '%s'
                ''' % (schema)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return [x.upper() for val in data for x in val]


    def get_platform_id(self, schema, platform, project):
        query = '''SELECT platform_id
                   FROM %s.platform
                   WHERE platform_name = '%s' and project_name = '%s'
                ''' % (schema, platform, project)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        if not data:
            return 'NULL'
        if not self._verify_singularity(data):
            return 'AMBIGUOUS'
        return data[0][0]

    def is_platform_busy(self, schema, plt_id):
        query = '''SELECT platform_busy,platform_owner
                   FROM %s.platform
                   WHERE platform_id = '%s'
                ''' % (schema, plt_id)

        cursor = self.runquery(query)
        data = cursor.fetchall()

        if data[0][0].lower() == 'no':
            return False, data[0][1]
        return True, data[0][1]

    def is_node_exitsin_platform(self, schema, node_ip, plt_id):
        query = '''SELECT node_ip
                   FROM %s.node
                   WHERE node_ip = '%s' and platform_id = '%s'
                ''' % (schema, node_ip, plt_id)

        cursor = self.runquery(query)
        data = cursor.fetchall()
        if not data:
            return False
        return True

    def is_bpd_exitsin_platform(self, schema, bpd_mac, plt_id):
        query = '''SELECT bpd_mac
                      FROM %s.bpd
                      WHERE bpd_mac = '%s' and platform_id = '%s'
                   ''' % (schema, bpd_mac, plt_id)

        cursor = self.runquery(query)
        data = cursor.fetchall()
        if not data:
            return False
        return True

    def release_platform(self, schema, platform, tester, project):
        '''To handle SSL SYSCALL error: Connection timed out'''
        self.close()
        self.connect()

        self.free_nodes(schema, platform, project)
        self.free_aps(schema, platform, project)
        query = '''UPDATE %s.platform
                   SET platform_busy = 'no', platform_owner = '', last_status_change = (SELECT now())
                   WHERE platform_name = '%s' and project_name = '%s' and platform_owner = '%s' and platform_busy != 'no'
                ''' % (schema, platform, project, tester)
        return self.runquery(query)
        # self.commit()

    def update_agentinfo_table(self):
        import os
        if not os.getenv('AGENT_ID', default=0):
            return 1
        aid = os.environ['AGENT_ID']
        name = os.environ['AGENT_NAME']
        pool = 'GFW-IVV'
        aos = os.environ['AGENT_OS']
        osarc = os.environ['AGENT_OSARCHITECTURE']
        homedir = os.environ['AGENT_HOMEDIRECTORY']
        cur_count = self.get_usage_count('kaizenbotschema', 'AGENTINFO', aid)

        query = '''INSERT INTO kaizenbotschema.AGENTINFO
                   VALUES (%d,'%s','%s','%s','%s','%s') ON CONFLICT (AGENT_ID)
                   DO UPDATE SET USAGE_COUNT=%d
                ''' % (int(aid), name, pool, aos, osarc, homedir, cur_count + 1)
        self.runquery(query)

    def update_runinfo_table(self, pipeline_link, testrun_link, elapsed_time):
        import os
        if not os.getenv('BUILD_BUILDNUMBER', default=0):
            return 1
        bnum = os.environ['BUILD_BUILDNUMBER']
        by = os.environ['BUILD_REQUESTEDFOR']
        uname = os.getenv('KAIZENBOT_G5R_USERNAME', default=os.environ['KAIZENBOT_USERNAME']).replace('"', '')
        upat = os.getenv('KAIZENBOT_G5R_USERPAT', default=os.environ['KAIZENBOT_USERPAT'])
        repo = os.environ['BUILD_REPOSITORY_URI']
        branch = os.environ['BUILD_SOURCEBRANCHNAME']
        aid = os.environ['AGENT_ID']
        plink = pipeline_link
        tlink = testrun_link
        time = elapsed_time

        query = '''INSERT INTO kaizenbotschema.RUNINFO
                   VALUES (%d,'%s','%s','%s','%s','%s',%d,'%s','%s',(SELECT justify_hours(interval '%s')))
                   ON CONFLICT (BUILD_ID) DO NOTHING
                ''' % (int(bnum), by, uname, upat, repo, branch, int(aid), plink, tlink, time)
        self.runquery(query)

    def read_nodes(self, schema, plt_id, node_type=None):
        if node_type:
            query = '''SELECT node_ip
                       FROM %s.Node
                       WHERE platform_id = '%s' and node_device_type = %s and node_status = 'active'
                    ''' % (schema, plt_id, node_type)
        else:
            query = '''SELECT node_ip
                       FROM %s.Node
                       WHERE platform_id = '%s' and node_status = 'active'
                    ''' % (schema, plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        nodes = []
        if data:
            for i in range(len(data)):
                nodes.append(data[i][0])
        return nodes

    def node_busy(self, schema, ip):
        query = '''SELECT node_busy
                   FROM %s.Node
                   WHERE node_ip = '%s'
                ''' % (schema, ip)
        cursor = self.runquery(query)
        data = cursor.fetchall()

        return data[0][0]

    def get_bpd_busy_status(self, schema, mac):
        query = '''SELECT bpd_busy
                   FROM %s.bpd
                   WHERE bpd_mac = '%s'
                ''' % (schema, mac)
        cursor = self.runquery(query)
        data = cursor.fetchall()

        return data[0][0]

    def ap_busy(self, schema, ip):
        query = '''SELECT ap_busy
                   FROM %s.AP
                   WHERE ap_ip = '%s'
                ''' % (schema, ip)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def get_current_count(self, schema, tablename, resource):
        tb_substr = 'mac'if tablename.upper() == 'BPD' else 'ip'
        query = '''SELECT busy_change_count
                 FROM %s.%s
                 WHERE %s_%s= '%s'
               ''' % (schema, tablename, tablename.lower(), tb_substr, resource)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def get_usage_count(self, schema, tablename, agentid):
        query = '''SELECT usage_count
                 FROM %s.%s
                 WHERE AGENT_ID= '%s'
               ''' % (schema, tablename, agentid)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        try:
            return data[0][0]
        except IndexError:
            return 0

    def increment_busy_change_count(self, schema, tablename, count, resource):
        tb_substr = 'mac' if tablename.upper() == 'BPD' else 'ip'
        query = '''UPDATE %s.%s
                   SET busy_change_count = %s
                   WHERE %s_%s = '%s'
                ''' % (schema, tablename, count, tablename.lower(), tb_substr, resource)
        self.runquery(query)

    def total_nodes_in_platform(self, schema, plt_id, node_type=None):
        if not node_type:
            query = '''SELECT COUNT(NODE_IP)
                       FROM %s.Node
                       WHERE platform_id = '%s' and node_status = 'active'
                    ''' % (schema, plt_id)
        else:
            query = '''SELECT COUNT(NODE_IP)
                       FROM %s.Node
                       WHERE platform_id = '%s' and node_device_type = %s  and node_status = 'active'
                    ''' % (schema, plt_id, node_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def total_bpds_in_platform(self,schema, plt_id, bpd_type=None):
        if not bpd_type:
            query = '''SELECT COUNT(BPD_MAC)
                       FROM %s.bpd
                       WHERE platform_id = '%s' and bpd_status = 'active'
                       ''' % (schema, plt_id)
        else:
            query = '''SELECT COUNT(BPD_MAC)
                       FROM %s.bpd
                       WHERE platform_id = '%s' and bpd_type = '%s' and bpd_status = 'active'
                       ''' % (schema, plt_id, bpd_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def total_aps_in_platform(self, schema, plt_id):
        query = '''SELECT COUNT(AP_IP)
                   FROM %s.AP
                   WHERE platform_id = '%s' and ap_status = 'active'
                ''' % (schema, plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def free_nodes_in_platform(self, schema, plt_id, node_type):
        if not node_type:
            query = '''SELECT COUNT(NODE_IP)
                       FROM %s.Node
                       WHERE node_busy = 'no' and platform_id = '%s' and node_status = 'active'
                    ''' % (schema, plt_id)
        else:
            query = '''SELECT COUNT(NODE_IP)
                       FROM %s.Node
                       WHERE node_busy = 'no' and platform_id = '%s' and node_device_type = %s and node_status = 'active'
                    ''' % (schema, plt_id, node_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def free_bpds_in_platform(self, schema, plt_id, bpd_type):
        if not bpd_type:
            query = '''SELECT COUNT(bpd_mac)
                       FROM %s.bpd
                       WHERE bpd_busy = 'no' and platform_id = '%s' and bpd_status = 'active'
                    ''' % (schema, plt_id)
        else:
            query = '''SELECT COUNT(bpd_mac)
                       FROM %s.bpd
                       WHERE bpd_busy = 'no' and platform_id = '%s' and bpd_type = '%s' and bpd_status = 'active'
                    ''' % (schema, plt_id, bpd_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def free_aps_in_platform(self, schema, plt_id):
        query = '''SELECT COUNT(AP_IP)
                   FROM %s.AP
                   WHERE ap_busy = 'no' and platform_id = '%s' and ap_status = 'active'
                ''' % (schema, plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def shared_nodes_in_platform(self, schema, plt_id, node_type):
        if not node_type:
            query = '''SELECT COUNT(NODE_IP)
                       FROM %s.Node
                       WHERE node_busy = 'shared' and platform_id = '%s' and node_status = 'active'
                    ''' % (schema, plt_id)
        else:
            query = '''SELECT COUNT(NODE_IP)
                       FROM %s.Node
                       WHERE node_busy = 'shared' and platform_id = '%s' and node_device_type = %s and node_status = 'active'
                    ''' % (schema, plt_id, node_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def shared_aps_in_platform(self, schema, plt_id):
        query = '''SELECT COUNT(AP_IP)
                   FROM %s.AP
                   WHERE ap_busy = 'shared' and platform_id = '%s' and ap_status = 'active'
                ''' % (schema, plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def get_nodes(self, schema, platform, project, num_of_nodes, node_type):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_node_cnt = self.total_nodes_in_platform(schema, plt_id)
        if num_of_nodes > ttl_node_cnt:
            return None, ttl_node_cnt
        self.lock.acquire()
        try:
            free_node_cnt = self.free_nodes_in_platform(schema, plt_id, node_type)
            shared_node_cnt = self.shared_nodes_in_platform(schema, plt_id, node_type)
            if num_of_nodes > (shared_node_cnt + free_node_cnt):
                return None, ttl_node_cnt

            alloted_node_cnt = 0
            nodes_data = []
            clm_names = self.column_names(schema, 'NODE')

            if not node_type:
                query = '''SELECT NODE_IP
                           FROM %s.Node
                           WHERE node_busy != 'yes' and platform_id = '%s' and node_status = 'active'
                        ''' % (schema, plt_id)
            else:
                query = '''SELECT NODE_IP
                           FROM %s.Node
                           WHERE node_busy != 'yes' and platform_id = '%s' and node_device_type = %s
                           and node_status = 'active'
                        ''' % (schema, plt_id, node_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            for i in range(len(data)):
                self._mark_node_as_shared(schema, data[i][0])
                query = '''SELECT *
                           FROM %s.NODE
                           WHERE node_ip = '%s'
                        ''' % (schema, data[i][0])
                cursor = self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                nodes_data.append(node)
                alloted_node_cnt += 1
                if alloted_node_cnt == num_of_nodes:
                    return nodes_data, ttl_node_cnt

            if not node_type:
                query = '''SELECT NODE_IP
                           FROM %s.Node
                           WHERE node_busy = 'no' and platform_id = '%s' and node_status = 'active'
                        ''' % (schema, plt_id)
            else:
                query = '''SELECT NODE_IP
                           FROM %s.Node
                           WHERE node_busy = 'no' and platform_id = '%s' and node_device_type = %s
                           and node_status = 'active'
                        ''' % (schema, plt_id, node_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            for i in range(len(data)):
                self._mark_node_as_shared(schema, data[i][0])
                query = '''SELECT *
                           FROM %s.NODE
                           WHERE node_ip = '%s'
                        ''' % (schema, data[i][0])
                cursor = self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                nodes_data.append(node)
                alloted_node_cnt += 1
                if alloted_node_cnt == num_of_nodes:
                    return nodes_data, ttl_node_cnt

        finally:
            self.lock.release()


    def get_aps(self, schema, platform, project, num_of_aps):
        plt_id = self.get_platform_id(schema, platform, project)
        ttl_ap_cnt = self.total_aps_in_platform(schema, plt_id)
        if num_of_aps > ttl_ap_cnt:
            return None, ttl_ap_cnt
        self.lock.acquire()
        try:
            free_ap_cnt = self.free_aps_in_platform(schema, plt_id)
            shared_ap_cnt = self.shared_aps_in_platform(schema, plt_id)
            if num_of_aps > (shared_ap_cnt + free_ap_cnt):
                return None, ttl_ap_cnt

            alloted_ap_cnt = 0
            aps_data = []
            clm_names = self.column_names(schema, 'AP')

            query = '''SELECT AP_IP
                       FROM %s.AP
                       WHERE ap_busy != 'yes' and platform_id = '%s' and ap_status = 'active'
                    ''' % (schema, plt_id)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            for i in range(len(data)):
                self._mark_ap_as_shared(schema, data[i][0])
                query = '''SELECT *
                           FROM %s.AP
                           WHERE ap_ip = '%s'
                        ''' % (schema, data[i][0])
                cursor = self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                aps_data.append(ap)
                alloted_ap_cnt += 1
                if alloted_ap_cnt == num_of_aps:
                    return aps_data, ttl_ap_cnt

            query = '''SELECT AP_IP
                       FROM %s.AP
                       WHERE ap_busy = 'no' and platform_id = '%s'  and ap_status = 'active'
                    ''' % (schema, plt_id)
            cursor = self.runquery(query)
            data = cursor.fetchall()

            for i in range(len(data)):
                self._mark_ap_as_shared(schema, data[i][0])
                query = '''SELECT *
                           FROM %s.AP
                           WHERE ap_ip = '%s'
                        ''' % (schema, data[i][0])
                cursor = self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]: column[1] for column in zip(*[clm_names, list(d[0])])}
                aps_data.append(ap)
                alloted_ap_cnt += 1
                if alloted_ap_cnt == num_of_aps:
                    return aps_data, ttl_ap_cnt
        finally:
            self.lock.release()

    def get_busy_resources(self, schema, platform, project, resource):
        res_data = []
        plt_id = self.get_platform_id(schema, platform, project)
        query = '''SELECT *
                FROM %s.%s
                WHERE platform_id = '%s' and %s_busy != 'no'
            ''' % (schema, resource, plt_id, resource)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        if data:
            for i in range(len(data)):
                res_data.append(data[i][0])
        return res_data

    def free_nodes(self, schema, platform, project, nodes=None):
        plt_id = self.get_platform_id(schema, platform, project)
        '''# it is important to compare with None,
        "if not nodes:" gives True for empty list also,
        in that case there are chances that accidentally
        a process can free the nodes alloted to another process.
        '''
        busy_count_list = []
        if nodes == None:
            query = '''UPDATE %s.Node
                       SET node_busy = 'no', busy_change_count = busy_change_count + 1,
                       last_busy_change = (SELECT now())
                       WHERE platform_id = '%s' and node_busy = 'yes'
                    ''' % (schema, plt_id)
            self.runquery(query)
            return busy_count_list
        else:
            for ip in nodes:
                cur_busy_count = self.get_current_count(schema, 'node', ip)
                can_free = False
                node_shared_instances = self.shared_nodes.get('%s' % ip, 0)

                # if node is shared; decrease shared count of node
                if node_shared_instances:
                    self.shared_nodes[ip] = node_shared_instances - 1
                    # after decrease, if node shared count is 0; free node
                    if self.shared_nodes[ip] == 0:
                        del self.shared_nodes[ip]
                        can_free = True
                else:
                    # node is locked; not shared
                    can_free = True

                if can_free:
                    query = '''UPDATE %s.Node
                               SET node_busy = 'no', last_busy_change = (SELECT now())
                               WHERE node_ip = '%s'
                            ''' % (schema, ip)
                    self.runquery(query)
                    cur_busy_count = int(cur_busy_count)
                    cur_busy_count += 1
                    cur_busy_count = str(cur_busy_count)
                    self.increment_busy_change_count(schema, 'node', cur_busy_count, ip)
                    busy_count_dict = {ip: cur_busy_count}
                    busy_count_list.append(busy_count_dict)
            return busy_count_list

    def free_bpds(self, schema, platform, project, bpd_macs=None):
        plt_id = self.get_platform_id(schema, platform, project)
        '''# it is important to compare with None,
        "if not bpd_macs:" gives True for empty list also,
        in that case there are chances that accidentally
        a process can free the bpds alloted to another process.
        '''
        busy_count_list = []
        if 'BPD' not in self.table_names(schema):
            return busy_count_list
        if bpd_macs == None:
            query = '''UPDATE %s.bpd
                       SET bpd_busy = 'no', busy_change_count = busy_change_count + 1,
                       last_busy_change = (SELECT now())
                       WHERE platform_id = '%s' and bpd_busy = 'yes'
                    ''' % (schema, plt_id)
            self.runquery(query)
            return busy_count_list
        else:
            for mac in bpd_macs:
                cur_busy_count = self.get_current_count(schema, 'bpd', mac)

                query = '''UPDATE %s.bpd
                           SET bpd_busy = 'no', busy_change_count = busy_change_count + 1,
                           last_busy_change = (SELECT now())
                           WHERE bpd_mac = '%s'
                        ''' % (schema, mac)
                self.runquery(query)
                cur_busy_count = int(cur_busy_count)
                cur_busy_count += 1
                busy_count_dict = {mac: cur_busy_count}
                busy_count_list.append(busy_count_dict)
            return busy_count_list

    def free_aps(self, schema, platform, project, aps=None):

        plt_id = self.get_platform_id(schema, platform, project)
        '''# it is important to compare with None,
        "if not aps:" gives True for empty list also,
        in that case there are chances that accidentally
        a process can free the aps alloted to another process.
        '''
        busy_count_list = []
        if 'AP' not in self.table_names(schema):
            return busy_count_list
        if aps == None:
            query = '''UPDATE %s.AP
                       SET ap_busy = 'no', last_busy_change = (SELECT now())
                       WHERE platform_id = '%s'
                    ''' % (schema, plt_id)
            self.runquery(query)
            aps = self.get_busy_resources(schema, platform, project, 'ap')
            for ip in aps:
                cur_busy_count = self.get_current_count(schema, 'ap', ip)
                cur_busy_count = int(cur_busy_count)
                cur_busy_count += 1
                cur_busy_count = str(cur_busy_count)
                self.increment_busy_change_count(schema, 'ap', cur_busy_count, ip)
                busy_count_dict = {}
                busy_count_dict[ip] = cur_busy_count
                busy_count_list.append(busy_count_dict)
            return busy_count_list
        else:
            for ip in aps:
                cur_busy_count = self.get_current_count(schema, 'ap', ip)
                can_free = False
                ap_shared_instances = self.shared_aps.get('%s' % ip, 0)

                # if ap is shared; decrease shared count of ap
                if ap_shared_instances:
                    self.shared_aps[ip] = ap_shared_instances - 1
                    # after decrease, if ap shared count is 0; free ap
                    if self.shared_aps[ip] == 0:
                        del self.shared_aps[ip]
                        can_free = True
                else:
                    # ap is locked; not shared
                    can_free = True

                if can_free:
                    query = '''UPDATE %s.AP
                               SET ap_busy = 'no', last_busy_change = (SELECT now())
                               WHERE ap_ip = '%s'
                            ''' % (schema, ip)
                    self.runquery(query)
                    cur_busy_count = int(cur_busy_count)
                    cur_busy_count += 1
                    cur_busy_count = str(cur_busy_count)
                    self.increment_busy_change_count(schema, 'ap', cur_busy_count, ip)
                    busy_count_dict = {ip: cur_busy_count}
                    busy_count_list.append(busy_count_dict)
            return busy_count_list

    def nodedict_from_db(self, schema):
        query = '''SELECT *
                   FROM %s.Node
                ''' % (schema)
        cursor = self.runquery(query)

        rows = cursor.fetchall()
        colnames = self.column_names(schema, 'Node')

        kzbot_gen5dev_dict = {}
        for x, row in enumerate(rows):
            for col, row in zip(colnames, row):
                if rows[x][0] in kzbot_gen5dev_dict.keys():
                    kzbot_gen5dev_dict[rows[x][0]].update({col: row})
                else:
                    kzbot_gen5dev_dict[rows[x][0]] = {col: row}
        return kzbot_gen5dev_dict
