# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in Connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
from azure.devops.connection import Connection
from msrest.authentication import BasicAuthentication
from azure.devops import *
import pprint, os, base64, glob, time
from .logging_robot import Loggers
from msrest.exceptions import AuthenticationError
from azure.devops.v6_0 import client_factory
from azure.devops.v6_0.test_plan import models
from pathlib import Path

if(os.name=='nt'):
    Result_Dir = os.path.join(os.getcwd(), "Results")
    Log_Dir = os.path.join(os.getcwd(), "Logs")
else:
    Result_Dir = os.environ.get('KAIZENBOT_INTERNAL_OUTDIR')
    Log_Dir = os.environ.get('KAIZENBOT_INTERNAL_LOGDIR')
    if Log_Dir is None:
        Log_Dir = os.path.join(os.getcwd(), "Logs")
    else:
        '''check if Log_Dir is a directory'''
        if os.path.isdir(Log_Dir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(Log_Dir))
        else:
            raise Exception("Directory {} does not exists".format(Log_Dir))
        
    if Result_Dir is None:
        Result_Dir = os.path.join(os.getcwd(), "Results")
    else:
        '''check if Result_Dir is a directory'''
        if os.path.isdir(Result_Dir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(Result_Dir))
        else:
            raise Exception("Directory {} does not exists".format(Result_Dir))

log_obj = Loggers()
logger = log_obj.get_logger('KaizenBot')

'''Client paths'''
TEST_CLIENT = "azure.devops.v6_0.test.test_client.TestClient"
TESTPLAN_CLIENT = "azure.devops.v6_0.test_plan.test_plan_client.TestPlanClient"
WORK_CLIENT = "azure.devops.released.work.work_client.WorkClient"
WORK_ITEM_TRACKING_CLIENT = "azure.devops.v6_0.work_item_tracking.work_item_tracking_client.WorkItemTrackingClient"
BUILD_CLIENT = "azure.devops.v6_0.build.build_client.BuildClient"
CORE_CLIENT = "azure.devops.v6_0.core.core_client.CoreClient"
PIPELINE_CLIENT = "azure.devops.v6_0.pipelines.pipelines_client.PipelinesClient"
RELEASE_CLIENT = "azure.devops.v6_0.release.release_client.ReleaseClient"
TFVC_CLIENT = "azure.devops.v6_0.tfvc.tfvc_client.TfvcClient"
GIT_CLIENT_BASE = "azure.devops.v6_0.git.git_client_base.GitClientBase"

'''Constants'''
Test_Run_Batch_Size=100000
TestResultOutcome=['None', 'Passed', 'Failed', 'Inconclusive', 'Timeout', 'Aborted', 'Blocked', 'Not Executed', 'Warning', 'Error', 'Not Applicable', 'Paused', 'In Progress']
TestResultState = ['Unspecified', 'Completed', 'In Progress', 'Paused', 'Pending', 'Queued', 'Max Value']
TestRunState = ['Unspecified', 'NotStarted', 'InProgress', 'Completed', 'Aborted', 'Waiting', 'NeedsInvestigation']

class VSTSLibrary:
    def __init__(self, pat=None):
        self.pat = 'vamal7crzrrmsuc3y75k5y6mgrudbec5qtbcmytonj4ge5t75jzq'#pat
        self.connection = self.authentication()
        pass
    
    def _logger(self):
        raise NotImplementedError
    
    def authentication(self):
        """ This keyword establishes connection with VSTS based on the personal access token provided by the user
        """
        organization_url = 'https://dev.azure.com/itron'
        try:
            # Create a connection to the org
            credentials = BasicAuthentication('', self.pat)
            connection = Connection(base_url=organization_url, creds=credentials)
            
        except AuthenticationError:
            logger.exception("Authentication failed, please verify your personal access token")
            raise Exception("Authentication failed, please verify your personal access token")
        except Exception as e:
            logger.exception(e)
            raise Exception(e)
        else:
            logger.info("Connected to ADS")
            return connection
    
    def get_projects_by_name(self):
        """ This keyword return the all projects name 
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        project_list=[]
        get_projects_response = core_client.get_projects()
        if get_projects_response is not None:
            for project in get_projects_response.value:
                index += 1                
                project_list.append(project.name)
        if get_projects_response.continuation_token is not None and get_projects_response.continuation_token != "":
            # Get the next page of projects
            get_projects_response = core_client.get_projects(continuation_token=get_projects_response.continuation_token)
        else:
            # All projects have been retrieved
            get_projects_response = None
        return(project_list)
    
    def get_projects_by_id(self):
        """ This keyword return the all projects id
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        project_list=[]
        get_projects_response = core_client.get_projects()
        if get_projects_response is not None:
            for project in get_projects_response.value:
                index += 1                
                project_list.append(project.id)
        if get_projects_response.continuation_token is not None and get_projects_response.continuation_token != "":
            # Get the next page of projects
            get_projects_response = core_client.get_projects(continuation_token=get_projects_response.continuation_token)
        else:
            # All projects have been retrieved
            get_projects_response = None
        return(project_list)
    
    def get_project_by_name(self):
        """ This keyword return the project name i.e. RnD
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        project_name = self.get_projects_by_name()
        project = core_client.get_project(project_name[1])
        return(project.name)#this will be RnD
    
    def get_project_by_id(self):
        """ This keyword return the project id i.e. id corresponding to RnD
        """
        core_client = self.connection.clients.get_core_client()
        index=0
        get_projects_response = core_client.get_projects()
        if get_projects_response is not None:
            for project in get_projects_response.value:
                index += 1                
        if get_projects_response.continuation_token is not None and get_projects_response.continuation_token != "":
            # Get the next page of projects
            get_projects_response = core_client.get_projects(continuation_token=get_projects_response.continuation_token)
        else:
            # All projects have been retrieved
            get_projects_response = None
        return(project.id)
    
    def get_plans(self):
        """ This keyword return the test plans list for the project `RnD`
        """
        work_client = self.connection.get_client(WORK_CLIENT)
        project = self.get_project_by_id()
        plans_list=[]
        for plan in work_client.get_plans(project):
            logger.info(plan.id +' : ' +plan.name)
            plans_list.append(plan.name)
        return(plans_list)
    
    def get_nested(self, data, *args):
        """ This keyword reads data from nested dictionary
        """
        if args and data:
            element  = args[0]
            if element:
                value = data.get(element)
                return value if len(args) == 1 else self.get_nested(value, *args[1:])
            
    def get_test_plan(self, planid):
        """ This keyword returns the test plan name for the provided test planid and project provided as id
        
        This takes mandatory argument `planid` for which test plan name to be retrieved
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_project_by_id()
        if (planid is not None or planid !=''):
            planid = int(planid)
        testplan = test_plan_client.get_test_plan_by_id(projectid, planid)
        return testplan.name
    
    def get_test_plans_by_name(self):
        """ This keyword returns the test plan list for the project provided as name i.e RnD
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_projects_by_name()
        testplan_list=[]
        testplan = test_plan_client.get_test_plans(projectid[1])
        for plan in testplan:
            testplan_list.append(plan.name)
        return testplan_list
    
    def get_test_plans_by_id(self):
        """ This keyword returns the test plan list for the project provided as id
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_projects_by_id()
        testplan_list=[]
        testplan = test_plan_client.get_test_plans(projectid[1])
        for plan in testplan:
            testplan_list.append(plan.id)
        return testplan_list
    
    def get_test_suites_by_name(self, planid):
        """ This keyword returns the test suite list with all the test cases for the provided 'planid`
        and project provided as id
        
        This takes mandatory argument `planid` for which test suites to be retrieved
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_projects_by_id()
        testsuite_list=[]
        testsuite = test_plan_client.get_test_suites_for_plan(projectid[1], planid)
        for suite in testsuite:
            testsuite_list.append(suite.name)
        return testsuite_list
    
    def get_test_suites_by_id(self, planid):
        """ This keyword returns the test suite list with all the test cases for the provided 'planid`
        and project provided as name
        
        This takes mandatory argument `planid` for which test suites to be retrieved
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_projects_by_id()
        testsuite_list=[]
        testsuite = test_plan_client.get_test_suites_for_plan(projectid[1], planid)
        for suite in testsuite:
            testsuite_list.append(suite.id)
        test_suite=','.join(map(str, testsuite_list))
        print(type(test_suite))
        return test_suite
        #return testsuite_list
    
    def get_test_suite_by_id(self, planid, suiteid):
        """ This keyword returns the test suite name pf all the test cases for the provided 'planid`, 
        `suiteid` and project provided as id
        
        This takes mandatory argument `planid` and 'suiteid` for which test suite name to be retrieved
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_projects_by_id()
        testsuite = test_plan_client.get_test_suite_by_id(projectid[1], planid, suiteid)
        print(testsuite.parent_suite.id)
        return testsuite.name
    
    def create_test_suite(self, suite_name, plan_id, suiteid):
        """ This keyword returns the test suite id created for the provided 'planid`, 
        `suiteid` and project provided as id
        
        This takes mandatory argument `planid` and 'suiteid` for which test suite name to be retrieved
        and `suite_name` argument which will create suite with the provided suite name.
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        projectid = self.get_project_by_id()
        testsuites = test_plan_client.get_test_suite_by_id(projectid, plan_id, suiteid)
        tsuites = {'id': testsuites.parent_suite.id, 'name':testsuites.parent_suite.id}
        tscp ={
            'name': suite_name, 
            'parent_suite': tsuites,
            'suite_type':2,
            }
        testsuite = test_plan_client.create_test_suite(tscp,projectid, plan_id)
        return testsuite.id
    
    def reset_test_point_to_active(self, planid, suiteid):
        """ This keyword resets the test cases to active state for the provided 'planid`, 
        `suiteid` and project provided as name
        
        This takes mandatory argument `planid` and 'suiteid` for which test case need 
        to be reset to active state.
        
        This keyword return the list of points which has been reset to active
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        test_client = self.connection.get_client(TEST_CLIENT)
        project = self.get_project_by_name()
        points= test_client.get_points(project, planid, suiteid)
        for point in points:
            tpup = {
                'id': point.id,
                'is_active': True
                
                }
            tp_list=[]
            tp_list.append(tpup)
            points = test_plan_client.update_test_points(tp_list, project, planid, suiteid)
            points_list=[]
            for test_points in points:
                points_list.append(test_points.id)
            return points_list

    def add_test_cases_to_suite(self, planid, suiteid, *testcaseids):
        """ This keyword resets the test cases to active state for the provided 'planid`, 
        `suiteid` and project provided as name
        
        This takes mandatory argument `planid` and 'suiteid` for which test case need 
        to be reset to active state.
        
        This keyword return the list of points which has been reset to active
        """
        projectid = self.get_project_by_id()
        test_client=self.connection.get_client(TEST_CLIENT)
        flag=False
        try:
            for testcaseid in testcaseids:
                ts = test_client.add_test_cases_to_suite(projectid, planid, suiteid, testcaseid)
                for details in ts:
                    if int(details.test_case.id) == testcaseid:
                        flag=True
                        logger.info("Test case added to test suite successfully")
                        pointid = self.get_test_points(planid, suiteid)
                    else:
                        flag=False
                        logger.info("Failed to add test case to test suite")
        except Exception as e:
            logger.exception(e)
            raise Exception(e)
        else:
            return flag
        
    def get_test_configurations_by_name(self):
        """ This keyword gets the test configurations for project provided as name
        
        This keyword return the list of configurations name for the RnD project
        """
        project = self.get_projects_by_name()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        config_list = []
        lookformore = True
        max = 0
        while(lookformore):
            configs = test_plan_client.get_test_configurations(project[1], max)
            if (configs is not None and configs != []):
                for config in configs:
                    config_list.append(config.name)
                    max+=1
                    logging.info(config.name + ' : ' + str(config.id))
            else:
                break
        return config_list
    
    def get_test_configurations_by_id(self):
        """ This keyword gets the test configurations for project provided as name
        
        This keyword return the list of configurations id for the RnD project
        """
        project = self.get_projects_by_name()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        config_list = []
        lookformore = True
        max = 0
        while(lookformore):
            configs = test_plan_client.get_test_configurations(project[1], max)
            if (configs is not None and configs != []):
                for config in configs:
                    print(config)
                    #config_list.append(config.id)
                    max+=1
                    #print(config.name + ' : ' + str(config.id))
            else:
                break
        return config#_list
    
    def get_test_configuration_name(self, test_config_id):
        """ This keyword gets the test configuration name for the provided `test_config_id`
         for project provided as name
        
        This keyword return the configuration name for for the provided `test_config_id`
        """
        project = self.get_projects_by_name()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        configs = test_plan_client.get_test_configuration_by_id(project[1], test_config_id)
        return configs.name
    
    def get_workitem(self, testcaseid):
        """ This keyword returns the test case title for the provided `testcaseid`
         for project provided as name
        """
        project = self.get_project_by_id()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        test = work_item_tracking_client.get_work_item(testcaseid, project)
        #return(test.fields['System.Title'])
        return(test.fields['Microsoft.VSTS.TCM.AutomationStatus'])
    
    def get_workitems(self, *testcaseid):
        """ This keyword returns the list of test case titles for the provided test cases ids using 
         `*testcaseid` for project provided as name
        """
        project = self.get_project_by_id()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        test = work_item_tracking_client.get_work_items(testcaseid)
        test_list=[]
        for items in test:
            test_list.append(items.fields['System.Title'])
        return test_list
            
    def get_test_cases(self,plan_id, suite_id):
        """ This keyword gets the test cases to for the provided 'planid`, 
        `suiteid` and project provided as name
        
        This takes mandatory argument `planid` and 'suiteid` for which test case need 
        to be reset to active state.
        
        This keyword return the list of test cases IDs
        """
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        index=0
        test_case_list=[]
        for tests in test_client.get_test_cases(project, plan_id, suite_id):
            logger.info("Getting Test Cases ID: {}".format(tests.test_case.id))#getting test case Ids only
            test_case_list.append(tests.test_case.id) 
        return test_case_list
    
    def get_test_case_list(self, planid, suiteid, configid=None):
        """ This keyword gets the test cases to for the provided 'planid`, 
        `suiteid`, `configid` and project provided as name
        
        This takes mandatory argument `planid` and 'suiteid` for which test case need 
        to be reset to active state.
        
        This takes optional argument `configid`
        
        This keyword return the list of test cases IDs
        """
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        work_client = self.connection.get_client(WORK_CLIENT)
        core_client = self.connection.get_client(CORE_CLIENT)
        project = self.get_project_by_id()
        test_case_list=[]
        testcases = test_plan_client.get_test_case_list(project, planid, suiteid, configuration_ids=configid)
        for testcase in testcases:
            test_case_list.append(testcase.work_item.id)
            for points in testcase.point_assignments:
                print(points.configuration_id)
        return test_case_list

    ##Need to check
    def get_backlog_configurations(self):
        project = self.get_project_by_id()
        Team_Context={
            'project_id': project,
            'team': 'FW-DevOps-Networks-GenX'
            }
        config = work_client.get_backlog_configurations(Team_Context)
        print(config)
        
    def get_teams(self):
        """ This keyword gets the team lists for the provided project i.e. RnD
        
        This keyword return the list of teams
        """
        core_client = self.connection.get_client(CORE_CLIENT)
        project = self.get_project_by_name()
        team = core_client.get_teams(project)
        teamlist=[]
        for t in team:
            teamlist.append(t.name +':'+ str(t.id))
        print(teamlist)
            
        
    def get_test_points(self, planid, suiteid):
        """ This keyword gets the tests points of each test cases to for the provided 
        'planid`, `suiteid`, `configid` and project provided as name
        
        This takes mandatory argument `planid` and 'suiteid` for which test case need 
        to be reset to active state.
        
        This keyword return the list of test points for each test cases
        """
        project = self.get_project_by_id()
        test_client = self.connection.get_client(TEST_CLIENT)
        points = test_client.get_points(project, planid, suiteid)
        points_id_list=[]
        for point_id in points:
            points_id_list.append(point_id.id)
        pprint.pprint("Point Id is: " + str(point_id.id) + ", Test Case ID: " + str(point_id.test_case.id) + ", Test Case name: " +point_id.test_case.name)
        return points_id_list
    
    def get_test_runs(self, excludeDeletedRuns = False):
        """ This keyword gets the tests runs for project RnD
        
        argument `excludeDeletedRuns` is set to 'False` by default and can
        be set to `True` if we want to excluded delete test runs
        
        This keyword return the list of test runs
        """
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        run_list=[]
        lookformore = True
        top = 0
        skip=0
        DELETED_STATE = "255"
        while(lookformore):
            configs = test_client.get_test_runs(project, top = Test_Run_Batch_Size)
            if (configs is not None and configs != []):
                if(len(configs) == Test_Run_Batch_Size):
                    skip+= Test_Run_Batch_Size
                    if(top > Test_Run_Batch_Size):
                        top -= Test_Run_Batch_Size
                    elif top == 0:
                        pass
                    else:
                        lookformore = False 
                else:
                    lookformore = False
                if(excludeDeletedRuns):
                    for config in configs:
                        if (config.state == DELETED_STATE):
                            configs.remove(config.state == DELETED_STATE)
                for run in configs:
                    run_list.append(run.id)
                    top+=1
                    logging.info(run.name + ' : ' + str(run.id))
            else:
                break
        return run_list
        
    def get_test_run_by_id(self, runid):
        """ This keyword gets the tests run id for provided `runid` for project RnD
        
        This takes mandatory argument `runid`
        
        This keyword return the test run id
        """
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        test_run = test_client.get_test_run_by_id(project, runid)
        #logger.info("Run Id: " + test_run.id +', ' + 'Owner Name: ' +test_run.owner.display_name +', ' +"Last Updated by: "+test_run.last_updated_by.display_name +', ' +"Name: " + test_run.name+', '+ "State: "+test_run.state)
        print(test_run.plan.id)
        print(test_run.release)
        return test_run.id
    
    def delete_test_run(self, runid):
        """ This keyword delets the provided `runid` for project RnD
        """
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        test_run = test_client.delete_test_run(project, runid)
    
    def get_test_results(self, runid):
        """ This keyword gets the tests results for provided `runid` for project RnD
        
        This takes mandatory argument `runid`
        
        This keyword return the test results list
        """
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        results= test_client.get_test_results(project, runid, top=None)
        print(results)
        test_results=[]
        for result in results:
            print(result.test_case.id)
            test_results.append(result.test_case.id)
        return test_results

    def create_test_run(self, planid, suiteid, runName, configid=None, state='', outcome='', buildId=0, comment='', username='', platform='', flavor=''):
        """ This keyword creates the test run for provided `planid`, 'suiteid'
        for project RnD
        
        This takes mandatory arguments `planid`, `suiteid`, `runName`
        
        This takes optional argument `configid`.
        
        These arguments have default value set to empty or 0 are `state`, `outcome`,
        `buildId`, `comment`, `username`, `platform`, `flavor`
        
        This keyword returns the created test run id
        """
        planid=int(planid)
        project = self.get_project_by_id()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        test_client = self.connection.get_client(TEST_CLIENT)
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        points= test_client.get_points(project, planid, suiteid)
        testPlan = test_plan_client.get_test_plan_by_id(project, planid)
        CpuId ={'display_name': testPlan.owner.display_name}
        ## Build platform and flavor can only be specified when a build ID is also given.
        if (buildId == 0):
            platform = ''
            flavor = ''
         
        tplan = {'id': testPlan.id}
        rcm = {
                'name': runName, 
                'plan': tplan,
                'owner': CpuId
            }
        '''Create Test Run'''
        run = test_client.create_test_run(rcm, project)
        logger.info("Run ID is: {}".format(run.id))
        runid = {'id': run.id}
        runId = {'test_run': runid}
        testplanid = {'test_plan': tplan}
        test_result=[]
        '''Create Test Result'''
        if(points !=[] or points is not None):
            ntcid=[]
            npointid=[]
            for point in points:
                tcid = point.test_case.id
                ntcid.append(tcid)
                npointid.append(point.id)
            for i in range(0, len(ntcid)):
                test_res={}
                b=ntcid[i]
                a=npointid[i]
                p={'id': a}
                pointId={'test_point': p}
                owner_name ={'owner': testPlan.owner}
                RunBy = {'run_by': testPlan.owner}
                testcase = work_item_tracking_client.get_work_item(int(b), project)
                tc={'id': b}
                testcaseid={'test_case': tc}
                testcasetitle={'test_case_title': testcase.fields['System.Title']}
                testcaserevision={'test_case_revision': testcase.rev}
#                 if (testcase.fields['Microsoft.VSTS.TCM.Steps'] is not None):
#                     logger.info("Unable to retrieve test steps for TC ID: {}".format(testcase.id))
                test_res.update(owner_name) 
                test_res.update(testplanid) 
                test_res.update(testcaseid)
                test_res.update(testcasetitle) 
                test_res.update(testcaserevision) 
                test_res.update(RunBy)
                test_res.update(pointId)
                test_res.update(runId)
                test_result.append(test_res)
            TestCaseResults = test_client.add_test_results_to_test_run(test_result, project, run.id)
            if(TestCaseResults !=[] or TestCaseResults is not None) and (state !='' and outcome !=''):
                for result in TestCaseResults:
                    result.state = state
                    result.outcome=outcome
                TestResults = test_client.update_test_results(TestCaseResults, project, result.test_run.id)
            if (state !='' or state is not None):
                for Results in TestResults:
                    states = Results.state
                rum={
                    'state': state
                    }
                newTestRun = test_client.update_test_run(rum, project, result.test_run.id)
                print(testPlan)
        return newTestRun.id, newTestRun.web_access_url
    
    def update_test_run_and_results(self, testresults_list):
        """ This keyword updates the test run and results for provided `testresults_list'
        for project RnD
        
        This takes mandatory arguments `testresults_list`
        
        This keyword returns the updated test result object
        """
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        runn = self.get_test_runs()
        for run in runn:
            res = test_client.update_test_results(testresults_list,project,run.id)
            print(res)
        return res
            
    def create_test_result_attachment(self, run_id, test_case_result_id):
        """ This keyword creates the test results attachment and attaches results
        for provided `test_case_result_id'
        for project RnD
        
        This takes mandatory arguments `test_case_result_id`
        
        This keyword returns the flag as `Success` or `Failure` based on attachment 
        completed or not respectively.
        """
        project = self.get_project_by_id()
        filepath= path+'/*'
        if(system() is 'Windows'):
            PATH = path+'\\'
        else:
            PATH = path+'/'
        report_list=[]
        log_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if (PATH+'report') in list_of_files[i]:
                report_list.append(list_of_files[i]) 
        latest_report_file = max(report_list, key=os.path.getctime)
        filename = Path(latest_report_file).name

        with open(report, 'rb') as f:
            encoded_string = base64.b64encode(f.read()).decode('ascii')
            
        test_client = self.connection.get_client(TEST_CLIENT)
        Test_Attachment_Request_Model={
            'attachment_type': 'GeneralAttachment',
            'comment': 'attach report',
            'file_name': filename,
            'stream': encoded_string
            }
        attachment_id = test_client.create_test_result_attachment(Test_Attachment_Request_Model, project, run_id, test_case_result_id)
        print(attachment_id.id)
        checkid = test_client.get_test_result_attachments(project, run_id, test_case_result_id)
        attachmentid_list=[]
        for item in checkid:
            attachmentid_list.append(item.id)
        if(attachment_id.id in attachmentid_list):
            logger.info("Attached result successfully")
            flag ="Success"
        else:
            logger.error("Attachment failed")
            flag="Failure"
        return flag

    def create_test_run_attachment(self, run_id):
        """ This keyword creates the test run attachment and attaches results
        for provided `run_id' for project RnD and verifies attachment
        
        This takes mandatory arguments `run_id`
        
        This keyword returns the flag as `Success` or `Failure` based on attachment 
        completed or not respectively.
        """
        project = self.get_project_by_id()
        filepath= path+'/*'
        if(system() is 'Windows'):
            PATH = path+'\\'
        else:
            PATH = path+'/'
        report_list=[]
        log_list=[]
        list_of_files = glob.glob(filepath)
        for i in range(0, len(list_of_files)):
            if (PATH+'report') in list_of_files[i]:
                report_list.append(list_of_files[i]) 
        latest_report_file = max(report_list, key=os.path.getctime)
        
        filename = Path(latest_report_file).name
        with open(report, 'rb') as f:
            encoded_string = base64.b64encode(f.read()).decode('ascii')
        test_client = self.connection.get_client(TEST_CLIENT)
        Test_Attachment_Request_Model={
            'attachment_type': 'GeneralAttachment',
            'comment': 'attach report',
            'file_name': filename,
            'stream': str(encoded_string)
            }
        res = test_client.create_test_run_attachment(Test_Attachment_Request_Model, project, run_id)
        check = test_client.get_test_run_attachments(project, run_id)
        for item in check:
            flag='Success'
        else:
            flag='Failed'
        return flag

    def get_test_run_attachments(self, runid):
        """ This keyword gets the test run attachment for provided `run_id'
        for project RnD
        
        This takes mandatory arguments `run_id`
        
        This keyword returns attachment id.
        """
        project = self.get_project_by_id()
        test_client = self.connection.get_client(TEST_CLIENT)
        res = test_client.get_test_run_attachments(project, runid)
        for name in res:
            logger.info("Attachment file name: {} and id is: {}".format(name.filename, name.id))
        return name.id
    
    def get_pipelines(self):
        project = self.get_project_by_id()
        pipeline_client = self.connection.get_client(PIPELINE_CLIENT)
        res=pipeline_client.list_pipelines(project)
        for val in res:
            if(val.name=='KaizenBot Test Framework'):
                print(val.id)
                print(val._links)
                print(val.url)
        return val.name
    
    def get_releases(self, release_id):
        project = self.get_project_by_id()
        release_client = self.connection.get_client(RELEASE_CLIENT)
        res=release_client.get_release(project, release_id)
        #print(res)
#             if(val.name=='KaizenBot Test Framework'):
#             print(val.created_by)
#             print(val._links)
#             print(val.release_definition)
        return res.release_definition._links
    
    def create_test_configuartion(self, config_name):
        '''creating configuration'''
        project = self.get_project_by_id()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        TestConfigurationCreateUpdateParameters={
            'name': config_name,
            'is_default':True,
            'description': 'KaizenBot Gen5Riva configuration',
            'values':[
                {
                    'name':config_name,
                    'value':config_name
                }
            ],
            'state':'Active'
            }
        config_id=test_plan_client.create_test_configuration(TestConfigurationCreateUpdateParameters,project)
        return config_id
    
    def update_test_configuartion(self, config_name, config_id):
        '''creating configuration'''
        project = self.get_project_by_id()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        TestConfigurationCreateUpdateParameters={
            'name': config_name,
            'is_default':True,
            'description': 'KaizenBot Gen5Riva configuration',
            'values':[
                {
                    'name':config_name,
                    'value':config_name
                }
            ],
            'state':'Active'
            }
        config_id=test_plan_client.update_test_configuration(TestConfigurationCreateUpdateParameters,project, config_id)
        return config_id.id
    
    def update_suite_testcase(self,planid, suiteid, config_id):
        project = self.get_project_by_id()
        id_tc={
            'id':2012103
            }
        SuiteTestCaseCreateUpdateParameters={
                'point_assignments':
                    [{
                    'configuration_id':config_id
                    }
                    ],
                    'work_item': id_tc             
                }
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        val=test_plan_client.update_suite_test_cases([SuiteTestCaseCreateUpdateParameters], project, planid, suiteid)
        for a in val:
            print(a)
            
    def get_test_configurations(self):
        project = self.get_project_by_id()
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        test_config_list=[]
        lookformore = True
        token_val='0'
        MAX_CONFIG=5000
        skip=0
        while(lookformore):
            configs=test_plan_client.get_test_configurations(project, continuation_token=token_val)
            print(configs)
            if (configs is not None and configs != []):
                for data in configs:
                    test_config_list.append(str(data.id) +"---" +str(data.name))
                    if(data.id != MAX_CONFIG):
                        token_val= data.id
                        print(token_val)
                    elif (data.id == MAX_CONFIG):
                        lookformore=False
                        break
            else:
                lookformore=False
            token_val=str(int(data.id) + 1)
        return test_config_list
    
    def update_workitem(self, workitemid):
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        docsam = []
        fv= {"Microsoft.VSTS.TCM.AutomatedTestName":"Automated Test", "Microsoft.VSTS.TCM.AutomatedTestStorage": "Test", "Microsoft.VSTS.TCM.AutomatedTestType": "Test"}
        for field in fv.keys():
            value = fv[field]
            print("Updating field {} with value {}".format(field,value))
            vstspath = "/fields/" + field
            tmp = {"op":"add", "path":vstspath, "from": "null", "value": value}
            docsam.append(tmp)
        wid = work_item_tracking_client.update_work_item(docsam,workitemid, expand='Fields')
        return wid
    
    def update_field(self):
        project = self.get_project_by_id()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        payload={
            'Microsoft.VSTS.TCM.AutomationStatus': 'Automated'
            }
        xyz=work_item_tracking_client.update_field(payload, '')
        
    def get_field(self):
        project = self.get_project_by_id()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        xyz=work_item_tracking_client.get_field('Microsoft.VSTS.TCM.AutomationStatus')
        return xyz.supported_operations
    
    def get_fields(self):
        project = self.get_project_by_id()
        work_item_tracking_client = self.connection.get_client(WORK_ITEM_TRACKING_CLIENT)
        xyz=work_item_tracking_client.get_fields(project, expand='512')
        for a in xyz:
            print(a)
        return a
    
    def get_pr_by_id(self,pr_id):
        project = self.get_project_by_id()
        git_client_base = self.connection.get_client(GIT_CLIENT_BASE)
        xyz=git_client_base.get_pull_request('GFW.IVV',pr_id, project,include_work_item_refs=True)
        wi=xyz.work_item_refs
        wi_list=[]
        for a in wi:
            wi_list.append(a.id)
        return wi_list
    
    def get_config_from_runid(self, runid):
        project = self.get_project_by_id()
        test_client = self.connection.clients.get_test_client()
        results= test_client.get_test_results(project, runid, top=None)
        test_results=[]
        for result in results:
            test_results.append(result.configuration.id)
        test_plan_client = self.connection.get_client(TESTPLAN_CLIENT)
        conf=test_plan_client.get_test_configuration_by_id(project, result.configuration.id)
        conf_dict={}
        for val in conf.values:
            conf_dict.update({val.name:val.value})
        return conf_dict
    
    def get_project_id(self):
        organization_url = 'https://dev.azure.com/itron'
        self.pat = 'vamal7crzrrmsuc3y75k5y6mgrudbec5qtbcmytonj4ge5t75jzq'#pat
        credentials = BasicAuthentication('', self.pat)
        connection = Connection(base_url=organization_url, creds=credentials)
        core_client = self.connection.clients.get_core_client()
        index=0
        project_list=[]
        get_projects_response = core_client.get_projects()
        if get_projects_response is not None:
            for project in get_projects_response.value:
                index += 1                
                project_list.append(project.id)
        if get_projects_response.continuation_token is not None and get_projects_response.continuation_token != "":
            # Get the next page of projects
            get_projects_response = core_client.get_projects(continuation_token=get_projects_response.continuation_token)
        else:
            # All projects have been retrieved
            get_projects_response = None
        return(project_list)

    
