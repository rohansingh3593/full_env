from robotremoteserver import RobotRemoteServer
import time
import sys
import sqlite3
from sqlite3 import Error
from threading import RLock

class KBotDBServer:
    def __init__(self,db_file):
        """ create a database connection to a SQLite database """
        self.conn = None
        self.db_file = db_file
        self.connect()
        self.lock = RLock()
        self.shared_nodes = {}  # TYPE: DICT{str:int} {shared-node-ip:number of shared instances} 
        self.shared_aps = {}    # TYPE: DICT{str:int} {shared-ap-ip:number of shared instances}
        
    def __del__(self):
        self.close()
        
    def connect(self):
        try:
            self.conn = sqlite3.connect(self.db_file,uri=True)
            self.conn.execute("PRAGMA foreign_keys = ON")
        except Error as e:
            print(e)
            raise
    
    def commit(self):
        if self.conn:
            self.conn.commit()
            
    def close(self):
        if self.conn:
            self.conn.close()
            
    def runquery(self,query):
        try:
            #acquire lock here
            self.lock.acquire()
            cursor = self.conn.execute(query)
            self.commit()
            return cursor
        except sqlite3.OperationalError:
            raise
        finally:
            #release lock here
            self.lock.release()
            
    def runscript(self, sql_file):
        if not os.path.isfile(sql_file):
            raise FileNotFoundError("file '%s' does not exist"%sql_file)
            
        with open(sql_file, 'r') as sf:
            script = sf.read()
            
        try:
            #acquire lock here
            self.lock.acquire()
            cursor = self.conn.executescript(script)
            self.commit()
            return cursor
        except sqlite3.OperationalError:
            raise
        finally:
            #release lock here
            self.lock.release()    
            
    def column_names(self,table):
        query = '''SELECT *
                   FROM %s
                '''%table
        cursor = self.runquery(query)
        names = [description[0] for description in cursor.description]
        return names

    def table_names(self):
        query = '''SELECT name
                   FROM sqlite_master
                   WHERE type="table"'''
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return [tname[0].upper() for tname in data]

    def _verify_singularity(self, data):
        if not (data and 
                isinstance(data, list) and 
                len(data) == 1 and 
                data[0] and 
                isinstance(data[0], tuple) and
                len(data[0]) == 1 ):
        
            return False
        return True
        
    def get_platform_id(self,platform,project):
        query = '''SELECT platform_id
                   FROM platform 
                   WHERE platform_name = '%s' and project_name = '%s'
                '''%(platform,project)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        if not data:
            return 'NULL'
        if not self._verify_singularity(data):
            return 'AMBIGUOUS'
        return data[0][0]    
        
    def is_platform_busy(self,plt_id):
        query = '''SELECT platform_busy,platform_owner
                   FROM platform 
                   WHERE platform_id = '%s'
                '''%(plt_id)
                
        cursor = self.runquery(query)
        data = cursor.fetchall()
            
        if data[0][0].lower() == 'no':
            return False,data[0][1]
        return True,data[0][1]

    def is_node_exitsin_platform(self, node_ip, plt_id):
        query = '''SELECT node_ip
                   FROM node
                   WHERE node_ip = '%s' and platform_id = '%s'
                ''' % (node_ip, plt_id)

        cursor = self.runquery(query)
        data = cursor.fetchall()
        if not data:
            return False
        return True
    
    def _acquire_first_free_platform(self,tester, project):
        query = '''SELECT platform_id
                   FROM Platform
                   WHERE platform_busy = 'no' and project_name = '%s'
                '''%project
        self.lock.acquire()
        try:
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                return None,'ALL'
            
            query = '''UPDATE platform 
                       SET platform_busy = 'yes', platform_owner = '%s'
                       WHERE platform_id = '%s' 
                    '''%(tester,data[0][0])
        
            self.runquery(query)
            
            query = '''SELECT platform_name
                       FROM Platform
                       WHERE platform_id = '%s'
                    '''%data[0][0]
            cursor = self.runquery(query)
            data = cursor.fetchall()
            return data[0][0], None
        finally:
            self.lock.release()
    
    def acquire_platform(self,platform,tester,project):
        if platform.upper() == 'ANY':
            return self._acquire_first_free_platform(tester, project)
            
        plt_id = self.get_platform_id(platform,project)
        if plt_id == 'NULL':
            raise Exception("No platform '%s' exists under project '%s'"%(platform,project))
        if plt_id == 'AMBIGUOUS':
            raise Exception("Ambiguous platform definitions are found for platform '%s' and project '%s'"%(platform,project))
            
        busy,owner= self.is_platform_busy(plt_id)
        if busy:
            return None,owner
        query = '''UPDATE platform 
                   SET platform_busy = 'yes', platform_owner = '%s'
                   WHERE platform_id = '%s' 
                '''%(tester,plt_id)
        
        self.runquery(query)
        return platform,owner
        
    def release_platform(self,platform,tester,project):
        self.free_nodes(platform,project)
        self.free_aps(platform,project)
        query = '''UPDATE platform 
                   SET platform_busy = 'no', platform_owner = NULL
                   WHERE platform_name = '%s' and project_name = '%s' and platform_owner = '%s'
                '''%(platform,project,tester)
        
        self.runquery(query)
        #self.commit()

    def read_nodes(self, plt_id, node_type = None):
        if node_type:
            query = '''SELECT node_ip
                       FROM Node 
                       WHERE platform_id = '%s' and node_device_type = %s
                    '''%(plt_id, node_type)
        else:
            query = '''SELECT node_ip
                       FROM Node 
                       WHERE platform_id = '%s'
                    '''%plt_id
        cursor = self.runquery(query)
        data = cursor.fetchall()
        nodes = []
        if data:
            for i in range(len(data)):
                nodes.append(data[i][0])
        return nodes
            
    def _mark_node_as_busy(self, ip):
        cur_busy_count=self.get_current_count('node',ip)
        query = '''UPDATE Node
                   SET node_busy = 'yes'
                   WHERE node_ip = '%s'
                '''%ip
        self.runquery(query)
        cur_busy_count=int(cur_busy_count)
        cur_busy_count+=1
        cur_busy_count=str(cur_busy_count)
        self.increment_busy_change_count('node',cur_busy_count,ip)
        return cur_busy_count
        
    def _mark_node_as_shared(self, ip):
        cur_busy_count=self.get_current_count('node',ip)
        query = '''UPDATE Node
                   SET node_busy = 'shared'
                   WHERE node_ip = '%s'
                '''%ip
        self.runquery(query)
        self.shared_nodes[ip] = self.shared_nodes.get('%s'%ip, 0) + 1
        cur_busy_count=int(cur_busy_count)
        cur_busy_count+=1
        cur_busy_count=str(cur_busy_count)
        self.increment_busy_change_count('node',cur_busy_count,ip)
        return cur_busy_count
        
    def node_busy(self, ip):
        query = '''SELECT node_busy
                   FROM Node
                   WHERE node_ip = '%s'
                '''%ip
        cursor = self.runquery(query)    
        data = cursor.fetchall()
            
        return data[0][0]
        
    def _mark_ap_as_busy(self, ip):
        cur_busy_count=self.get_current_count('ap',ip)
        query = '''UPDATE AP
                   SET ap_busy = 'yes'
                   WHERE ap_ip = '%s'
                '''%ip
        self.runquery(query)
        cur_busy_count=int(cur_busy_count)
        cur_busy_count+=1
        cur_busy_count=str(cur_busy_count)
        self.increment_busy_change_count('ap',cur_busy_count,ip)
        return cur_busy_count
        
        
    def _mark_ap_as_shared(self, ip):
        cur_busy_count=self.get_current_count('ap',ip)
        query = '''UPDATE AP
                   SET ap_busy = 'shared'
                   WHERE ap_ip = '%s'
                '''%ip
        self.runquery(query)
        self.shared_aps[ip] = self.shared_aps.get('%s'%ip, 0) + 1
        cur_busy_count=int(cur_busy_count)
        cur_busy_count+=1
        cur_busy_count=str(cur_busy_count)
        self.increment_busy_change_count('ap',cur_busy_count,ip)
        return cur_busy_count
        
    def ap_busy(self, ip):
        query = '''SELECT ap_busy
                   FROM AP
                   WHERE ap_ip = '%s'
                '''%ip
        cursor = self.runquery(query)    
        data = cursor.fetchall()
        return data[0][0]
        
    def get_current_count(self,tablename,resource):
        query='''SELECT busy_change_count
                 FROM %s
                 WHERE %s_ip= '%s'
              
               '''%(tablename,tablename.lower(),resource)
        cursor=self.runquery(query)
        data= cursor.fetchall()
        busy_count = data[0][0]
        if busy_count is None:
            busy_count = 0
        return busy_count
    
    def increment_busy_change_count(self, tablename, count, resource):
        query = '''UPDATE %s
                   SET busy_change_count = %s
                   WHERE %s_ip = '%s'
                '''%(tablename,count,tablename.lower(),resource)
        self.runquery(query)
             
    
    def total_nodes_in_platform(self, plt_id, node_type=None):
        if not node_type:
            query = '''SELECT COUNT(NODE_IP) 
                       FROM Node 
                       WHERE platform_id = '%s'
                    '''%(plt_id)
        else:
            query = '''SELECT COUNT(NODE_IP) 
                       FROM Node 
                       WHERE platform_id = '%s' and node_device_type = %s
                    '''%(plt_id,node_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]
    
    def total_aps_in_platform(self, plt_id):
        query = '''SELECT COUNT(AP_IP) 
                   FROM AP 
                   WHERE platform_id = '%s'
                '''%(plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]
        
    def free_nodes_in_platform(self, plt_id, node_type):
        if not node_type:
            query = '''SELECT COUNT(NODE_IP)
                       FROM Node 
                       WHERE node_busy = 'no' and platform_id = '%s' 
                    '''%(plt_id)
        else:
            query = '''SELECT COUNT(NODE_IP)
                       FROM Node 
                       WHERE node_busy = 'no' and platform_id = '%s' and node_device_type = %s
                    '''%(plt_id,node_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def free_aps_in_platform(self, plt_id):
        query = '''SELECT COUNT(AP_IP)
                   FROM AP
                   WHERE ap_busy = 'no' and platform_id = '%s'
                '''%(plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]
        
    def shared_aps_in_platform(self, plt_id):
        query = '''SELECT COUNT(AP_IP)
                   FROM AP
                   WHERE ap_busy = 'shared' and platform_id = '%s'
                '''%(plt_id)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]
        
    def shared_nodes_in_platform(self, plt_id, node_type):
        if not node_type:
            query = '''SELECT COUNT(NODE_IP)
                       FROM Node 
                       WHERE node_busy = 'shared' and platform_id = '%s' 
                    '''%(plt_id)
        else:
            query = '''SELECT COUNT(NODE_IP)
                       FROM Node 
                       WHERE node_busy = 'shared' and platform_id = '%s' and node_device_type = %s
                    '''%(plt_id,node_type)
        cursor = self.runquery(query)
        data = cursor.fetchall()
        return data[0][0]

    def allot_all_nodes(self,platform,project):
        plt_id = self.get_platform_id(platform, project)
        ttl_node_cnt = self.total_nodes_in_platform(plt_id)
        return self.allot_nodes(platform,project,ttl_node_cnt)
        
    def allot_all_aps(self,platform,project):
        plt_id = self.get_platform_id(platform, project)
        ttl_ap_cnt = self.total_aps_in_platform(plt_id)
        return self.allot_aps(platform,project,ttl_ap_cnt)

    def get_nodes(self, platform, project, num_of_nodes, node_type):
        plt_id = self.get_platform_id(platform,project)
        ttl_node_cnt = self.total_nodes_in_platform(plt_id)
        if num_of_nodes > ttl_node_cnt:
            return None, ttl_node_cnt
        self.lock.acquire()
        try:
            free_node_cnt = self.free_nodes_in_platform(plt_id, node_type)
            shared_node_cnt = self.shared_nodes_in_platform(plt_id, node_type)    
            if num_of_nodes > (shared_node_cnt + free_node_cnt):
                return None, ttl_node_cnt
            
            alloted_node_cnt = 0
            nodes_data = []
            clm_names=self.column_names('NODE')
            
            if not node_type:
                query = '''SELECT NODE_IP
                           FROM Node
                           WHERE node_busy = 'shared' and platform_id = '%s'
                        '''%plt_id
            else:
                query = '''SELECT NODE_IP
                           FROM Node
                           WHERE node_busy = 'shared' and platform_id = '%s' and node_device_type = %s
                        '''%(plt_id,node_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            
            for i in range(len(data)):
                self._mark_node_as_shared(data[i][0])
                query = '''SELECT *
                           FROM NODE
                           WHERE node_ip = '%s'
                        '''%(data[i][0])
                cursor=self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                nodes_data.append(node)
                alloted_node_cnt += 1
                if alloted_node_cnt == num_of_nodes:
                    return nodes_data, ttl_node_cnt
                    
            if not node_type:
                query = '''SELECT NODE_IP
                           FROM Node
                           WHERE node_busy = 'no' and platform_id = '%s'
                        '''%plt_id
            else:
                query = '''SELECT NODE_IP
                           FROM Node
                           WHERE node_busy = 'no' and platform_id = '%s' and node_device_type = %s
                        '''%(plt_id,node_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            
            for i in range(len(data)):
                self._mark_node_as_shared(data[i][0])
                query = '''SELECT *
                           FROM NODE
                           WHERE node_ip = '%s'
                        '''%(data[i][0])
                cursor=self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                nodes_data.append(node)
                alloted_node_cnt += 1
                if alloted_node_cnt == num_of_nodes:
                    return nodes_data, ttl_node_cnt
                    
        finally:
            self.lock.release()
        
    def allot_nodes(self, platform, project, num_of_nodes, node_type):
        plt_id = self.get_platform_id(platform,project)
        ttl_node_cnt = self.total_nodes_in_platform(plt_id)
        if num_of_nodes > ttl_node_cnt:
            return None, ttl_node_cnt
        self.lock.acquire()
        try:
            free_node_cnt = self.free_nodes_in_platform(plt_id, node_type)    
            if num_of_nodes > free_node_cnt:
                return None, ttl_node_cnt
            
            if not node_type:
                query = '''SELECT NODE_IP
                           FROM Node
                           WHERE node_busy = 'no' and platform_id = '%s'
                        '''%plt_id
            else:
                query = '''SELECT NODE_IP
                           FROM Node
                           WHERE node_busy = 'no' and platform_id = '%s' and node_device_type = %s
                        '''%(plt_id, node_type)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            
            alloted_node_cnt = 0
            nodes_data = []
            clm_names=self.column_names('Node')
            for i in range(len(data)):
                self._mark_node_as_busy(data[i][0])
                query = '''SELECT *
                           FROM Node 
                           WHERE node_ip = '%s'
                        '''%(data[i][0])
                cursor=self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                nodes_data.append(node)
                alloted_node_cnt += 1
                if alloted_node_cnt == num_of_nodes:
                    return nodes_data, ttl_node_cnt
        finally:
            self.lock.release()

    def get_aps(self, platform, project, num_of_aps):
        plt_id = self.get_platform_id(platform,project)
        ttl_ap_cnt = self.total_aps_in_platform(plt_id)
        if num_of_aps > ttl_ap_cnt:
            return None, ttl_ap_cnt
        self.lock.acquire()
        try:
            free_ap_cnt = self.free_aps_in_platform(plt_id)
            shared_ap_cnt = self.shared_aps_in_platform(plt_id)    
            if num_of_aps > (shared_ap_cnt + free_ap_cnt):
                return None, ttl_ap_cnt
            
            alloted_ap_cnt = 0
            aps_data = []
            clm_names=self.column_names('AP')
            
            query = '''SELECT AP_IP
                       FROM AP
                       WHERE ap_busy = 'shared' and platform_id = '%s'
                    '''%plt_id
            cursor = self.runquery(query)
            data = cursor.fetchall()
            
            for i in range(len(data)):
                self._mark_ap_as_shared(data[i][0])
                query = '''SELECT *
                           FROM AP 
                           WHERE ap_ip = '%s'
                        '''%(data[i][0])
                cursor=self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                aps_data.append(ap)
                alloted_ap_cnt += 1
                if alloted_ap_cnt == num_of_aps:
                    return aps_data, ttl_ap_cnt
                    
            query = '''SELECT AP_IP
                       FROM AP
                       WHERE ap_busy = 'no' and platform_id = '%s'
                    '''%plt_id
            cursor = self.runquery(query)
            data = cursor.fetchall()
            
            for i in range(len(data)):
                self._mark_ap_as_shared(data[i][0])
                query = '''SELECT *
                           FROM AP 
                           WHERE ap_ip = '%s'
                        '''%(data[i][0])
                cursor=self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                aps_data.append(ap)
                alloted_ap_cnt += 1
                if alloted_ap_cnt == num_of_aps:
                    return aps_data, ttl_ap_cnt
        finally:
            self.lock.release()    

    def allot_aps(self, platform, project, num_of_aps):
        plt_id = self.get_platform_id(platform,project)
        ttl_ap_cnt = self.total_aps_in_platform(plt_id)
        if num_of_aps > ttl_ap_cnt:
            return None, ttl_ap_cnt
        self.lock.acquire()
        try:
            free_ap_cnt = self.free_aps_in_platform(plt_id)    
            if num_of_aps > free_ap_cnt:
                return None, ttl_ap_cnt
                
            query = '''SELECT AP_IP
                       FROM AP
                       WHERE ap_busy = 'no' and platform_id = '%s'
                    '''%plt_id
            cursor = self.runquery(query)
            data = cursor.fetchall()
            
            alloted_ap_cnt = 0
            aps_data = []
            clm_names=self.column_names('AP')
            for i in range(len(data)):
                self._mark_ap_as_busy(data[i][0])
                query = '''SELECT *
                           FROM AP 
                           WHERE ap_ip = '%s'
                        '''%(data[i][0])
                cursor=self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                aps_data.append(ap)
                alloted_ap_cnt += 1
                if alloted_ap_cnt == num_of_aps:
                    return aps_data, ttl_ap_cnt
        finally:
            self.lock.release()
            
    def _all_nodes_with_attribute(self, attr_name, attr_values):
        nodes = []
        for attrv in attr_values:
            query = '''SELECT NODE_IP
                       FROM Node
                       WHERE %s = '%s'
                    '''%(attr_name, attrv)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                raise RuntimeError("Node table has no value '%s' for attribute '%s'"%(attrv, attr_name))
            for node in data[0]:
                if node not in nodes:
                    nodes.append(node)
        return nodes
        
    def allot_nodes_with_attribute(self, platform, project, attr_name, attr_values, lock):
        plt_id = self.get_platform_id(platform,project)
        
        if not isinstance(attr_values, list):
            raise RuntimeError("attribute values must be a list type")
        
        self.lock.acquire() 
        try:
            if attr_name.upper() != 'NODE_IP':
                nodes = self._all_nodes_with_attribute(attr_name, attr_values)
            else:
                nodes = attr_values
                
            clm_names=self.column_names('Node')
            nodes_data = []
            for node in nodes:
                if not self.is_node_exitsin_platform(node, plt_id):
                    raise RuntimeError("This node '%s' does not belong to platform '%s'" % (node, platform))
                status = self.node_busy(node)
                if status.lower() == 'yes' or (status.lower() == 'shared' and lock):
                    nodes_marked = [node['NODE_IP'] for node in nodes_data]
                    self.free_nodes(platform, project, nodes_marked)
                    nodes_data = []
                    break
                    
                if lock:    
                    self._mark_node_as_busy(node)
                else:
                    self._mark_node_as_shared(node)
                    
                query = '''SELECT *
                           FROM Node 
                           WHERE node_ip = '%s'
                        '''%(node)
                cursor=self.runquery(query)
                d = cursor.fetchall()
                node = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                nodes_data.append(node)
            return nodes_data
        finally:
            self.lock.release()    

    def _all_aps_with_attribute(self, attr_name, attr_values):
        aps = []
        for attrv in attr_values:
            query = '''SELECT AP_IP
                       FROM AP
                       WHERE %s = '%s'
                    '''%(attr_name, attrv)
            cursor = self.runquery(query)
            data = cursor.fetchall()
            if not data:
                raise RuntimeError("AP table has no value '%s' for attribute '%s'"%(attrv, attr_name))
            for ap in data[0]:
                if ap not in aps:
                    aps.append(ap)
        return aps
        
    def allot_aps_with_attribute(self, platform, project, attr_name, attr_values, lock):
        plt_id = self.get_platform_id(platform,project)
        
        if not isinstance(attr_values, list):
            raise RuntimeError("attribute values must be a list type")
        
        self.lock.acquire() 
        try:
            if attr_name.upper() != 'AP_IP':
                aps = self._all_aps_with_attribute(attr_name, attr_values)
            else:
                aps = attr_values
                
            clm_names=self.column_names('AP')
            aps_data = []
            for ap in aps:
                status = self.ap_busy(ap)
                if status.lower() == 'yes' or (status.lower() == 'shared' and lock):
                    aps_marked = [ap['AP_IP'] for ap in aps_data]
                    self.free_aps(platform, project, aps_marked)
                    aps_data = []
                    break
                    
                if lock:    
                    self._mark_ap_as_busy(ap)
                else:
                    self._mark_ap_as_shared(ap)
                    
                query = '''SELECT *
                           FROM AP 
                           WHERE ap_ip = '%s'
                        '''%(ap)
                cursor=self.runquery(query)
                d = cursor.fetchall()
                ap = {column[0]:column[1] for column in zip(*[ clm_names,list(d[0]) ])}
                aps_data.append(ap)
            return aps_data
        finally:
            self.lock.release()                
    
    def get_busy_resources(self,platform, project, resource):
        plt_id = self.get_platform_id(platform,project)
        query='''SELECT %s_IP
                FROM %s
                WHERE platform_id = '%s' and %s_busy != 'no'
            '''%(resource,resource,plt_id,resource)
        cursor=self.runquery(query)
        data=cursor.fetchall()
        res_data = []
        if data:
            for i in range(len(data)):
                res_data.append(data[i][0])
        return res_data
        
    def free_nodes(self, platform, project, nodes=None):
        plt_id = self.get_platform_id(platform,project)
        '''# it is important to compare with None, 
        "if not nodes:" gives True for empty list also, 
        in that case there are chances that accidentally
        a process can free the nodes alloted to another process.
        '''
        busy_count_list=[]
        if nodes == None:    
            query = '''UPDATE Node
                       SET node_busy = 'no'
                       WHERE platform_id = '%s'
                    '''%plt_id
            self.runquery(query)
            nodes=self.get_busy_resources(platform, project, 'node')
            for ip in nodes:
                cur_busy_count=self.get_current_count('node',ip)
                cur_busy_count=int(cur_busy_count)
                cur_busy_count+=1
                cur_busy_count=str(cur_busy_count)
                self.increment_busy_change_count('node',cur_busy_count,ip)
                busy_count_dict={}
                busy_count_dict[ip]=cur_busy_count
                busy_count_list.append(busy_count_dict)
            return busy_count_list
        else:
            for ip in nodes:
                cur_busy_count=self.get_current_count('node',ip)
                can_free = False
                node_shared_instances = self.shared_nodes.get('%s'%ip, 0)
                
                # if node is shared; decrease shared count of node
                if node_shared_instances:
                    self.shared_nodes[ip] = node_shared_instances - 1
                    # after decrease, if node shared count is 0; free node
                    if self.shared_nodes[ip] == 0:
                        del self.shared_nodes[ip]
                        can_free = True
                else:
                    # node is locked; not shared
                    can_free = True
                    
                if can_free:
                    query = '''UPDATE Node
                               SET node_busy = 'no'
                               WHERE node_ip = '%s'
                            '''%ip
                    self.runquery(query)
                    cur_busy_count=int(cur_busy_count)
                    cur_busy_count+=1
                    cur_busy_count=str(cur_busy_count)
                    self.increment_busy_change_count('node',cur_busy_count,ip)
                    busy_count_dict={}
                    busy_count_dict[ip]=cur_busy_count
                    busy_count_list.append(busy_count_dict)
            return busy_count_list 
                
    def free_aps(self, platform, project, aps=None):
        
        plt_id = self.get_platform_id(platform,project)
        '''# it is important to compare with None, 
        "if not aps:" gives True for empty list also, 
        in that case there are chances that accidentally
        a process can free the aps alloted to another process.
        '''
        busy_count_list=[]
        if 'AP' not in self.table_names():
            return busy_count_list
        if aps == None:    
            query = '''UPDATE AP
                       SET ap_busy = 'no'
                       WHERE platform_id = '%s'
                    '''%plt_id
            self.runquery(query)
            aps=self.get_busy_resources(platform, project, 'ap')
            for ip in aps:
                cur_busy_count=self.get_current_count('ap',ip)
                cur_busy_count=int(cur_busy_count)
                cur_busy_count+=1
                cur_busy_count=str(cur_busy_count)
                self.increment_busy_change_count('ap',cur_busy_count,ip)
                busy_count_dict={}
                busy_count_dict[ip]=cur_busy_count
                busy_count_list.append(busy_count_dict)
            return busy_count_list
        else:
            for ip in aps:
                cur_busy_count=self.get_current_count('ap',ip)
                can_free = False
                ap_shared_instances = self.shared_aps.get('%s'%ip, 0)
                
                # if ap is shared; decrease shared count of ap
                if ap_shared_instances:
                    self.shared_aps[ip] = ap_shared_instances - 1
                    # after decrease, if ap shared count is 0; free ap
                    if self.shared_aps[ip] == 0:
                        del self.shared_aps[ip]
                        can_free = True
                else:
                    # ap is locked; not shared
                    can_free = True
                    
                if can_free:
                    query = '''UPDATE AP
                               SET ap_busy = 'no'
                               WHERE ap_ip = '%s'
                            '''%ip
                    self.runquery(query)
                    cur_busy_count=int(cur_busy_count)
                    cur_busy_count+=1
                    cur_busy_count=str(cur_busy_count)
                    self.increment_busy_change_count('ap',cur_busy_count,ip)
                    busy_count_dict={}
                    busy_count_dict[ip]=cur_busy_count
                    busy_count_list.append(busy_count_dict)
            return busy_count_list 

    def nodedict_from_db(self):
        query = 'SELECT * FROM "NODE"'
        cursor = self.runquery(query)

        rows = cursor.fetchall()
        colnames = self.column_names('Node')

        kzbot_gen5dev_dict = {}
        for x, row in enumerate(rows):
            for col, row in zip(colnames, row):
                if rows[x][0] in kzbot_gen5dev_dict.keys():
                    kzbot_gen5dev_dict[rows[x][0]].update({col: row})
                else:
                    kzbot_gen5dev_dict[rows[x][0]] = {col: row}
        return kzbot_gen5dev_dict

if __name__ == '__main__':
    import sys
    RobotRemoteServer(KBotDBServer(sys.argv[1]), host=sys.argv[2],
                      port=sys.argv[3], allow_stop=True)
