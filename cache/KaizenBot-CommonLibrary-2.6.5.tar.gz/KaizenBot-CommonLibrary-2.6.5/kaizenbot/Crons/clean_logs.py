import os, sys
import time
from datetime import datetime
import paramiko

dayinsec=86400
numofdays=60
current_time = time.time()
print(current_time)
user=sys.argv[1]
project=sys.argv[2]

client=paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(hostname='127.0.0.1', port=22, username=user, password='Itron@123')
client.invoke_shell()
transport = client.get_transport()
transport.set_keepalive(86400)

print('/home/%s/%s/Output_Directory/'%(user,project))
os.chdir('/home/%s/%s/Output_Directory/'%(user,project))

fh = open('/home/siraj/clean_up_%s.log'%user,'a+')

#for cdir, subdir, files in os.walk(os.getcwd()):
for cdir in os.listdir():
    cdir = os.path.join(os.getcwd(),cdir)
    #print(current_time-os.path.getmtime(cdir))
    #print(dayinsec*numofdays)
    if current_time-os.path.getmtime(cdir) > dayinsec*numofdays:
        print(cdir,os.path.getmtime(cdir))
        client.exec_command('rm -rf %s'%cdir)
        fh.write('%s directory deleted at %s\n'%(cdir,datetime.fromtimestamp(current_time).strftime("%m/%d/%Y, %H:%M:%S")))
        print(cdir,' deleted')
        #input()
fh.close()
client.close()
