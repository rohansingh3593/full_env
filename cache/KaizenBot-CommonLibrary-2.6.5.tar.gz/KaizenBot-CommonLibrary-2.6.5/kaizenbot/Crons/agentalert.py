import smtplib, os, sys
from kaizenbot.azurelibrary import AzureLibrary
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import timedelta

#Constants
AGENT_CLIENT = "azure.devops.v6_0.task_agent.task_agent_client.TaskAgentClient"
agent_pool_id_list = ['179', '161', '124']
mailfrom = 'kaizenbot@kaizenbot.itron.com'
mailto = ['rajasekhar.inguva@itron.com', 'sirajdeen.hameedkamsa@itron.com']
subject = 'Agent Down Alert!'
style='''<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-xfvv{background-color:#fffc9e;border-color:inherit;font-weight:bold;text-align:left;vertical-align:top}
.tg .tg-x6qq{background-color:#dae8fc;border-color:inherit;text-align:left;vertical-align:top}
.tg-sort-header::-moz-selection{background:0 0}
.tg-sort-header::selection{background:0 0}.tg-sort-header{cursor:pointer}
.tg-sort-header:after{content:'';float:right;margin-top:7px;border-width:0 5px 5px;border-style:solid;
  border-color:#404040 transparent;visibility:hidden}
.tg-sort-header:hover:after{visibility:visible}
.tg-sort-asc:after,.tg-sort-asc:hover:after,.tg-sort-desc:after{visibility:visible;opacity:.4}
.tg-sort-desc:after{border-bottom:none;border-width:5px 5px 0}</style>'''
thead = '<thead><tr>' + ''.join(map(lambda x: '<th class="tg-xfvv">' + x + '</th>', ['Agent_Name','Agent_Version','Status','Enabled','Last Status Change(IST)','Agent Pool'])) +'</tr></thead>'

class AgentAlert(AzureLibrary):
    def __init__(self):
        super().__init__(pat='ckfxnjjkwqao5uf37arlbtt2luuszvoxal4hsghjrnkmrnubxiqa')

    def get_poolname(self, pool_id):
        self.connection = self._authentication()
        agent_client = self.connection.get_client(AGENT_CLIENT)
        return agent_client.get_agent_pool(pool_id).name

    def list_agent(self, pool_id):
        self.connection = self._authentication()
        agent_client = self.connection.get_client(AGENT_CLIENT)
        return agent_client.get_agents(pool_id)

    def list_offline_agents(self, pool_id):
        tot_agent = self.list_agent(pool_id)
        down_list = [agent for agent in tot_agent if agent.status == 'offline' and agent.enabled]
        return down_list

    @staticmethod
    def send_mail(From, To, Subject, Body):
        try:
            email = MIMEMultipart('alternative')
            email['From'] = mailfrom
            email['To'] = ','.join(mailto)
            email['Subject'] = subject
            html_body = MIMEText(body, 'html')
            email.attach(html_body)

            smtpObj = smtplib.SMTP('localhost') if os.name != 'nt' else smtplib.SMTP('ban-w170401.itron.com')
            smtpObj.send_message(email)
            print("Successfully sent email")
        except smtplib.SMTPException as e:
            print(e)
            print("Error: unable to send email")


if __name__ == '__main__':
    try:
        obj = AgentAlert()
        html_content = ''
        tot_down = 0
        to_send = False
        for id in agent_pool_id_list:
            down_agent = obj.list_offline_agents(id)
            agent_poolname = obj.get_poolname(id)
            if to_send != True and len(down_agent) > 0:
                to_send = True
            if down_agent:
                tot_down += len(down_agent)

            for agent in down_agent:
                tz_delta = timedelta(minutes = 30, hours = 5)
                last_status_change_IST = agent.status_changed_on + tz_delta
                map_obj = map(lambda x: '<td class="tg-x6qq">' + x + '</td>',\
                              [agent.name,agent.version,agent.status,str(agent.enabled),last_status_change_IST.strftime("%m/%d/%Y, %I:%M:%S %p"),agent_poolname])
                content = '<tr>' + ''.join(map_obj) + '</tr>'
                html_content += content
            tbody = '<tbody>' + html_content + '</tbody>'

        body = '<p>Dear Admin,<br><br>Total Agent down:%s</p>'%tot_down + style + '<table id="tg-2w4HN" class="tg">'\
           + thead + tbody + '</table>' + '<br>Disclaimer: Do not reply! This is an automated email to alert you that few agents are down. Please check the AgentPool.' + '<br><br>Regards,<br>Team KaizenBot'
        if to_send:
            obj.send_mail(mailfrom, mailto, subject, body)
        else:
            print ('All Agents are Up and Running')
            sys.exit(0)
    except Exception as e:
        print(e)
        print('Error:Please check the code')
        sys.exit(1)
