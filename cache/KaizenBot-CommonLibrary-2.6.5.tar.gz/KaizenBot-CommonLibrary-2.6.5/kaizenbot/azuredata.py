import os

if not os.environ.get('AGENT_OS'):
    pat= 'vamal7crzrrmsuc3y75k5y6mgrudbec5qtbcmytonj4ge5t75jzq'
    update = False
    TestPlanID= '1870820'
    TestSuiteID='1934529'
    IncludeTag=''
    ExcludeTag=''
    tester='Shweta Kaushik'
    parallel = False
else:
    update = True
    pat = os.environ.get('KAIZENBOT_USERPAT')
    TestPlanID= os.environ.get('KAIZENBOT_TPLANID')
    buildname= os.environ.get('KAIZENBOT_BUILDNAME')
    TestSuiteID= os.environ.get('KAIZENBOT_SUITEID')
    IncludeTag = os.environ.get('KAIZENBOT_INCLUDETAGS')
    ExcludeTag = os.environ.get('KAIZENBOT_EXCLUDETAGS')
    tester = os.environ.get('KAIZENBOT_USERNAME')
    parallel = os.environ.get('KAIZENBOT_PIPELINE')
