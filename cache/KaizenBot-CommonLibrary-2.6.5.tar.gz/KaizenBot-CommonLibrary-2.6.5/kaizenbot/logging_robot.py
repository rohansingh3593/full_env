# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential 
  information, ideas and expressions. No part of which may be reproduced or 
  transmitted in any form or by any means electronic, mechanical, or otherwise. 
  Including photocopying and recording or in connection with any information 
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2020
                                Itron, Inc.
"""
import logging, os, sys
from time import strftime, localtime

if(os.name=='nt'):
    DestDir = os.path.join(os.getcwd(), "TraceLogs")
else:
    DestDir = os.environ.get('KAIZENBOT_INTERNAL_OUTDIR')
    if DestDir is None:
        DestDir = os.path.join(os.getcwd(), "TraceLogs")
    else:
        '''check if DestDir is a directory'''
        if os.path.isdir(DestDir):
            '''Give Permissions to folder'''
            os.system('chmod 777 '+ str(DestDir))
        else:
            raise Exception("Directory {} does not exists".format(DestDir))
    
if(not os.path.exists(DestDir)):
    os.mkdir(DestDir)
    
logFile = 'Trace_Log %s.txt' % (strftime("%Y-%m-%d %Hh-%Mm-%Ss", localtime()))
filepath = DestDir+'/'+logFile

'''Create formatter and add it to the handlers'''
c_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

#logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.INFO)

class Loggers:
    def __init__(self):
        pass
    
    def get_console_handler(self):
       console_handler = logging.StreamHandler()
       console_handler.setLevel(logging.ERROR)
       console_handler.setFormatter(c_format)
       return console_handler
    
    def get_file_handler(self):
       file_handler = logging.FileHandler(filepath, mode='a+')
       file_handler.setLevel(logging.DEBUG)
       file_handler.setFormatter(f_format)
       return file_handler
    
    def get_logger(self, logger_name):
        loggers = logging.getLogger(logger_name)
        loggers.setLevel(logging.DEBUG)
        loggers.addHandler(self.get_console_handler())
        loggers.addHandler(self.get_file_handler())
        # with this pattern, it's rarely necessary to propagate the error up to parent
        loggers.propagate = False
        return loggers
