from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger
import time, logging
from kaizenbot.kbotdbserver_psql import KBotDBServer
from kaizenbot.Misc.kbotdbconfig import DB_Dict


def _to_str_list(string, sep=','):
    """This converts str, int,list of ints, string-like-list of ints and string-like-list of strs to list of strs.
    1 --> ['1'] #int
    '1' --> ['1']    #str
    "1,2,3" --> ['1','2','3']    #str
    [1,2,3] --> ['1','2','3']    #list of ints
    ['1','2','3'] --> ['1','2','3']    # list of strs
    "[1,2,3]" --> ['1','2','3']    #string-like-list of ints
    "['1','2','3']" --> ['1','2','3']    #string-like-list of strs
    
    It also handles extra separators ``sep``.
    ",1,2,,3," --> ['1','2','3']
    """
    if isinstance(string, (str, int)):
        string = str(string)
        string = string.replace(' ', '')
        string = string.replace('[', '')
        string = string.replace(']', '')
        string = string.replace("'", '')  # string = string.replace('\'', '')
        string = string.replace('"', '')
        string = string.split(sep)
        while '' in string:
            string.remove('')

    elif isinstance(string, list):
        tmp = []
        for each_str in string:
            tmp.append(str(each_str))
        string = tmp

    else:
        raise TypeError

    return string


class _KBotDBClient_psql:
    def __init__(self, uri, owner, project, schema):
        self.__remotelib = None
        self.uri = uri
        self.owner = owner
        self.project = project
        self.platform = None
        self.schema = schema
        my_dict = DB_Dict[self.uri][self.schema]
        self.obj = KBotDBServer(pgdb=my_dict.get('db_name'), pguser=my_dict.get('db_user'),
                                pgpswd=my_dict.get('db_pwd'), pghost=self.uri.split(':')[0],
                                pgport=self.uri.split(':')[1])

    def acquire_platform(self, nowait, platform):
        platform = self._acquire_platform(nowait, platform)
        if platform is None:
            raise ValueError("Could not acquire a Platform")
        return platform

    def _acquire_platform(self, nowait, platform):
        logger = logging.getLogger("KaizenBot-DBClient-Psql")
        try:
            while True:
                _platform, owner_name = self.obj.acquire_platform(self.schema, platform, self.owner, self.project)

                if _platform:
                    logger.info('Platform "%s" acquired' % _platform)
                    print('Platform "%s" acquired' % _platform)
                    self.platform = _platform
                    return _platform

                if platform.upper() == 'ANY':
                    msg = "All platforms are busy"
                else:
                    msg = "Platform '%s' is acquired by %s" % (platform, owner_name)

                if nowait:
                    raise ValueError(msg)
                time.sleep(0.1)
                logger.debug(msg)
                print(msg)
        except RuntimeError:
            logger.error('No connection - is Resource Server running?')
            self.__remotelib = None
            raise
        return

    def release_platform(self):
        if self.platform:
            return self.obj.release_platform(self.schema, self.platform, self.owner, self.project)

    def capture_runinfo(self, pipe_link, test_link, elapsed_time):
        if pipe_link:
            self.obj.update_agentinfo_table(), self.obj.update_runinfo_table(pipe_link, test_link, elapsed_time)
        return

    def allot_all_nodes(self):
        if not self.platform:
            return None
        #plt_id = self._run_with_lib('get_platform_id', self.platform,self.project)
        plt_id = self.obj.get_platform_id(self.schema, self.platform, self.project)
        #ttl_nodes_cnt = self._run_with_lib('total_nodes_in_platform', plt_id)
        ttl_nodes_cnt = self.obj.total_nodes_in_platform(self.schema, plt_id)
        return self.obj.allot_nodes(self.schema, self.platform,self.project, ttl_nodes_cnt)
    
    def read_all_nodes(self, node_type=None):
        if not self.platform:
            return None
        #plt_id = self._run_with_lib('get_platform_id', self.platform,self.project)
        plt_id = self.obj.get_platform_id(self.schema, self.platform, self.project)
        #return self._run_with_lib('read_nodes', plt_id, node_type)
        return self.obj.read_nodes(self.schema, plt_id, node_type)
        
    def total_nodes_count(self):
        if not self.platform:
            return -1
        #plt_id = self._run_with_lib('get_platform_id', self.platform,self.project)
        plt_id = self.obj.get_platform_id(self.schema, self.platform, self.project)
        #ttl_nodes_cnt = self._run_with_lib('total_nodes_in_platform', plt_id)
        ttl_nodes_cnt = self.obj.total_nodes_in_platform(self.schema, plt_id)
        return ttl_nodes_cnt


class KBotDBClient_psql:
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    ROBOT_LIBRARY_VERSION = '1.0'

    def __init__(self):
        self.__platform = None
        self.__schema = None
        self.__project = None
        self.__uri = None
        self.__remotelib = None
        self._nodes = []
        self._aps = []
        self.__obj = None

    @property
    def _platform(self):
        try:
            self.__platform = BuiltIn().get_variable_value('${PLATFORM}')
            my_dict = DB_Dict[self._uri][self._schema]
            self.__obj = KBotDBServer(pgdb=my_dict.get('db_name'), pguser=my_dict.get('db_user'),
                                      pgpswd=my_dict.get('db_pwd'), pghost=self._uri.split(':')[0],
                                      pgport=self._uri.split(':')[1])
        except Exception:
            pass
        return self.__platform

    @property
    def _schema(self):
        try:
            self.__schema = BuiltIn().get_variable_value('${SCHEMA}')
        except Exception:
            pass
        return self.__schema

    @property
    def _project(self):
        try:
            self.__project = BuiltIn().get_variable_value('${PROJECT}')
        except Exception:
            pass
        return self.__project

    @property
    def _uri(self):
        try:
            self.__uri = BuiltIn().get_variable_value('${URI}')
        except Exception:
            pass
        return self.__uri

    def allot_all(self, timeout='3600', lock=True):
        """This allots all resources from acquired platform.
        This returns a list of count of alloted resources of each type.
        The counts will be in alphabetical order based on name of the resources.
        
        Example: [2,4] # 2 is count of alloted APs and 4 is count of alloted nodes.
        6 test variables will be available as AP1, AP2, NODE1, NODE2, NODE3, NODE4.
        Each variable will be a robot dictionary.
        
        Considering ${NODE1} dictionary has a key `IP`, it can be accessed either as 
        ${NODE1}[IP] or ${NODE1.IP}. Similarly, considering ${AP1} dictionary has a key `IP`, it 
        can be accessed either as ${AP1}[IP] or ${AP1.IP}.
        
        By default, ``timeout`` is 3600 seconds and ``lock`` is ``True``.
        If a false value to ``lock`` is given all resources will become sharable.
        
        ``All Keys will be in upper case. Key names will be similar as in the resource database.``
        
        ``All variables will be test variables (scope of variables will be within the test case).``
        
        Note: It is recommended to use this keyword in test setup.
        """
        plt_id = self.__obj.get_platform_id(self._schema, self._platform, self._project)
        ttl_nodes_cnt = self.__obj.total_nodes_in_platform(self._schema, plt_id)
        ttl_aps_cnt = self.__obj.total_aps_in_platform(self._schema, plt_id)
        return self.allot_aps(ttl_aps_cnt, timeout, lock), self.allot_nodes(None, ttl_nodes_cnt, timeout, lock)

    def allot_nodes(self, node_type=None, num_of_nodes=1, timeout='3600', lock=True):
        """It exclusively(default i.e. lock=True) allots as many nodes as given in ``num_of_nodes`` of node_type given
         in ``node_type``.
        
        By default ``node_type`` is ``None`` and ``num_of_nodes`` is 1 
        which means first free node (regardless of the node type) will be alloted.
        
        A specific node type can be given in ``node_type`` and any number of nodes can be requested using ``num_of_nodes``.
        A value ``all`` to ``num_of_nodes`` will allot all nodes from acquired platform.
        
        Default timeout is ``3600`` seconds.
        If a false value to ``lock`` is given all nodes will become sharable. 
        
        ``It is important to notice that nodes have incremental indexing. 
        So if any node variables already have been created by allot category keywords within the test scope, 
        the node variables will start from the next index.``
        
        Assuming no node variables have been created before in the test scope. 
        Nodes will be available as ``NODE1``, ``NODE2`` and so on; till the ``num_of_nodes`` each as robot dictionary
        variable and a value can be accessed using syntax ${NODE1}[key] or ${NODE1.key}.
        
        
        This returns the number of nodes alloted.
        
        Example:
        
        | `Allot Nodes` | node_type=91 | num_of_nodes=4   |  timeout=300 | lock=False | # allot 4 sharable nodes of node_type 91; exit if 4 nodes are not free even after 300 seconds.         |
        | `Allot Nodes` | node_type=15 | timeout=300      |              |            | # exclusively allot 1 nodes of node_type 15; exit if 1 nodes are not free even after 300 seconds.      |
        | `Allot Nodes` | node_type=15 | num_of_nodes=4   |              |            | # exclusively allot 4 nodes of node_type 15; exit if 4 nodes are not free even after 3600 seconds.     |
        | `Allot Nodes` | node_type=91 |                  |              |            | # exclusively allot 1 nodes of node_type 91; exit if 1 nodes are not free even after 3600 seconds.     |
        | `Allot Nodes` | node_type=91 | num_of_nodes=all |              |            | # exclusively allot all nodes of node_type 91; exit if all nodes are not free even after 3600 seconds. |
        
        Considering ${NODE1} dictionary has a key `IP`, it can be accessed either as 
        ${NODE1}[IP] or ${NODE1.IP}.
        
        ``All Keys will be in upper case. Key names will be similar as in the resource database.``
        
        ``All variables will be test variables (scope of variables will be within the test case).``
        
        Note: It is recommended to use this keyword in test setup. 
        """
        if not self._platform:
            raise RuntimeError("No platform is acquired")

        plt_id = self.__obj.get_platform_id(self._schema, self._platform, self._project)
        ttl_nodes = self.__obj.total_nodes_in_platform(self._schema, plt_id, node_type)

        if str(num_of_nodes).lower() == 'all':
            num_of_nodes = ttl_nodes

        try:
            num_of_nodes = int(num_of_nodes)
        except Exception:
            raise ValueError("'num_of_nodes' should be an integer or string convertible to integer")

        if int(ttl_nodes) < num_of_nodes:
            if node_type:
                msg = "Platform '%s' has only %s active nodes of type %s but requested %s nodes" % (
                    self._platform, str(ttl_nodes), str(node_type), str(num_of_nodes))
            else:
                msg = "Platform '%s' has only %s active nodes but requested %s nodes" % (
                    self._platform, str(ttl_nodes), str(num_of_nodes))
            raise RuntimeError(msg)

        if num_of_nodes <= 0:
            logger.info("Requested nodes' count: %s" % str(num_of_nodes))
            return 0

        logger.info("Requested nodes' count: %s" % str(num_of_nodes))
        node_values = self._allot_nodes(self._schema, self._platform, self._project, num_of_nodes, node_type, timeout,
                                        lock)

        if not node_values:
            raise ValueError("Could not allot nodes")

        if num_of_nodes != len(node_values):
            raise AssertionError("Could not allot requested number of nodes")

        logger.info("Alloted nodes' count: %s" % str(num_of_nodes))

        nodelists = []  # type List[List[str]]
        for node_value in node_values:
            nodelist = []
            for key, value in node_value.items():
                if value == '':
                    value = '${None}'
                nodelist.append("%s=%s" % (str(key).upper(), str(value)))
            nodelists.append(nodelist)

        ttl_cnt_of_allotted_nodes = len(self._nodes)
        for i in range(ttl_cnt_of_allotted_nodes, ttl_cnt_of_allotted_nodes + num_of_nodes):
            try:
                BuiltIn().set_test_variable('&{NODE' + str(i + 1) + '}', *nodelists[i - (ttl_cnt_of_allotted_nodes)])
            except Exception:
                BuiltIn().set_suite_variable('&{NODE' + str(i + 1) + '}', *nodelists[i - (ttl_cnt_of_allotted_nodes)])

        # node_values type List[DICT{str:str}]
        for node_value in node_values:
            self._nodes.append(node_value['NODE_IP'])
            logger.info("Busy count of Resource {}: {}".format(node_value['NODE_IP'], node_value['BUSY_CHANGE_COUNT']))
        return num_of_nodes

    def allot_bpds(self, num_of_bpds=1, bpd_type=None):
        """It exclusively allots as many bpds as given in ``num_of_bpds`` of bpd_type given
         in ``bpd_type``.

        By default ``bpd_type`` is ``None`` and ``num_of_bpds`` is 1
        which means first free bpd (regardless of the BPD type) will be alloted.

        A specific bpd type can be given in ``bpd_type`` and any number of nodes can be requested using ``num_of_bpds``.
        A value ``all`` to ``num_of_bpds`` will allot all bpds from acquired platform.

        Assuming no bpd variables have been created before in the test scope.
        Nodes will be available as ``BPD1``, ``BPD2`` and so on; till the ``num_of_bpds`` each as robot dictionary
        variable and a value can be accessed using syntax ${BPD1}[key] or ${NODE1.key}.

        This returns the number of bpds alloted.

        Example:

        | `Allot Bpds` | num_of_bpds=1   | bpd_type=GAS   | # allot 1 node of bpd_type GAS               |
        | `Allot Bpds` | num_of_bpds=all | bpd_type=WATER | # exclusively allot all bpds of WATER        |
        | `Allot Bpds` | num_of_bpds=all |                | # exclusively allot all bpds of any bpd_type |
        | `Allot Bpds` | num_of_bpds=20  | bpd_type=GAS   | # exclusively allot 20 bpds of bpd_type GAS  |
        | `Allot Bpds` |                 |                | # exclusively allot 1 bpd of any bpd_type    |

        ``All Keys will be in upper case. Key names will be similar as in the resource database.``

        ``All variables will be test/suite variables (scope of variables will be within the test case/test suite).``

        Note: It is recommended to use this keyword in test setup or suite setup.
        """
        if not self._platform:
            raise RuntimeError("No platform is acquired")

        plt_id = self.__obj.get_platform_id(self._schema, self._platform, self._project)
        ttl_bpds = self.__obj.total_bpds_in_platform(self._schema, plt_id, bpd_type)

        if str(num_of_bpds).lower() == 'all':
            num_of_bpds = ttl_bpds

        try:
            num_of_bpds = int(num_of_bpds)
        except Exception:
            raise ValueError("'num_of_bpds' should be an integer or string convertible to integer")

        if int(ttl_bpds) < num_of_bpds:
            if not bpd_type:
                msg = "Platform '%s' has only %d active BPDS but requested %d BPDS" % (
                self._platform, ttl_bpds, num_of_bpds)
            else:
                msg = "Platform '%s' has only %d active %s BPDS but requested %d BPDS" % (
                self._platform, ttl_bpds, bpd_type, num_of_bpds)
            raise RuntimeError(msg)

        if num_of_bpds <= 0:
            logger.info("Requested bpds' count: %d is invalid" % num_of_bpds)
            return 0

        logger.info("Requested bpds' count: %d" % num_of_bpds) if not bpd_type else logger.info("Requested %s bpds' count: %d" % (bpd_type, num_of_bpds))

        # ret type Tuple(List[DICT{str:str}],int)
        bpd_values = self.__obj.allot_bpds(self._schema, self._platform, self._project, num_of_bpds, bpd_type)[0]

        if not bpd_values:
            raise ValueError("Could not allot bpds")

        if num_of_bpds != len(bpd_values):
            raise AssertionError("Could not allot requested number of bpds")

        logger.info("Alloted bpds' count: %s" % str(num_of_bpds))

        # bpdlists type is List[List[str]]
        bpdlists = [['%s=%s'%(key,val if val!='' else '${None}') for key,val in bpd_val.items()] for bpd_val in bpd_values]

        ttl_cnt_of_allotted_bpds = len(bpd_values)
        for i in range(0, ttl_cnt_of_allotted_bpds):
            try:
                BuiltIn().set_test_variable('&{BPD' + str(i + 1) + '}', *bpdlists[i])
            except Exception:
                BuiltIn().set_suite_variable('&{BPD' + str(i + 1) + '}', *bpdlists[i])

        for node_value in bpd_values:
            logger.info("Busy count of Resource {}: {}".format(node_value['BPD_MAC'], node_value['BUSY_CHANGE_COUNT']))
        return num_of_bpds

    def allot_bpds_by_mac(self, bpd_mac):
        """It exclusively allots a bpd based on given ``mac``. Can be a single or many

        This returns the name of the robot dictionary variable.

        Example:
        `Allot Bpds By Mac` |           00078147B01D01CD         | # exclusively allot the bpd based on single mac   |
        `Allot Bpds By Mac` | 00078147B01D01CD,00078147B01D01CE  | # exclusively allot the bpds based on multiple mac|

        ``All Keys will be in upper case. Key names will be similar as in the resource database.``

        ``All variables will be test/suite variables (scope of variables will be within the test-case/test-suite).``

        Note: It is recommended to use this keyword in test setup or suite setup.
        """
        if not self._platform:
            raise RuntimeError("No platform is acquired")

        if not bpd_mac:
            raise ValueError("'bpd_mac' can not be none/empty")

        mac_list = _to_str_list(bpd_mac)
        #bpd_values ret type List[DICT{str:str}]
        bpd_values = self.__obj.allot_bpds_with_attribute(self._schema, self._platform, self._project, 'bpd_mac', mac_list)

        if not bpd_values:
            raise ValueError("Could not allot bpds")

        logger.info("Alloted bpds' count: %d" % len(bpd_values))

        # bpdlists type is List[List[str]]
        bpdlists = [['%s=%s' % (key, val if val != '' else '${None}') for key, val in bpd_val.items()] for bpd_val in
                    bpd_values]

        ttl_cnt_of_allotted_bpds = len(bpd_values)
        for i in range(0, ttl_cnt_of_allotted_bpds):
            try:
                BuiltIn().set_test_variable('&{BPD' + str(i + 1) + '}', *bpdlists[i])
            except Exception:
                BuiltIn().set_suite_variable('&{BPD' + str(i + 1) + '}', *bpdlists[i])

        for node_value in bpd_values:
            logger.info("Busy count of Resource {}: {}".format(node_value['BPD_MAC'], node_value['BUSY_CHANGE_COUNT']))
        return len(bpd_values)


    def allot_aps(self, num_of_aps=1, timeout='3600', lock=True):
        """It exclusively(default i.e. lock=True) allots as many APs as given in ``num_of_aps``.

        By default only 1 AP will be alloted. Any number of APs can be requested using ``num_of_aps``.
        A value ``all`` to ``num_of_aps`` will allot all APs from acquired platform.
        
        Default timeout is ``3600`` seconds.
        If a false value to ``lock`` is given all APs will become sharable. 

        ``It is important to notice that APs have incremental indexing. 
        So if any AP variables already have been created by allot category keywords within the test scope, 
        the AP variables will start from the next index.``
        
        Assuming no AP variables have been created before in the test scope.         
        APs will be available as ``AP1``, ``AP2`` and so on; till the ``num_of_aps`` each as robot dictionary variable
        and a value can be accessed using syntax ${AP1}[key] or ${AP1.key}.
        
        This returns the number of aps alloted.
        
        Example:
        
        | `Allot APs` | num_of_aps=4   |  timeout=300 | lock=False | # allot 4 sharable aps; exit if 4 aps are not free even after 300 seconds.         |
        | `Allot APs` | timeout=300    |              |            | # exclusively allot 1 aps; exit if 1 aps are not free even after 300 seconds.      |
        | `Allot APs` | num_of_aps=4   |              |            | # exclusively allot 4 aps; exit if 4 aps are not free even after 3600 seconds.     |
        | `Allot APs` |                |              |            | # exclusively allot 1 aps; exit if 1 aps are not free even after 3600 seconds.     |
        | `Allot APs` | num_of_aps=all |              |            | # exclusively allot all aps; exit if all aps are not free even after 3600 seconds. |
        
        Considering ${AP1} dictionary has a key `IP`, it can be accessed either as 
        ${AP1}[IP] or ${AP1.IP}.
        
        ``All Keys will be in upper case. Key names will be similar as in the resource database.``
        
        ``All variables will be test variables (scope of variables will be within the test case).``
        
        Note: It is recommended to use this keyword in test setup. 
        """
        if not self._platform:
            raise RuntimeError("No platform is acquired")
        if str(num_of_aps).lower() == 'all':
            plt_id = self.__obj.get_platform_id(self._schema, self._platform, self._project)
            num_of_aps = self.__obj.total_aps_in_platform(self._schema, plt_id)

        try:
            num_of_aps = int(num_of_aps)
        except:
            raise ValueError("'num_of_aps' should be an integer or string convertible to integer")
        if num_of_aps <= 0:
            logger.info("Requested APs' count: %s" % str(num_of_aps))
            return 0

        logger.info("Requested APs' count: %s" % str(num_of_aps))
        ap_values = self._allot_aps(self._schema, self._platform, self._project, num_of_aps, timeout, lock)

        if not ap_values:
            raise ValueError("Could not allot APs")

        if num_of_aps != len(ap_values):
            raise AssertionError("Could not allot requested number of APs")

        logger.info("Alloted APs' count: %s" % str(num_of_aps))

        aplists = []  # type List[List[str]]
        for ap_value in ap_values:
            aplist = []
            for key, value in ap_value.items():
                if value == '':
                    value = '${None}'
                aplist.append("%s=%s" % (str(key), str(value)))
            aplists.append(aplist)

        ttl_cnt_of_allotted_aps = len(self._aps)
        for i in range(ttl_cnt_of_allotted_aps, ttl_cnt_of_allotted_aps + num_of_aps):
            try:
                BuiltIn().set_test_variable('&{AP' + str(i + 1) + '}', *aplists[i - (ttl_cnt_of_allotted_aps)])
            except Exception:
                BuiltIn().set_suite_variable('&{AP' + str(i + 1) + '}', *aplists[i - (ttl_cnt_of_allotted_aps)])

        # ap_values type List[DICT{str:str}]
        for ap_value in ap_values:
            self._aps.append(ap_value['AP_IP'])
            logger.info("Busy count of Resource {}: {}".format(ap_value['AP_IP'], ap_value['BUSY_CHANGE_COUNT']))
        return num_of_aps

    def allot_node_with_ip_or_mac(self, ip=None, mac=None, timeout='3600', lock=True):
        """It exclusively(default i.e. lock=True) allots a node based on given ``ip`` or ``mac``.
        
        Default timeout is ``3600`` seconds.
        If a false value to ``lock`` is given node will become sharable.
        
        This returns the name of the robot dictionary variable.
        
        Example:
        
        | ${mynode}= | `Allot Node With Ip Or Mac` | ip=10.21.101.34  | timeout=300      | lock=False | # allot the node as sharable based o ip; exit if the node is not free even after 300 seconds.    |
        | ${mynode}= | `Allot Node With Ip Or Mac` | ip=10.21.101.34  | timeout=300      |            | # exclusively allot the node based on ip; exit if the node is not free even after 300 seconds.   |
        | ${mynode}= | `Allot Node With Ip Or Mac` | mac=10:21:101:34 |                  |            | # exclusively allot the node based on mac; exit if the node is not free even after 3600 seconds. |
        | ${mynode}= | `Allot Node With Ip Or Mac` | ip=10.21.101.34  | mac=10:21:101:35 |            | # exclusively allot the node based on ip; exit if the node is not free even after 3600 seconds.  |
        | ${mynode}= | `Allot Node With Ip Or Mac` | ip=10.21.101.34  |                  |            | # exclusively allot the node based on ip; exit if the node is not free even after 3600 seconds.  |
        
        Considering the robot dictionary, ``mynode`` holds the name of,  has a key `IP`, it can be accessed either as 
        ${${mynode}}[IP] or ${${mynode}.IP}.
        
        ``All Keys will be in upper case. Key names will be similar as in the resource database.``
        
        ``All variables will be test variables (scope of variables will be within the test case).``
        
        Note: It is recommended to use this keyword in test setup. 
        """
        if not self._platform:
            raise RuntimeError("No platform is acquired")

        if not ip and not mac:
            raise ValueError("Both 'ip' and 'mac' can not be none/empty")

        if ip:
            attr_values = _to_str_list(ip)
            attr_name = 'NODE_IP'
        else:
            attr_values = _to_str_list(mac)
            attr_name = 'NODE_MAC'

        if len(attr_values) > 1:
            raise ValueError("Expected only one ip/mac; got a list: %s" % str(attr_values))

        node_values = self._allot_nodes_with_attribute(self._schema, self._platform, self._project, attr_name,
                                                       attr_values, timeout, lock)

        if not node_values:
            raise ValueError("Could not allot nodes")

        num_of_nodes = len(node_values)
        logger.info("Alloted nodes' count: %s" % str(num_of_nodes))

        nodelists = []  # type List[List[str]]
        for node_value in node_values:
            nodelist = []
            for key, value in node_value.items():
                if value == '':
                    value = '${None}'
                nodelist.append("%s=%s" % (str(key), str(value)))
            nodelists.append(nodelist)

        ttl_cnt_of_allotted_nodes = len(self._nodes)
        # node_values type List[DICT{str:str}]
        for node_value in node_values:
            self._nodes.append(node_value['NODE_IP'])
            logger.info("Busy count of Resource {}: {}".format(node_value['NODE_IP'], node_value['BUSY_CHANGE_COUNT']))
        logger.info(self._nodes)

        vars = []
        for i in range(ttl_cnt_of_allotted_nodes, ttl_cnt_of_allotted_nodes + num_of_nodes):
            try:
                BuiltIn().set_test_variable('&{NODE' + str(i + 1) + '}', *nodelists[i - (ttl_cnt_of_allotted_nodes)])
            except Exception:
                BuiltIn().set_suite_variable('&{NODE' + str(i + 1) + '}', *nodelists[i - (ttl_cnt_of_allotted_nodes)])

            vars.append('NODE' + str(i + 1))

        return vars[0] if len(vars) == 1 else vars

    def allot_ap_with_ip_or_mac(self, ip=None, mac=None, timeout='3600', lock=True):
        """It exclusively(default i.e. lock=True) allots a AP based on given ``ip`` or ``mac``.
        
        Default timeout is ``3600`` seconds.
        If a false value to ``lock`` is given AP will become sharable.
        
        This returns the name of the robot dictionary variable.
        
        Example:
        
        | ${myap}= | `Allot AP With Ip Or Mac` | ip=10.21.101.34  | timeout=300      | lock=False | # allot the AP as sharable based o ip; exit if the AP is not free even after 300 seconds.    |
        | ${myap}= | `Allot AP With Ip Or Mac` | ip=10.21.101.34  | timeout=300      |            | # exclusively allot the AP based on ip; exit if the AP is not free even after 300 seconds.   |
        | ${myap}= | `Allot AP With Ip Or Mac` | mac=10:21:101:34 |                  |            | # exclusively allot the AP based on mac; exit if the AP is not free even after 3600 seconds. |
        | ${myap}= | `Allot AP With Ip Or Mac` | ip=10.21.101.34  | mac=10:21:101:35 |            | # exclusively allot the AP based on ip; exit if the AP is not free even after 3600 seconds.  |
        | ${myap}= | `Allot AP With Ip Or Mac` | ip=10.21.101.34  |                  |            | # exclusively allot the AP based on ip; exit if the AP is not free even after 3600 seconds.  |
        
        Considering the robot dictionary, ``myap`` holds the name of,  has a key `IP`, it can be accessed either as 
        ${${myap}}[IP] or ${${myap}.IP}.
        
        ``All Keys will be in upper case. Key names will be similar as in the resource database.``
        
        ``All variables will be test variables (scope of variables will be within the test case).``
        
        Note: It is recommended to use this keyword in test setup. 
        """
        if not self._platform:
            raise RuntimeError("No platform is acquired")

        if not ip and not mac:
            raise ValueError("Both 'ip' and 'mac' can not be none/empty")

        if ip:
            attr_values = _to_str_list(ip)
            attr_name = 'AP_IP'
        else:
            attr_values = _to_str_list(mac)
            attr_name = 'AP_MAC'

        if len(attr_values) > 1:
            raise ValueError("Expected only one ip/mac; got a list: %s" % str(attr_values))

        ap_values = self._allot_aps_with_attribute(self._schema, self._platform, self._project, attr_name, attr_values,
                                                   timeout, lock)

        if not ap_values:
            raise ValueError("Could not allot aps")

        num_of_aps = len(ap_values)
        logger.info("Alloted APs' count: %s" % str(num_of_aps))

        aplists = []  # type List[List[str]]
        for ap_value in ap_values:
            aplist = []
            for key, value in ap_value.items():
                if value == '':
                    value = '${None}'
                aplist.append("%s=%s" % (str(key), str(value)))
            aplists.append(aplist)

        ttl_cnt_of_allotted_aps = len(self._aps)
        # ap_values type List[DICT{str:str}]
        for ap_value in ap_values:
            self._aps.append(ap_value['AP_IP'])
            logger.info("Busy count of Resource {}: {}".format(ap_value['AP_IP'], ap_value['BUSY_CHANGE_COUNT']))
        logger.info(self._aps)

        vars = []
        for i in range(ttl_cnt_of_allotted_aps, ttl_cnt_of_allotted_aps + num_of_aps):
            try:
                BuiltIn().set_test_variable('&{AP' + str(i + 1) + '}', *aplists[i - (ttl_cnt_of_allotted_aps)])
            except Exception:
                BuiltIn().set_sutie_variable('&{AP' + str(i + 1) + '}', *aplists[i - (ttl_cnt_of_allotted_aps)])

            vars.append('AP' + str(i + 1))

        return vars[0] if len(vars) == 1 else vars

    def _allot_nodes(self, schema, platform, project, num_of_nodes, node_type, timeout, lock):
        try:
            elapsed_time = 0.0
            while True:
                if lock:
                    node_values, total_nodes = self.__obj.allot_nodes(schema,
                                                                      platform, project, num_of_nodes, node_type)
                else:
                    node_values, total_nodes = self.__obj.get_nodes(schema,
                                                                    platform, project, num_of_nodes, node_type)

                if node_values:
                    return node_values

                if num_of_nodes > total_nodes:
                    raise ValueError("Platform '%s' has only %s nodes but requested %s nodes" % (
                        platform, str(total_nodes), str(num_of_nodes)))
                time.sleep(0.1)
                elapsed_time += 0.1
                if elapsed_time > float(timeout):
                    raise TimeoutError("Could not allot requested number of nodes after '%s' seconds" % str(timeout))
                if int(elapsed_time * 10) % 50 == 0:
                    print("still waiting for %s nodes after %s" % (str(num_of_nodes), str(int(elapsed_time))))
        except Exception as e:
            logger.error(e)
            raise e
        return

    def _allot_aps(self, schema, platform, project, num_of_aps, timeout, lock):
        try:
            elapsed_time = 0.0
            while True:
                if lock:
                    ap_values, total_aps = self.__obj.allot_aps(schema, platform, project, num_of_aps)
                else:
                    ap_values, total_aps = self.__obj.get_aps(schema, platform, project, num_of_aps)

                if ap_values:
                    return ap_values

                if num_of_aps > total_aps:
                    raise ValueError("Platform '%s' has only %s APs but requested %s APs" % (
                        platform, str(total_aps), str(num_of_aps)))
                time.sleep(0.1)
                elapsed_time += 0.1
                if elapsed_time > float(timeout):
                    raise TimeoutError("Could not allot requested number of APs after '%s' seconds" % str(timeout))
                if int(elapsed_time * 10) % 50 == 0:
                    print("still waiting for %s APs after %s" % (str(num_of_aps), str(int(elapsed_time))))
        except Exception as e:
            logger.error(e)
            raise e
        return

    def _allot_nodes_with_attribute(self, schema, platform, project, attr_name, attr_values, timeout, lock):
        try:
            elapsed_time = 0.0
            while True:
                node_values = \
                    self.__obj.allot_nodes_with_attribute(schema, platform, project, attr_name, attr_values, lock)

                if node_values:
                    return node_values

                time.sleep(0.1)
                elapsed_time += 0.1
                if elapsed_time > float(timeout):
                    raise TimeoutError("Could not allot requested nodes after '%s' seconds" % str(timeout))
                if int(elapsed_time * 10) % 50 == 0:
                    print("still waiting for nodes after %s" % (str(int(elapsed_time))))
        except Exception as e:
            logger.error(e)
            raise e
        return

    def _allot_aps_with_attribute(self, schema, platform, project, attr_name, attr_values, timeout, lock):
        try:
            elapsed_time = 0.0
            while True:
                ap_values = self.__obj.allot_aps_with_attribute(schema, platform, project, attr_name, attr_values, lock)

                if ap_values:
                    return ap_values

                time.sleep(0.1)
                elapsed_time += 0.1
                if elapsed_time > float(timeout):
                    raise TimeoutError("Could not allot requested APs after '%s' seconds" % str(timeout))
                if int(elapsed_time * 10) % 50 == 0:
                    print("still waiting for APs after %s" % (str(int(elapsed_time))))
        except Exception as e:
            logger.error(e)
            raise (e)
        return

    def free_nodes(self, nodes=None):
        """It frees all nodes alloted by keyword `Allot Nodes` by default.
        
        Specific nodes can be provided in ``nodes``. Multiple nodes can be provided separated by comma as python like list.
        
        Example:
        
        | `Free Nodes` | nodes=${NODE1.NODE_IP} | # provided node will be freed and NODE1 variable will be set to None. |
        | `Free Nodes` |                        | # all nodes will be freed and all NODE variables will be set to None. |
        
        Note: It is recommended to use this keyword in test teardown.
        """
        plt_id = self.__obj.get_platform_id(self._schema, self._platform, self._project)
        ttl_allotted_nodes = len(self._nodes)
        ttl_nodes_cnt = int(self.__obj.total_nodes_in_platform(self._schema, plt_id))
        ttl_busy_nodes_cnt = len(self.__obj.get_busy_resources(self._schema, self._platform, self._project, 'node'))

        try:
            if (ttl_allotted_nodes == ttl_nodes_cnt) or (ttl_allotted_nodes == ttl_busy_nodes_cnt):
                self.__obj.free_nodes(self._schema, self._platform, self._project)
                for i in range(ttl_allotted_nodes):
                    try:
                        BuiltIn().set_test_variable('${NODE' + str(i + 1) + '}', '${None}')
                    except Exception:
                        BuiltIn().set_suite_variable('${NODE' + str(i + 1) + '}', '${None}')
                    self._nodes.pop(0)
            elif nodes:
                nodes = _to_str_list(nodes)
                cur_busy_count = self.__obj.free_nodes(self._schema, self._platform, self._project, nodes)
                logger.info("Current Busy Count: {}".format(cur_busy_count))
                for node in nodes:
                    if node in self._nodes:
                        i = self._nodes.index(node)
                        try:
                            BuiltIn().set_test_variable('${NODE' + str(i + 1) + '}', '${None}')
                        except Exception:
                            BuiltIn().set_suite_variable('${NODE' + str(i + 1) + '}', '${None}')
                        self._nodes.pop(i)
            else:
                cur_busy_count = self.__obj.free_nodes(self._schema, self._platform, self._project, self._nodes)
                for values in cur_busy_count:
                    for key, value in values.items():
                        logger.info("Busy count of Resource {}: {}".format(key, value))
                for i in range(ttl_allotted_nodes):
                    try:
                        BuiltIn().set_test_variable('${NODE' + str(i + 1) + '}', '${None}')
                    except Exception:
                        BuiltIn().set_suite_variable('${NODE' + str(i + 1) + '}', '${None}')
                    self._nodes.pop(0)
        except Exception as e:
            logger.error('Free_Nodes has an exception:' + e)
        finally:
            logger.info("Resource remaining after Free Nodes: %d" % len(self._nodes))
            return

    def free_aps(self, aps=None):
        """It frees all APs alloted by keyword `Allot APs` by default.
        
        Specific APs can be provided in ``aps``. Multiple APs can be provided separated by comma or as python like list.
        
        Example:
        
        | `Free APs` | aps=${AP1.AP_IP} | # provided Ap will be freed and AP1 variable will be set to None. |
        | `Free APs` |                  | # all APs will be freed and all AP variables will be set to None. |
        
        Note: It is recommended to use this keyword in test teardown.
        """
        if 'AP' not in self.__obj.table_names(self._schema):
            return

        try:
            if aps:
                aps = _to_str_list(aps)
                cur_busy_count = self.__obj.free_aps(self._schema, self._platform, self._project, aps)

                for values in cur_busy_count:
                    for key, value in values.items():
                        logger.info("Busy count of Resource {}: {}".format(key, value))
                aps_to_remove = []
                for ap in aps:
                    if ap in self._aps:
                        i = self._aps.index(ap)
                        aps_to_remove.append(ap)
                        try:
                            BuiltIn().set_test_variable('${AP' + str(i + 1) + '}', '${None}')
                        except Exception:
                            BuiltIn().set_suite_variable('${AP' + str(i + 1) + '}', '${None}')

                for ap in aps_to_remove:
                    self._aps.remove(ap)
            else:
                cur_busy_count = self.__obj.free_aps(self._schema, self._platform, self._project, self._aps)
                for values in cur_busy_count:
                    for key, value in values.items():
                        logger.info("Busy count of Resource {}: {}".format(key, value))
                for i in range(len(self._aps)):
                    try:
                        BuiltIn().set_test_variable('${AP' + str(i + 1) + '}', '${None}')
                    except Exception:
                        BuiltIn().set_suite_variable('${AP' + str(i + 1) + '}', '${None}')

                self._aps = []
        except Exception as e:
            logger.error('Free_Aps has an exception:' + e)

    def free_bpds(self, bpds=None):
        """It frees all BPDs alloted by keyword `Allot Bpds` by default.

        Specific BPDs can be provided in ``bpds``. Multiple BPDs can be provided separated by comma or as python like list.

        Example:

        | `Free Bpds` | bpds=${BPD1.BPD_MAC} | # provided Ap will be freed and BPD1 variable will be set to None. |
        | `Free Bpds` |                     | # all BPDs will be freed and all BPD variables will be set to None. |

        Note: It is recommended to use this keyword in test teardown.
        """
        if 'BPD' not in self.__obj.table_names(self._schema):
            return

        ttl_busy_bpds_cnt = len(self.__obj.get_busy_resources(self._schema, self._platform, self._project, 'bpd'))
        if ttl_busy_bpds_cnt == 0:
            return

        try:
            if not bpds:
                self.__obj.free_bpds(self._schema, self._platform, self._project)
                for i in range(ttl_busy_bpds_cnt):
                    try:
                        BuiltIn().set_test_variable('${BPD' + str(i + 1) + '}', '${None}')
                    except Exception:
                        BuiltIn().set_suite_variable('${BPD' + str(i + 1) + '}', '${None}')
            else:
                bpds_list = _to_str_list(bpds)
                cur_busy_count = self.__obj.free_bpds(self._schema, self._platform, self._project, bpds_list)
                logger.info("Current Busy Count: {}".format(cur_busy_count))
                all_variables = BuiltIn().get_variables()
                for key in all_variables.keys():
                    if key.find('&{BPD') == 0:
                        bpd_mac_from_variable = BuiltIn()._get_logged_variable(key,all_variables)[1]['BPD_MAC'].strip()
                        if bpd_mac_from_variable in bpds_list:
                            try:
                                BuiltIn().set_test_variable('$'+key[1:], '${None}')
                            except Exception:
                                BuiltIn().set_suite_variable('$'+key[1:], '${None}')
        except Exception as e:
            logger.error('Free_Bpds has an exception:' + e)
        finally:
            logger.info("Resource remaining after Free Bpds: %d" % len(
                self.__obj.get_busy_resources(self._schema, self._platform, self._project, 'bpd')))
            return

    def free_all(self):
        """This frees all resources.
        
        Example:
        
        | `Free All` |
        
        Note: It is recommended to use this keyword in test teardown.
        """
        self.free_nodes()
        self.free_bpds()
        self.free_aps()

    def nodedict_from_db(self):
        """This function will create a nodes dictionary from database. this is added for gen5riva dev team
        return type: dict of dict

        Example:
        | `Nodedict From Db` |
        """
        return self.__obj.nodedict_from_db(self._schema)

    def is_node_busy(self, ip):
        """This  will check the busy status of the given nodes on the database.
        return type: str either 'yes' or 'no'

        Example:
        | `Is Node Busy` |
        """
        return self.__obj.node_busy(self._schema, ip)

    def is_bpd_busy(self, mac):
        """This  will check the busy status of the given bpd on the database.
        return type: str either 'yes' or 'no'

        Example:
        | `Is Bpd Busy` |
        """
        return self.__obj.get_bpd_busy_status(self._schema, mac)

    def is_ap_busy(self, ip):
        """This  will check the busy status of the given AP on the database.
        return type: str either 'yes' or 'no'

        Example:
        | `Is Ap Busy` |
        """
        return self.__obj.ap_busy(self._schema, ip)


kbotdbclient_psql = KBotDBClient_psql
