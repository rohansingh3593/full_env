#!/usr/bin/env python3
import sys, os
import kaizenbot.getuserdetails as getuserdetails

def git_repo(filepath,repo,branch):
    path=filepath
    if not os.path.isdir(path):
        os.mkdir(path)

    uname = os.environ.get('KAIZENBOT_USERNAME')
    pat = os.environ.get('KAIZENBOT_USERPAT')
    alias = getuserdetails.get_user_details_from_name(uname)
    #alias = os.environ.get('BUILD_REQUESTEDFOREMAIL').split('@')[0]
    if not repo:
        repo=os.environ.get('BUILD_REPOSITORY_NAME')
    if not branch:
        branch=os.environ.get('BUILD_SOURCEBRANCH').split('refs/heads/')[1]
    oauth = alias + ':'+ pat
    clone='git clone https://'+oauth+'@dev.azure.com/itron/RnD/_git/' + repo
    pull_cmd = 'sshpass -p  ' + oauth + ' git pull origin ' + branch
    pull_branch = pull_cmd if os.name != 'nt' else 'bash -c "' + pull_cmd + '"'
    os.chdir(path)
    if(not os.path.exists(path+'/'+repo)):
        os.system(clone)
    os.chdir(path+'/'+repo)
    fetch_cmd = 'sshpass -p  '+oauth+' git fetch --all' if os.name != 'nt' else 'bash -c "sshpass -p  '+oauth+' git fetch --all'+'"'
    reset_cmd = 'sshpass -p  '+oauth+' git reset --hard origin/' + branch if os.name != 'nt' else 'bash -c "sshpass -p  '+oauth+' git reset --hard origin/' + branch+'"'
    os.system(fetch_cmd)
    os.system(reset_cmd)
    os.system(pull_branch)

def git_repo_oauth(filepath,repo,branch):
    path=filepath
    if not os.path.isdir(path):
        os.mkdir(path)

    gitauth = ' http.extraheader="AUTHORIZATION: bearer %s "' % (os.environ.get('SYSTEM_ACCESSTOKEN'))
    giturl = 'https://dev.azure.com/itron/RnD/_git'
    if not repo:
        repo=os.environ.get('BUILD_REPOSITORY_NAME')
    if not branch:
        branch=os.environ.get('BUILD_SOURCEBRANCH').split('refs/heads/')[1]
    #clone='git clone https://skulkarn:bj7olv6odjgugo2r4klmpn7ho2ywttqkchxf6bity7bfdgcvqcdq@dev.azure.com/itron/RnD/_git/' + repo
    clone='git clone -c %s %s/%s' % (gitauth, giturl, repo)
    print("Clone: %s" % (clone))
    pull_branch = "git pull -c " + gitauth + " origin " + branch
    os.chdir(path)
    if(not os.path.exists(path+'/'+repo)):
        os.system(clone)
    os.chdir(path+'/'+repo)
    os.system('git fetch --all -c ' + gitauth)
    os.system('git reset -c ' + gitauth + '--hard origin/' + branch)
    os.system(pull_branch)

if __name__ == "__main__":
    if len(sys.argv) <2:
        raise RuntimeError("Please provide file path to save repo from git")
    if len(sys.argv) == 2:
        filepath = sys.argv[1]
        repo=None
        branch=None
    else:
        filepath = sys.argv[1]
        repo=sys.argv[2]
        branch=sys.argv[3]

    if os.environ.get('SYSTEM_ACCESSTOKEN') not in ('',None):
        git_repo_oauth(filepath,repo,branch)
    else:
        git_repo(filepath,repo,branch)
