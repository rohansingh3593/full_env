# coding=utf-8
"""
                         PROPRIETARY RIGHTS NOTICE:

  All rights reserved. This material contains the valuable properties and trade
                                secrets of

                                Itron, Inc.
                            West Union, SC., USA,

  embodying substantial creative efforts and trade secrets, confidential
  information, ideas and expressions. No part of which may be reproduced or
  transmitted in any form or by any means electronic, mechanical, or otherwise.
  Including photocopying and recording or in connection with any information
  storage or retrieval system without the permission in writing from Itron, Inc.

                           Copyright © 2021
                                Itron, Inc.
"""
import os
import sys
import clr

MdapiPath = os.path.dirname(os.path.realpath(__file__))
sys.path.append(MdapiPath)

# Add MDAPI libraries
clr.AddReference("/Mdapi/Itron.Mdapi.Common")
clr.AddReference("/Mdapi/Itron.Mdapi.Tools")
clr.AddReference("/Mdapi/Itron.Mdapi.Cosem")

# Common namespaces...
from Itron.Mdapi.Common import *
from Itron.Mdapi.Tools import *
from Itron.Mdapi.Tools.Cosem.Api import *
from Itron.Mdapi.Tools.Python import *
from Itron.Mdapi.Tools.Security.SecurityTools import *
from Itron.Mdapi.Tools.Devices.BPD.Classes import *
from Itron.Mdapi.Tools.Devices.BPD import *
from Itron.Mdapi.Cosem import *
from Itron.Mdapi.Cosem.Api import *
from Itron.Mdapi.Cosem.Helpers import *
from Itron.Mdapi.Cosem.ItronAccess import *
from Itron.Mdapi.Cosem.DLMS import *
from time import sleep


class MDAPILibrary:
    # Class Attributes:
    dev_tools_exe = {
        'onedut':
            os.path.join(os.environ.get('USERPROFILE'),
                         'Desktop/SMG_Software/EnableSerialOneDUT/bin/Debug/EnableSerialOneDUT.exe').replace("\\", "/"),
    }
    mode_dict = {0: '100S', 1: 'IoT'}
    devtype_dict = {24: 'GasINS', 25: 'WaterINS'}
    cert_types = ['Birth', 'RootCA', 'SubCA', 'AAA', 'NMS', 'Xroot', 'Operator', 'DLCA', 'DL']

    def __init__(self):
        self.BpdDebugPort = None
        self.Api = None
        self.found_what_i_need = False
        self.bpd_log = ""

    def __del__(self):
        self.bpd_DisConnect()

    def _MdapiLogger_GlobToLog(self, Sender, Tag, Message, ):
        """self.bpd_log+= Tag + "=>" + Message
        if 'NCL:DLL CNF SUCCESS' in Message:
            self.found_what_i_need = True
            return"""
        if Tag == 'BpdDbiPort':
            print(Tag + "=>" + Message, end='')

    def _get_param_att(self, ParamId, ParamIndex):
        ParamAtt = CosemFactory.CreateICosemAttDesc(1, "0.128.96.9.36.255", 2)
        SelectWriter = ICosemAttWithSelectWriter(ParamAtt)
        SelectWriter.WriteStruct(2)
        SelectWriter.WriteUInt16(ParamId)
        SelectWriter.WriteUInt16(ParamIndex)
        return SelectWriter.ToICosemAttWithSelect()

    def _set_param_att(self, Data, ParamId, ParamIndex):
        ParamAtt = CosemFactory.CreateICosemAttDesc(1, "0.128.96.9.36.255", 2)
        DataWriter = ICosemAttWithDataWriter(ParamAtt)
        DataWriter.WriteStruct(3)
        DataWriter.WriteUInt16(ParamId)
        DataWriter.WriteUInt16(ParamIndex)
        DataWriter.WriteOctetString(Data)
        return DataWriter.ToICosemAttWithData()

    def _change_mode(self, mode_enum):
        att = ICosemAttWithDataWriter(CosemFactory.CreateICosemAttDesc(9, "0.0.10.0.141.255", 1))
        att.WriteUInt16(mode_enum)  # mode_enum is 1 for ModeSwitch100SToIoT and 2 for ModeSwitchIoTTo100S
        rsp = ItronAccessServiceExt.ItronAccessAct(self.Api, att)

        if rsp.ActionResult != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.ActionResult))
        return rsp.ActionResult

    def _get_cert_att(self, cert_id):
        CertAtt = CosemFactory.CreateICosemAttDesc(8194, "0.128.96.1.8.255", cert_id)
        return ItronAccessServiceExt.ItronAccessGet(self.Api, CertAtt)

    def _erase_certs(self, cert_list=None):
        if not cert_list:
            return -1
        else:
            all_certs = SecToolCerts.CERTS_ALL
            if isinstance(cert_list, str):
                cert_list = cert_list.split(',')
            cert_list = [x.strip() for x in cert_list]
            cert_ids = [all_certs[self.cert_types.index(cert_type)] for cert_type in cert_list]
        return SecToolCerts.EraseCerts(self.Api, cert_ids)

    def _get_event_id(self, event):
        event_id = getattr(S500_EVENTS, event)
        return event_id

    def _get_device_id(self, devType):
        device_id = getattr(MdDeviceType, devType)
        return device_id

    def bpd_run_devTool(self, tool_name, *args):
        """Gives you option to RUN developer tool executables with parameter as number of arguments.

        ``tool_name`` is a short name of each & every executables. For now the only option is ``onedut``
        and can be extended eventually.

        The ``tool_name``, with optionals ``*args``, will append the additional parameters
        require to run the developer tool seamlessly.

        Valid ``tool_name`` are listed below:
        - ``onedut:`` denotes location of EnableSerialOneDUT.exe

        Examples:
        |   =Keyword=     | =too_name= |  =*args[0]=  |  =*args[1]= |
        | Bpd Run DevTool |   onedut   |    001       |      A      |
        | Bpd Run DevTool |   onedut   |    001       |      F      |
        | Bpd Run DevTool |   onedut   |    002       |      B      |
        """
        cmd = self.dev_tools_exe[tool_name.lower()]
        os.chdir(os.path.dirname(cmd))
        arguments = []
        if args:
            arguments = [' ' + val for val in args]
        cmd += ''.join(arguments)
        print(cmd)
        ret_code = os.system('start /B ' + cmd)
        sleep(5)
        if ret_code:
            raise RuntimeError('Error running %s' % self.dev_tools_exe[tool_name.lower()])
        return ret_code

    def bpd_Connect(self, bpdport):
        """Initializes BPD connection to the given COM port ``bpdport``.

        Examples:
        |  =Keyword=  | =bpdport= |
        | Bpd Connect |   COM10   |
        | Bpd Connect |   COM11   |
        | Bpd Connect |  ${port}  |
        """
        self.BpdDebugPort = bpdport
        if self.Api:
            print('Api IS NOT NULL')
            return
        try:
            self.Api = PyBpdPort(self.BpdDebugPort)
            if not self.Api.Logon():
                print("BPD Connected from %s" % self.BpdDebugPort)
            self.Api.GlobToLog += self._MdapiLogger_GlobToLog
            return
        except Exception as e:
            print('PyBpdPort Connection Failed: %s' % e)

    def bpd_DisConnect(self):
        """Initializes BPD connection to the given COM port ``bpdport``.

        Examples:
        |    =Keyword=   |                      =comments=                                |
        | Bpd DisConnect | #dispose BPD connection from COM port acquired by `Bpd Connect`|.

        See also `Bpd Connect`.
        """
        if self.Api:
            self.Api.Dispose()
            self.Api = None
        return

    def bpd_read_ESN(self):
        """Reads Endpoint Serial Number (ESN) from connected BPD.

        Examples:
        |    =Keyword=   |
        |  Bpd Read ESN  |
        """
        if not self.Api:
            return -1
        esnAtt = CosemFactory.CreateICosemAttDesc(1, "0.0.96.1.1.255", 2)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, esnAtt)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        return reader.ReadOctetStringAsAscii()

    def bpd_read_sysInfo(self):
        """Reads System Information from connected BPD.

        Examples:
        |     =Keyword=    |
        | Bpd Read SysInfo |
        """
        info = BpdInfo()
        info.Execute(self.Api)
        return info.ToString()

    def bpd_read_MAC(self):
        """Reads MAC address of the connected BPD.

        Examples:
        |  =Keyword=   |
        | Bpd Read MAC |
        """
        if not self.Api:
            return -1
        macAtt = CosemFactory.CreateICosemAttDesc(1, "128.1.1.1.1.10", 2)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, macAtt)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))
        reader = ICosemDataReader(rsp)
        mac = reader.ReadOctetString()
        # return Utils.ByteArrayToHexString(mac, ":")
        return Utils.ByteArrayToHexString(mac)

    def bpd_write_MAC(self, mac_add):
        """Sets MAC address of connected BPD as ``mac_add``.

        ``mac_add`` is a MAC Address hexadecimal string without any special character in-between.

        Examples:
        |   =Keyword=   |    =mac_add=     |
        | Bpd Write MAC | 00078143b01d01b1 |

        :return: 0 for a Success Write operation.
        """
        if not self.Api:
            return -1
        Data = Utils.HexStringToByteArray(mac_add)
        macAtt = CosemFactory.CreateICosemAttDesc(1, "128.1.1.1.1.10", 2)
        DataWriter = ICosemAttWithDataWriter(macAtt)
        DataWriter.WriteOctetString(Data)
        val = DataWriter.ToICosemAttWithData()
        rsp = ItronAccessServiceExt.ItronAccessSet(self.Api, val)

        if rsp != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp))
        return rsp

    def bpd_getMode(self):
        """Reads the current Mode of the connected BPD.

        Examples:
        |  =Keyword=  |
        | Bpd GetMode |
        """
        if not self.Api:
            return -1
        modeAtt = CosemFactory.CreateICosemAttDesc(1, "0.128.96.5.0.255", 2)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, modeAtt)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        return self.mode_dict[rsp.Data.Data]

    def bpd_SwitchToIOT(self):
        """Sets mode of connected BPD to IOT mode.

        Examples:
        |    =Keyword=    |
        | Bpd SwitchToIOT |

        :return: 0 for a Success SwitchMode.
        """
        return self._change_mode(1)

    def bpd_SwitchTo100S(self):
        """Sets mode of connected BPD to 100S mode.

        Examples:
        |    =Keyword=     |
        | Bpd SwitchTo100S |

        :return: 0 for a Success SwitchMode.
        """
        return self._change_mode(2)

    def bpd_reboot(self):
        """Initializes Soft Reboot to the connected BPD and it will not wait until BPD comes up but returns immediately.

        Examples:
        | =Keyword=  |
        | Bpd Reboot |

        :return: 0 for Reboot initialize.
        """
        ResetType = 0  # SoftReset
        if not self.Api:
            return -1
        att = ICosemAttWithDataWriter(CosemFactory.CreateICosemAttDesc(1, "0.128.96.9.30.255", -1))
        att.WriteUInt8(ResetType)
        rsp = ItronAccessServiceExt.ItronAccessAct(self.Api, att)

        if rsp.ActionResult != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.ActionResult))
        return rsp.ActionResult

    '''def _bpd_reboot_and_wait(self):
        self.found_what_i_need = False
        self.bpd_reboot()
        while not self.found_what_i_need:
            sleep(1)'''

    def bpd_read_SSID(self):
        """Reads SSID of connected BPD.

        Examples:
        |   =Keyword=   |
        | Bpd Read SSID |
        """
        if not self.Api:
            return -1
        MAC_BACT_SSID_Att = self._get_param_att(12296, 0)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, MAC_BACT_SSID_Att)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        reader.ReadStruct()
        reader.ReadUInt16()
        reader.ReadUInt16()
        return Utils.ByteArrayToHexString(reader.ReadOctetString())

    def bpd_write_SSID(self, hex_string):
        """Sets SSID of connected BPD as per given in ``hex_string``.

        ``hex_string`` is a SSID hexadecimal string and it should little-endian format.

        Examples:
        |    =Keyword=   | =hex_string= |
        | Bpd Write SSID |    b8fa      |

        :return: 0 for a Success Write operation.
        """
        if not self.Api:
            return -1
        data = Utils.HexStringToByteArray(hex_string)
        MAC_BACT_SSID_Att = self._set_param_att(data, 12296, 0)
        rsp = ItronAccessServiceExt.ItronAccessSet(self.Api, MAC_BACT_SSID_Att)

        if rsp != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp))
        return rsp

    def bpd_get_deviceType(self):
        """Reads DeviceType of connected BPD.
        Mostly, GasINS or WaterINS will be the return value

        Examples:
        |      =Keyword=     |
        | Bpd Get DeviceType |

        :return: GasINS or WaterINS or NotFound.
        """
        if not self.Api:
            return -1
        devtypeAtt = CosemFactory.CreateICosemAttDesc(1, "0.0.96.1.128.255", 2)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, devtypeAtt)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        val = reader.ReadUInt8()
        res = int(str(round((val + 5) / 4)), 16)
        return self.devtype_dict.get(res, 'NotFound')

    def bpd_read_phyId(self):
        """Reads PhyID of connected BPD.

        Examples:
        |    =Keyword=   |
        | Bpd Read PhyId |
        """
        if not self.Api:
            return -1
        DLL_PIB_ID_llsSfd_Att = self._get_param_att(12734, 0)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, DLL_PIB_ID_llsSfd_Att)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        reader.ReadStruct()
        reader.ReadUInt16()
        reader.ReadUInt16()
        return Utils.ByteArrayToHexString(reader.ReadOctetString())

    def bpd_write_phyId(self, hex_string):
        """Sets PhyID of connected BPD as per given in ``hex_string``.

        ``hex_string`` is a PhyID hexadecimal string of length 8.

        Examples:
        |     =Keyword=   | =hex_string= |
        | Bpd Write PhyId |   58130000   |

        :return: 0 for a Success Write operation.
        """
        if not self.Api:
            return -1
        data = Utils.HexStringToByteArray(hex_string)
        DLL_PIB_ID_llsSfd_Att = self._set_param_att(data, 12734, 0)
        rsp = ItronAccessServiceExt.ItronAccessSet(self.Api, DLL_PIB_ID_llsSfd_Att)

        if rsp != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp))
        return rsp

    def bpd_get_fwVersion_list(self):
        """Reads Firmware Version list of connected BPD.

        Examples:
        |        =Keyword=       |
        | Bpd Get FwVersion List |
        """
        if not self.Api:
            return -1
        fwAtt = CosemFactory.CreateICosemAttDesc(1, "0.1.0.2.1.255", 2)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, fwAtt)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        fw_list_len = reader.ReadArray()
        ver_list = []
        for index in range(fw_list_len):
            reader.ReadStruct()
            ver_type = reader.ReadEnum()
            ver_hex = Utils.ByteArrayToHexString(reader.ReadOctetString(), 'x')
            ver = '.'.join(list(map(lambda x: str(int(x, 16)), ver_hex.split('x'))))
            ver_list.append((ver_type, ver))
        return ver_list

    def bpd_get_fwVersion(self, ver_type):
        """Reads Firmware Version of connected BPD as per the``ver_type``.

        ``ver_type`` is a version_type string.

        Examples:
        |     =Keyword=     | =ver_type= |
        | Bpd Get FwVersion |    LRFW    |
        | Bpd Get FwVersion |    LRFW2   |
        | Bpd Get FwVersion |     STM    |
        | Bpd Get FwVersion |     MSP    |
        """
        version_list = self.bpd_get_fwVersion_list()
        if ver_type.upper() == 'STM':
            return version_list[1][1]
        elif ver_type.upper() == 'LRFW2' or ver_type.upper() == 'MSP':
            return version_list[2][1]
        else:
            return version_list[0][1]

    def bpd_read_cert(self, cert_type):
        """Reads Certificate from the connected BPD as per the``cert_type``.

        ``cert_type`` is a type of cert to read.

        Examples:
        |   =Keyword=   | =cert_type= |
        | Bpd Read Cert |    Birth    |
        | Bpd Read Cert |   RootCA    |
        | Bpd Read Cert |    SubCA    |
        """
        bpdCertData = BpdCertData()
        all_certs = SecToolCerts.CERTS_ALL
        SlotNumber = all_certs[self.cert_types.index(cert_type)]
        rsp = self._get_cert_att(cert_id=SlotNumber)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        reader.ReadStruct()
        bpdCertData.CertType = reader.ReadUInt8()
        bpdCertData.PubCert = reader.ReadOctetString()
        bpdCertData.PriKey = reader.ReadOctetString()

        return bpdCertData

    def bpd_show_cert(self, cert_dir, cert_type):
        """Shows available Certificate on ``cert_dir`` for the connected BPD as per the``cert_type``.

        ``cert_type`` is a type of cert to show.

        Examples:
        |   =Keyword=   | =cert_type= |
        | Bpd Show Cert |    Birth    |
        | Bpd Show Cert |    RootCA   |
        | Bpd Show Cert |    SubCA    |
        """
        all_certs = SecToolCerts.CERTS_ALL
        cert_id = all_certs[self.cert_types.index(cert_type)]

        SecTool = SecToolCerts(cert_dir)
        Device = EpIdAndDeviceType()
        Device.EpId = self.bpd_read_ESN().split('.')[-1]
        Device.DeviceType = self._get_device_id(self.bpd_get_deviceType())

        return SecTool.FindCertFile(cert_id, Device)

    def bpd_load_certs(self, cert_dir, cert_list=None):
        """Loads all the Certificates requested at ``cert_list`` from ``cert_dir`` to the connected BPD.

        ``cert_dir`` is a parent directory of the security certificates.
        ``cert_list`` is a type of certificates to be loaded into the BPD. Either comma separated ``cert_type`` string
        or a list contains list of ``cert_type`` are accepted.

        Examples:
        |    =Keyword=   |     =cert_dir=    |         =cert_list=        |                                     |
        | Bpd Load Certs | ${cert_directory} |    'Birth,RootCA,SubCA'    |                                     |
        | Bpd Load Certs | ${cert_directory} |    'Birth,RootCA,SubCA'    | #comma separated cert_type accepted |
        | Bpd Load Certs | ${cert_directory} | ['Birth','RootCA','SubCA'] | #list of cert_type accepted         |
        """
        Device = EpIdAndDeviceType()
        Device.EpId = self.bpd_read_ESN().split('.')[-1]
        Device.DeviceType = self._get_device_id(self.bpd_get_deviceType())

        if cert_list:
            all_certs = SecToolCerts.CERTS_ALL
            if isinstance(cert_list, str):
                cert_list = cert_list.split(',')
            cert_list = [x.strip() for x in cert_list]
            cert_ids = [all_certs[self.cert_types.index(cert_type)] for cert_type in cert_list]
            res = SecToolCerts.LoadCerts(self.Api, cert_dir, Device, cert_ids)
        else:
            # res = SecToolCerts.LoadCerts(self.Api, cert_dir, Device)
            res = "No Certificate Loaded"
        return res

    def bpd_verify_certs(self, cert_dir, cert_type):
        """Compares BPD certificate with available Certificate on ``cert_dir``
        for the connected BPD as per the``cert_type``.

        ``cert_dir`` is a parent directory of the security certificates.
        ``cert_type`` is a type of cert to validate.

        Examples:
        |     =Keyword=   |     =cert_dir=    |  =cert_type= |
        | Bpd Verify Cert | ${cert_directory} |    'Birth'   |
        | Bpd Verify Cert | ${cert_directory} |   'RootCA'   |
        | Bpd Verify Cert | ${cert_directory} |    'SubCA'   |
        """
        SecTool = SecToolCerts(cert_dir)
        Device = EpIdAndDeviceType()
        Device.EpId = self.bpd_read_ESN().split('.')[-1]
        Device.DeviceType = self._get_device_id(self.bpd_get_deviceType())

        all_certs = SecTool.CERTS_ALL
        cert_id = all_certs[self.cert_types.index(cert_type)]

        return 'Matched' if SecTool.Verify(self.Api, cert_dir, Device, cert_id) else 'Mismatch'

    def _bpd_erase_all_certs(self):
        return self._erase_certs('Birth,RootCA,SubCA,AAA,DLCA,DL')

    def bpd_erase_cert(self, cert_type):
        """Erase the given ``cert_type`` Certificate from the connected BPD.

        Warning: Erasing certificates from BPD may cause issues.  Think twice before using this keyword.

        ``cert_dir`` is a parent directory of the security certificates.
        ``cert_list`` is a type of certificates to be loaded into the BPD. Either comma separated ``cert_type`` string
        or a list contains list of ``cert_type`` are accepted.

        Examples:
        |     =Keyword=  | =cert_type= |
        | Bpd Erase Cert |   'Birth'   |
        | Bpd Erase Cert |   'RootCA'  |
        | Bpd Erase Cert |   'SubCA'   |

        Warning: Erasing certificates from BPD may cause issues.  Think twice before using this keyword.
        """
        return self._erase_certs(cert_type)

    def bpd_raise_alarm_event(self, eventType):
        """Raises Event according to the given eventType.

        ``eventType`` is a type of event you want to raise for.

        Few valid ``eventType`` are listed below:
        InterDigit, RegisterError, InvalidRead, TiltDetected, MagneticDetected, Endpoint_LowBattery,
        ConsumerLeakDetected, ConsumerLeakEnd, ReverseFlowDetected, ReverseFlowEnd, LeakSensorOk, LeakSensorNoComms,
        LeakSensorDetached, ValveOK, ValveNoComms, TiltDebounceParameterChanged, PulseMismatch, CutCableDetected,
        CutCableEnd, HighFlowDetected, and many more.

        For full list of ``eventType`` please do check ``S500_EVENTS`` [namespace Itron.Mdapi.Tools.Devices.BPD]

        Examples:
        |       =Keyword=       |      =eventType=    |
        | Bpd Raise Alarm Event |   MagneticDetected  |
        | Bpd Raise Alarm Event | Endpoint_LowBattery |

        :return: 0 for a Success Alarm Push
        """
        if not self.Api:
            return -1
        eventId = self._get_event_id(eventType)
        data = Utils.HexStringToByteArray('0')
        devAtt = ICosemAttWithDataWriter(CosemFactory.CreateICosemAttDesc(1, "128.1.1.1.1.10", 5))
        devAtt.WriteStruct(2)
        devAtt.WriteUInt16(eventId)
        devAtt.WriteOctetString(data)
        rsp = ItronAccessServiceExt.ItronAccessAct(self.Api, devAtt.ToICosemAttWithData())

        if rsp.ActionResult != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.ActionResult))
        return rsp.ActionResult

    def bpd_get_configTag(self):
        """Reads config tag value which was loaded to the BPD from the config.xml file

        Examples:
        |    =Keyword=      |
        | Bpd Get ConfigTag |

        :return: tag_value string
        """
        # writer = ICosemAttWithDataWriter(CosemFactory.CreateICosemAttDesc(1, "0.128.96.0.0.255", -1))
        # writer.WriteVisibleString(Utils.ToUnixTimestamp2000().ToString())
        # IASetPrint(writer.ToICosemAttWithData())
        tagAtt = CosemFactory.CreateICosemAttDesc(1, "0.128.96.0.0.255", 2)
        rsp = ItronAccessServiceExt.ItronAccessGet(self.Api, tagAtt)

        if rsp.Result != DataAccessResults.OK:
            raise Exception("DataAccessResults is " + str(rsp.Result))

        reader = ICosemDataReader(rsp)
        return reader.ReadVisibleStringAsString()


mdapilibrary = MDAPILibrary