#!/usr/bin/env python

import re
import sys
import os
import atexit
import subprocess
from os.path import abspath, dirname, join
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.egg_info import egg_info
from kaizenbot.Misc.version import VERSION

PKGVERSION = VERSION
REQUIREMENTS = ['wheel']
REQUIREMENTS.append('KaizenBot-Linux==2.2')
CLASSIFIERS = '''
Development Status :: 5 - Production/Stable
License :: Itron
Intended Audience :: Automation Engineers
Operating System :: OS Independent
Programming Language :: Python
Topic :: Software Development :: Testing
Framework :: Robot Framework
Framework :: Robot Framework :: Library
'''.strip().splitlines()

def post_install():
    pkgtemp=os.path.dirname(sys.argv[0]) +"/build/lib/kaizenbot/Misc/"
    cmdname="post-install.sh"
    tmpcmd=pkgtemp+cmdname
    print("In post install code\n")
    os.system(tmpcmd)
        
class KaizenBotPostInstall(egg_info):
    """Post install code will run here"""
    def run(self):
        if os.name == 'posix':
            if sys.argv[1] != 'sdist':
                atexit.register(post_install)
        egg_info.run(self)
setup(
	name='KaizenBot-CommonLibrary',## this will be changed based on library name
	version=PKGVERSION,
	description='KaizenBot Common Library',
	author_email='Sirajdeen.Hameedkamsa@itron.com,Rajasekhar.Inguva@itron.com',
	url='http://kaizenbot.itron.com/html/index.html',
	keywords='KaizenBot Common Library',
	platforms='any',
	classifiers=CLASSIFIERS,
    cmdclass={'egg_info':KaizenBotPostInstall},
	install_requires=REQUIREMENTS,
    include_package_data=True,
	python_requires='>=3.6',
	packages=['kaizenbot','kaizenbot.Misc']## this will be changed based on library name
)
